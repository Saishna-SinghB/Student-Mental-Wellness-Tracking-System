
// WELLNESSHUB ADMIN DASHBOARD
// Updated charts and visible colours

const DASHBOARD_API =
    'api/demoAPI.php?action=admin_dashboard_summary';

// BRIGHT MOOD CHART COLOURS

const MOOD_COLORS = {
    Grateful: '#5FF1AF',
    Calm: '#70D9FF',
    Hopeful: '#C9A5FF',
    Anxious: '#FFD17A',
    Frustrated: '#FF8FA5'
};

const OTHER_MOOD_COLOR = '#F0B9FF';

const SVG_NS = 'http://www.w3.org/2000/svg';

// LOAD DASHBOARD

document.addEventListener(
    'DOMContentLoaded',
    loadAdminDashboard
);

async function loadAdminDashboard() {

    try {

        const response = await fetch(DASHBOARD_API, {
            method: 'GET',
            credentials: 'same-origin',
            cache: 'no-store',
            headers: {
                Accept: 'application/json'
            }
        });

        if (!response.ok) {
            throw new Error(
                `Dashboard request failed (HTTP ${response.status})`
            );
        }

        const result = await response.json();

        if (
            !result ||
            result.success !== true ||
            !result.data
        ) {
            throw new Error(
                result?.message ||
                'Dashboard data is unavailable.'
            );
        }

        const data = result.data;
        const kpis = data.kpis || {};

        // UPDATE DASHBOARD STATISTICS

        setKpi(
            'kpiTotalUsers',
            kpis.total_users
        );

        setKpi(
            'kpiActiveStudents',
            kpis.active_students
        );

        setKpi(
            'kpiCounsellors',
            kpis.counsellor_accounts
        );

        setKpi(
            'kpiSessions',
            kpis.sessions_this_month
        );

        // USER GROWTH CHART

        renderGrowthChart(
            Array.isArray(data.user_growth)
                ? data.user_growth
                : []
        );

        // JOURNAL MOOD BREAKDOWN

        renderEmotionBreakdown(
            Array.isArray(data.emotion_breakdown)
                ? data.emotion_breakdown
                : []
        );

    } catch (error) {

        console.error(
            'Unable to load WellnessHub admin dashboard:',
            error
        );

        renderGrowthMessage(
            'Could not load growth data.'
        );

        showMoodMessage(
            'Could not load journal mood data. Check your API connection.'
        );
    }
}

// UPDATE STATISTICS

function setKpi(id, value) {

    const element = document.getElementById(id);

    if (!element) return;

    const count = Number(value);

    element.textContent =
        value !== undefined &&
        value !== null &&
        Number.isFinite(count)
            ? count.toLocaleString()
            : '–';
}

// CREATE SVG ELEMENTS

function svgElement(
    name,
    attributes = {},
    value = null
) {

    const element = document.createElementNS(
        SVG_NS,
        name
    );

    Object.entries(attributes).forEach(
        ([key, attributeValue]) => {

            element.setAttribute(
                key,
                String(attributeValue)
            );

        }
    );

    if (value !== null) {
        element.textContent = value;
    }

    return element;
}

// CLEAR USER GROWTH CHART

function clearGrowthChart() {

    [
        'growthLines',
        'growthDots',
        'growthLabels'
    ].forEach(id => {

        document.getElementById(id)?.replaceChildren();

    });

}

// DISPLAY GROWTH ERROR MESSAGE

function renderGrowthMessage(message) {

    clearGrowthChart();

    document.getElementById('growthLabels')
        ?.appendChild(

            svgElement(
                'text',
                {
                    x: 210,
                    y: 90,
                    class: 'chart-message'
                },
                message
            )

        );
}

// DRAW USER GROWTH CHART

function renderGrowthChart(rows) {

    clearGrowthChart();

    if (!rows.length) {

        renderGrowthMessage(
            'No signup data available yet.'
        );

        return;
    }

    // GET USER COUNTS

    const counts = rows.map(row => {

        const count = Number(
            row.cnt ?? row.count ?? 0
        );

        return Number.isFinite(count)
            ? Math.max(0, count)
            : 0;

    });

    const maxCount = Math.max(
        1,
        ...counts
    );

    // CALCULATE CHART POSITIONS

    const xFor = i => {

        return rows.length > 1
            ? 30 + i * (360 / (rows.length - 1))
            : 210;

    };

    const yFor = count => {

        return 145 - (count / maxCount) * 110;

    };

    const points = counts.map((count, i) => ({
        x: xFor(i),
        y: yFor(count),
        count
    }));

    const lines =
        document.getElementById('growthLines');

    const dots =
        document.getElementById('growthDots');

    const labels =
        document.getElementById('growthLabels');

    if (!lines || !dots || !labels) return;

    // DRAW PINK LINES

    if (points.length > 1) {

        const path = points.map((point, i) => {

            return (
                (i === 0 ? 'M' : 'L') +
                point.x.toFixed(2) +
                ' ' +
                point.y.toFixed(2)
            );

        }).join(' ');

        lines.appendChild(

            svgElement(
                'path',
                {
                    class: 'chart-line',
                    d: path
                }
            )

        );
    }

    // DRAW DOTS AND LABELS

    points.forEach((point, i) => {

        const monthLabel = String(
            rows[i].label ??
            rows[i].month ??
            ''
        );

        // DOT

        const dot = svgElement(
            'circle',
            {
                class: 'chart-dot',
                cx: point.x,
                cy: point.y,
                r: 5
            }
        );

        // TOOLTIP

        dot.appendChild(

            svgElement(
                'title',
                {},
                `${monthLabel}: ${point.count} new users`
            )

        );

        dots.appendChild(dot);

        // DISPLAY NUMBER ABOVE DOT

        labels.appendChild(

            svgElement(
                'text',
                {
                    class: 'chart-value-label',
                    x: point.x,
                    y: Math.max(
                        16,
                        point.y - 13
                    )
                },
                String(point.count)
            )

        );

        // DISPLAY MONTH BELOW GRAPH

        labels.appendChild(

            svgElement(
                'text',
                {
                    class: 'chart-label',
                    x: point.x,
                    y: 173
                },
                monthLabel
            )

        );

    });
}

// NORMALIZE MOOD NAMES

function normalizeMoodName(value) {

    const name = String(
        value ?? ''
    ).trim();

    return Object.keys(MOOD_COLORS).find(
        known =>
            known.toLowerCase() ===
            name.toLowerCase()
    ) || name || 'Other';

}

// READ DATA FROM API

function valueIfProvided(row, keys) {

    for (const key of keys) {

        if (
            row[key] !== undefined &&
            row[key] !== null &&
            row[key] !== ''
        ) {

            return Number(row[key]);

        }

    }

    return null;
}

// CALCULATE PERCENTAGES THAT TOTAL 100%

function percentagesSummingTo100(weights) {

    const total = weights.reduce(
        (sum, value) => sum + value,
        0
    );

    if (total <= 0) {
        return weights.map(() => 0);
    }

    // CALCULATE EXACT PERCENTAGES

    const exact = weights.map(
        value => value * 100 / total
    );

    // ROUND DOWN FIRST

    const rounded = exact.map(Math.floor);

    let remaining = 100 - rounded.reduce(
        (sum, value) => sum + value,
        0
    );

    // DISTRIBUTE REMAINING PERCENTAGE POINTS

    const priority = exact.map(
        (value, index) => ({
            index,
            fraction: value - Math.floor(value)
        })
    ).sort(
        (a, b) =>
            b.fraction - a.fraction ||
            a.index - b.index
    );

    for (let i = 0; i < remaining; i++) {

        rounded[priority[i].index]++;

    }

    return rounded;
}

// DISPLAY MOOD ERROR OR EMPTY MESSAGE

function showMoodMessage(message) {

    const legend =
        document.getElementById('concernsLegend');

    const donut =
        document.getElementById('concernsDonut');

    if (legend) {

        const item = document.createElement('li');

        item.className = 'chart-empty';

        item.textContent = message;

        legend.replaceChildren(item);
    }

    if (donut) {

        donut.style.background = '#735389';

        donut.setAttribute(
            'aria-label',
            message
        );

        const center = document.createElement('span');

        center.className = 'donut-center';

        center.textContent = 'No data';

        donut.replaceChildren(center);
    }
}

// JOURNAL MOOD BREAKDOWN CHART

function renderEmotionBreakdown(rows) {

    const legend =
        document.getElementById('concernsLegend');

    const donut =
        document.getElementById('concernsDonut');

    if (!legend || !donut) return;

    // CHECK IF JOURNAL DATA EXISTS

    if (!rows.length) {

        showMoodMessage(
            'No journal entries with a mood tag yet.'
        );

        return;
    }

    const validRows = rows.filter(
        row => row && typeof row === 'object'
    );

    // USE ACTUAL MOOD COUNTS WHEN AVAILABLE

    const useCounts =
        validRows.length > 0 &&
        validRows.every(row =>

            valueIfProvided(
                row,
                ['cnt', 'count', 'total']
            ) !== null

        );

    // GROUP MOODS

    const grouped = new Map();

    validRows.forEach(row => {

        const name = normalizeMoodName(
            row.emotion ??
            row.mood ??
            row.label
        );

        const raw = useCounts

            ? valueIfProvided(
                row,
                ['cnt', 'count', 'total']
            )

            : valueIfProvided(
                row,
                ['percentage', 'percent']
            );

        const weight = Number.isFinite(raw)
            ? Math.max(0, raw)
            : 0;

        grouped.set(
            name,
            (grouped.get(name) || 0) + weight
        );

    });

    // REMOVE EMPTY MOODS

    const moods = Array.from(
        grouped,
        ([name, weight]) => ({
            name,
            weight
        })
    ).filter(
        mood => mood.weight > 0
    );

    const totalWeight = moods.reduce(
        (sum, mood) => sum + mood.weight,
        0
    );

    if (!totalWeight) {

        showMoodMessage(
            'No journal mood data available yet.'
        );

        return;
    }

    // CALCULATE ACCURATE PERCENTAGES

    const rounded = percentagesSummingTo100(
        moods.map(mood => mood.weight)
    );

    const stops = [];

    let progress = 0;

    const legendItems = [];

    // BUILD DONUT AND LEGEND

    moods.forEach((mood, i) => {

        const color =
            MOOD_COLORS[mood.name] ||
            OTHER_MOOD_COLOR;

        const start = progress;

        progress +=
            mood.weight * 100 / totalWeight;

        const end =
            i === moods.length - 1
                ? 100
                : progress;

        // DONUT SEGMENT

        stops.push(
            `${color} ${start.toFixed(5)}% ${end.toFixed(5)}%`
        );

        // LEGEND ITEM

        const item = document.createElement('li');

        // COLOURED CIRCLE

        const swatch = document.createElement('span');

        swatch.className = 'mood-swatch';

        swatch.style.backgroundColor = color;

        swatch.setAttribute(
            'aria-hidden',
            'true'
        );

        // MOOD NAME AND PERCENTAGE

        const label = document.createElement('span');

        label.textContent =
            `${mood.name}: ${rounded[i]}%`;

        item.append(
            swatch,
            label
        );

        legendItems.push(item);

    });

    // APPLY COLOURS TO THE DONUT

    donut.style.background =
        `conic-gradient(${stops.join(', ')})`;

    // ACCESSIBLE CHART DESCRIPTION

    donut.setAttribute(
        'aria-label',
        moods.map(
            (mood, i) =>
                `${mood.name} ${rounded[i]} percent`
        ).join(', ')
    );

    // DISPLAY TOTAL ENTRIES INSIDE DONUT

    const center = document.createElement('span');

    center.className = 'donut-center';

    center.textContent = useCounts
        ? `${totalWeight.toLocaleString()} entries`
        : 'Mood mix';

    donut.replaceChildren(center);

    // UPDATE LEGEND

    legend.replaceChildren(...legendItems);

}
