
<?php
require_once __DIR__ . '/admin-auth.php';

/* ======================================
   ADMIN PROFILE DETAILS
====================================== */

$adminFullName = trim(
    (string) ($_SESSION['full_name'] ?? 'Administrator')
);

$adminInitial = strtoupper(
    substr($adminFullName ?: 'A', 0, 1)
);

function profileSafe($value): string {
    return htmlspecialchars(
        (string) $value,
        ENT_QUOTES | ENT_SUBSTITUTE,
        'UTF-8'
    );
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>My Profile — WellnessHub Admin</title>

    <link rel="stylesheet" href="css/style.css">

    <style>

        /* ======================================
           GENERAL PAGE DESIGN
        ====================================== */

        body.whp-page {
            margin: 0;
            min-height: 100vh;
            background: #241031;
            color: #ffffff;
            font-family: 'Poppins', Arial, sans-serif;
        }

        .whp-page * {
            box-sizing: border-box;
        }

        .whp-page [hidden] {
            display: none !important;
        }

        /* ======================================
           MAIN PAGE LAYOUT
        ====================================== */

        .whp-page .whp-shell {
            display: grid;
            grid-template-columns: 290px minmax(0, 1fr);
            min-height: 100vh;
            width: 100%;
        }

        /* ======================================
           PURPLE ADMIN SIDEBAR
        ====================================== */

        .whp-page .whp-sidebar {
            background: #301545;
            border-right: 1px solid #4b2862;
            padding: 24px 18px;
        }

        .whp-page .whp-logo {
            display: flex;
            align-items: center;
            gap: 11px;

            margin: 0 0 30px 10px;

            color: #ffffff;
            font-size: 19px;
            font-weight: 800;
            text-decoration: none;
        }

        .whp-page .whp-logo-mark {
            display: grid;
            place-items: center;

            width: 35px;
            height: 35px;

            background: #542579;
            color: #ffffff;

            border-radius: 11px;
            font-size: 21px;
        }

        /* ======================================
           SIDEBAR NAVIGATION
        ====================================== */

        .whp-page .whp-nav {
            display: flex;
            flex-direction: column;
            gap: 7px;
        }

        .whp-page .whp-nav a {
            display: flex;
            align-items: center;
            gap: 13px;

            padding: 13px 15px;
            border-radius: 12px;

            color: #e8d6f5;
            text-decoration: none;

            font-size: 15px;
            font-weight: 700;
            line-height: 1.4;

            transition: background 0.2s ease;
        }

        .whp-page .whp-nav a:hover {
            background: #4e2676;
            color: #ffffff;
        }

        .whp-page .whp-nav a.active {
            background: #703bd3;
            color: #ffffff;
        }

        .whp-page .whp-nav-icon {
            display: inline-block;
            min-width: 24px;
            font-size: 19px;
            text-align: center;
        }

        /* ======================================
           MAIN CONTENT AREA
        ====================================== */

        .whp-page .whp-main {
            display: flex;
            flex-direction: column;

            min-width: 0;
            min-height: 100vh;

            padding: 28px 35px;

            background: #241031;
        }

        /* ======================================
           PAGE HEADER
        ====================================== */

        .whp-page .whp-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 20px;

            width: 100%;
            margin-bottom: 12px;
        }

        .whp-page .whp-header h1 {
            margin: 0;

            color: #ffffff;
            font-size: 32px;
            font-weight: 800;
            line-height: 1.3;
        }

        /* ======================================
           HEADER AVATAR
        ====================================== */

        .whp-page .whp-top-avatar {
            display: grid;
            place-items: center;

            width: 45px;
            height: 45px;
            flex-shrink: 0;

            border-radius: 50%;
            overflow: hidden;

            background: #7044d7;
            color: #ffffff;

            font-size: 19px;
            font-weight: 800;
            text-decoration: none;
            cursor: pointer;
        }

        .whp-page .whp-top-avatar:hover {
            box-shadow:
                0 0 0 4px rgba(171, 119, 255, 0.3);
        }

        .whp-page .whp-top-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        /* ======================================
           CENTER PROFILE CARD ON PAGE
        ====================================== */

        .whp-page .whp-center {
            display: flex;
            justify-content: center;
            align-items: center;

            flex: 1;
            width: 100%;

            padding: 24px 0 40px;
        }

        /* ======================================
           WHITE PROFILE CARD
        ====================================== */

        .whp-page .whp-card {
            width: min(630px, 100%);

            padding: 38px 32px 43px;

            background: #ffffff;
            color: #1b2331;

            border: 1px solid #57336e;
            border-radius: 25px;

            box-shadow:
                0 15px 40px rgba(0, 0, 0, 0.22);
        }

        /* ======================================
           PROFILE PICTURE
        ====================================== */

        .whp-page .whp-picture-area {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
        }

        .whp-page .whp-picture {
            display: grid;
            place-items: center;

            width: 145px;
            height: 145px;

            margin-bottom: 19px;

            border-radius: 50%;
            overflow: hidden;

            background: #7044d7;
            color: #ffffff;

            font-size: 58px;
            font-weight: 800;

            box-shadow:
                0 7px 22px rgba(112, 68, 215, 0.18);
        }

        .whp-page .whp-picture img {
            display: block;
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        /* ======================================
           UPLOAD AND REMOVE BUTTONS
        ====================================== */

        .whp-page .whp-buttons {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-wrap: wrap;
            gap: 10px;
        }

        .whp-page .whp-btn {
            padding: 11px 18px;

            background: #7044d7;
            border: 1px solid #7044d7;
            border-radius: 11px;

            color: #ffffff;

            font: inherit;
            font-size: 14px;
            font-weight: 800;

            cursor: pointer;

            transition:
                background 0.2s ease,
                transform 0.2s ease;
        }

        .whp-page .whp-btn:hover {
            background: #8555e6;
            transform: translateY(-1px);
        }

        .whp-page .whp-btn:disabled {
            opacity: 0.6;
            cursor: wait;
            transform: none;
        }

        .whp-page .whp-btn-remove {
            background: #fff1f4;
            color: #9c3446;
            border-color: #f0d8dc;
        }

        .whp-page .whp-btn-remove:hover {
            background: #ffe3ea;
        }

        /* ======================================
           PROFILE FEEDBACK MESSAGE
        ====================================== */

        .whp-page .whp-feedback {
            width: 100%;
            max-width: 470px;

            margin-top: 18px;
            padding: 12px 15px;

            background: #f2eafd;
            color: #512794;

            border-radius: 11px;

            font-size: 13px;
            line-height: 1.5;
        }

        .whp-page .whp-feedback.success {
            background: #e9f8ed;
            color: #276b44;
        }

        .whp-page .whp-feedback.error {
            background: #fff0f2;
            color: #a52c48;
        }

        /* ======================================
           ACCOUNT DETAILS
        ====================================== */

        .whp-page .whp-details {
            display: flex;
            flex-direction: column;

            gap: 22px;
            margin-top: 55px;
        }

        .whp-page .whp-detail-label {
            display: block;
            margin-bottom: 6px;

            color: #777585;

            font-size: 13px;
            font-weight: 800;

            letter-spacing: 0.04em;
            text-transform: uppercase;
        }

        .whp-page .whp-detail-value {
            color: #1b2331;

            font-size: 18px;
            font-weight: 750;

            line-height: 1.5;
            overflow-wrap: anywhere;
        }

        .whp-page .whp-role {
            display: inline-block;

            padding: 7px 13px;

            background: #f1e8ff;
            color: #512794;

            border-radius: 20px;

            font-size: 14px;
            font-weight: 800;
        }

        /* ======================================
           TABLET
        ====================================== */

        @media (max-width: 920px) {

            .whp-page .whp-shell {
                grid-template-columns:
                    225px minmax(0, 1fr);
            }

            .whp-page .whp-sidebar {
                padding: 21px 12px;
            }

            .whp-page .whp-logo {
                margin-left: 6px;
                font-size: 17px;
            }

            .whp-page .whp-nav a {
                padding: 12px 10px;
                font-size: 14px;
                gap: 9px;
            }

            .whp-page .whp-main {
                padding: 25px 22px;
            }

            .whp-page .whp-card {
                padding: 32px 25px;
            }
        }

        /* ======================================
           MOBILE
        ====================================== */

        @media (max-width: 650px) {

            .whp-page .whp-shell {
                display: block;
            }

            .whp-page .whp-sidebar {
                padding: 16px;
            }

            .whp-page .whp-logo {
                margin-bottom: 16px;
            }

            .whp-page .whp-nav {
                flex-direction: row;
                overflow-x: auto;
                gap: 6px;
            }

            .whp-page .whp-nav a {
                flex-shrink: 0;
                white-space: nowrap;
                padding: 10px 12px;
            }

            .whp-page .whp-main {
                min-height: auto;
                padding: 25px 16px;
            }

            .whp-page .whp-header h1 {
                font-size: 28px;
            }

            .whp-page .whp-top-avatar {
                width: 40px;
                height: 40px;
            }

            .whp-page .whp-center {
                padding: 25px 0;
            }

            .whp-page .whp-card {
                width: 100%;
                padding: 30px 20px;
                border-radius: 20px;
            }

            .whp-page .whp-picture {
                width: 135px;
                height: 135px;
                font-size: 54px;
            }

            .whp-page .whp-details {
                margin-top: 42px;
            }

            .whp-page .whp-detail-value {
                font-size: 16px;
            }
        }

    </style>
</head>

<body class="whp-page">

<div class="whp-shell">

    <!-- ======================================
         ADMIN SIDEBAR
    ====================================== -->

    <aside class="whp-sidebar">

        <a
            href="admin-dashboard.php"
            class="whp-logo"
        >
            <span class="whp-logo-mark">
                ☘
            </span>

            <span>WellnessHub</span>
        </a>

        <nav
            class="whp-nav"
            aria-label="Admin navigation"
        >

            <a href="admin-dashboard.php">
                <span class="whp-nav-icon">▣</span>
                Dashboard
            </a>

            <a href="admin-users.php">
                <span class="whp-nav-icon">👥</span>
                Users
            </a>

            <a href="admin-counsellors.php">
                <span class="whp-nav-icon">♡</span>
                Counsellors
            </a>

            <a href="admin-reports.php">
                <span class="whp-nav-icon">📊</span>
                Reports
            </a>

            <a href="system-logs.php">
                <span class="whp-nav-icon">☷</span>
                System Logs
            </a>

            <a href="admin-settings.php">
                <span class="whp-nav-icon">⚙</span>
                Settings
            </a>

            <a
                href="admin-profile.php"
                class="active"
                aria-current="page"
            >
                <span class="whp-nav-icon">👤</span>
                My Profile
            </a>

            <a href="logout.php">
                <span class="whp-nav-icon">↪</span>
                Logout
            </a>

        </nav>

    </aside>

    <!-- ======================================
         MAIN PROFILE PAGE
    ====================================== -->

    <main class="whp-main">

        <!-- PROFILE HEADER -->

        <header class="whp-header">

            <h1>My Profile</h1>

            <a
                class="whp-top-avatar"
                href="admin-profile.php"
                title="My Profile"
                aria-label="My Profile"
            >

                <span id="headerInitial">
                    <?= profileSafe($adminInitial) ?>
                </span>

                <img
                    id="headerPicture"
                    alt="Admin profile picture"
                    hidden
                >

            </a>

        </header>

        <!-- ======================================
             CENTERED PROFILE CARD
        ====================================== -->

        <div class="whp-center">

            <section
                class="whp-card"
                aria-label="My Profile Details"
            >

                <!-- PROFILE PICTURE -->

                <div class="whp-picture-area">

                    <div class="whp-picture">

                        <span id="profileInitial">
                            <?= profileSafe($adminInitial) ?>
                        </span>

                        <img
                            id="profilePicture"
                            alt="My profile picture"
                            hidden
                        >

                    </div>

                    <!-- IMAGE INPUT -->

                    <input
                        id="pictureFile"
                        type="file"
                        accept="image/png,image/jpeg,image/gif,image/webp"
                        hidden
                    >

                    <!-- UPLOAD AND REMOVE BUTTONS -->

                    <div class="whp-buttons">

                        <button
                            type="button"
                            class="whp-btn"
                            id="uploadPicture"
                        >
                            Upload Picture
                        </button>

                        <button
                            type="button"
                            class="whp-btn whp-btn-remove"
                            id="removePicture"
                            hidden
                        >
                            Remove Picture
                        </button>

                    </div>

                    <!-- MESSAGE -->

                    <div
                        id="profileMessage"
                        class="whp-feedback"
                        role="status"
                        aria-live="polite"
                        hidden
                    ></div>

                </div>

                <!-- ======================================
                     ACCOUNT DETAILS
                ====================================== -->

                <div class="whp-details">

                    <div>
                        <span class="whp-detail-label">
                            Full Name
                        </span>

                        <div
                            class="whp-detail-value"
                            id="profileName"
                        >
                            <?= profileSafe($adminFullName) ?>
                        </div>
                    </div>

                    <div>
                        <span class="whp-detail-label">
                            Email Address
                        </span>

                        <div
                            class="whp-detail-value"
                            id="profileEmail"
                        >
                            Loading...
                        </div>
                    </div>

                    <div>
                        <span class="whp-detail-label">
                            Account Type
                        </span>

                        <span class="whp-role">
                            Administrator
                        </span>
                    </div>

                    <div>
                        <span class="whp-detail-label">
                            Gender
                        </span>

                        <div
                            class="whp-detail-value"
                            id="profileGender"
                        >
                            Loading...
                        </div>
                    </div>

                </div>

            </section>

        </div>

    </main>

</div>

<!-- ======================================
     ADMIN PROFILE JAVASCRIPT
====================================== -->

<script>
(() => {

    const API = "api/demoAPI.php";

    const byId = id =>
        document.getElementById(id);

    const pictureInput = byId("pictureFile");
    const uploadButton = byId("uploadPicture");
    const removeButton = byId("removePicture");
    const message = byId("profileMessage");

    // CHECK IMAGE FORMAT

    function isPicture(value) {
        return (
            typeof value === "string" &&
            /^data:image\/(?:png|jpe?g|gif|webp);base64,[A-Za-z0-9+/=]+$/
                .test(value)
        );
    }

    // SHOW MESSAGES

    function showMessage(text, type = "") {

        message.textContent = text;

        message.className =
            "whp-feedback" +
            (type ? " " + type : "");

        message.hidden = false;
    }

    // UPDATE PROFILE PICTURES

    function renderPicture(image) {

        const hasPicture = isPicture(image);

        const avatars = [
            ["profilePicture", "profileInitial"],
            ["headerPicture", "headerInitial"]
        ];

        for (const [imgId, textId] of avatars) {

            const img = byId(imgId);
            const text = byId(textId);

            if (hasPicture) {
                img.src = image;
            } else {
                img.removeAttribute("src");
            }

            img.hidden = !hasPicture;
            text.hidden = hasPicture;
        }

        removeButton.hidden = !hasPicture;
    }

    // CONNECT TO EXISTING API

    async function apiRequest(action, data = null) {

        const options = {
            method: data === null ? "GET" : "POST",
            credentials: "same-origin",
            cache: "no-store",
            headers: data === null
                ? {
                    "Accept": "application/json"
                }
                : {
                    "Content-Type":
                        "application/x-www-form-urlencoded",
                    "Accept": "application/json"
                }
        };

        if (data !== null) {
            options.body = new URLSearchParams(data);
        }

        const response = await fetch(
            API + "?action=" + encodeURIComponent(action),
            options
        );

        let result;

        try {
            result = await response.json();
        } catch (error) {
            throw new Error(
                "Invalid server response. Check demoAPI.php."
            );
        }

        if (!response.ok || !result.success) {
            throw new Error(
                result.message || "Server request failed."
            );
        }

        return result.data || {};
    }

    // LOAD PROFILE INFORMATION

    async function loadProfile() {

        try {

            const data = await apiRequest("profile_get");

            const name = String(
                data.full_name || "Administrator"
            ).trim();

            const initial =
                name.charAt(0).toUpperCase() || "A";

            byId("profileName").textContent = name;

            byId("profileEmail").textContent =
                data.email || "Not provided";

            byId("profileGender").textContent =
                data.gender || "Not specified";

            byId("profileInitial").textContent =
                initial;

            byId("headerInitial").textContent =
                initial;

            renderPicture(
                data.profile_picture || ""
            );

        } catch (error) {

            byId("profileEmail").textContent =
                "Unable to load";

            byId("profileGender").textContent =
                "Unable to load";

            showMessage(
                "Could not load your profile: " +
                error.message,
                "error"
            );
        }
    }

    // OPEN FILE PICKER

    uploadButton.addEventListener("click", () => {
        pictureInput.click();
    });

    // UPLOAD PROFILE PICTURE

    pictureInput.addEventListener("change", async () => {

        const file = pictureInput.files?.[0];

        if (!file) {
            return;
        }

        const allowedTypes = [
            "image/png",
            "image/jpeg",
            "image/gif",
            "image/webp"
        ];

        if (!allowedTypes.includes(file.type)) {

            showMessage(
                "Please choose a JPG, PNG, WEBP or GIF image.",
                "error"
            );

            pictureInput.value = "";
            return;
        }

        if (file.size > 2 * 1024 * 1024) {

            showMessage(
                "Your picture must be smaller than 2 MB.",
                "error"
            );

            pictureInput.value = "";
            return;
        }

        uploadButton.disabled = true;
        removeButton.disabled = true;

        showMessage("Uploading picture...");

        try {

            const image = await new Promise(
                (resolve, reject) => {

                    const reader = new FileReader();

                    reader.onload = () => {
                        resolve(reader.result);
                    };

                    reader.onerror = () => {
                        reject(
                            new Error(
                                "Unable to read the selected picture."
                            )
                        );
                    };

                    reader.readAsDataURL(file);
                }
            );

            await apiRequest(
                "profile_picture_upload",
                { image: image }
            );

            renderPicture(image);

            showMessage(
                "Profile picture uploaded successfully!",
                "success"
            );

        } catch (error) {

            showMessage(
                "Upload failed: " + error.message,
                "error"
            );

        } finally {

            uploadButton.disabled = false;
            removeButton.disabled = false;

            pictureInput.value = "";
        }
    });

    // REMOVE PROFILE PICTURE

    removeButton.addEventListener("click", async () => {

        if (!confirm(
            "Are you sure you want to remove your profile picture?"
        )) {
            return;
        }

        uploadButton.disabled = true;
        removeButton.disabled = true;

        showMessage("Removing picture...");

        try {

            await apiRequest(
                "profile_picture_remove",
                {}
            );

            renderPicture("");

            showMessage(
                "Profile picture removed successfully.",
                "success"
            );

        } catch (error) {

            showMessage(
                "Could not remove picture: " +
                error.message,
                "error"
            );

        } finally {

            uploadButton.disabled = false;
            removeButton.disabled = false;
        }
    });

    loadProfile();

})();
</script>

</body>
</html>
