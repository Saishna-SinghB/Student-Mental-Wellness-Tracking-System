<?php
require_once __DIR__ . '/admin-auth.php';
require_once __DIR__ . '/demoDB.php';

// ADMIN DETAILS
$adminName = trim(
    (string)($_SESSION['full_name'] ?? 'Admin')
);

$adminInitial = strtoupper(
    substr($adminName !== '' ? $adminName : 'Admin', 0, 1)
);

// LOAD ADMIN PROFILE PICTURE
$adminPicture = (string)($_SESSION['profile_picture'] ?? '');

try {

    $stmt = $pdo->prepare("
        SELECT profile_picture
        FROM users
        WHERE user_id = ?
        AND role = 'admin'
        LIMIT 1
    ");

    $stmt->execute([$_SESSION['user_id']]);

    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {

        $adminPicture = (string)(
            $user['profile_picture'] ?? ''
        );

        $_SESSION['profile_picture'] = $adminPicture;

    }

} catch (PDOException $e) {

    error_log(
        'Admin picture error: ' . $e->getMessage()
    );

}

// VALIDATE PROFILE PICTURE
$hasAdminPicture = preg_match(
    '#^data:image/(?:png|jpeg|gif|webp);base64,[A-Za-z0-9+/=]+$#D',
    $adminPicture
) === 1;
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>System Logs — WellnessHub</title>

    <link rel="stylesheet" href="css/style.css">

    <style>

        /* PERFECTLY ROUND ADMIN PROFILE PICTURE */

        .topbar-actions .avatar.admin-avatar {
            width: 44px !important;
            height: 44px !important;
            min-width: 44px !important;
            min-height: 44px !important;
            flex: 0 0 44px !important;
            aspect-ratio: 1 / 1;
            border-radius: 50% !important;
            overflow: hidden;
            padding: 0;
            display: grid;
            place-items: center;
            box-sizing: border-box;
        }

        .topbar-actions .avatar.admin-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-radius: 50%;
            display: block;
        }

    </style>

</head>

<body class="app-body admin-body">

<div class="app-shell admin-shell">

    <!-- ADMIN SIDEBAR -->

    <aside class="sidebar admin-sidebar">

        <a
            class="brand-mini sidebar-brand"
            href="index.php"
        >

            <span class="mini-leaf" aria-hidden="true">
                ☘
            </span>

            <span>WellnessHub</span>

        </a>

        <nav
            class="side-nav"
            aria-label="Admin navigation"
        >

            <a href="admin-dashboard.php">
                <span>▣</span> Dashboard
            </a>

            <a href="admin-users.php">
                <span>👥</span> Users
            </a>

            <a href="admin-counsellors.php">
                <span>♡</span> Counsellors
            </a>

            <a href="admin-reports.php">
                <span>📊</span> Reports
            </a>

            <a
                class="active"
                href="system-logs.php"
            >
                <span>☷</span> System Logs
            </a>

            <a href="admin-settings.php">
                <span>⚙</span> Settings
            </a>

            <!-- MY PROFILE -->

            <a href="admin-profile.php">
                <span>👤</span> My Profile
            </a>

            <a href="logout.php">
                <span>↪</span> Logout
            </a>

        </nav>

    </aside>


    <!-- MAIN CONTENT -->

    <main class="dashboard-main admin-main">

        <!-- HEADER -->

        <header class="topbar admin-topbar">

            <div>

                <p class="eyebrow">
                    Admin Side
                </p>

                <h1>System Logs</h1>

                <p class="page-subtitle">
                    Monitor security, login and platform activity.
                </p>

            </div>


            <!-- TOP RIGHT BUTTONS -->

            <div class="topbar-actions">

                <!-- SYSTEM LOGS BELL -->

                <a
                    class="icon-btn admin-icon"
                    href="system-logs.php"
                    aria-label="System logs"
                >
                    🔔
                </a>


                <!-- ROUND ADMIN PROFILE PICTURE -->

                <a
                    href="admin-profile.php"
                    class="avatar admin-avatar"
                    title="Click to view My Profile"
                    aria-label="Open My Profile"
                >

                    <?php if ($hasAdminPicture): ?>

                        <img
                            src="<?= htmlspecialchars(
                                $adminPicture,
                                ENT_QUOTES,
                                'UTF-8'
                            ) ?>"
                            alt="Admin profile picture"
                        >

                    <?php else: ?>

                        <?= htmlspecialchars(
                            $adminInitial,
                            ENT_QUOTES,
                            'UTF-8'
                        ) ?>

                    <?php endif; ?>

                </a>

            </div>

        </header>


        <!-- SYSTEM LOGS CONTENT -->

        <section class="panel">

            <div class="panel-heading">

                <h2>Recent Activity</h2>

                <!-- EXPORT LOGS BUTTON -->

                <button
                    class="btn btn-purple btn-small"
                    type="button"
                    id="exportLogsBtn"
                >
                    Export Logs
                </button>

            </div>


            <!-- LOG LIST -->

            <div
                class="notification-list"
                id="logList"
            >

                <p class="muted">
                    Loading logs…
                </p>

            </div>

        </section>

    </main>

</div>


<!-- EXISTING JAVASCRIPT -->

<script src="js/system-logs.js"></script>

</body>
</html>