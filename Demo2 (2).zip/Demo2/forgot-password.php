
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password — WellnessHub</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body>

<main class="auth-screen">
<section class="auth-card forgot-card">

    <div class="auth-number">PASSWORD RECOVERY</div>

    <div class="brand-mini">
        <span class="mini-leaf" aria-hidden="true">☘</span>
        <span>WellnessHub</span>
    </div>

    <!-- RESET PROGRESS -->
    <ol class="fp-steps" id="fpSteps"
        aria-label="Password reset progress">
        <li class="current" data-step="1">
            <span>1</span>Email
        </li>
        <li data-step="2">
            <span>2</span>Verify
        </li>
        <li data-step="3">
            <span>3</span>New password
        </li>
    </ol>

    <!-- STEP 1: EMAIL -->
    <div id="emailStep" class="forgot-step active-step">

        <header class="auth-header">
            <div class="fp-icon" aria-hidden="true">
                <svg width="26" height="26" viewBox="0 0 24 24"
                     fill="none" stroke="currentColor"
                     stroke-width="1.9" stroke-linecap="round"
                     stroke-linejoin="round">
                    <rect x="4" y="10.5" width="16"
                          height="10" rx="2.5"/>
                    <path d="M8 10.5V8a4 4 0 0 1 8 0v2.5"/>
                    <circle cx="12" cy="15.5" r="1.2"
                            fill="currentColor"/>
                </svg>
            </div>

            <h1>Forgot your password?</h1>
            <p>
                Enter your account email and we’ll send
                you a code to reset it.
            </p>
        </header>

        <form id="forgotEmailForm" class="auth-form" novalidate>
            <label class="field">
                <span>Email</span>
                <input id="resetEmail"
                       type="email"
                       placeholder="name@my.richfield.ac.za"
                       autocomplete="email"
                       required>
            </label>

            <p id="emailMessage" class="forgot-message"
               role="alert" aria-live="polite"></p>

            <button class="btn btn-primary btn-full"
                    type="submit">
                Send verification code
            </button>
        </form>

        <p class="forgot-back">
            <a href="login.php">← Back to Login</a>
        </p>
    </div>

    <!-- STEP 2: VERIFY CODE -->
    <div id="codeStep" class="forgot-step">

        <header class="auth-header">
            <div class="fp-icon" aria-hidden="true">
                <svg width="26" height="26" viewBox="0 0 24 24"
                     fill="none" stroke="currentColor"
                     stroke-width="1.9" stroke-linecap="round"
                     stroke-linejoin="round">
                    <rect x="3.5" y="5.5" width="17"
                          height="13" rx="2.5"/>
                    <path d="m4.5 7.5 7.5 6 7.5-6"/>
                </svg>
            </div>

            <h1>Check your email</h1>
            <p>
                We sent a 6-digit code to
                <strong id="sentTo" class="fp-sentto"></strong>
                It expires in 10 minutes.
            </p>
        </header>

        <div id="devCodeBox" class="fp-devcode" hidden>
            <span class="fp-devcode-label">
                Development mode — email isn’t configured,
                so your code is shown here
            </span>

            <strong id="devCodeValue"
                    class="fp-devcode-value">------</strong>

            <button id="devCodeUse"
                    class="fp-link-btn" type="button">
                Fill it in for me
            </button>
        </div>

        <form id="verificationForm" class="auth-form" novalidate>
            <label class="field">
                <span>Verification code</span>
                <input id="verificationCode"
                       class="verification-input"
                       type="text"
                       maxlength="6"
                       inputmode="numeric"
                       pattern="[0-9]*"
                       placeholder="000000"
                       autocomplete="one-time-code"
                       required>
            </label>

            <p id="codeMessage" class="forgot-message"
               role="alert" aria-live="polite"></p>

            <button class="btn btn-primary btn-full"
                    type="submit">
                Verify code
            </button>
        </form>

        <p class="fp-resend">
            Didn’t get it? Check your spam folder or
            <button id="resendCode"
                    class="fp-link-btn" type="button">
                Resend Code
            </button>
        </p>

        <p class="forgot-back">
            <button id="backToEmail"
                    class="fp-link-btn" type="button">
                ← Use a different email
            </button>
        </p>
    </div>

    <!-- STEP 3: NEW PASSWORD -->
    <div id="passwordStep" class="forgot-step">

        <header class="auth-header">
            <div class="fp-icon" aria-hidden="true">
                <svg width="26" height="26" viewBox="0 0 24 24"
                     fill="none" stroke="currentColor"
                     stroke-width="1.9" stroke-linecap="round"
                     stroke-linejoin="round">
                    <circle cx="8.5" cy="14.5" r="4"/>
                    <path d="m11.5 11.5 8-8M16 7l2.5 2.5M14 9l2 2"/>
                </svg>
            </div>

            <h1>Create a new password</h1>

            <p id="passwordHelp">
                Choose a strong password you haven’t used before.
            </p>
        </header>

        <form id="newPasswordForm" class="auth-form" novalidate>

            <label class="field">
                <span>New password</span>
                <input id="newPassword"
                       type="password"
                       placeholder="Enter new password"
                       autocomplete="new-password"
                       required>
            </label>

            <label class="field">
                <span>Confirm password</span>
                <input id="confirmPassword"
                       type="password"
                       placeholder="Confirm new password"
                       autocomplete="new-password"
                       required>
            </label>

            <div class="password-requirements">
                <p>Your password must have:</p>

                <span id="lengthRequirement">
                    ○ At least 8 characters
                </span>

                <span id="capitalRequirement">
                    ○ At least one uppercase letter
                </span>

                <span id="specialRequirement">
                    ○ At least one special character (e.g. @ ! #)
                </span>
            </div>

            <p id="passwordMessage" class="forgot-message"
               role="alert" aria-live="polite"></p>

            <button class="btn btn-primary btn-full"
                    type="submit">
                Reset password
            </button>
        </form>
    </div>

    <!-- STEP 4: SUCCESS -->
    <div id="successStep" class="forgot-step">

        <div class="forgot-success">
            <div class="success-circle" aria-hidden="true">
                <svg width="34" height="34" viewBox="0 0 24 24"
                     fill="none" stroke="currentColor"
                     stroke-width="2.6" stroke-linecap="round"
                     stroke-linejoin="round">
                    <path d="m5 12.5 4.5 4.5L19 7.5"/>
                </svg>
            </div>

            <h1>Password updated</h1>

            <p>
                Your password has been changed.
                You can now log in with your new password.
            </p>

            <a href="login.php" class="btn btn-primary btn-full">
                Go to Login
            </a>
        </div>
    </div>

    <p class="legal-text">
        Secure • Confidential • POPIA Compliant
    </p>

</section>
</main>

<!-- PASSWORD RECOVERY JAVASCRIPT -->
<script>
document.addEventListener("DOMContentLoaded", () => {

    const API = "api/demoAPI.php";
    const EMAIL_KEY = "userResetEmail";
    const TOKEN_KEY = "userResetToken";

    const $ = id => document.getElementById(id);

    const steps = [
        $("emailStep"),
        $("codeStep"),
        $("passwordStep"),
        $("successStep")
    ];

    const email = $("resetEmail");
    const code = $("verificationCode");
    const password = $("newPassword");
    const confirm = $("confirmPassword");

    const emailMsg = $("emailMessage");
    const codeMsg = $("codeMessage");
    const passMsg = $("passwordMessage");

    const resend = $("resendCode");
    const progress = $("fpSteps");

    let cooldownTimer = null;

    function savedEmail() {
        return sessionStorage.getItem(EMAIL_KEY);
    }

    function showMessage(element, text, type = "error") {
        element.textContent = text;
        element.classList.remove("error", "success");

        if (text) {
            element.classList.add(type);
        }
    }

    function setBusy(form, busy) {
        form.querySelectorAll('button[type="submit"]')
            .forEach(button => button.disabled = busy);
    }

    async function post(action, fields) {
        const response = await fetch(
            API + "?action=" + action,
            {
                method: "POST",
                headers: {
                    "Content-Type":
                        "application/x-www-form-urlencoded"
                },
                body: new URLSearchParams(fields)
            }
        );

        return response.json();
    }

    function showStep(step) {
        steps.forEach(item => {
            item.classList.toggle(
                "active-step",
                item === step
            );
        });

        const current = steps.indexOf(step) + 1;

        progress.querySelectorAll("li").forEach(li => {
            const number = Number(li.dataset.step);

            li.classList.toggle("done", number < current);
            li.classList.toggle("current", number === current);
        });

        if (step === steps[1]) {
            $("sentTo").textContent =
                savedEmail() || "your email address";
        }

        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });
    }

    function showDevCode(result) {
        const value = result?.data?.dev_code;
        const box = $("devCodeBox");

        box.hidden = !value;
        $("devCodeValue").textContent =
            value || "------";
    }

    $("devCodeUse").addEventListener("click", () => {
        code.value = $("devCodeValue")
            .textContent.replace(/\D/g, "");

        code.focus();
    });

    function restart(message) {
        clearInterval(cooldownTimer);

        sessionStorage.removeItem(EMAIL_KEY);
        sessionStorage.removeItem(TOKEN_KEY);

        showStep(steps[0]);
        showMessage(emailMsg, message);
    }

    function startCooldown() {
        clearInterval(cooldownTimer);

        let remaining = 60;
        resend.disabled = true;

        const tick = () => {
            if (remaining <= 0) {
                clearInterval(cooldownTimer);
                resend.disabled = false;
                resend.textContent = "Resend Code";
            } else {
                resend.textContent =
                    `Resend Code (${remaining}s)`;
                remaining--;
            }
        };

        tick();
        cooldownTimer = setInterval(tick, 1000);
    }

    // STEP 1 - SEND CODE
    $("forgotEmailForm").addEventListener(
        "submit",
        async event => {
            event.preventDefault();

            showMessage(emailMsg, "");

            const value = email.value.trim().toLowerCase();

            if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
                showMessage(
                    emailMsg,
                    "Please enter a valid email address."
                );
                return;
            }

            setBusy(event.currentTarget, true);

            try {
                const result = await post(
                    "forgot_password_request",
                    { email: value }
                );

                if (!result.success) {
                    showMessage(
                        emailMsg,
                        result.message || "Unable to send code."
                    );
                    return;
                }

                sessionStorage.setItem(EMAIL_KEY, value);
                sessionStorage.removeItem(TOKEN_KEY);

                showDevCode(result);

                showMessage(
                    emailMsg,
                    "If that account exists, a verification code has been sent.",
                    "success"
                );

                setTimeout(() => {
                    code.value = "";
                    showMessage(codeMsg, "");

                    showStep(steps[1]);
                    code.focus();
                    startCooldown();
                }, 700);

            } catch (error) {
                showMessage(
                    emailMsg,
                    "Could not reach the server."
                );
            } finally {
                setBusy(event.currentTarget, false);
            }
        }
    );

    // STEP 2 - VERIFY CODE
    code.addEventListener("input", () => {
        code.value = code.value
            .replace(/\D/g, "")
            .slice(0, 6);
    });

    $("verificationForm").addEventListener(
        "submit",
        async event => {
            event.preventDefault();

            showMessage(codeMsg, "");

            if (code.value.length !== 6) {
                showMessage(
                    codeMsg,
                    "Please enter the complete 6-digit code."
                );
                return;
            }

            if (!savedEmail()) {
                restart(
                    "Your session expired. Please enter your email again."
                );
                return;
            }

            setBusy(event.currentTarget, true);

            try {
                const result = await post(
                    "forgot_password_verify",
                    {
                        email: savedEmail(),
                        code: code.value
                    }
                );

                if (!result.success) {
                    showMessage(
                        codeMsg,
                        result.message || "Invalid code."
                    );
                    return;
                }

                if (!result.data?.reset_token) {
                    showMessage(
                        codeMsg,
                        "Reset token missing. Please request a new code."
                    );
                    return;
                }

                sessionStorage.setItem(
                    TOKEN_KEY,
                    result.data.reset_token
                );

                showDevCode(null);

                showMessage(
                    codeMsg,
                    "Account verified successfully.",
                    "success"
                );

                setTimeout(() => {
                    showStep(steps[2]);
                    password.focus();
                }, 600);

            } catch (error) {
                showMessage(
                    codeMsg,
                    "Could not reach the server."
                );
            } finally {
                setBusy(event.currentTarget, false);
            }
        }
    );

    // RESEND CODE
    resend.addEventListener("click", async () => {
        showMessage(codeMsg, "");

        if (!savedEmail()) {
            restart(
                "Your session expired. Please enter your email again."
            );
            return;
        }

        resend.disabled = true;

        try {
            const result = await post(
                "forgot_password_request",
                { email: savedEmail() }
            );

            if (!result.success) {
                showMessage(
                    codeMsg,
                    result.message || "Unable to resend code."
                );
                resend.disabled = false;
                return;
            }

            code.value = "";
            showDevCode(result);

            showMessage(
                codeMsg,
                "A new verification code has been sent.",
                "success"
            );

            startCooldown();

        } catch (error) {
            showMessage(
                codeMsg,
                "Could not reach the server."
            );
            resend.disabled = false;
        }
    });

    // BACK TO EMAIL
    $("backToEmail").addEventListener("click", () => {
        clearInterval(cooldownTimer);

        code.value = "";
        showDevCode(null);

        showMessage(codeMsg, "");
        showMessage(emailMsg, "");

        sessionStorage.removeItem(TOKEN_KEY);

        showStep(steps[0]);
        email.focus();
    });

    // PASSWORD RULES FOR ALL USERS
    $("passwordHelp").textContent =
        "Choose a strong password you haven’t used before.";

    $("prefixRequirement")?.remove();

    const SPECIAL =
        /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>/?]/;

    function updateRequirement(id, valid, text) {
        const element = $(id);

        if (!element) return;

        element.classList.toggle("valid", valid);
        element.textContent =
            (valid ? "✓ " : "○ ") + text;
    }

    password.addEventListener("input", () => {
        updateRequirement(
            "lengthRequirement",
            password.value.length >= 8,
            "At least 8 characters"
        );

        updateRequirement(
            "capitalRequirement",
            /[A-Z]/.test(password.value),
            "At least one uppercase letter"
        );

        updateRequirement(
            "specialRequirement",
            SPECIAL.test(password.value),
            "At least one special character (e.g. @ ! #)"
        );
    });

    // STEP 3 - RESET PASSWORD
    $("newPasswordForm").addEventListener(
        "submit",
        async event => {
            event.preventDefault();

            showMessage(passMsg, "");

            const value = password.value;

            if (value.length < 8) {
                showMessage(
                    passMsg,
                    "Password must contain at least 8 characters."
                );
                return;
            }

            if (!/[A-Z]/.test(value)) {
                showMessage(
                    passMsg,
                    "Password must contain an uppercase letter."
                );
                return;
            }

            if (!SPECIAL.test(value)) {
                showMessage(
                    passMsg,
                    "Password must contain at least one special character."
                );
                return;
            }

            if (value !== confirm.value) {
                showMessage(
                    passMsg,
                    "The passwords do not match."
                );
                return;
            }

            const resetToken =
                sessionStorage.getItem(TOKEN_KEY);

            if (!savedEmail() || !resetToken) {
                restart(
                    "Your session expired. Please start again."
                );
                return;
            }

            setBusy(event.currentTarget, true);

            try {
                const result = await post(
                    "forgot_password_reset",
                    {
                        email: savedEmail(),
                        reset_token: resetToken,
                        new_password: value
                    }
                );

                if (!result.success) {
                    showMessage(
                        passMsg,
                        result.message || "Password reset failed."
                    );
                    return;
                }

                sessionStorage.removeItem(EMAIL_KEY);
                sessionStorage.removeItem(TOKEN_KEY);
                sessionStorage.removeItem("userResetRole");

                password.value = "";
                confirm.value = "";

                showStep(steps[3]);

            } catch (error) {
                showMessage(
                    passMsg,
                    "Could not reach the server."
                );
            } finally {
                setBusy(event.currentTarget, false);
            }
        }
    );

});
</script>

</body>
</html>
