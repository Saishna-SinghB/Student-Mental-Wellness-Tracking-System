<?php
/*
 * Crisis keyword list used by screenJournalText().
 *
 * IMPORTANT: this is a simple word/phrase screen, NOT AI and NOT a clinical
 * assessment. It will miss unusual wording and will occasionally flag
 * harmless text, so a counsellor always reviews an alert. The list below
 * must be reviewed and approved by the supervisor (Mr Naidoo) before the
 * system is relied on.
 *
 * Matching is done on normalised text (lower case, punctuation removed,
 * curly apostrophes straightened), so "Self-harm" matches "self harm".
 */
function threatLexicon(): array {
    static $lexicon = null;
    if ($lexicon === null) {
        $lexicon = [
            // Single words that are flagged wherever they appear.
            'words' => array_flip([
                'suicide', 'suicidal', 'selfharm', 'selfharming',
            ]),
            // Phrases (each is matched as whole words).
            'phrases' => [
                // ending one's life
                'end life', 'end my life', 'ending my life', 'end it all', 'ending it all',
                'take my own life', 'taking my own life', 'take my life',
                'kill myself', 'killing myself', 'kill my self', 'unalive myself',
                'hang myself', 'take an overdose', 'overdose on purpose',
                // wanting to die / not wanting to live
                'want to die', 'wanna die', 'wish i was dead', 'wish i were dead',
                'wish i wasnt alive', "wish i wasn't alive", 'wish i was never born',
                'better off dead', 'better off without me', 'rather be dead',
                'no reason to live', 'nothing to live for', 'no point in living',
                'not worth living', 'life is not worth living', 'life isnt worth living',
                "life isn't worth living",
                'dont want to live', "don't want to live", 'do not want to live',
                'dont want to be here anymore', "don't want to be here anymore",
                'do not want to be here anymore', 'dont want to be alive',
                "don't want to be alive", 'do not want to be alive',
                'cant go on', "can't go on", 'cannot go on', 'cant take it anymore',
                "can't take it anymore",
                // self-harm
                'self harm', 'self harming', 'self harmed', 'harm myself', 'harming myself',
                'harmed myself', 'hurt myself', 'hurting myself', 'hurt my self',
                'cut myself', 'cutting myself', 'cut my wrists', 'cutting my wrists',
            ],
        ];
    }
    return $lexicon;
}

function normaliseThreatText(string $text): string {
    $plain = preg_replace('/<[^>]*>/', ' ', $text);
    $plain = html_entity_decode($plain, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $plain = str_replace(["\u{2019}", "\u{2018}", '`'], "'", $plain);   // curly apostrophes
    $plain = mb_strtolower($plain, 'UTF-8');
    $plain = preg_replace('/[^\p{L}\p{N}\']+/u', ' ', $plain);
    return trim(preg_replace('/\s+/u', ' ', $plain));
}

function screenJournalText(string $text): bool {
    $normalised = normaliseThreatText($text);
    if ($normalised === '') {
        return false;
    }

    $lexicon = threatLexicon();

    foreach (explode(' ', $normalised) as $token) {
        if (isset($lexicon['words'][$token])) {
            return true;
        }
    }

    $padded = ' ' . $normalised . ' ';
    foreach ($lexicon['phrases'] as $phrase) {
        if (str_contains($padded, ' ' . $phrase . ' ')) {
            return true;
        }
    }

    return false;
}
