<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <meta name="theme-color" content="#f1f8f2">

    <title>Welcome to WellnessHub</title>

    <style>

        :root {
            --forest: #123c2b;
            --green: #28784f;
            --mint: #eaf7ec;
            --ink: #173829;
            --soft: #678475;
        }

        * {
            box-sizing: border-box;
        }

        html {
            min-height: 100%;
        }

        body {
            margin: 0;
            min-height: 100vh;

            font-family:
                Inter,
                "Segoe UI",
                Arial,
                sans-serif;

            color: var(--ink);

            background:
                radial-gradient(
                    circle at 5% 12%,
                    #cde9d5 0,
                    transparent 32%
                ),
                radial-gradient(
                    circle at 95% 88%,
                    #d8eddf 0,
                    transparent 31%
                ),
                #f3f9f4;
        }

        a {
            text-decoration: none;
        }

        /* MAIN PAGE */

        .welcome-page {
            min-height: 100vh;
            display: grid;
            place-items: center;
            padding: clamp(16px, 3vw, 42px);
        }

        /* MAIN CARD */

        .welcome-card {
            width: min(1160px, 100%);
            min-height: 660px;

            display: grid;
            grid-template-columns: 1fr 0.93fr;

            background: #fffefa;

            border: 1px solid rgba(255,255,255,0.9);
            border-radius: 32px;

            box-shadow:
                0 24px 75px rgba(30,88,53,0.13);

            overflow: hidden;

            animation: enter 0.55s ease both;
        }

        /* LEFT SIDE */

        .welcome-copy {
            padding: clamp(32px, 4.5vw, 62px);
            display: flex;
            flex-direction: column;
            min-width: 0;
        }

        /* BRAND */

        .brand {
            display: flex;
            align-items: center;
            gap: 12px;

            font-size: 23px;
            font-weight: 900;

            color: var(--forest);

            letter-spacing: -0.8px;
        }

        /* WELLNESSHUB LOGO */

        .brand-mark {
            width: 46px;
            height: 46px;

            display: grid;
            grid-template-columns: repeat(2, 1fr);

            gap: 4px;
            padding: 10px;

            border-radius: 14px;

            background: #e5f3e8;

            position: relative;

            box-shadow:
                inset 0 0 0 1px #d4e9da;
        }

        .brand-mark::after {
            content: "";

            position: absolute;

            width: 3px;
            height: 28px;

            top: 9px;
            left: calc(50% - 1.5px);

            border-radius: 8px;

            background: #236a46;
        }

        .brand-mark i {
            background: linear-gradient(
                145deg,
                #82c796,
                #33885d
            );

            border-radius: 80% 20% 80% 20%;
        }

        .brand-mark i:nth-child(even) {
            border-radius: 20% 80% 20% 80%;
        }

        /* WELCOME MESSAGE */

        .welcome-message {
            margin: auto 0;
            padding: 48px 0 35px;
        }

        .eyebrow {
            display: inline-flex;
            align-items: center;
            gap: 9px;

            padding: 9px 13px;

            border-radius: 999px;

            background: #e9f5eb;
            color: #2e7951;

            font-size: 11px;
            font-weight: 900;
            letter-spacing: 0.12em;

            text-transform: uppercase;
        }

        .eyebrow::before {
            content: "";

            width: 7px;
            height: 7px;

            background: #4ca36d;
            border-radius: 50%;
        }

        /* HEADING */

        h1 {
            margin: 23px 0 19px;

            font-size: clamp(38px, 4.1vw, 64px);
            line-height: 1.08;

            font-weight: 850;
            letter-spacing: -0.055em;

            color: var(--forest);
        }

        h1 span {
            color: #438d63;
        }

        /* DESCRIPTION */

        .intro {
            max-width: 420px;
            margin: 0;

            font-size: clamp(15px, 1.25vw, 17px);
            line-height: 1.75;

            color: #5e7769;
            font-weight: 500;
        }

        /* LOGIN BUTTONS */

        .actions {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;

            margin-top: 32px;
        }

        .action {
            min-width: 162px;
            min-height: 55px;

            display: inline-flex;

            align-items: center;
            justify-content: center;

            gap: 12px;

            padding: 14px 20px;

            border-radius: 14px;

            font-size: 14px;
            font-weight: 850;

            transition:
                transform 0.2s ease,
                box-shadow 0.2s ease;
        }

        .action:hover {
            transform: translateY(-2px);
        }

        .action:focus-visible {
            outline: 3px solid #81c69a;
            outline-offset: 3px;
        }

        /* LOGIN */

        .action-primary {
            color: #ffffff;

            background: linear-gradient(
                135deg,
                #27764f,
                #46a16d
            );

            box-shadow:
                0 14px 28px rgba(40,120,79,0.24);
        }

        /* REGISTER */

        .action-secondary {
            color: #256b49;
            background: #ffffff;

            border: 1px solid #cfe3d5;
        }

        .action svg {
            width: 19px;
            height: 19px;
        }

        .subnote {
            margin: 15px 0 0;
            font-size: 12px;
            color: #819689;
        }

        /* FEATURES */

        .features {
            display: flex;
            flex-wrap: wrap;

            gap: 11px 17px;

            padding-top: 22px;

            border-top: 1px solid #e6eee7;

            font-size: 12px;
            font-weight: 700;

            color: #678373;
        }

        .features span {
            white-space: nowrap;
        }

        .features b {
            color: #37845a;
            font-size: 17px;
            font-weight: 700;

            vertical-align: -1px;

            padding-right: 3px;
        }

        /* RIGHT SIDE */

        .welcome-art {
            position: relative;
            min-height: 660px;

            overflow: hidden;

            background:
                radial-gradient(
                    circle at 38% 18%,
                    #e9f8ea,
                    transparent 40%
                ),
                linear-gradient(
                    160deg,
                    #d2ecd7,
                    #90c7a1 70%,
                    #5eaa7d
                );

            display: flex;
            flex-direction: column;

            align-items: center;
            justify-content: center;

            padding: 42px 28px;

            isolation: isolate;
        }

        .welcome-art::before,
        .welcome-art::after {
            content: "";

            position: absolute;

            width: 440px;
            height: 440px;

            border-radius: 50%;

            border:
                1px solid rgba(255,255,255,0.35);

            pointer-events: none;
        }

        .welcome-art::before {
            top: -215px;
            right: -185px;
        }

        .welcome-art::after {
            bottom: -265px;
            left: -160px;

            width: 550px;
            height: 550px;
        }

        /* RIGHT HEADING */

        .art-heading {
            margin: -15px 0 43px;

            color: #245f41;
            text-align: center;

            font-size: 14px;
            font-weight: 800;
            letter-spacing: 0.02em;

            position: relative;
            z-index: 2;
        }

        /* MOOD CARD */

        .mood-card {
            width: min(390px, 100%);

            padding: 24px;

            border-radius: 25px;

            background: rgba(255,255,255,0.94);

            border:
                1px solid rgba(255,255,255,0.9);

            box-shadow:
                0 25px 60px rgba(25,85,54,0.19);

            position: relative;
            z-index: 2;

            transform: rotate(-2deg);

            animation:
                float-card 6s ease-in-out infinite;
        }

        .mood-top {
            display: flex;
            align-items: center;
            gap: 9px;

            color: #658570;

            font-size: 12px;
            font-weight: 850;
        }

        .mood-icon {
            display: grid;
            place-items: center;

            width: 32px;
            height: 32px;

            border-radius: 11px;

            background: #e4f4e8;

            color: #378359;
            font-size: 20px;
        }

        .mood-today {
            margin-left: auto;

            color: #4a9c6a;

            font-size: 10px;
            letter-spacing: 0.1em;
        }

        .mood-card h2 {
            font-size: 24px;
            letter-spacing: -0.03em;

            color: #1d4932;

            margin: 21px 0 5px;
        }

        .mood-card p {
            margin: 0;

            color: #82968b;
            font-size: 12px;
        }

        /* MOOD OPTIONS */

        .mood-options {
            display: grid;

            grid-template-columns: repeat(5, 1fr);

            gap: 7px;

            margin: 23px 0 20px;
        }

        .mood-option {
            display: grid;
            justify-items: center;

            gap: 6px;

            padding: 11px 2px 9px;

            border-radius: 13px;

            background: #f5f9f5;

            color: #527c62;

            font-size: 22px;
        }

        .mood-option small {
            font-size: 10px;
            font-weight: 750;
        }

        .mood-option.selected {
            background: #e2f4e7;

            outline: 2px solid #73ba8a;

            color: #2a8554;
        }

        /* CARD FOOTER */

        .mood-bottom {
            display: flex;

            justify-content: space-between;
            align-items: center;

            gap: 12px;

            padding-top: 15px;

            border-top: 1px solid #e7eee8;

            color: #769280;

            font-size: 11px;
            font-weight: 700;
        }

        .heart {
            color: #e78e95;
            font-size: 19px;
        }

        /* FLOATING NOTES */

        .floating-note {
            position: absolute;

            display: flex;
            align-items: center;

            gap: 9px;

            z-index: 3;

            padding: 12px 15px;

            background: rgba(255,255,255,0.92);

            color: #35764f;

            border-radius: 15px;

            box-shadow:
                0 10px 30px rgba(35,100,61,0.12);

            font-size: 11px;
            font-weight: 800;
        }

        .floating-note b {
            background: #e6f5e9;

            width: 24px;
            height: 24px;

            display: grid;
            place-items: center;

            border-radius: 50%;
        }

        .note-one {
            top: 27%;
            left: 3%;

            transform: rotate(-7deg);
        }

        .note-two {
            right: 2%;
            bottom: 19%;

            transform: rotate(6deg);
        }

        .footer-note {
            position: absolute;

            bottom: 20px;

            color: rgba(23,78,47,0.7);

            font-size: 11px;
            font-weight: 750;

            z-index: 2;
        }

        /* ANIMATIONS */

        @keyframes enter {

            from {
                opacity: 0;
                transform: translateY(13px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }

        }

        @keyframes float-card {

            0%, 100% {
                transform:
                    translateY(0)
                    rotate(-2deg);
            }

            50% {
                transform:
                    translateY(-7px)
                    rotate(-2deg);
            }

        }

        /* TABLET */

        @media (max-width: 900px) {

            .welcome-card {
                grid-template-columns: 1fr;
                max-width: 660px;
            }

            .welcome-copy {
                min-height: 540px;
            }

            .welcome-art {
                min-height: 460px;
            }

            .welcome-message {
                padding: 38px 0 30px;
            }

            .art-heading {
                margin-bottom: 30px;
            }

            .note-one {
                top: 20%;
            }

            .note-two {
                bottom: 9%;
            }

        }

        /* MOBILE */

        @media (max-width: 540px) {

            .welcome-page {
                padding: 12px;
            }

            .welcome-card {
                border-radius: 23px;
            }

            .welcome-copy {
                padding: 28px 22px;
                min-height: auto;
            }

            .brand {
                font-size: 20px;
            }

            .brand-mark {
                width: 42px;
                height: 42px;
            }

            .welcome-message {
                padding: 42px 0 35px;
            }

            h1 {
                font-size: clamp(38px, 10vw, 48px);
            }

            .actions {
                display: grid;
                grid-template-columns: 1fr;
            }

            .action {
                width: 100%;
            }

            .features {
                margin-top: 20px;
            }

            .welcome-art {
                min-height: 380px;
                padding: 38px 17px 46px;
            }

            .mood-card {
                padding: 18px;
            }

            .mood-card h2 {
                font-size: 20px;
            }

            .mood-option {
                font-size: 19px;
                padding: 9px 1px;
            }

            .floating-note {
                display: none;
            }

            .art-heading {
                margin: -2px 0 24px;
            }

        }

        @media (prefers-reduced-motion: reduce) {

            *,
            *::before,
            *::after {
                animation: none !important;
                transition: none !important;
            }

        }

    </style>

</head>

<body>

<main class="welcome-page">

    <section class="welcome-card">

        <!-- LEFT SIDE -->

        <div class="welcome-copy">

            <!-- LOGO -->

            <div class="brand">

                <span class="brand-mark" aria-hidden="true">
                    <i></i>
                    <i></i>
                    <i></i>
                    <i></i>
                </span>

                <span>WellnessHub</span>

            </div>

            <!-- WELCOME MESSAGE -->

            <div class="welcome-message">

                <span class="eyebrow">
                    A calmer space for students
                </span>

                <h1>
                    Your wellbeing<br>
                    <span>starts here.</span>
                </h1>

                <p class="intro">
                    Take a moment for yourself.
                    Track your mood, reflect privately,
                    and find support when you need it —
                    all in one caring space.
                </p>

                <!-- BUTTONS -->

                <div class="actions">

                    <a
                        class="action action-primary"
                        href="login.php">

                        Log in

                        <svg
                            viewBox="0 0 24 24"
                            fill="none"
                            aria-hidden="true">

                            <path
                                d="M4 12h16m-6-6 6 6-6 6"
                                stroke="currentColor"
                                stroke-width="2"
                                stroke-linecap="round"
                                stroke-linejoin="round">
                            </path>

                        </svg>

                    </a>

                    <a
                        class="action action-secondary"
                        href="register.php">

                        Create account

                    </a>

                </div>

                <p class="subnote">
                    New to WellnessHub?
                    Create your student account to begin.
                </p>

            </div>

            <!-- FEATURES -->

            <div class="features">

                <span>
                    <b>◷</b> Mood tracking
                </span>

                <span>
                    <b>✎</b> Private journal
                </span>

                <span>
                    <b>♡</b> Peer support
                </span>

            </div>

        </div>

        <!-- RIGHT SIDE -->

        <div class="welcome-art" aria-hidden="true">

            <div class="art-heading">
                A gentle reminder: you are not alone.
            </div>

            <div class="floating-note note-one">

                <b>✓</b>

                One day at a time

            </div>

            <!-- DECORATIVE MOOD CARD -->

            <div class="mood-card">

                <div class="mood-top">

                    <span class="mood-icon">☘</span>

                    Daily check-in

                    <span class="mood-today">
                        TODAY
                    </span>

                </div>

                <h2>How are you feeling?</h2>

                <p>
                    It's okay to pause and check in.
                </p>

                <div class="mood-options">

                    <span class="mood-option">
                        ☺
                        <small>Great</small>
                    </span>

                    <span class="mood-option">
                        ☀
                        <small>Good</small>
                    </span>

                    <span class="mood-option selected">
                        ◡
                        <small>Okay</small>
                    </span>

                    <span class="mood-option">
                        ☁
                        <small>Low</small>
                    </span>

                    <span class="mood-option">
                        ♡
                        <small>Help</small>
                    </span>

                </div>

                <div class="mood-bottom">

                    <span>
                        Small steps make a difference.
                    </span>

                    <span class="heart">
                        ♥
                    </span>

                </div>

            </div>

            <div class="floating-note note-two">

                <b>♥</b>

                You've got this

            </div>

            <div class="footer-note">
                Breathe • Reflect • Grow
            </div>

        </div>

    </section>

</main>

</body>

</html>