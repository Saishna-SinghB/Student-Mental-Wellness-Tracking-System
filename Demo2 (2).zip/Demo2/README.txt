WellnessHub Complete HTML/CSS Preview

Open index.html first.

Student screens:
- index.html
- login.html
- register.html
- dashboard.html
- mood-tracking.html
- journal.html
- self-help-library.html
- achievements.html
- counselling-booking.html
- peer-support.html
- notifications.html
- settings.html
- weekly-summary.html

Counsellor screens:
- counsellor-login.html
- counsellor-dashboard.html
- risk-alerts.html
- counsellor-appointments.html
- counsellor-students.html
- counsellor-resources.html

Admin screens:
- admin-dashboard.html
- admin-reports.html
- admin-users.html
- admin-counsellors.html
- system-logs.html
- admin-settings.html

For PHP, rename .html files to .php and keep this in the <head> of every page:
<link rel="stylesheet" href="css/style.css" />


=====================================================================
SETUP (XAMPP) — read this first
=====================================================================
1. Copy this folder to C:\xampp\htdocs\ and start Apache + MySQL.
2. In phpMyAdmin create a database called  wellnesshub  (utf8mb4) and
   import wellnesshub.sql into it.
3. Edit mail-config.php with a real Gmail address + app password to send
   password-reset emails. Until then, on localhost the reset code is shown
   on the verification step (development mode only).
4. Open login.php. ONE login page is used by everyone: the system sends each
   account to the right place (student, counsellor or admin dashboard).
   The SQL file creates demo accounts and sample data:
     Admin        Admin@Richfield.ac.za          /  @Admin2026
     Counsellor   naidoo@richfield.ac.za         /  12345678
     Counsellors  zanele.khumalo@mindspace.example, pieter@counselcare.example,
                  aisha.patel@richfield.ac.za, sibusiso@talkhub.example
                                                 /  123@Counsellor
     Students     402410101@my.richfield.ac.za ... 402410112@my.richfield.ac.za
                                                 /  Student@123
   Counsellors can be external to Richfield (any email address works).
   New students register themselves on register.php.
5. CHANGE these passwords on any shared or live server. They are public
   defaults. (Admin > Users > edit user > reset password.)

Already imported an older wellnesshub.sql? Drop the database, create an empty one
named wellnesshub, and import the latest wellnesshub.sql (it now includes demo data).
If you only need the admin back, run add_default_accounts.sql once instead.

Something not working on a new PC? Open  http://localhost/<folder>/check-setup.php
It shows exactly what is wrong (PHP version, database name/password, missing tables, admin account).
Delete check-setup.php when done.
