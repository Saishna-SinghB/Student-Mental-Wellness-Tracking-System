
<?php
require_once __DIR__ . '/admin-auth.php';

// Administrator details
$adminName = trim(
    (string)($_SESSION['full_name'] ?? 'Admin')
);

$firstName = explode(
    ' ',
    $adminName !== '' ? $adminName : 'Admin'
)[0];

$adminInitial = strtoupper(
    substr($firstName, 0, 1)
);

// Administrator profile picture
$adminPicture = $_SESSION['profile_picture'] ?? '';

$hasPicture = is_string($adminPicture) && preg_match(
    '#^data:image/(png|jpe?g|gif|webp);base64,[A-Za-z0-9+/=]+$#',
    $adminPicture
);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Admin Dashboard — WellnessHub</title>

    <link rel="stylesheet" href="css/style.css">

    <style>

        /* ADMIN DASHBOARD */

        .admin-main,
        .admin-main h1 {
            color: #ffffff;
        }

        .admin-main .eyebrow,
        .admin-main .page-subtitle {
            color: #e9d5ff !important;
        }

        /* DASHBOARD CARDS */

        .admin-main .kpi-card,
        .admin-main .panel {
            color: #ffffff !important;
            background: #35164b !important;
            border: 1px solid #694084 !important;
        }

        .admin-main .kpi-card span {
            color: #ead5ff !important;
        }

        .admin-main .kpi-card strong,
        .admin-main .panel h2 {
            color: #ffffff !important;
        }

        /* SIDEBAR */

        .admin-sidebar .side-nav a {
            color: #f5eaff;
        }

        .admin-sidebar .side-nav a span {
            color: #e7ccff;
        }

        .admin-sidebar .side-nav a.active,
        .admin-sidebar .side-nav a.active span {
            color: #ffffff;
        }

        /* ADMIN PROFILE */

        .admin-profile-link {
            display: flex !important;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            text-decoration: none;
        }

        .admin-profile-link img {
            display: block;
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-radius: 50%;
        }

        .admin-profile-link:hover {
            box-shadow: 0 0 0 4px #a78bfa88;
        }

        .admin-profile-link:focus-visible {
            outline: 3px solid #efd4ff;
            outline-offset: 3px;
        }

        /* INTERACTIVE CHART PANELS */

        .interactive-charts > .panel {
            min-width: 0;
        }

        .chart-area {
            position: relative;
            width: 100%;
            height: 330px;
            margin-top: 14px;
        }

        .chart-area canvas {
            display: block;
            max-width: 100%;
        }

        .chart-area [hidden] {
            display: none !important;
        }

        .chart-empty {
            text-align: center;
            color: #f0ddff;
            padding: 40px 12px;
            font-weight: 700;
        }

        /* REFRESH BUTTON */

        #refreshCharts {
            background: #7040d2;
            border: 1px solid #ac8bff;
            color: #ffffff;
            padding: 10px 16px;
            border-radius: 10px;
            cursor: pointer;
            margin: 5px 0 14px;
            font-weight: 700;
        }

        #refreshCharts:hover {
            background: #8859e8;
        }

        #refreshCharts:disabled {
            opacity: 0.65;
            cursor: wait;
        }

        /* ERROR MESSAGE */

        #dashboardError {
            background: #773253;
            border: 1px solid #ff9bb7;
            border-radius: 12px;
            padding: 12px 16px;
            color: #ffffff;
            margin: 4px 0 16px;
        }

        #dashboardError[hidden] {
            display: none;
        }

        /* MOBILE DESIGN */

        @media (max-width: 650px) {

            .chart-area {
                height: 300px;
            }

        }

    </style>

</head>

<body class="app-body admin-body">

<div class="app-shell admin-shell">

    <!-- ADMIN SIDEBAR -->

    <aside class="sidebar admin-sidebar">

        <a class="brand-mini sidebar-brand" href="index.php">
            <span class="mini-leaf" aria-hidden="true">☘</span>
            <span>WellnessHub</span>
        </a>

        <nav class="side-nav" aria-label="Admin navigation">

            <a class="active" href="admin-dashboard.php">
                <span>▣</span> Dashboard
            </a>

            <a href="admin-users.php">
                <span>👥</span> Users
            </a>

            <a href="admin-counsellors.php">
                <span>♡</span> Counsellors
            </a>

            <a href="admin-reports.php">
                <span>📊</span> Reports
            </a>

            <a href="system-logs.php">
                <span>☷</span> System Logs
            </a>

            <a href="admin-settings.php">
                <span>⚙</span> Settings
            </a>

            <a href="logout.php">
                <span>↪</span> Logout
            </a>

        </nav>

    </aside>

    <!-- MAIN DASHBOARD -->

    <main class="dashboard-main admin-main">

        <!-- HEADER -->

        <header class="topbar admin-topbar">

            <div>

                <p class="eyebrow">
                    Admin Side
                </p>

                <h1>
                    Admin Dashboard
                </h1>

                <p class="page-subtitle">
                    Overview of the WellnessHub platform.
                </p>

            </div>

            <div class="topbar-actions">

                <a
                    class="icon-btn admin-icon"
                    href="system-logs.php"
                    aria-label="System logs"
                >
                    🔔
                </a>

                <!-- ADMIN PROFILE -->

                <a
                    href="admin-profile.php"
                    class="avatar admin-avatar admin-profile-link"
                    aria-label="Open My Profile"
                    title="View My Profile"
                >

                    <?php if ($hasPicture): ?>

                        <img
                            src="<?= htmlspecialchars(
                                $adminPicture,
                                ENT_QUOTES,
                                'UTF-8'
                            ) ?>"
                            alt="My Profile"
                        >

                    <?php else: ?>

                        <?= htmlspecialchars(
                            $adminInitial,
                            ENT_QUOTES,
                            'UTF-8'
                        ) ?>

                    <?php endif; ?>

                </a>

            </div>

        </header>

        <!-- DASHBOARD CONTENT -->

        <section class="page-grid">

            <!-- KPI CARDS -->

            <div class="kpi-grid">

                <div class="kpi-card">
                    <span>Total Users</span>
                    <strong id="kpiTotalUsers">–</strong>
                </div>

                <div class="kpi-card">
                    <span>Active Students</span>
                    <strong id="kpiActiveStudents">–</strong>
                </div>

                <div class="kpi-card">
                    <span>Counsellors</span>
                    <strong id="kpiCounsellors">–</strong>
                </div>

                <div class="kpi-card">
                    <span>Sessions This Month</span>
                    <strong id="kpiSessions">–</strong>
                </div>

            </div>

            <!-- REFRESH BUTTON -->

            <div>

                <button
                    type="button"
                    id="refreshCharts"
                >
                    ↻ Refresh Charts
                </button>

                <p
                    id="dashboardError"
                    role="alert"
                    hidden
                ></p>

            </div>

            <!-- INTERACTIVE CHARTS -->

            <section
                class="two-col interactive-charts"
                aria-label="Interactive dashboard charts"
            >

                <!-- USER GROWTH -->

                <article class="panel">

                    <h2>User Growth</h2>

                    <div class="chart-area">

                        <canvas
                            id="growthChart"
                            role="img"
                            aria-label="Monthly user registrations"
                        ></canvas>

                        <p
                            id="growthEmpty"
                            class="chart-empty"
                            hidden
                        ></p>

                    </div>

                </article>

                <!-- JOURNAL MOOD BREAKDOWN -->

                <article class="panel">

                    <h2>Journal Mood Breakdown</h2>

                    <div class="chart-area">

                        <canvas
                            id="journalMoodChart"
                            role="img"
                            aria-label="Journal mood distribution"
                        ></canvas>

                        <p
                            id="moodEmpty"
                            class="chart-empty"
                            hidden
                        ></p>

                    </div>

                </article>

            </section>

        </section>

    </main>

</div>

<!-- CHART.JS LIBRARY -->

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.6.1/dist/chart.umd.min.js"></script>

<!-- DASHBOARD JAVASCRIPT -->

<script>

// CHART COLOURS

const moodPalette = {
    Grateful: '#5FF1AF',
    Calm: '#70D9FF',
    Hopeful: '#C9A5FF',
    Anxious: '#FFD17A',
    Frustrated: '#FF8FA5'
};

let growthInstance = null;
let moodInstance = null;

// LOAD DASHBOARD

document.addEventListener('DOMContentLoaded', () => {

    document.getElementById('refreshCharts')
        .addEventListener('click', loadDashboard);

    loadDashboard();

});

// ERROR MESSAGE

function showError(message) {

    const el = document.getElementById('dashboardError');

    el.hidden = false;
    el.textContent = message;

}

// EMPTY CHART MESSAGE

function showEmpty(canvasId, messageId, message) {

    document.getElementById(canvasId).hidden = true;

    const empty = document.getElementById(messageId);

    empty.textContent = message;
    empty.hidden = false;

}

// SHOW CHART CANVAS

function showCanvas(canvasId, messageId) {

    document.getElementById(canvasId).hidden = false;
    document.getElementById(messageId).hidden = true;

}

// REMOVE OLD CHARTS

function destroyCharts() {

    if (growthInstance) {
        growthInstance.destroy();
        growthInstance = null;
    }

    if (moodInstance) {
        moodInstance.destroy();
        moodInstance = null;
    }

}

// FETCH DATABASE INFORMATION

async function loadDashboard() {

    const button = document.getElementById('refreshCharts');

    document.getElementById('dashboardError').hidden = true;

    button.disabled = true;
    button.textContent = 'Loading…';

    try {

        if (typeof Chart === 'undefined') {

            throw new Error(
                'Chart.js did not load. Check your internet connection.'
            );

        }

        const response = await fetch(
            'api/demoAPI.php?action=admin_dashboard_summary',
            {
                credentials: 'same-origin',
                cache: 'no-store',
                headers: {
                    Accept: 'application/json'
                }
            }
        );

        if (!response.ok) {

            throw new Error(
                'API request failed (HTTP ' +
                response.status + ')'
            );

        }

        const result = await response.json();

        if (
            !result ||
            result.success !== true ||
            !result.data
        ) {

            throw new Error(
                result?.message ||
                'The dashboard API returned no data.'
            );

        }

        const d = result.data;
        const k = d.kpis || {};

        // UPDATE KPI CARDS

        const fields = {
            kpiTotalUsers: k.total_users,
            kpiActiveStudents: k.active_students,
            kpiCounsellors: k.counsellor_accounts,
            kpiSessions: k.sessions_this_month
        };

        Object.entries(fields).forEach(([id, value]) => {

            const number = Number(value);

            document.getElementById(id).textContent =
                value != null &&
                Number.isFinite(number)
                    ? number.toLocaleString()
                    : '–';

        });

        // DRAW BOTH CHARTS

        drawGrowth(
            Array.isArray(d.user_growth)
                ? d.user_growth
                : []
        );

        drawMoodChart(
            Array.isArray(d.emotion_breakdown)
                ? d.emotion_breakdown
                : []
        );

    } catch (error) {

        console.error(
            'Dashboard load failed:',
            error
        );

        destroyCharts();

        showEmpty(
            'growthChart',
            'growthEmpty',
            'Could not load growth data.'
        );

        showEmpty(
            'journalMoodChart',
            'moodEmpty',
            'Could not load journal mood data.'
        );

        showError(error.message);

    } finally {

        button.disabled = false;
        button.textContent = '↻ Refresh Charts';

    }

}

// USER GROWTH CHART

function drawGrowth(rows) {

    // REMOVE PREVIOUS CHART

    if (growthInstance) {

        growthInstance.destroy();
        growthInstance = null;

    }

    if (!rows.length) {

        showEmpty(
            'growthChart',
            'growthEmpty',
            'No registrations to display yet.'
        );

        return;

    }

    showCanvas('growthChart', 'growthEmpty');

    // MONTHS

    const labels = rows.map(row =>
        String(row.label ?? row.month ?? '')
    );

    // USER COUNTS

    const counts = rows.map(row => {

        const number = Number(
            row.cnt ?? row.count ?? 0
        );

        return Number.isFinite(number)
            ? Math.max(0, number)
            : 0;

    });

    // INTERACTIVE LINE CHART

    growthInstance = new Chart(
        document.getElementById('growthChart'),
        {

            type: 'line',

            data: {

                labels: labels,

                datasets: [{

                    label: 'New users',

                    data: counts,

                    borderColor: '#ff9fdf',

                    backgroundColor: 'rgba(255,159,223,.16)',

                    borderWidth: 3,

                    fill: true,

                    tension: 0.38,

                    pointRadius: 5,

                    pointHoverRadius: 8,

                    pointBackgroundColor: '#ffffff',

                    pointBorderColor: '#ff9fdf',

                    pointBorderWidth: 3

                }]

            },

            options: {

                responsive: true,

                maintainAspectRatio: false,

                interaction: {
                    mode: 'index',
                    intersect: false
                },

                animation: {
                    duration: 750
                },

                plugins: {

                    legend: {

                        display: true,

                        labels: {
                            color: '#f8edff',
                            font: {
                                size: 13
                            }
                        }

                    },

                    tooltip: {

                        backgroundColor: '#101e34',

                        titleColor: '#ffffff',

                        bodyColor: '#ffffff',

                        callbacks: {

                            label: context =>
                                context.parsed.y + ' new users'

                        }

                    }

                },

                scales: {

                    x: {

                        ticks: {
                            color: '#f7eaff'
                        },

                        grid: {
                            color: 'rgba(255,255,255,.10)'
                        }

                    },

                    y: {

                        beginAtZero: true,

                        suggestedMax:
                            Math.max(1, ...counts) + 1,

                        ticks: {
                            color: '#f7eaff',
                            stepSize: 1,
                            precision: 0
                        },

                        grid: {
                            color: 'rgba(255,255,255,.17)'
                        }

                    }

                }

            }

        }
    );

}

// CALCULATE PERCENTAGES

function roundPercentages(counts) {

    const total = counts.reduce(
        (sum, count) => sum + count,
        0
    );

    if (!total) {
        return counts.map(() => 0);
    }

    const exact = counts.map(
        count => count * 100 / total
    );

    const rounded = exact.map(Math.floor);

    const ranked = exact.map(
        (value, i) => ({
            i,
            fraction: value - Math.floor(value)
        })
    ).sort(
        (a, b) =>
            b.fraction - a.fraction ||
            a.i - b.i
    );

    const remainder = 100 - rounded.reduce(
        (a, b) => a + b,
        0
    );

    for (let i = 0; i < remainder; i++) {

        rounded[ranked[i].i]++;

    }

    return rounded;

}

// JOURNAL MOOD BREAKDOWN CHART

function drawMoodChart(rows) {

    // REMOVE PREVIOUS CHART

    if (moodInstance) {

        moodInstance.destroy();
        moodInstance = null;

    }

    // GET SAVED JOURNAL MOODS

    const moods = rows.map(row => ({

        name: String(
            row.emotion ?? ''
        ).trim(),

        count: Number(
            row.count ?? row.cnt ?? 0
        )

    })).filter(row =>
        row.name &&
        Number.isFinite(row.count) &&
        row.count > 0
    );

    if (!moods.length) {

        showEmpty(
            'journalMoodChart',
            'moodEmpty',
            'No journal entries with a mood tag yet.'
        );

        return;

    }

    showCanvas(
        'journalMoodChart',
        'moodEmpty'
    );

    const counts = moods.map(
        row => row.count
    );

    const total = counts.reduce(
        (a, b) => a + b,
        0
    );

    const percentages = roundPercentages(counts);

    // MOOD COLOURS

    const colours = moods.map(row => {

        const match = Object.keys(moodPalette).find(
            key =>
                key.toLowerCase() ===
                row.name.toLowerCase()
        );

        return moodPalette[match] || '#F0B9FF';

    });

    // SHOW TOTAL ENTRIES INSIDE CHART

    const centreText = {

        id: 'journalCentreText',

        afterDraw(chart) {

            const { ctx, chartArea } = chart;

            const x =
                (chartArea.left + chartArea.right) / 2;

            const y =
                (chartArea.top + chartArea.bottom) / 2;

            ctx.save();

            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';

            ctx.fillStyle = '#ffffff';

            ctx.font = 'bold 17px Arial, sans-serif';

            ctx.fillText(
                total.toLocaleString() + ' entries',
                x,
                y
            );

            ctx.restore();

        }

    };

    // INTERACTIVE DOUGHNUT CHART

    moodInstance = new Chart(
        document.getElementById('journalMoodChart'),
        {

            type: 'doughnut',

            data: {

                labels: moods.map(
                    (row, i) =>
                        row.name + ' ' +
                        percentages[i] + '%'
                ),

                datasets: [{

                    label: 'Journal entries',

                    data: counts,

                    backgroundColor: colours,

                    borderWidth: 0,

                    hoverOffset: 14,

                    spacing: 2

                }]

            },

            plugins: [centreText],

            options: {

                responsive: true,

                maintainAspectRatio: false,

                cutout: '57%',

                animation: {
                    duration: 850
                },

                plugins: {

                    legend: {

                        display: true,

                        position: 'top',

                        labels: {

                            color: '#ffffff',

                            usePointStyle: true,

                            pointStyle: 'circle',

                            padding: 15,

                            font: {
                                size: 13,
                                weight: 'bold'
                            }

                        }

                    },

                    tooltip: {

                        backgroundColor: '#101e34',

                        titleColor: '#ffffff',

                        bodyColor: '#ffffff',

                        callbacks: {

                            label: context => {

                                const i = context.dataIndex;

                                return (
                                    moods[i].name + ': ' +
                                    counts[i] + ' entries (' +
                                    percentages[i] + '%)'
                                );

                            }

                        }

                    }

                }

            }

        }
    );

}

</script>

</body>
</html>
