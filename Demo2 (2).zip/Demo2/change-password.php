<?php
require_once __DIR__ . '/auth-check.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Change Password — WellnessHub</title>

    <link rel="stylesheet" href="css/style.css">

    <style>

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #0d192b;
            color: white;
        }

        .password-container {
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
            box-sizing: border-box;
        }

        .password-card {
            background: #172840;
            width: 100%;
            max-width: 500px;
            padding: 35px;
            border-radius: 20px;
            border: 1px solid #2b435e;
            box-sizing: border-box;
        }

        .password-card h1 {
            text-align: center;
            margin-bottom: 10px;
            color: white;
        }

        .password-card p {
            text-align: center;
            color: #a8c3df;
            margin-bottom: 25px;
        }

        .password-field {
            margin-bottom: 22px;
        }

        .password-field label {
            display: block;
            margin-bottom: 10px;
            font-weight: bold;
            color: white;
        }

        .input-wrapper {
            position: relative;
        }

        .input-wrapper input {
            width: 100%;
            height: 55px;
            padding: 12px 55px 12px 15px;
            background: #0d1b2c;
            border: 1px solid #34516d;
            border-radius: 10px;
            color: white;
            font-size: 16px;
            box-sizing: border-box;
        }

        .input-wrapper input:focus {
            outline: none;
            border-color: #55b77d;
        }

        .eye-button {
            position: absolute;
            right: 12px;
            top: 50%;
            transform: translateY(-50%);
            background: transparent;
            border: none;
            color: #69b9ff;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 7px;
        }

        .eye-button svg {
            width: 23px;
            height: 23px;
            fill: none;
            stroke: currentColor;
            stroke-width: 2;
            stroke-linecap: round;
            stroke-linejoin: round;
        }

        .password-rules {
            background: #183b2c;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 22px;
            color: #d2f1df;
            font-size: 14px;
            line-height: 1.7;
        }

        .update-btn {
            width: 100%;
            padding: 16px;
            border: none;
            border-radius: 10px;
            background: #38895f;
            color: white;
            font-size: 17px;
            font-weight: bold;
            cursor: pointer;
        }

        .update-btn:hover {
            background: #48a873;
        }

        .update-btn:disabled {
            opacity: 0.6;
            cursor: not-allowed;
        }

        .back-link {
            display: block;
            margin-top: 22px;
            text-align: center;
            color: #8ec7ff;
            text-decoration: none;
        }

        .message {
            margin-bottom: 15px;
            text-align: center;
            font-size: 14px;
            font-weight: bold;
        }

        .message.error {
            color: #ff9292;
        }

        .message.success {
            color: #7ee4a5;
        }

    </style>
</head>

<body>

<div class="password-container">

    <div class="password-card">

        <h1>Change Password</h1>

        <p>
            Update your WellnessHub account password.
        </p>

        <form id="changePasswordForm">

            <!-- CURRENT PASSWORD -->

            <div class="password-field">

                <label for="currentPassword">
                    Current Password
                </label>

                <div class="input-wrapper">

                    <input
                        type="password"
                        id="currentPassword"
                        placeholder="Enter current password"
                        autocomplete="current-password"
                        required
                    >

                    <button
                        type="button"
                        class="eye-button"
                        data-target="currentPassword"
                        aria-label="Show password">
                    </button>

                </div>

            </div>

            <!-- NEW PASSWORD -->

            <div class="password-field">

                <label for="newPassword">
                    New Password
                </label>

                <div class="input-wrapper">

                    <input
                        type="password"
                        id="newPassword"
                        placeholder="Enter new password"
                        autocomplete="new-password"
                        required
                    >

                    <button
                        type="button"
                        class="eye-button"
                        data-target="newPassword"
                        aria-label="Show password">
                    </button>

                </div>

            </div>

            <!-- CONFIRM PASSWORD -->

            <div class="password-field">

                <label for="confirmPassword">
                    Re-enter New Password
                </label>

                <div class="input-wrapper">

                    <input
                        type="password"
                        id="confirmPassword"
                        placeholder="Re-enter new password"
                        autocomplete="new-password"
                        required
                    >

                    <button
                        type="button"
                        class="eye-button"
                        data-target="confirmPassword"
                        aria-label="Show password">
                    </button>

                </div>

            </div>

            <!-- PASSWORD REQUIREMENTS -->

            <div class="password-rules">

                Your new password must contain:

                <ul>
                    <li>At least 8 characters</li>
                    <li>One uppercase letter</li>
                    <li>One special character (@, #, !, etc.)</li>
                </ul>

            </div>

            <!-- MESSAGE -->

            <div
                id="passwordMessage"
                class="message"
                role="status">
            </div>

            <!-- BUTTON -->

            <button
                type="submit"
                class="update-btn"
                id="updatePasswordBtn">

                Update Password

            </button>

        </form>

        <a href="settings.php" class="back-link">
            ← Back to Settings
        </a>

    </div>

</div>

<script>

    // SVG EYE ICONS (NO EMOJIS)

    const eyeOpen = `
        <svg viewBox="0 0 24 24" aria-hidden="true">
            <path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z"/>
            <circle cx="12" cy="12" r="3"/>
        </svg>
    `;

    const eyeClosed = `
        <svg viewBox="0 0 24 24" aria-hidden="true">
            <path d="M3 3l18 18"/>
            <path d="M10.6 5.1A11.2 11.2 0 0 1 12 5c6.5 0 10 7 10 7a15 15 0 0 1-3.2 4.1"/>
            <path d="M6.3 6.3C3.5 8.2 2 12 2 12s3.5 7 10 7c1.8 0 3.4-.5 4.8-1.3"/>
            <path d="M10 10a3 3 0 0 0 4 4"/>
        </svg>
    `;

    // SHOW AND HIDE PASSWORD

    document.querySelectorAll(".eye-button").forEach(button => {

        button.innerHTML = eyeOpen;

        button.addEventListener("click", function () {

            const input = document.getElementById(
                this.dataset.target
            );

            if (input.type === "password") {

                input.type = "text";
                this.innerHTML = eyeClosed;
                this.setAttribute("aria-label", "Hide password");

            } else {

                input.type = "password";
                this.innerHTML = eyeOpen;
                this.setAttribute("aria-label", "Show password");

            }

        });

    });


    // UPDATE PASSWORD

    document.getElementById("changePasswordForm")
        .addEventListener("submit", async function (event) {

            event.preventDefault();

            const currentPassword =
                document.getElementById("currentPassword").value;

            const newPassword =
                document.getElementById("newPassword").value;

            const confirmPassword =
                document.getElementById("confirmPassword").value;

            const message =
                document.getElementById("passwordMessage");

            const button =
                document.getElementById("updatePasswordBtn");

            message.textContent = "";
            message.className = "message";

            if (!currentPassword || !newPassword || !confirmPassword) {

                message.textContent = "Please complete all password fields.";
                message.classList.add("error");
                return;

            }

            if (newPassword !== confirmPassword) {

                message.textContent = "New passwords do not match.";
                message.classList.add("error");
                return;

            }

            if (
                newPassword.length < 8 ||
                !/[A-Z]/.test(newPassword) ||
                !/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(newPassword)
            ) {

                message.textContent =
                    "Password must have 8 characters, an uppercase letter and a special character.";

                message.classList.add("error");
                return;

            }

            button.disabled = true;
            button.textContent = "Updating...";

            try {

                const response = await fetch(
                    "api/demoAPI.php?action=change_password",
                    {
                        method: "POST",

                        headers: {
                            "Content-Type": "application/x-www-form-urlencoded"
                        },

                        body: new URLSearchParams({
                            current_password: currentPassword,
                            new_password: newPassword
                        })
                    }
                );

                const data = await response.json();

                if (data.success) {

                    message.textContent =
                        "Password updated successfully!";

                    message.classList.add("success");

                    document.getElementById(
                        "changePasswordForm"
                    ).reset();

                    document.querySelectorAll(".eye-button").forEach(eye => {
                        document.getElementById(eye.dataset.target).type = "password";
                        eye.innerHTML = eyeOpen;
                    });

                } else {

                    message.textContent = data.message ||
                        "Could not update password.";

                    message.classList.add("error");

                }

            } catch (error) {

                message.textContent =
                    "Could not reach the server.";

                message.classList.add("error");

            } finally {

                button.disabled = false;
                button.textContent = "Update Password";

            }

        });

</script>

</body>
</html>