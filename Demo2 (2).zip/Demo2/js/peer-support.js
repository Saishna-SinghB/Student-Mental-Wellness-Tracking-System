// WELLNESSHUB PEER SUPPORT JAVASCRIPT

'use strict';

const PEER_API = 'api/demoAPI.php';

const CATEGORY_PILL = {
    Support: 'pill-purple',
    Vent: 'pill-orange',
    Advice: 'pill-blue',
    Encouragement: 'pill-green'
};

let currentTab = 'recent';


// ===================================
// API REQUESTS
// ===================================

async function peerRequest(action, options = {}) {

    const url = new URL(
        PEER_API,
        window.location.href
    );

    url.searchParams.set('action', action);

    if (options.query) {

        Object.entries(options.query).forEach(([key, value]) => {

            url.searchParams.set(key, String(value));

        });

    }

    const requestOptions = {
        credentials: 'same-origin'
    };

    if (options.body) {

        requestOptions.method = 'POST';

        requestOptions.headers = {
            'Content-Type': 'application/x-www-form-urlencoded'
        };

        requestOptions.body = new URLSearchParams(options.body);

    }

    let response;

    try {

        response = await fetch(
            url.toString(),
            requestOptions
        );

    } catch (error) {

        throw new Error(
            'Cannot connect to the server. Check Apache in XAMPP.'
        );

    }

    const responseText = await response.text();

    let result;

    try {

        result = JSON.parse(responseText);

    } catch (error) {

        console.error(
            'Invalid API response:',
            response.status,
            responseText.slice(0, 300)
        );

        if (response.status === 404) {

            throw new Error(
                'API file not found. Check api/demoAPI.php.'
            );

        }

        throw new Error(
            'Server error (HTTP ' + response.status + ').'
        );

    }

    if (!response.ok || !result.success) {

        throw new Error(
            result.message || 'Request failed.'
        );

    }

    return result.data || {};

}


// ===================================
// STATUS MESSAGES
// ===================================

function showPostMessage(message, type = '') {

    const element = document.getElementById('postMessage');

    element.textContent = message;

    element.className = 'peer-message';

    if (type) {
        element.classList.add(type);
    }

}


function showFeedMessage(message) {

    const feed = document.getElementById('postFeed');

    feed.innerHTML = '';

    const paragraph = document.createElement('p');

    paragraph.className = 'muted';

    paragraph.textContent = message;

    feed.appendChild(paragraph);

}


// ===================================
// TIME AGO
// ===================================

function timeAgo(dateString) {

    const then = new Date(
        String(dateString || '').replace(' ', 'T')
    );

    if (isNaN(then.getTime())) {
        return 'Recently';
    }

    const minutes = Math.max(
        0,
        Math.floor((Date.now() - then.getTime()) / 60000)
    );

    if (minutes < 1) return 'Just now';

    if (minutes < 60) return minutes + 'm ago';

    const hours = Math.floor(minutes / 60);

    if (hours < 24) return hours + 'h ago';

    const days = Math.floor(hours / 24);

    if (days < 7) return days + 'd ago';

    return then.toLocaleDateString();

}


// ===================================
// CREATE POST CARDS
// ===================================

function postCardEl(post) {

    const card = document.createElement('div');

    card.className = 'post-card';

    card.dataset.postId = post.post_id;


    // POST INFORMATION

    const meta = document.createElement('div');

    meta.className = 'post-meta';


    const author = document.createElement('span');

    author.textContent = post.is_mine
        ? 'Anonymous Student (You)'
        : 'Anonymous Student';


    const category = document.createElement('span');

    category.className =
        'pill ' +
        (CATEGORY_PILL[post.category] || 'pill-purple');

    category.textContent = post.category;


    meta.appendChild(author);

    meta.appendChild(category);


    // POST BODY

    const body = document.createElement('p');

    body.textContent = post.content;


    // ACTIONS

    const actions = document.createElement('div');

    actions.className = 'post-actions';


    // LIKE BUTTON

    const likeButton = document.createElement('button');

    likeButton.type = 'button';

    likeButton.className =
        'like-btn' + (post.liked_by_me ? ' liked' : '');

    likeButton.textContent =
        (post.liked_by_me ? '♥ ' : '♡ ') +
        post.like_count;

    likeButton.addEventListener('click', () => {

        toggleLike(post.post_id, likeButton);

    });


    // REPLY BUTTON

    const replyButton = document.createElement('button');

    replyButton.type = 'button';

    replyButton.textContent =
        '💬 ' + post.reply_count;

    replyButton.addEventListener('click', () => {

        toggleReplies(
            post.post_id,
            card,
            replyButton
        );

    });


    // REPORT BUTTON

    const reportButton = document.createElement('button');

    reportButton.type = 'button';

    reportButton.textContent = 'Report';

    reportButton.addEventListener('click', () => {

        reportPost(post.post_id, reportButton);

    });


    // POST DATE

    const time = document.createElement('span');

    time.className = 'muted';

    time.textContent = timeAgo(post.created_at);


    actions.appendChild(likeButton);

    actions.appendChild(replyButton);

    actions.appendChild(reportButton);

    actions.appendChild(time);


    // REPLY THREAD

    const thread = document.createElement('div');

    thread.className = 'reply-thread';


    // COMPLETE CARD

    card.appendChild(meta);

    card.appendChild(body);

    card.appendChild(actions);

    card.appendChild(thread);

    return card;

}


// ===================================
// LOAD POST FEED
// ===================================

async function loadFeed() {

    const feed = document.getElementById('postFeed');

    const selectedTab = currentTab;

    showFeedMessage('Loading posts...');

    try {

        const data = await peerRequest(
            'post_list',
            {
                query: {
                    tab: selectedTab
                }
            }
        );

        if (selectedTab !== currentTab) {
            return;
        }

        if (!Array.isArray(data.posts)) {

            throw new Error(
                'The server did not return a posts list.'
            );

        }

        feed.innerHTML = '';

        if (data.posts.length === 0) {

            showFeedMessage(
                selectedTab === 'mine'
                    ? "You haven't posted anything yet."
                    : 'No posts yet. Be the first to share.'
            );

            return;

        }

        data.posts.forEach(post => {

            feed.appendChild(
                postCardEl(post)
            );

        });

    } catch (error) {

        console.error('Feed error:', error);

        if (selectedTab === currentTab) {

            showFeedMessage(error.message);

        }

    }

}


// ===================================
// LIKE POSTS
// ===================================

async function toggleLike(postId, likeButton) {

    likeButton.disabled = true;

    try {

        const data = await peerRequest(
            'post_like',
            {
                body: {
                    post_id: postId
                }
            }
        );

        likeButton.classList.toggle(
            'liked',
            Boolean(data.liked_by_me)
        );

        likeButton.textContent =
            (data.liked_by_me ? '♥ ' : '♡ ') +
            data.like_count;

    } catch (error) {

        alert(error.message);

    } finally {

        likeButton.disabled = false;

    }

}


// ===================================
// REPLIES
// ===================================

async function toggleReplies(postId, card, replyButton) {

    const thread = card.querySelector('.reply-thread');

    if (thread.style.display === 'block') {

        thread.style.display = 'none';

        return;

    }

    thread.style.display = 'block';

    if (thread.dataset.loaded === 'true') {
        return;
    }

    thread.textContent = 'Loading replies...';

    try {

        const data = await peerRequest(
            'post_reply_list',
            {
                query: {
                    post_id: postId
                }
            }
        );

        if (!Array.isArray(data.replies)) {

            throw new Error(
                'The server did not return replies.'
            );

        }

        thread.innerHTML = '';


        // EXISTING REPLIES

        if (data.replies.length === 0) {

            const empty = document.createElement('p');

            empty.className = 'muted';

            empty.textContent = 'No replies yet.';

            thread.appendChild(empty);

        } else {

            data.replies.forEach(reply => {

                const item = document.createElement('div');

                item.className = 'reply-item';

                item.textContent =
                    'Anonymous Student: ' + reply.content;

                thread.appendChild(item);

            });

        }


        // REPLY INPUT

        const inputWrap = document.createElement('div');

        inputWrap.className = 'reply-input';


        const input = document.createElement('input');

        input.type = 'text';

        input.placeholder = 'Write a reply...';

        input.maxLength = 1000;


        const sendButton = document.createElement('button');

        sendButton.type = 'button';

        sendButton.className = 'btn btn-primary btn-small';

        sendButton.textContent = 'Reply';


        // SUBMIT REPLY

        async function submitReply() {

            const text = input.value.trim();

            if (!text) return;

            sendButton.disabled = true;

            try {

                const result = await peerRequest(
                    'post_reply_create',
                    {
                        body: {
                            post_id: postId,
                            content: text
                        }
                    }
                );


                const emptyMessage =
                    thread.querySelector('p.muted');

                if (
                    emptyMessage &&
                    emptyMessage.textContent === 'No replies yet.'
                ) {

                    emptyMessage.remove();

                }


                const replyItem = document.createElement('div');

                replyItem.className = 'reply-item';

                replyItem.textContent =
                    'Anonymous Student (You): ' +
                    result.content;

                thread.insertBefore(
                    replyItem,
                    inputWrap
                );

                input.value = '';


                const count = parseInt(
                    replyButton.textContent.replace(/[^0-9]/g, ''),
                    10
                ) || 0;

                replyButton.textContent =
                    '💬 ' + (count + 1);

            } catch (error) {

                alert(error.message);

            } finally {

                sendButton.disabled = false;

            }

        }


        sendButton.addEventListener('click', submitReply);

        input.addEventListener('keydown', event => {

            if (event.key === 'Enter') {

                event.preventDefault();

                submitReply();

            }

        });


        inputWrap.appendChild(input);

        inputWrap.appendChild(sendButton);

        thread.appendChild(inputWrap);

        thread.dataset.loaded = 'true';

    } catch (error) {

        thread.textContent = error.message;

    }

}


// ===================================
// REPORT POSTS
// ===================================

async function reportPost(postId, reportButton) {

    if (!confirm('Report this post to moderators?')) {
        return;
    }

    reportButton.disabled = true;

    try {

        await peerRequest(
            'post_report',
            {
                body: {
                    post_id: postId
                }
            }
        );

        reportButton.textContent = 'Reported';

        reportButton.style.opacity = '0.5';

        alert('Post reported successfully.');

    } catch (error) {

        alert(error.message);

        reportButton.disabled = false;

    }

}


// ===================================
// PAGE EVENTS
// ===================================

document.addEventListener('DOMContentLoaded', () => {

    // LOAD POSTS

    loadFeed();


    // RECENT / POPULAR / MY POSTS

    document.querySelectorAll('#feedTabs .tab-btn')
        .forEach(tab => {

            tab.addEventListener('click', () => {

                document.querySelectorAll('#feedTabs .tab-btn')
                    .forEach(other => {

                        other.classList.remove('active');

                    });

                tab.classList.add('active');

                currentTab = tab.dataset.tab;

                loadFeed();

            });

        });


    // CREATE ANONYMOUS POST

    const postButton = document.getElementById('postBtn');

    const contentInput = document.getElementById('postContent');

    const categoryInput = document.getElementById('postCategory');


    postButton.addEventListener('click', async () => {

        const content = contentInput.value.trim();

        if (!content) {

            showPostMessage(
                'Write something before posting.',
                'error'
            );

            contentInput.focus();

            return;

        }

        postButton.disabled = true;

        postButton.textContent = 'Posting...';

        showPostMessage('');


        try {

            await peerRequest(
                'post_create',
                {
                    body: {
                        content: content,
                        category: categoryInput.value
                    }
                }
            );


            // CLEAR FORM

            contentInput.value = '';


            // RETURN TO RECENT POSTS

            currentTab = 'recent';

            document.querySelectorAll('#feedTabs .tab-btn')
                .forEach(tab => {

                    tab.classList.toggle(
                        'active',
                        tab.dataset.tab === 'recent'
                    );

                });


            // RELOAD POSTS

            await loadFeed();

            showPostMessage(
                'Your post was shared anonymously.',
                'success'
            );

        } catch (error) {

            showPostMessage(
                error.message,
                'error'
            );

        } finally {

            postButton.disabled = false;

            postButton.textContent = 'Post Anonymously';

        }

    });

});