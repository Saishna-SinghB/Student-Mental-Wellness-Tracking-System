
<?php
// ============================================
// WELLNESSHUB - STUDENT ACHIEVEMENTS
// ============================================

// START SESSION
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// CHECK STUDENT LOGIN
if (empty($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// DATABASE CONNECTION
require_once __DIR__ . '/demoDB.php';

date_default_timezone_set('Africa/Johannesburg');

// ESCAPE OUTPUT
function achE($value): string {
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES | ENT_SUBSTITUTE,
        'UTF-8'
    );
}

// COUNT STUDENT ACTIVITY
function achCount(
    PDO $db,
    string $table,
    int $userId,
    string $extra = ''
): int {
    $statement = $db->prepare(
        "SELECT COUNT(*)
         FROM {$table}
         WHERE user_id = :uid {$extra}"
    );

    $statement->execute([
        ':uid' => $userId
    ]);

    return (int)$statement->fetchColumn();
}

// ============================================
// FIND COUNSELLING BOOKING PAGE
// ============================================

$bookingPage = null;

$bookingCandidates = [
    'booking.php',
    'bookings.php',
    'counselling.php',
    'counseling.php',
    'counselling-booking.php',
    'book-session.php',
    'book-appointment.php',
    'book-counselling.php',
    'booking.html'
];

foreach ($bookingCandidates as $candidate) {
    if (is_file(__DIR__ . '/' . $candidate)) {
        $bookingPage = $candidate;
        break;
    }
}

// ============================================
// STUDENT INFORMATION
// ============================================

$userId = (int)$_SESSION['user_id'];

$fullName = trim(
    (string)($_SESSION['full_name'] ?? 'Student')
);

$initial = strtoupper(
    substr($fullName ?: 'Student', 0, 1)
);

// DEFAULT VALUES
$checkins = 0;
$journals = 0;
$posts = 0;
$replies = 0;
$bookings = 0;

$activeDays = 0;
$currentStreak = 0;
$bestStreak = 0;

$error = false;

// ============================================
// DATABASE STATISTICS
// ============================================

try {

    if (!isset($pdo) || !($pdo instanceof PDO)) {
        throw new RuntimeException(
            'Database connection unavailable.'
        );
    }

    // MOOD CHECK-INS
    $checkins = achCount(
        $pdo,
        'mood_checkins',
        $userId
    );

    // JOURNAL ENTRIES
    $journals = achCount(
        $pdo,
        'journal_entries',
        $userId
    );

    // PEER SUPPORT POSTS
    $posts = achCount(
        $pdo,
        'posts',
        $userId
    );

    // PEER SUPPORT REPLIES
    $replies = achCount(
        $pdo,
        'post_replies',
        $userId
    );

    // COUNSELLING BOOKINGS
    $bookings = achCount(
        $pdo,
        'bookings',
        $userId,
        "AND status IN ('booked','completed')"
    );

    // ========================================
    // ACTIVE DAYS
    // ========================================

    $activity = $pdo->prepare("
        SELECT COUNT(DISTINCT day)
        FROM (
            SELECT checkin_date AS day
            FROM mood_checkins
            WHERE user_id = :u1

            UNION ALL

            SELECT DATE(created_at)
            FROM journal_entries
            WHERE user_id = :u2

            UNION ALL

            SELECT DATE(created_at)
            FROM posts
            WHERE user_id = :u3

            UNION ALL

            SELECT DATE(created_at)
            FROM post_replies
            WHERE user_id = :u4
        ) a
        WHERE day IS NOT NULL
    ");

    $activity->execute([
        ':u1' => $userId,
        ':u2' => $userId,
        ':u3' => $userId,
        ':u4' => $userId
    ]);

    $activeDays = (int)$activity->fetchColumn();

    // ========================================
    // MOOD CHECK-IN STREAK
    // ========================================

    $statement = $pdo->prepare("
        SELECT DISTINCT checkin_date
        FROM mood_checkins
        WHERE user_id = :uid
        ORDER BY checkin_date
    ");

    $statement->execute([
        ':uid' => $userId
    ]);

    $dates = array_map(
        fn($value) => substr((string)$value, 0, 10),
        $statement->fetchAll(PDO::FETCH_COLUMN)
    );

    $lookup = array_fill_keys($dates, true);

    $previous = null;
    $running = 0;

    foreach ($dates as $date) {

        if (
            $previous !== null &&
            date(
                'Y-m-d',
                strtotime($previous . ' +1 day')
            ) === $date
        ) {
            $running++;
        } else {
            $running = 1;
        }

        $bestStreak = max($bestStreak, $running);
        $previous = $date;
    }

    $cursor = new DateTimeImmutable('today');

    if (!isset($lookup[$cursor->format('Y-m-d')])) {
        $cursor = $cursor->modify('-1 day');
    }

    while (isset($lookup[$cursor->format('Y-m-d')])) {

        $currentStreak++;
        $cursor = $cursor->modify('-1 day');
    }

} catch (Throwable $exception) {

    error_log(
        'WellnessHub Achievements: ' .
        $exception->getMessage()
    );

    $error = true;
}

// ============================================
// XP CALCULATIONS
// ============================================

$features =
    (int)($checkins > 0) +
    (int)($journals > 0) +
    (int)($bookings > 0) +
    (int)(($posts + $replies) > 0);

$xp =
    ($checkins * 10) +
    ($journals * 15) +
    ($posts * 5) +
    ($replies * 5) +
    ($bookings * 20);

$xpPerLevel = 1000;

$level = intdiv($xp, $xpPerLevel) + 1;

$progress = $xp % $xpPerLevel;

$progressPercentage = round(
    ($progress / $xpPerLevel) * 100
);

// ============================================
// ACHIEVEMENT BADGES
// ============================================

$badges = [

    [
        '🌱',
        'First Steps',
        'Complete your first mood check-in.',
        $checkins,
        1
    ],

    [
        '📝',
        'Mindful Writer',
        'Write your first journal entry.',
        $journals,
        1
    ],

    [
        '🔥',
        '7-Day Streak',
        'Check in for 7 consecutive days.',
        $bestStreak,
        7
    ],

    [
        '🤝',
        'Peer Helper',
        'Reply to a peer-support post.',
        $replies,
        1
    ],

    [
        '🏆',
        'Wellness Explorer',
        'Use 3 different wellness features.',
        $features,
        3
    ],

    [
        '💚',
        'Seeking Support',
        'Book your first counselling session.',
        $bookings,
        1
    ],

    [
        '📖',
        'Journal Champion',
        'Write 10 journal entries.',
        $journals,
        10
    ],

    [
        '⭐',
        'Steady Progress',
        'Be active on 14 different days.',
        $activeDays,
        14
    ]

];

$unlocked = count(
    array_filter(
        $badges,
        fn($badge) => $badge[3] >= $badge[4]
    )
);

// ============================================
// STUDENT STATISTICS
// ============================================

$stats = [

    ['😊', 'Mood Check-ins', $checkins],

    ['📝', 'Journal Entries', $journals],

    ['📆', 'Days Active', $activeDays],

    ['🔥', 'Current Streak', $currentStreak],

    ['💬', 'Peer Interactions', $posts + $replies],

    ['💚', 'Counselling Bookings', $bookings],

    [
        '🏅',
        'Badges Unlocked',
        $unlocked . ' / ' . count($badges)
    ],

    [
        '⚡',
        'XP Until Next Level',
        $xpPerLevel - $progress
    ]

];

// ============================================
// HOW TO EARN XP
// ============================================

$earn = [

    [
        '🙂',
        'Mood check-in',
        $checkins,
        10,
        'mood-tracking.php'
    ],

    [
        '✍️',
        'Journal entry',
        $journals,
        15,
        'journal.php'
    ],

    [
        '💬',
        'Peer-support post',
        $posts,
        5,
        'peer-support.php'
    ],

    [
        '🤝',
        'Peer-support reply',
        $replies,
        5,
        'peer-support.php'
    ],

    [
        '💚',
        'Counselling booking',
        $bookings,
        20,
        $bookingPage
    ]

];
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>Achievements — WellnessHub</title>

<link rel="stylesheet" href="css/style.css">

<style>

/* ==========================================
   GENERAL SETTINGS
========================================== */

* {
    box-sizing: border-box;
}

body.ach-page {

    /* LIGHT MODE COLOURS */

    --page-bg: linear-gradient(
        115deg,
        #c7e5ce,
        #f1f7f2
    );

    --shell-bg: #f6faf6;
    --sidebar-bg: #ffffff;
    --card-bg: #ffffff;
    --item-bg: #f8fbf8;

    --text-color: #163b2b;
    --heading-color: #113b2c;
    --muted-color: #718579;

    --accent-color: #287748;
    --border-color: #e5eee6;

    --nav-color: #344c3d;
    --nav-hover: #edf6ef;
    --nav-active: #307950;

    --soft-bg: #eaf6ed;
    --soft-text: #255e3e;

    --button-bg: #f1f8f3;
    --button-text: #206443;

    --tag-bg: #ddf2e3;
    --tag-text: #24764e;

    --track-bg: #e6eee7;

    --locked-bg: #fafbfa;

    margin: 0;
    min-height: 100vh;

    background: var(--page-bg);
    color: var(--text-color);

    font-family: Arial, Helvetica, sans-serif;

    transition:
        background 0.3s ease,
        color 0.3s ease;
}

/* ==========================================
   DARK MODE
   SUPPORTS BODY OR HTML THEME CLASSES
========================================== */

html:is(
    .dark,
    .dark-body,
    .dark-mode,
    .dark-theme,
    .theme-dark,
    [data-theme="dark"]
) body.ach-page,

body.ach-page:is(
    .dark,
    .dark-body,
    .dark-mode,
    .dark-theme,
    .theme-dark,
    [data-theme="dark"]
) {

    --page-bg: linear-gradient(
        115deg,
        #081321,
        #12243a
    );

    --shell-bg: #0d1a2b;
    --sidebar-bg: #101f33;
    --card-bg: #172b45;
    --item-bg: #213851;

    --text-color: #e7f0fb;
    --heading-color: #ffffff;
    --muted-color: #b6c9dd;

    --accent-color: #89e8b9;
    --border-color: #344c68;

    --nav-color: #dae9f7;
    --nav-hover: #243d57;
    --nav-active: #236c53;

    --soft-bg: #204638;
    --soft-text: #d5ffe7;

    --button-bg: #244838;
    --button-text: #d4ffeb;

    --tag-bg: #285943;
    --tag-text: #d9ffe5;

    --track-bg: #364b60;

    --locked-bg: #1d2d42;
}

/* ==========================================
   MAIN LAYOUT
========================================== */

.ach-shell {
    display: flex;
    min-height: calc(100vh - 56px);
    margin: 28px;

    background: var(--shell-bg);

    border-radius: 32px;
    overflow: hidden;

    box-shadow: 0 15px 55px rgba(0,0,0,0.08);
}

/* ==========================================
   SIDEBAR
========================================== */

.ach-sidebar {
    flex: 0 0 280px;
    padding: 30px 20px;

    background: var(--sidebar-bg);

    border-right: 1px solid var(--border-color);
}

.ach-brand {
    display: flex;
    align-items: center;
    gap: 12px;

    margin-bottom: 34px;

    font-size: 19px;
    font-weight: 800;

    color: var(--heading-color);
}

.ach-logo {
    display: grid;
    place-items: center;

    width: 39px;
    height: 39px;

    border-radius: 13px;

    background: var(--soft-bg);
    color: var(--accent-color);
}

.ach-nav {
    display: flex;
    flex-direction: column;
    gap: 8px;
}

.ach-nav a,
.ach-nav .ach-disabled {
    display: flex;
    align-items: center;
    gap: 15px;

    padding: 14px 17px;

    border-radius: 13px;

    text-decoration: none;

    font-size: 15px;
    font-weight: 700;

    color: var(--nav-color);
}

.ach-nav a:hover {
    background: var(--nav-hover);
}

.ach-nav a.active {
    background: var(--nav-active);
    color: #ffffff;
}

.ach-nav a.active:hover {
    background: var(--nav-active);
    color: #ffffff;
}

.ach-nav .ach-disabled {
    color: var(--muted-color);
    cursor: not-allowed;
}

.ach-nav .symbol {
    width: 20px;
    text-align: center;
    font-size: 18px;
}

/* ==========================================
   MAIN CONTENT
========================================== */

.ach-main {
    flex: 1;
    min-width: 0;

    padding: 35px 34px 45px;
}

.ach-top {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;

    gap: 15px;
    margin-bottom: 28px;
}

.ach-eyebrow {
    margin-bottom: 13px;

    font-weight: 800;
    font-size: 14px;
    letter-spacing: 1px;

    color: var(--accent-color);
}

.ach-top h1 {
    margin: 0 0 13px;

    font-size: 35px;

    color: var(--heading-color);
}

.ach-subtitle {
    margin: 0;

    color: var(--muted-color);

    font-size: 18px;
    font-weight: 700;
}

.ach-actions {
    display: flex;
    gap: 15px;
}

.ach-bell,
.ach-avatar {
    display: grid;
    place-items: center;

    width: 53px;
    height: 53px;

    text-decoration: none;
}

.ach-bell {
    background: var(--card-bg);

    border: 1px solid var(--border-color);
    border-radius: 19px;

    font-size: 22px;
}

.ach-avatar {
    background: linear-gradient(
        130deg,
        #e4bfa0,
        #ac7554
    );

    border-radius: 50%;
    border: 3px solid var(--card-bg);

    color: white;

    font-size: 22px;
    font-weight: 800;
}

/* ==========================================
   CARDS
========================================== */

.ach-card {
    background: var(--card-bg);

    padding: 27px;
    margin-bottom: 23px;

    border: 1px solid var(--border-color);
    border-radius: 28px;

    box-shadow: 0 11px 33px rgba(0,0,0,0.07);
}

/* ==========================================
   WELLNESS JOURNEY
========================================== */

.ach-hero {
    display: grid;

    grid-template-columns: 110px 1fr auto;

    align-items: center;

    gap: 25px;
    min-height: 195px;
}

.ach-hero-icon {
    display: grid;
    place-items: center;

    width: 110px;
    height: 110px;

    background: linear-gradient(
        135deg,
        #d0ecd6,
        #98d1a5
    );

    border: 4px solid var(--border-color);
    border-radius: 37px;

    font-size: 52px;
}

.ach-section-label {
    margin: 0 0 12px;

    font-size: 14px;
    font-weight: 800;
    letter-spacing: 1px;

    color: var(--accent-color);
}

.ach-hero h2 {
    margin: 0 0 12px;
    font-size: 28px;
    color: var(--heading-color);
}

.ach-track {
    height: 16px;

    background: var(--track-bg);

    border-radius: 40px;
    overflow: hidden;
}

.ach-fill {
    height: 100%;

    background: linear-gradient(
        90deg,
        #6aba87,
        #278254
    );

    border-radius: 40px;
}

.ach-progress-label {
    display: flex;
    justify-content: space-between;

    gap: 10px;
    margin-top: 10px;

    color: var(--muted-color);

    font-size: 14px;
}

.ach-button {
    display: inline-block;

    padding: 14px 20px;

    background: var(--button-bg);
    color: var(--button-text);

    border: 1px solid var(--border-color);
    border-radius: 15px;

    text-decoration: none;
    font-weight: 800;
}

.ach-button:hover {
    filter: brightness(1.1);
}

/* ==========================================
   SECTION HEADINGS
========================================== */

.ach-heading {
    display: flex;
    justify-content: space-between;
    align-items: center;

    gap: 12px;
    margin-bottom: 20px;
}

.ach-heading h2 {
    margin: 0;
    font-size: 23px;
    color: var(--heading-color);
}

.ach-heading p {
    margin: 0;

    color: var(--muted-color);

    font-size: 14px;
}

/* ==========================================
   STATISTICS
========================================== */

.ach-stats {
    display: grid;

    grid-template-columns: repeat(
        4,
        minmax(0, 1fr)
    );

    gap: 15px;
}

.ach-stat {
    padding: 19px;

    background: var(--item-bg);

    border: 1px solid var(--border-color);
    border-radius: 19px;
}

.ach-stat-icon {
    display: block;

    margin-bottom: 11px;
    font-size: 26px;
}

.ach-stat strong {
    display: block;

    font-size: 29px;

    color: var(--heading-color);
}

.ach-stat-label {
    display: block;

    margin-top: 7px;

    color: var(--muted-color);

    font-weight: 700;
    font-size: 13px;
}

/* ==========================================
   STREAK MESSAGE
========================================== */

.ach-note {
    margin-top: 18px;
    padding: 18px 21px;

    background: var(--soft-bg);
    color: var(--soft-text);

    border: 1px solid var(--border-color);
    border-radius: 18px;
}

.ach-note strong {
    display: block;
    margin-bottom: 5px;
}

.ach-note span {
    font-size: 14px;
    line-height: 1.5;
}

/* ==========================================
   BADGES
========================================== */

.ach-badges {
    display: grid;

    grid-template-columns: repeat(
        4,
        minmax(0, 1fr)
    );

    gap: 15px;
}

.ach-badge {
    padding: 21px 14px;

    background: var(--item-bg);

    border: 1px solid var(--border-color);
    border-radius: 21px;

    text-align: center;
}

.ach-badge.locked {
    background: var(--locked-bg);
}

.ach-badge-icon {
    display: grid;
    place-items: center;

    width: 73px;
    height: 73px;

    margin: 0 auto 13px;

    background: var(--soft-bg);

    border-radius: 22px;
    font-size: 36px;
}

.ach-badge.locked .ach-badge-icon {
    filter: grayscale(1);
    opacity: 0.55;
}

.ach-badge h3 {
    margin: 0 0 9px;

    font-size: 16px;

    color: var(--heading-color);
}

.ach-badge p {
    min-height: 40px;
    margin: 0 0 13px;

    color: var(--muted-color);

    font-size: 13px;
    line-height: 1.5;
}

.ach-tag {
    display: inline-block;

    padding: 6px 11px;

    background: var(--tag-bg);
    color: var(--tag-text);

    border-radius: 20px;

    font-size: 12px;
    font-weight: 800;
}

.ach-badge.locked .ach-tag {
    background: var(--track-bg);
    color: var(--muted-color);
}

.ach-mini-track {
    height: 7px;

    margin: 12px 0 6px;

    background: var(--track-bg);

    border-radius: 20px;
    overflow: hidden;
}

.ach-mini-track div {
    height: 100%;
    background: #6bb985;
}

.ach-badge small {
    color: var(--muted-color);
}

/* ==========================================
   HOW TO EARN XP
========================================== */

.ach-earn {
    display: grid;

    grid-template-columns: repeat(
        2,
        minmax(0, 1fr)
    );

    gap: 13px;
}

.ach-earn a,
.ach-earn .ach-earn-disabled {
    display: flex;
    align-items: center;

    gap: 13px;
    padding: 17px;

    background: var(--item-bg);
    color: var(--text-color);

    border: 1px solid var(--border-color);
    border-radius: 17px;

    text-decoration: none;
}

.ach-earn a:hover {
    background: var(--nav-hover);
    border-color: var(--accent-color);
}

.ach-earn-disabled {
    opacity: 0.6;
}

.ach-earn-icon {
    display: grid;
    place-items: center;

    flex-shrink: 0;

    width: 45px;
    height: 45px;

    background: var(--soft-bg);

    border-radius: 14px;
    font-size: 23px;
}

.ach-earn-copy {
    flex: 1;
    min-width: 0;
}

.ach-earn-copy strong {
    display: block;

    margin-bottom: 5px;

    color: var(--heading-color);

    font-size: 14px;
}

.ach-earn-copy span {
    font-size: 13px;
    color: var(--muted-color);
}

.ach-points {
    padding: 8px 10px;

    background: var(--tag-bg);
    color: var(--tag-text);

    border-radius: 10px;

    font-weight: 800;
    font-size: 13px;

    white-space: nowrap;
}

/* ==========================================
   MESSAGES
========================================== */

.ach-notice {
    margin-bottom: 20px;
    padding: 16px 20px;

    background: #fff8eb;
    color: #765828;

    border: 1px solid #efdfbb;
    border-radius: 16px;
}

.ach-error {
    background: #fff5f0;
    color: #8f4226;
}

.ach-footnote {
    margin-top: 16px;

    color: var(--muted-color);

    font-size: 13px;
    line-height: 1.6;
}

/* ==========================================
   RESPONSIVE DESIGN
========================================== */

@media (max-width: 1150px) {

    .ach-sidebar {
        flex-basis: 235px;
    }

    .ach-main {
        padding: 28px 22px;
    }

    .ach-stats,
    .ach-badges {
        grid-template-columns: repeat(
            2,
            minmax(0, 1fr)
        );
    }
}

@media (max-width: 740px) {

    .ach-shell {
        display: block;
        margin: 0;
        border-radius: 0;
    }

    .ach-sidebar {
        padding: 15px;
    }

    .ach-brand {
        margin-bottom: 12px;
    }

    .ach-nav {
        flex-direction: row;
        overflow-x: auto;
    }

    .ach-nav a,
    .ach-nav .ach-disabled {
        flex-shrink: 0;
        padding: 10px;
        font-size: 13px;
    }

    .ach-main {
        padding: 23px 16px;
    }

    .ach-top h1 {
        font-size: 29px;
    }

    .ach-subtitle {
        font-size: 15px;
    }

    .ach-hero {
        grid-template-columns: 75px 1fr;
        gap: 14px;
    }

    .ach-hero-icon {
        width: 75px;
        height: 75px;

        font-size: 36px;
        border-radius: 23px;
    }

    .ach-hero .ach-button {
        grid-column: 1 / -1;
        text-align: center;
    }

    .ach-card {
        padding: 20px 16px;
    }

    .ach-earn {
        grid-template-columns: 1fr;
    }
}

@media (max-width: 420px) {

    .ach-badges {
        grid-template-columns: 1fr;
    }

    .ach-heading {
        align-items: flex-start;
        flex-direction: column;
    }

    .ach-bell,
    .ach-avatar {
        width: 44px;
        height: 44px;
    }
}

</style>

</head>

<body class="app-body ach-page">

<!-- LOAD THE SAVED LIGHT/DARK THEME -->
<script src="js/theme.js"></script>

<div class="ach-shell">

    <!-- =====================================
         STUDENT SIDEBAR
    ====================================== -->

    <aside class="ach-sidebar">

        <div class="ach-brand">
            <span class="ach-logo">☘</span>
            WellnessHub
        </div>

        <nav
            class="ach-nav"
            aria-label="Student navigation"
        >

            <a href="dashboard.php">
                <span class="symbol">▣</span>
                Dashboard
            </a>

            <a href="mood-tracking.php">
                <span class="symbol">☺</span>
                Mood Tracking
            </a>

            <a href="journal.php">
                <span class="symbol">✎</span>
                Journal
            </a>

            <a href="self-help-library.php">
                <span class="symbol">▤</span>
                Self-Help Library
            </a>

            <?php if ($bookingPage !== null): ?>

                <a href="<?= achE($bookingPage) ?>">
                    <span class="symbol">♡</span>
                    Book Counselling
                </a>

            <?php else: ?>

                <span
                    class="ach-disabled"
                    title="Booking page not found"
                >
                    <span class="symbol">♡</span>
                    Book Counselling (unavailable)
                </span>

            <?php endif; ?>

            <a href="peer-support.php">
                <span class="symbol">☷</span>
                Peer Support
            </a>

            <a
                href="achievements.php"
                class="active"
                aria-current="page"
            >
                <span class="symbol">★</span>
                Achievements
            </a>

            <a href="notifications.php">
                <span class="symbol">🔔</span>
                Notifications
            </a>

            <a href="settings.php">
                <span class="symbol">⚙</span>
                Settings
            </a>

            <a href="logout.php">
                <span class="symbol">↪</span>
                Logout
            </a>

        </nav>

    </aside>

    <!-- =====================================
         MAIN CONTENT
    ====================================== -->

    <main class="ach-main">

        <header class="ach-top">

            <div>

                <div class="ach-eyebrow">
                    STUDENT SIDE
                </div>

                <h1>Achievements</h1>

                <p class="ach-subtitle">
                    Keep going! You are doing amazing.
                </p>

            </div>

            <div class="ach-actions">

                <a
                    class="ach-bell"
                    href="notifications.php"
                    aria-label="Notifications"
                >
                    🔔
                </a>

                <a
                    class="ach-avatar"
                    href="settings.php"
                    aria-label="Settings"
                >
                    <?= achE($initial) ?>
                </a>

            </div>

        </header>

        <!-- =====================================
             BOOKING NOTICE
        ====================================== -->

        <?php if ($bookingPage === null): ?>

            <div class="ach-notice">

                The counselling booking page could not
                be found in your Demo2 folder.

                Check whether the booking page exists
                under a different filename.

            </div>

        <?php endif; ?>

        <!-- =====================================
             DATABASE ERROR
        ====================================== -->

        <?php if ($error): ?>

            <div class="ach-notice ach-error">

                Achievements could not load from MySQL.

                Check your database connection in
                <strong>demoDB.php</strong> and make
                sure the activity tables exist.

            </div>

        <?php else: ?>

            <!-- =====================================
                 WELLNESS JOURNEY
            ====================================== -->

            <section class="ach-card ach-hero">

                <div class="ach-hero-icon">
                    ☘
                </div>

                <div>

                    <p class="ach-section-label">
                        YOUR WELLNESS JOURNEY
                    </p>

                    <h2>
                        Level <?= $level ?>
                    </h2>

                    <div
                        class="ach-track"
                        role="progressbar"
                        aria-label="Level progress"
                        aria-valuemin="0"
                        aria-valuemax="100"
                        aria-valuenow="<?= $progressPercentage ?>"
                    >

                        <div
                            class="ach-fill"
                            style="width: <?= $progressPercentage ?>%;"
                        ></div>

                    </div>

                    <div class="ach-progress-label">

                        <span>
                            <?= number_format($xp) ?>
                            total XP
                        </span>

                        <span>
                            <?= number_format($progress) ?>
                            / 1,000 XP
                        </span>

                    </div>

                </div>

                <a
                    class="ach-button"
                    href="#earn-xp"
                >
                    Earn XP +
                </a>

            </section>

            <!-- =====================================
                 STUDENT STATISTICS
            ====================================== -->

            <section class="ach-card">

                <div class="ach-heading">

                    <h2>Your Stats</h2>

                    <p>
                        Based on your real WellnessHub activity
                    </p>

                </div>

                <div class="ach-stats">

                    <?php foreach ($stats as $item): ?>

                        <div class="ach-stat">

                            <span class="ach-stat-icon">
                                <?= achE($item[0]) ?>
                            </span>

                            <strong>
                                <?php
                                echo is_int($item[2])
                                    ? number_format($item[2])
                                    : achE($item[2]);
                                ?>
                            </strong>

                            <span class="ach-stat-label">
                                <?= achE($item[1]) ?>
                            </span>

                        </div>

                    <?php endforeach; ?>

                </div>

                <!-- STREAK MESSAGE -->

                <div class="ach-note">

                    <strong>

                        🌿

                        <?php if ($currentStreak > 0): ?>

                            You have a
                            <?= $currentStreak ?>-day
                            check-in streak!

                        <?php else: ?>

                            Start a check-in streak today!

                        <?php endif; ?>

                    </strong>

                    <span>

                        Your longest check-in streak is
                        <?= $bestStreak ?> days.

                        Every check-in helps you reflect
                        on your wellbeing.

                    </span>

                </div>

            </section>

            <!-- =====================================
                 ACHIEVEMENT BADGES
            ====================================== -->

            <section class="ach-card">

                <div class="ach-heading">

                    <h2>Badges</h2>

                    <p>
                        <?= $unlocked ?> unlocked ·
                        <?= count($badges) - $unlocked ?>
                        still to earn
                    </p>

                </div>

                <div class="ach-badges">

                    <?php foreach ($badges as $badge): ?>

                        <?php

                        $earned = $badge[3] >= $badge[4];

                        $percent = min(
                            100,
                            round(
                                $badge[3] * 100 / $badge[4]
                            )
                        );

                        ?>

                        <article
                            class="ach-badge <?= $earned ? '' : 'locked' ?>"
                        >

                            <div class="ach-badge-icon">
                                <?= achE($badge[0]) ?>
                            </div>

                            <h3>
                                <?= achE($badge[1]) ?>
                            </h3>

                            <p>
                                <?= achE($badge[2]) ?>
                            </p>

                            <?php if ($earned): ?>

                                <span class="ach-tag">
                                    ✓ Unlocked
                                </span>

                            <?php else: ?>

                                <span class="ach-tag">
                                    🔒 Locked
                                </span>

                                <div class="ach-mini-track">

                                    <div
                                        style="width: <?= $percent ?>%;"
                                    ></div>

                                </div>

                                <small>
                                    <?= min($badge[3], $badge[4]) ?>
                                    /
                                    <?= $badge[4] ?>
                                    completed
                                </small>

                            <?php endif; ?>

                        </article>

                    <?php endforeach; ?>

                </div>

            </section>

            <!-- =====================================
                 HOW TO EARN XP
            ====================================== -->

            <section
                class="ach-card"
                id="earn-xp"
            >

                <div class="ach-heading">

                    <h2>How to Earn XP</h2>

                    <p>
                        Build positive habits at your own pace
                    </p>

                </div>

                <div class="ach-earn">

                    <?php foreach ($earn as $activity): ?>

                        <?php if ($activity[4] !== null): ?>

                            <a href="<?= achE($activity[4]) ?>">

                        <?php else: ?>

                            <div class="ach-earn-disabled">

                        <?php endif; ?>

                            <span class="ach-earn-icon">
                                <?= achE($activity[0]) ?>
                            </span>

                            <span class="ach-earn-copy">

                                <strong>
                                    <?= achE($activity[1]) ?>
                                </strong>

                                <span>

                                    <?= number_format($activity[2]) ?>
                                    completed ·

                                    <?= number_format(
                                        $activity[2] * $activity[3]
                                    ) ?>
                                    XP earned

                                </span>

                            </span>

                            <span class="ach-points">
                                +<?= $activity[3] ?> XP
                            </span>

                        <?php if ($activity[4] !== null): ?>

                            </a>

                        <?php else: ?>

                            </div>

                        <?php endif; ?>

                    <?php endforeach; ?>

                </div>

                <p class="ach-footnote">

                    XP comes from saved mood check-ins,
                    journal entries, peer-support posts,
                    replies, and eligible counselling bookings.

                    Each level requires 1,000 XP.

                    Self-help resource views are not currently
                    tracked in your database.

                </p>

            </section>

        <?php endif; ?>

    </main>

</div>

</body>
</html>
