
<?php
require_once __DIR__ . '/counsellor-auth.php';

$name = trim((string)($_SESSION['full_name'] ?? 'Counsellor'));
$initial = strtoupper(substr($name ?: 'C', 0, 1));

function counsellorSafe($value) {
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES | ENT_SUBSTITUTE,
        'UTF-8'
    );
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile — WellnessHub Counsellor</title>
    <link rel="stylesheet" href="css/style.css">

    <style>
        body.cprofile-page {
            margin: 0;
            background: #0b1423;
            color: white;
            font-family: Arial, sans-serif;
        }

        .cprofile-page * {
            box-sizing: border-box;
        }

        .cprofile-page [hidden] {
            display: none !important;
        }

        .cprofile-shell {
            display: grid;
            grid-template-columns: 275px minmax(0, 1fr);
            min-height: 100vh;
            background: #0e1829;
        }

        .cprofile-sidebar {
            background: #101c2d;
            border-right: 1px solid #26374e;
            padding: 28px 20px;
        }

        .cprofile-logo {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 35px;
            color: white;
            font-size: 19px;
            font-weight: 800;
            text-decoration: none;
        }

        .cprofile-logo span:first-child {
            background: #193857;
            padding: 10px;
            border-radius: 12px;
            color: #79b5ff;
        }

        .cprofile-nav {
            display: flex;
            flex-direction: column;
            gap: 9px;
        }

        .cprofile-nav a {
            display: flex;
            align-items: center;
            gap: 14px;
            color: #aec4df;
            padding: 15px;
            border-radius: 13px;
            text-decoration: none;
            font-size: 15px;
            font-weight: 700;
        }

        .cprofile-nav a:hover {
            background: #1b304c;
        }

        .cprofile-nav a.active {
            background: #286ab8;
            color: white;
        }

        .cprofile-main {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            min-width: 0;
            padding: 35px;
        }

        .cprofile-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .cprofile-header h1 {
            margin: 0;
            color: #fff;
            font-size: 30px;
        }

        .cprofile-header-avatar {
            display: grid;
            place-items: center;
            width: 48px;
            height: 48px;
            border: 3px solid #314763;
            border-radius: 50%;
            background: #192a43;
            color: white;
            font-weight: 800;
            text-decoration: none;
            overflow: hidden;
        }

        .cprofile-header-avatar img,
        .cprofile-picture img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .cprofile-center {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 30px 0;
        }

        .cprofile-card {
            width: min(600px, 100%);
            padding: 35px;
            background: #17263d;
            border: 1px solid #2a4161;
            border-radius: 25px;
            box-shadow: 0 15px 35px rgba(0,0,0,.2);
        }

        .cprofile-top {
            display: flex;
            align-items: center;
            flex-direction: column;
            text-align: center;
        }

        .cprofile-picture {
            display: grid;
            place-items: center;
            width: 145px;
            height: 145px;
            margin-bottom: 20px;
            border-radius: 50%;
            background: #3679cd;
            color: white;
            font-size: 58px;
            font-weight: 800;
            overflow: hidden;
        }

        .cprofile-buttons {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 10px;
        }

        .cprofile-button {
            padding: 11px 18px;
            background: #286ab8;
            color: white;
            border: none;
            border-radius: 11px;
            font-size: 14px;
            font-weight: 700;
            cursor: pointer;
        }

        .cprofile-button:hover {
            background: #3883d5;
        }

        .cprofile-remove {
            background: #733545;
        }

        .cprofile-button:disabled {
            opacity: .6;
            cursor: wait;
        }

        .cprofile-message {
            margin-top: 15px;
            padding: 11px;
            border-radius: 8px;
            background: #223d64;
            font-size: 13px;
        }

        .cprofile-message.error {
            background: #673043;
        }

        .cprofile-details {
            display: grid;
            gap: 23px;
            margin-top: 43px;
        }

        .cprofile-label {
            display: block;
            margin-bottom: 7px;
            font-size: 12px;
            font-weight: 800;
            letter-spacing: 1px;
            color: #91abc9;
            text-transform: uppercase;
        }

        .cprofile-value {
            font-size: 18px;
            font-weight: 700;
            color: white;
            overflow-wrap: anywhere;
        }

        @media (max-width: 750px) {
            .cprofile-shell {
                display: block;
            }

            .cprofile-sidebar {
                padding: 15px;
            }

            .cprofile-nav {
                flex-direction: row;
                overflow-x: auto;
            }

            .cprofile-nav a {
                white-space: nowrap;
                flex-shrink: 0;
            }

            .cprofile-main {
                min-height: auto;
                padding: 22px 15px;
            }

            .cprofile-card {
                padding: 25px;
            }
        }
    </style>
</head>

<body class="cprofile-page">

<div class="cprofile-shell">

    <aside class="cprofile-sidebar">

        <a class="cprofile-logo"
           href="counsellor-dashboard.php">
            <span>✿</span>
            <span>WellnessHub</span>
        </a>

        <nav class="cprofile-nav">

            <a href="counsellor-dashboard.php">
                ▣ Dashboard
            </a>

            <a href="counsellor-students.php">
                👥 Students
            </a>

            <a href="risk-alerts.php">
                ⚠ Risk Alerts
            </a>

            <a href="counsellor-appointments.php">
                📅 Appointments
            </a>

            <a href="counsellor-resources.php">
                ▤ Resources
            </a>

            <a href="counsellor-profile.php"
               class="active">
                👤 My Profile
            </a>

            <a href="logout.php">
                ↪ Logout
            </a>

        </nav>

    </aside>

    <main class="cprofile-main">

        <header class="cprofile-header">

            <h1>My Profile</h1>

            <a class="cprofile-header-avatar"
               href="counsellor-profile.php"
               title="My Profile">

                <span id="topInitial">
                    <?= counsellorSafe($initial) ?>
                </span>

                <img id="topPicture"
                     alt="Profile picture"
                     hidden>

            </a>

        </header>

        <div class="cprofile-center">

            <section class="cprofile-card">

                <div class="cprofile-top">

                    <div class="cprofile-picture">

                        <span id="profileInitial">
                            <?= counsellorSafe($initial) ?>
                        </span>

                        <img id="profilePicture"
                             alt="My profile picture"
                             hidden>

                    </div>

                    <input type="file"
                           id="pictureInput"
                           accept="image/png,image/jpeg,image/webp,image/gif"
                           hidden>

                    <div class="cprofile-buttons">

                        <button class="cprofile-button"
                                id="uploadPicture"
                                type="button">
                            Upload Picture
                        </button>

                        <button class="cprofile-button cprofile-remove"
                                id="removePicture"
                                type="button"
                                hidden>
                            Remove Picture
                        </button>

                    </div>

                    <div id="profileMessage"
                         class="cprofile-message"
                         role="status"
                         hidden></div>

                </div>

                <div class="cprofile-details">

                    <div>
                        <span class="cprofile-label">
                            Full Name
                        </span>

                        <div class="cprofile-value"
                             id="profileName">
                            <?= counsellorSafe($name) ?>
                        </div>
                    </div>

                    <div>
                        <span class="cprofile-label">
                            Email Address
                        </span>

                        <div class="cprofile-value"
                             id="profileEmail">
                            Loading...
                        </div>
                    </div>

                    <div>
                        <span class="cprofile-label">
                            Account Type
                        </span>

                        <div class="cprofile-value">
                            Counsellor
                        </div>
                    </div>

                    <div>
                        <span class="cprofile-label">
                            Gender
                        </span>

                        <div class="cprofile-value"
                             id="profileGender">
                            Loading...
                        </div>
                    </div>

                </div>

            </section>

        </div>

    </main>

</div>

<script>
(() => {

    const $ = id => document.getElementById(id);

    const fileInput = $('pictureInput');
    const uploadButton = $('uploadPicture');
    const removeButton = $('removePicture');
    const message = $('profileMessage');

    function showMessage(text, error = false) {
        message.hidden = false;
        message.textContent = text;
        message.className =
            'cprofile-message' + (error ? ' error' : '');
    }

    function renderPicture(value) {

        const valid =
            typeof value === 'string' &&
            /^data:image\/(?:png|jpe?g|gif|webp);base64,[A-Za-z0-9+/=]+$/
                .test(value);

        for (const [imageId, initialId] of [
            ['profilePicture', 'profileInitial'],
            ['topPicture', 'topInitial']
        ]) {

            const image = $(imageId);
            const initial = $(initialId);

            if (valid) {
                image.src = value;
            } else {
                image.removeAttribute('src');
            }

            image.hidden = !valid;
            initial.hidden = valid;
        }

        removeButton.hidden = !valid;
    }

    async function api(action, data = null) {

        const options = {
            method: data === null ? 'GET' : 'POST',
            credentials: 'same-origin',
            cache: 'no-store'
        };

        if (data !== null) {
            options.headers = {
                'Content-Type':
                    'application/x-www-form-urlencoded'
            };
            options.body = new URLSearchParams(data);
        }

        const response = await fetch(
            'api/demoAPI.php?action=' +
            encodeURIComponent(action),
            options
        );

        let result;

        try {
            result = await response.json();
        } catch {
            throw new Error(
                'Invalid server response. Check demoAPI.php.'
            );
        }

        if (!response.ok || !result.success) {
            throw new Error(
                result.message || 'Request failed.'
            );
        }

        return result.data || {};
    }

    async function loadProfile() {

        try {

            const data = await api('profile_get');

            const fullName = String(
                data.full_name || 'Counsellor'
            ).trim();

            const initial =
                fullName.charAt(0).toUpperCase() || 'C';

            $('profileName').textContent = fullName;
            $('profileEmail').textContent =
                data.email || 'Not provided';
            $('profileGender').textContent =
                data.gender || 'Not specified';

            $('profileInitial').textContent = initial;
            $('topInitial').textContent = initial;

            renderPicture(data.profile_picture || '');

        } catch (error) {

            $('profileEmail').textContent =
                'Unable to load';

            $('profileGender').textContent =
                'Unable to load';

            showMessage(error.message, true);
        }
    }

    uploadButton.addEventListener('click', () => {
        fileInput.click();
    });

    fileInput.addEventListener('change', async () => {

        const file = fileInput.files[0];
        if (!file) return;

        const allowed = [
            'image/png',
            'image/jpeg',
            'image/webp',
            'image/gif'
        ];

        if (
            !allowed.includes(file.type) ||
            file.size > 2 * 1024 * 1024
        ) {
            showMessage(
                'Choose a JPG, PNG, WEBP or GIF under 2 MB.',
                true
            );
            fileInput.value = '';
            return;
        }

        uploadButton.disabled = true;
        removeButton.disabled = true;

        try {

            const picture = await new Promise(
                (resolve, reject) => {

                    const reader = new FileReader();

                    reader.onload =
                        () => resolve(reader.result);

                    reader.onerror =
                        () => reject(
                            new Error('Could not read image.')
                        );

                    reader.readAsDataURL(file);
                }
            );

            await api(
                'profile_picture_upload',
                { image: picture }
            );

            renderPicture(picture);
            showMessage('Picture uploaded successfully.');

        } catch (error) {
            showMessage(error.message, true);
        } finally {
            uploadButton.disabled = false;
            removeButton.disabled = false;
            fileInput.value = '';
        }
    });

    removeButton.addEventListener('click', async () => {

        if (!confirm('Remove your profile picture?')) {
            return;
        }

        uploadButton.disabled = true;
        removeButton.disabled = true;

        try {

            await api('profile_picture_remove', {});
            renderPicture('');
            showMessage('Profile picture removed.');

        } catch (error) {
            showMessage(error.message, true);
        } finally {
            uploadButton.disabled = false;
            removeButton.disabled = false;
        }
    });

    loadProfile();

})();
</script>

</body>
</html>
