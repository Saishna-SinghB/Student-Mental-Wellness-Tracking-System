<?php
require_once __DIR__ . '/counsellor-auth.php';
require_once __DIR__ . '/demoDB.php';

$counsellorName = trim((string)($_SESSION['full_name'] ?? 'Counsellor'));
$counsellorInitial = strtoupper(substr($counsellorName, 0, 1));

// LOAD COUNSELLOR PROFILE PICTURE
$profilePicture = '';

try {
    $stmt = $pdo->prepare("
        SELECT profile_picture
        FROM users
        WHERE user_id = ?
        AND role = 'counsellor'
        LIMIT 1
    ");

    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        $profilePicture = $user['profile_picture'] ?? '';
        $_SESSION['profile_picture'] = $profilePicture;
    }
} catch (PDOException $e) {
    error_log('Profile picture error: ' . $e->getMessage());
    $profilePicture = $_SESSION['profile_picture'] ?? '';
}

$hasProfilePicture = is_string($profilePicture)
    && preg_match(
        '#^data:image/(?:jpeg|png|gif|webp);base64,[A-Za-z0-9+/=]+$#D',
        $profilePicture
    ) === 1;

$avatarStyle = '';

if ($hasProfilePicture) {
    $safePicture = htmlspecialchars($profilePicture, ENT_QUOTES, 'UTF-8');
    $avatarStyle = 'style="background-image:url(\'' . $safePicture .
        '\');background-size:cover;background-position:center;"';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Student Overview — WellnessHub</title>
    <link rel="stylesheet" href="css/style.css">

    <style>
        .students-heading {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 20px;
            flex-wrap: wrap;
            margin-bottom: 25px;
        }

        .students-heading h2 {
            margin: 0;
            color: #ffffff;
        }

        .student-search-box {
            display: flex;
            align-items: stretch;
            width: 100%;
            max-width: 440px;
            border: 1px solid #385272;
            border-radius: 15px;
            overflow: hidden;
            background: #0d1b2d;
        }

        .student-search-box:focus-within {
            border-color: #68acff;
            box-shadow: 0 0 0 3px rgba(72,145,235,0.2);
        }

        .student-search-input {
            flex: 1;
            min-width: 0;
            padding: 14px 17px;
            background: transparent;
            color: #ffffff;
            border: none;
            outline: none;
            font-size: 15px;
        }

        .student-search-input::placeholder {
            color: #9cb1c9;
        }

        .student-search-button {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 7px;
            padding: 12px 18px;
            background: #2768b6;
            color: #ffffff;
            border: none;
            cursor: pointer;
            font-size: 15px;
            font-weight: 800;
        }

        .student-search-button:hover {
            background: #3486dc;
        }

        .student-search-button:focus-visible {
            outline: 3px solid #ffffff;
            outline-offset: -4px;
        }

        .student-table-wrapper {
            width: 100%;
            overflow-x: auto;
        }

        .students-table {
            width: 100%;
            min-width: 700px;
            border-collapse: separate;
            border-spacing: 0 12px;
        }

        .students-table th {
            padding: 12px 16px;
            text-align: left;
            color: #a5c7ec;
            font-size: 13px;
            text-transform: uppercase;
        }

        .students-table td {
            padding: 18px 16px;
            background: #0e1c30;
            color: #ffffff;
            border-top: 1px solid #2b4564;
            border-bottom: 1px solid #2b4564;
        }

        .students-table td:first-child {
            border-left: 1px solid #2b4564;
            border-radius: 14px 0 0 14px;
        }

        .students-table td:last-child {
            border-right: 1px solid #2b4564;
            border-radius: 0 14px 14px 0;
        }

        .students-table .note-btn {
            background: #245d93;
            color: white;
            border: 1px solid #417db5;
            border-radius: 11px;
            padding: 10px 15px;
            font-weight: 700;
            cursor: pointer;
        }

        .students-table .note-btn:hover {
            background: #347db9;
        }

        .student-row[hidden],
        #noResults[hidden] {
            display: none !important;
        }

        .student-search-status {
            margin-top: 15px;
            color: #b6cae3;
            font-size: 14px;
        }

        .student-note-editor {
            margin-top: 25px;
        }

        .student-note-editor textarea {
            width: 100%;
            min-height: 140px;
            padding: 15px;
            color: white;
            background: #0d1b2d;
            border: 1px solid #385272;
            border-radius: 14px;
            resize: vertical;
        }

        @media (max-width: 768px) {
            .students-heading {
                flex-direction: column;
                align-items: stretch;
            }

            .student-search-box {
                max-width: 100%;
            }
        }
    </style>
</head>

<body class="app-body dark-body counsellor-body">

<div class="app-shell dark-shell">

    <!-- SIDEBAR -->
    <aside class="sidebar counsellor-sidebar">

        <a class="brand-mini sidebar-brand" href="index.php">
            <span class="mini-leaf" aria-hidden="true">☘</span>
            <span>WellnessHub</span>
        </a>

        <nav class="side-nav" aria-label="Counsellor navigation">

            <a href="counsellor-dashboard.php">
                <span>▣</span> Dashboard
            </a>

            <a class="active" href="counsellor-students.php">
                <span>👥</span> Students
            </a>

            <a href="risk-alerts.php">
                <span>⚠</span> Risk Alerts
            </a>

            <a href="counsellor-appointments.php">
                <span>📅</span> Appointments
            </a>

            <a href="counsellor-resources.php">
                <span>▤</span> Resources
            </a>

            <a href="counsellor-profile.php">
                <span>👤</span> My Profile
            </a>

            <a href="logout.php">
                <span>↪</span> Logout
            </a>

        </nav>
    </aside>

    <!-- MAIN CONTENT -->
    <main class="dashboard-main dark-main">

        <header class="topbar dark-topbar">
            <div>
                <p class="eyebrow">Counsellor Side</p>
                <h1>Student Overview</h1>
                <p class="page-subtitle">
                    View student wellbeing summaries and follow-up statuses.
                </p>
            </div>

            <div class="topbar-actions">

                <a class="icon-btn dark-icon"
                   href="risk-alerts.php"
                   aria-label="Risk alerts">
                    🔔
                </a>

                <!-- SAVED PROFILE PICTURE -->
                <a
                    href="counsellor-profile.php"
                    class="avatar dark-avatar"
                    title="Click to view My Profile"
                    aria-label="Open My Profile"
                    <?= $avatarStyle ?>
                >
                    <?php if (!$hasProfilePicture): ?>
                        <?= htmlspecialchars($counsellorInitial, ENT_QUOTES, 'UTF-8') ?>
                    <?php endif; ?>
                </a>

            </div>
        </header>

        <section class="page-grid">

            <!-- STUDENTS PANEL -->
            <article class="panel">

                <div class="students-heading">
                    <h2>Students</h2>

                    <div class="student-search-box" role="search">

                        <input
                            type="search"
                            id="studentSearch"
                            class="student-search-input"
                            placeholder="Search any student..."
                            aria-label="Search by student name or number"
                            autocomplete="off"
                        >

                        <button
                            type="button"
                            id="studentSearchButton"
                            class="student-search-button"
                            aria-label="Search students"
                        >
                            🔍 Search
                        </button>

                    </div>
                </div>

                <div class="student-table-wrapper">
                    <table class="students-table">
                        <thead>
                            <tr>
                                <th>Student</th>
                                <th>Mood</th>
                                <th>Risk</th>
                                <th>Last Check-in</th>
                                <th>Action</th>
                            </tr>
                        </thead>

                        <tbody id="studentsTableBody">
                            <tr>
                                <td colspan="5">
                                    Loading students...
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <p
                    id="studentSearchStatus"
                    class="student-search-status"
                    aria-live="polite"
                ></p>

            </article>

            <!-- FOLLOW-UP NOTE -->
            <article
                class="panel student-note-editor"
                id="noteEditor"
                style="display:none;"
            >
                <h2 id="noteEditorTitle">
                    Add Follow-up Note
                </h2>

                <input type="hidden" id="noteStudentId" value="">

                <label class="field">
                    <span>Note</span>

                    <textarea
                        id="noteText"
                        placeholder="Write an internal follow-up note..."
                    ></textarea>
                </label>

                <button
                    type="button"
                    class="btn btn-blue btn-full"
                    id="saveNoteBtn"
                >
                    Save Note
                </button>

            </article>

        </section>
    </main>
</div>

<script>
const MOOD_EMOJI = {
    great: '😊',
    good: '🙂',
    okay: '😐',
    low: '😟',
    struggling: '😣'
};

let allStudents = [];

const searchInput = document.getElementById('studentSearch');
const searchButton = document.getElementById('studentSearchButton');
const tableBody = document.getElementById('studentsTableBody');
const searchStatus = document.getElementById('studentSearchStatus');

loadAllStudents();

searchInput.addEventListener('input', filterStudents);

searchButton.addEventListener('click', () => {
    filterStudents();
    searchInput.focus();
});

document.getElementById('saveNoteBtn')
    .addEventListener('click', saveNote);

// LOAD STUDENTS
async function loadAllStudents() {
    try {
        const response = await fetch(
            'api/demoAPI.php?action=counsellor_students_list',
            {
                credentials: 'same-origin',
                cache: 'no-store'
            }
        );

        if (!response.ok) {
            throw new Error('HTTP ' + response.status);
        }

        const result = await response.json();

        if (!result.success) {
            throw new Error(result.message || 'Unable to load students.');
        }

        allStudents = Array.isArray(result.data?.students)
            ? result.data.students
            : [];

        renderStudents(allStudents);
        filterStudents();

    } catch (error) {
        console.error('Student loading error:', error);

        tableBody.innerHTML = `
            <tr>
                <td colspan="5" style="text-align:center; padding:25px;">
                    Could not load students. Check the API connection.
                </td>
            </tr>
        `;

        searchStatus.textContent = 'Unable to load student records.';
    }
}

// SHOW STUDENTS
function renderStudents(students) {
    tableBody.innerHTML = '';

    students.forEach(student => {
        const row = document.createElement('tr');
        row.className = 'student-row';

        const fullName = String(student.full_name || '');
        const studentNumber = String(student.student_number || '');

        row.dataset.search = (
            fullName + ' ' + studentNumber
        ).replace(/\s+/g, ' ').toLowerCase();

        const nameCell = document.createElement('td');
        nameCell.textContent = fullName;
        row.appendChild(nameCell);

        const moodCell = document.createElement('td');
        const mood = String(student.last_mood || '').toLowerCase();

        moodCell.textContent = mood
            ? (MOOD_EMOJI[mood] || '😐') + ' ' + mood
            : '—';

        row.appendChild(moodCell);

        const riskCell = document.createElement('td');
        const riskPill = document.createElement('span');

        riskPill.className = 'pill pill-green';
        riskPill.textContent = 'Low';

        if (Number(student.has_high_risk) === 1) {
            riskPill.className = 'pill pill-red';
            riskPill.textContent = 'High';
        } else if (Number(student.open_alerts) > 0) {
            riskPill.className = 'pill pill-orange';
            riskPill.textContent = 'Medium';
        }

        riskCell.appendChild(riskPill);
        row.appendChild(riskCell);

        const checkinCell = document.createElement('td');
        checkinCell.textContent = student.last_checkin || '—';
        row.appendChild(checkinCell);

        const actionCell = document.createElement('td');

        const noteButton = document.createElement('button');
        noteButton.type = 'button';
        noteButton.className = 'note-btn';
        noteButton.textContent = 'Add Note';

        noteButton.addEventListener('click', () => {
            openNoteEditor(student);
        });

        actionCell.appendChild(noteButton);
        row.appendChild(actionCell);

        tableBody.appendChild(row);
    });

    const noResults = document.createElement('tr');
    noResults.id = 'noResults';
    noResults.hidden = true;

    const noResultsCell = document.createElement('td');
    noResultsCell.colSpan = 5;
    noResultsCell.textContent = 'No students found.';
    noResultsCell.style.textAlign = 'center';
    noResultsCell.style.padding = '30px';

    noResults.appendChild(noResultsCell);
    tableBody.appendChild(noResults);
}

// SEARCH STUDENTS
function filterStudents() {
    const query = searchInput.value
        .trim()
        .replace(/\s+/g, ' ')
        .toLowerCase();

    const studentRows = tableBody.querySelectorAll('.student-row');

    let matchingCount = 0;

    studentRows.forEach(row => {
        const matches = row.dataset.search.includes(query);
        row.hidden = !matches;

        if (matches) {
            matchingCount++;
        }
    });

    const noResults = document.getElementById('noResults');

    if (noResults) {
        noResults.hidden = matchingCount > 0;
    }

    searchStatus.textContent = query === ''
        ? `Showing all ${allStudents.length} students`
        : `${matchingCount} matching student(s) out of ${allStudents.length}`;
}

// OPEN NOTE EDITOR
function openNoteEditor(student) {
    const editor = document.getElementById('noteEditor');

    document.getElementById('noteEditorTitle').textContent =
        'Add follow-up note — ' + student.full_name;

    document.getElementById('noteStudentId').value = student.user_id;
    document.getElementById('noteText').value = '';

    editor.style.display = 'block';

    editor.scrollIntoView({
        behavior: 'smooth',
        block: 'nearest'
    });

    document.getElementById('noteText').focus();
}

// SAVE NOTE
async function saveNote() {
    const userId = document.getElementById('noteStudentId').value;
    const noteText = document.getElementById('noteText');
    const note = noteText.value.trim();

    if (!userId) {
        alert('Please select a student.');
        return;
    }

    if (!note) {
        alert('Please write a note before saving.');
        noteText.focus();
        return;
    }

    const saveButton = document.getElementById('saveNoteBtn');

    const formData = new FormData();
    formData.append('user_id', userId);
    formData.append('note', note);

    saveButton.disabled = true;
    saveButton.textContent = 'Saving...';

    try {
        const response = await fetch(
            'api/demoAPI.php?action=counsellor_note_save',
            {
                method: 'POST',
                credentials: 'same-origin',
                body: formData
            }
        );

        if (!response.ok) {
            throw new Error('HTTP ' + response.status);
        }

        const result = await response.json();

        if (!result.success) {
            alert(result.message || 'Could not save note.');
            return;
        }

        document.getElementById('noteEditor').style.display = 'none';
        alert('Follow-up note saved successfully.');

    } catch (error) {
        console.error('Save note error:', error);
        alert('Unable to save the note. Please try again.');

    } finally {
        saveButton.disabled = false;
        saveButton.textContent = 'Save Note';
    }
}
</script>

</body>
</html>