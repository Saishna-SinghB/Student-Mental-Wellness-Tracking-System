<?php
/*
 * check-setup.php — one-page setup checker for a new machine.
 * Open  http://localhost/<folder>/check-setup.php  after importing the SQL.
 * It shows exactly what is wrong (PHP version, database name/password,
 * missing tables or columns, admin account) instead of "Could not reach
 * the server". Only works on localhost, and is safe to delete afterwards.
 */
$ip = $_SERVER['REMOTE_ADDR'] ?? '';
if (!in_array($ip, ['127.0.0.1', '::1'], true) && PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit('This page only works on localhost.');
}

$checks = [];
function add(string $name, bool $ok, string $detail = '', string $fix = ''): void {
    global $checks;
    $checks[] = compact('name', 'ok', 'detail', 'fix');
}

// 1. PHP version / extensions
add('PHP 8.0 or newer', version_compare(PHP_VERSION, '8.0.0', '>='), 'This PC runs PHP ' . PHP_VERSION,
    'Install a current XAMPP (PHP 8.x). The project uses PHP 8 features, so PHP 7 shows "Could not reach the server".');
foreach (['pdo_mysql', 'mbstring', 'openssl', 'json'] as $ext) {
    add("PHP extension: $ext", extension_loaded($ext), '', "Enable extension=$ext in php.ini, then restart Apache.");
}

// 2. Database settings (read from demoDB.php so this matches the real app)
$src = @file_get_contents(__DIR__ . '/demoDB.php') ?: '';
$get = function (string $var) use ($src): string {
    return preg_match('/\$' . $var . '\s*=\s*\'([^\']*)\'/', $src, $m) ? $m[1] : '';
};
[$host, $dbname, $dbuser, $dbpass] = [$get('host'), $get('dbname'), $get('dbuser'), $get('dbpass')];
add('demoDB.php readable', $src !== '', "host=$host, database=$dbname, user=$dbuser, password=" . ($dbpass === '' ? '(empty)' : '(set)'));

$pdo = null;
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $dbuser, $dbpass,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]);
    add("Connected to database '$dbname'", true);
} catch (Throwable $e) {
    $msg = $e->getMessage();
    $fix = 'Check MySQL is running in the XAMPP control panel.';
    if (stripos($msg, 'Unknown database') !== false) {
        $fix = "The database is not named '$dbname'. Either rename/create it as '$dbname' and import wellnesshub.sql, or change \$dbname in demoDB.php to the name you used.";
    } elseif (stripos($msg, 'Access denied') !== false) {
        $fix = 'Wrong MySQL user/password. Edit $dbuser / $dbpass in demoDB.php to match this PC\'s MySQL login.';
    }
    add("Connect to database '$dbname'", false, $msg, $fix);
}

// 3. Tables and columns
if ($pdo) {
    $need = ['users', 'mood_checkins', 'journal_entries', 'posts', 'post_likes', 'post_replies', 'post_reports',
        'bookings', 'counsellors', 'counsellor_notes', 'resources', 'notifications', 'user_settings',
        'password_reset_codes', 'activities', 'auditlog', 'risk_alerts', 'platform_settings'];
    $have = $pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);
    $missing = array_values(array_diff($need, $have));
    add('All tables present', !$missing, $missing ? 'Missing: ' . implode(', ', $missing) : count($have) . ' tables found',
        "Re-import wellnesshub.sql into an EMPTY database called '$dbname' (drop the old one first). Importing on top of an older copy can stop half-way.");

    $cols = [
        'users' => ['is_active', 'last_login_at', 'profile_picture', 'gender', 'qualification'],
        'journal_entries' => ['alert_tier'],
        'counsellors' => ['user_id'],
    ];
    foreach ($cols as $table => $list) {
        if (!in_array($table, $have, true)) continue;
        $existing = $pdo->query("SHOW COLUMNS FROM `$table`")->fetchAll(PDO::FETCH_COLUMN);
        $gone = array_values(array_diff($list, $existing));
        add("Columns up to date in $table", !$gone, $gone ? 'Missing: ' . implode(', ', $gone) : '',
            'Your database is from an older version. Drop it and re-import the latest wellnesshub.sql.');
    }

    // 4. Accounts
    if (in_array('users', $have, true)) {
        $accounts = [
            ['Admin', 'Admin@Richfield.ac.za', '@Admin2026', 'admin'],
            ['Counsellor', 'naidoo@richfield.ac.za', '12345678', 'counsellor'],
        ];
        foreach ($accounts as [$label, $email, $pw, $role]) {
            $st = $pdo->prepare('SELECT password_hash, role, is_active FROM users WHERE email = ?');
            $st->execute([$email]);
            $row = $st->fetch();
            if (!$row) {
                add("$label account exists ($email)", false, 'Not found in the users table.',
                    'Run add_default_accounts.sql in phpMyAdmin, selecting the database \'' . $dbname . '\' first.');
            } else {
                $okPw = password_verify($pw, $row['password_hash']);
                add("$label default password works", $okPw && $row['role'] === $role && (int) $row['is_active'] === 1,
                    'role=' . $row['role'] . ', active=' . $row['is_active'] . ($okPw ? '' : ', password differs from the default (someone changed it)'),
                    'If this PC should use the defaults, run add_default_accounts.sql again in database \'' . $dbname . '\'.');
            }
        }
    }
}

// 5. Mail
add('mail-config.php present', is_file(__DIR__ . '/mail-config.php'), '',
    'Needed for the password-reset email. Without real Gmail details the code is shown on the page instead (localhost only).');

$allOk = !array_filter($checks, fn($c) => !$c['ok']);
if (PHP_SAPI === 'cli') {
    foreach ($checks as $c) echo ($c['ok'] ? '[ OK ] ' : '[FAIL] ') . $c['name'] . ($c['detail'] ? ' — ' . $c['detail'] : '') . ($c['ok'] ? '' : "\n         FIX: " . $c['fix']) . "\n";
    exit;
}
?><!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Setup check — WellnessHub</title>
<style>
 body{font-family:system-ui,Segoe UI,Arial,sans-serif;background:#f3f8f4;color:#1b2a21;margin:0;padding:28px 16px}
 .wrap{max-width:760px;margin:0 auto}
 h1{margin:0 0 4px;font-size:24px} .sub{color:#5d6d63;margin:0 0 20px}
 .banner{padding:14px 16px;border-radius:12px;font-weight:700;margin-bottom:18px}
 .banner.ok{background:#e3f4e8;color:#1d563b}.banner.bad{background:#fde8e8;color:#9b2c2c}
 .row{background:#fff;border:1px solid #dfe9e2;border-radius:12px;padding:12px 14px;margin-bottom:10px}
 .row b{display:block}.tag{display:inline-block;min-width:44px;font-weight:800;font-size:12px;border-radius:6px;padding:2px 8px;margin-right:8px}
 .ok .tag{background:#e3f4e8;color:#1d563b}.fail .tag{background:#fde8e8;color:#9b2c2c}
 .detail{color:#5d6d63;font-size:13px;margin-top:4px;word-break:break-word}.fix{font-size:13px;margin-top:6px;color:#8a5a00}
</style></head><body><div class="wrap">
<h1>WellnessHub setup check</h1>
<p class="sub">Folder: <?= htmlspecialchars(basename(__DIR__)) ?> · PHP <?= htmlspecialchars(PHP_VERSION) ?></p>
<div class="banner <?= $allOk ? 'ok' : 'bad' ?>"><?= $allOk ? 'Everything looks good. You can log in.' : 'Something needs fixing — see the red items below.' ?></div>
<?php foreach ($checks as $c): ?>
  <div class="row <?= $c['ok'] ? 'ok' : 'fail' ?>">
    <b><span class="tag"><?= $c['ok'] ? 'OK' : 'FIX' ?></span><?= htmlspecialchars($c['name']) ?></b>
    <?php if ($c['detail']): ?><div class="detail"><?= htmlspecialchars($c['detail']) ?></div><?php endif; ?>
    <?php if (!$c['ok'] && $c['fix']): ?><div class="fix">→ <?= htmlspecialchars($c['fix']) ?></div><?php endif; ?>
  </div>
<?php endforeach; ?>
<p class="sub">Delete check-setup.php when you are done.</p>
</div></body></html>
