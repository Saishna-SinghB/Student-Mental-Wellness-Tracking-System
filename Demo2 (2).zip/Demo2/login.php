<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="UTF-8" />

  <meta name="viewport" content="width=device-width, initial-scale=1.0" />

  <title>Login — WellnessHub</title>

  <link rel="stylesheet" href="css/style.css" />

  <style>

    /* ==========================================
       LOGIN MESSAGE BANNERS
    ========================================== */

    .banner {
      padding: 12px 14px;
      border-radius: 10px;
      font-size: 13px;
      font-weight: 700;
      margin-bottom: 16px;
      display: none;
    }

    .banner.error {
      background: rgba(243, 109, 109, 0.12);
      color: #ad3434;
      display: block;
    }

    .banner.success {
      background: rgba(87, 166, 111, 0.15);
      color: #1d563b;
      display: block;
    }


    /* ==========================================
       PASSWORD INPUT CONTAINER
    ========================================== */

    .password-input-wrapper {
      position: relative;
      display: block;
      width: 100%;
    }

    .password-input-wrapper input {
      width: 100%;
      box-sizing: border-box;
      padding-right: 60px !important;
    }


    /* ==========================================
       SHOW / HIDE PASSWORD EYE BUTTON
    ========================================== */

    .password-toggle {
      position: absolute;
      top: 50%;
      right: 12px;

      transform: translateY(-50%);

      display: flex;
      align-items: center;
      justify-content: center;

      width: 44px;
      height: 44px;

      padding: 0;

      border: none;
      border-radius: 10px;

      background: transparent;

      color: #2e7d50;

      cursor: pointer;

      z-index: 2;

      transition:
        background 0.2s ease,
        color 0.2s ease;
    }

    .password-toggle:hover {
      background: rgba(46, 125, 80, 0.10);
      color: #185a37;
    }

    .password-toggle:focus-visible {
      outline: 2px solid #2e7d50;
      outline-offset: 2px;
    }

    .password-toggle svg {
      width: 24px;
      height: 24px;

      fill: none;
      stroke: currentColor;
      stroke-width: 2;

      stroke-linecap: round;
      stroke-linejoin: round;
    }


    /* ==========================================
       MOBILE RESPONSIVENESS
    ========================================== */

    @media (max-width: 600px) {

      .password-toggle {
        right: 8px;
      }

      .password-input-wrapper input {
        padding-right: 55px !important;
      }

    }

  </style>

</head>

<body>

  <main class="auth-screen">

    <section class="auth-card">

      <!-- LOGIN LABEL -->

      <div class="auth-number">
        LOGIN
      </div>


      <!-- WELLNESSHUB LOGO -->

      <div class="brand-mini">

        <span
          class="mini-leaf"
          aria-hidden="true">
          ☘
        </span>

        <span>
          WellnessHub
        </span>

      </div>


      <!-- WELCOME MESSAGE -->

      <header class="auth-header">

        <h1>
          Welcome Back
        </h1>

        <p>
          Login to your account
        </p>

      </header>


      <!-- ERROR / SUCCESS MESSAGE -->

      <div
        id="formBanner"
        class="banner"
        role="status"
        aria-live="polite">
      </div>


      <!-- =====================================
           LOGIN FORM
      ====================================== -->

      <form
        class="auth-form"
        id="loginForm"
        novalidate>


        <!-- EMAIL ADDRESS -->

        <label class="field">

          <span>
            Email
          </span>

          <input
            type="email"
            id="email"
            name="email"
            placeholder="Enter your email address"
            autocomplete="username"
            required
          />

        </label>


        <!-- =====================================
             PASSWORD WITH EYE ICON
        ====================================== -->

        <label class="field">

          <span>
            Password
          </span>

          <div class="password-input-wrapper">

            <input
              type="password"
              id="password"
              name="password"
              placeholder="Enter your password"
              autocomplete="current-password"
              required
            />


            <!-- SHOW / HIDE PASSWORD BUTTON -->

            <button
              type="button"
              class="password-toggle"
              id="togglePassword"
              aria-label="Show password"
              aria-controls="password"
              aria-pressed="false"
              title="Show password">


              <!-- EYE ICON -->

              <svg
                id="eyeShow"
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                aria-hidden="true">

                <path
                  d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12">
                </path>

                <circle
                  cx="12"
                  cy="12"
                  r="3">
                </circle>

              </svg>


              <!-- CROSSED EYE ICON -->

              <svg
                id="eyeHide"
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                aria-hidden="true"
                style="display: none;">

                <path
                  d="M3 3l18 18">
                </path>

                <path
                  d="M10.6 5.1A11.2 11.2 0 0 1 12 5c6.5 0 10 7 10 7a15 15 0 0 1-3.2 4.1">
                </path>

                <path
                  d="M6.3 6.3C3.5 8.2 2 12 2 12s3.5 7 10 7c1.8 0 3.4-.5 4.8-1.3">
                </path>

                <path
                  d="M10 10a3 3 0 0 0 4 4">
                </path>

              </svg>

            </button>

          </div>

        </label>


        <!-- FORGOT PASSWORD -->

        <a
          class="forgot-link"
          href="forgot-password.php">

          Forgot Password?

        </a>


        <!-- LOGIN BUTTON -->

        <button
          class="btn btn-primary btn-full"
          type="submit"
          id="submitBtn">

          Login

        </button>

      </form>


      <!-- =====================================
           PRIVACY POLICY AND POPIA
      ====================================== -->

      <p class="legal-text">

        By continuing, you acknowledge the

        <a href="popia.php">
          Privacy Policy
        </a>

        and

        <a href="popia.php">
          POPIA Compliance
        </a>.

      </p>


      <!-- =====================================
           CREATE ACCOUNT
      ====================================== -->

      <p class="form-footer">

        Need an account?

        <a href="register.php">
          Create Account
        </a>

      </p>

    </section>

  </main>


  <!-- ==========================================
       EXISTING LOGIN FUNCTIONALITY
  ========================================== -->

  <script src="js/login.js"></script>


  <!-- ==========================================
       SHOW / HIDE PASSWORD JAVASCRIPT
  ========================================== -->

  <script>

    document.addEventListener("DOMContentLoaded", function () {

      // Get password input
      const passwordInput =
        document.getElementById("password");

      // Get eye button
      const togglePassword =
        document.getElementById("togglePassword");

      // Get eye icons
      const eyeShow =
        document.getElementById("eyeShow");

      const eyeHide =
        document.getElementById("eyeHide");


      // Check that all elements exist
      if (
        !passwordInput ||
        !togglePassword ||
        !eyeShow ||
        !eyeHide
      ) {
        return;
      }


      // Handle eye button click
      togglePassword.addEventListener("click", function (event) {

        event.preventDefault();

        // Check whether password is hidden
        const isPasswordHidden =
          passwordInput.type === "password";


        if (isPasswordHidden) {

          // SHOW PASSWORD
          passwordInput.type = "text";

          // Change icon
          eyeShow.style.display = "none";
          eyeHide.style.display = "block";

          // Accessibility
          togglePassword.setAttribute(
            "aria-label",
            "Hide password"
          );

          togglePassword.setAttribute(
            "aria-pressed",
            "true"
          );

          togglePassword.title = "Hide password";

        } else {

          // HIDE PASSWORD
          passwordInput.type = "password";

          // Change icon
          eyeShow.style.display = "block";
          eyeHide.style.display = "none";

          // Accessibility
          togglePassword.setAttribute(
            "aria-label",
            "Show password"
          );

          togglePassword.setAttribute(
            "aria-pressed",
            "false"
          );

          togglePassword.title = "Show password";

        }

      });

    });

  </script>

</body>

</html>