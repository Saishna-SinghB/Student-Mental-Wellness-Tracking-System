
document.addEventListener("DOMContentLoaded", () => {

    // ======================================
    // WELLNESSHUB ADMIN SETTINGS
    // ======================================

    const API = "api/demoAPI.php";

    const toggle = document.getElementById(
        "switchAuditLogging"
    );

    const auditStatus = document.getElementById(
        "auditStatus"
    );

    const message = document.getElementById(
        "adminSettingsMessage"
    );

    const refreshButton = document.getElementById(
        "refreshAdminSettings"
    );

    let auditEnabled = true;
    let saving = false;
    let loaded = false;

    // ======================================
    // DISPLAY FEEDBACK
    // ======================================

    function showMessage(text, type = "") {

        message.textContent = text;

        message.classList.remove(
            "success",
            "error"
        );

        if (type) {
            message.classList.add(type);
        }

        message.hidden = false;
    }

    // ======================================
    // UPDATE SWITCH APPEARANCE
    // ======================================

    function render() {

        toggle.classList.toggle(
            "on",
            auditEnabled
        );

        toggle.setAttribute(
            "aria-checked",
            String(auditEnabled)
        );

        toggle.disabled = !loaded || saving;

        toggle.title = loaded
            ? "Click to change audit logging"
            : "Audit logging is unavailable";

        if (!loaded) {

            auditStatus.textContent = "Unavailable";

            auditStatus.classList.remove(
                "enabled"
            );

            return;
        }

        auditStatus.textContent = auditEnabled
            ? "Enabled"
            : "Disabled";

        auditStatus.classList.toggle(
            "enabled",
            auditEnabled
        );
    }

    // ======================================
    // READ SERVER RESPONSE
    // ======================================

    async function parseResponse(response) {

        const contentType =
            response.headers.get("content-type") || "";

        if (!contentType.includes("application/json")) {

            throw new Error(
                "The server returned an unexpected response. " +
                "Check your login session and demoAPI.php."
            );
        }

        const result = await response.json();

        if (!response.ok || !result.success) {

            throw new Error(
                result.message ||
                "The server could not complete the request."
            );
        }

        return result;
    }

    // ======================================
    // LOAD SAVED AUDIT LOGGING STATUS
    // ======================================

    async function loadSettings() {

        if (saving) {
            return;
        }

        loaded = false;

        render();

        showMessage(
            "Loading settings from WellnessHub..."
        );

        refreshButton.disabled = true;

        try {

            const response = await fetch(
                API + "?action=admin_platform_settings_get",
                {
                    method: "GET",
                    credentials: "same-origin",
                    cache: "no-store",
                    headers: {
                        "Accept": "application/json"
                    }
                }
            );

            const result = await parseResponse(response);

            const value =
                result.data?.audit_logging_enabled;

            if (value === undefined || value === null) {

                throw new Error(
                    "Audit logging status was missing " +
                    "from the server response."
                );
            }

            auditEnabled =
                value === true ||
                value === 1 ||
                value === "1";

            loaded = true;

            render();

            showMessage(
                "Settings loaded successfully.",
                "success"
            );

        } catch (error) {

            loaded = false;

            render();

            showMessage(
                "Unable to load settings: " +
                error.message,
                "error"
            );

        } finally {

            refreshButton.disabled = false;

        }
    }

    // ======================================
    // SAVE AUDIT LOGGING
    // ======================================

    async function saveAuditSetting() {

        if (!loaded || saving) {
            return;
        }

        const nextValue = !auditEnabled;

        // SECURITY WARNING

        if (!nextValue) {

            const confirmed = window.confirm(
                "WARNING: Turning off audit logging " +
                "can stop security-relevant actions " +
                "from being recorded.\n\n" +
                "Are you sure you want to disable it?"
            );

            if (!confirmed) {
                return;
            }
        }

        saving = true;

        render();

        showMessage(
            "Saving audit logging setting..."
        );

        try {

            const response = await fetch(
                API + "?action=admin_platform_settings_update",
                {
                    method: "POST",
                    credentials: "same-origin",

                    headers: {
                        "Content-Type":
                            "application/x-www-form-urlencoded",
                        "Accept": "application/json"
                    },

                    body: new URLSearchParams({
                        audit_logging_enabled:
                            nextValue ? "1" : "0"
                    })
                }
            );

            await parseResponse(response);

            // UPDATE ONLY AFTER SERVER CONFIRMS

            auditEnabled = nextValue;

            loaded = true;

            showMessage(
                auditEnabled
                    ? "Audit logging enabled and saved."
                    : "Audit logging disabled and saved.",
                "success"
            );

        } catch (error) {

            showMessage(
                "Could not save audit logging: " +
                error.message,
                "error"
            );

        } finally {

            saving = false;

            render();
        }
    }

    // ======================================
    // BUTTON EVENTS
    // ======================================

    toggle.addEventListener(
        "click",
        saveAuditSetting
    );

    refreshButton.addEventListener(
        "click",
        loadSettings
    );

    // LOAD SETTINGS ON PAGE OPEN

    loadSettings();

});
