
<?php
// WELLNESSHUB - SELF-HELP LIBRARY

require_once __DIR__ . '/auth-check.php';

function libH($value): string {
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES | ENT_SUBSTITUTE,
        'UTF-8'
    );
}

$fullName = trim(
    (string)($_SESSION['full_name'] ?? 'Student')
);

$firstName = explode(
    ' ',
    $fullName ?: 'Student'
)[0];

$initial = strtoupper(
    substr($firstName, 0, 1)
);

$profilePicture = (string)(
    $_SESSION['profile_picture'] ?? ''
);

$avatarStyle = $profilePicture !== ''
    ? ' style="background-image:url(\'' .
      libH($profilePicture) .
      '\');background-size:cover;background-position:center;"'
    : '';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">

    <script>
        if (
            localStorage.getItem("wellnesshub_dark_mode") === "1"
        ) {
            document.documentElement.classList.add(
                "theme-pending-dark"
            );
        }
    </script>

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Self-Help Library — WellnessHub</title>

    <link rel="stylesheet" href="css/style.css">

    <style>

        /* =====================================
           SELF-HELP LIBRARY STYLING
        ===================================== */

        .whlib {
            --lib-green: #2c7751;
            --lib-ink: #173d2c;
            --lib-muted: #718478;
            --lib-line: #e0ede4;
            --lib-white: #ffffff;

            max-width: 1300px;
        }

        .whlib * {
            box-sizing: border-box;
        }

        .whlib button {
            font: inherit;
        }

        /* WELCOME BANNER */

        .whlib .lib-hero {
            position: relative;
            overflow: hidden;

            background: linear-gradient(
                110deg,
                #174c36,
                #2d8557
            );

            border-radius: 24px;
            color: white;
            padding: 32px;
            margin-bottom: 22px;

            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 20px;
        }

        .whlib .lib-hero::after {
            content: "";

            position: absolute;
            width: 280px;
            height: 280px;

            border: 1px solid #ffffff35;
            border-radius: 50%;

            right: -85px;
            top: -150px;

            pointer-events: none;
        }

        .whlib .lib-kicker {
            color: #b9eed0;
            font-weight: 800;
            font-size: 12px;
            letter-spacing: 1.5px;
            text-transform: uppercase;
        }

        .whlib .lib-hero h2 {
            font-size: clamp(22px, 2.4vw, 32px);
            line-height: 1.2;
            color: white;

            margin: 8px 0 10px;
            max-width: 540px;
        }

        .whlib .lib-hero p {
            color: #e0f2e7;
            margin: 0;
            line-height: 1.55;
            max-width: 600px;
        }

        .whlib .lib-hero-art {
            flex: none;
            z-index: 1;

            background: #ffffff25;
            border: 1px solid #ffffff55;

            border-radius: 24px;

            width: 105px;
            height: 105px;

            display: grid;
            place-items: center;

            font-size: 56px;

            transform: rotate(7deg);
        }

        /* PANELS */

        .whlib .lib-panel {
            border: 1px solid var(--lib-line);
            background: var(--lib-white);

            border-radius: 24px;
            padding: 24px;
            margin-bottom: 22px;

            box-shadow: 0 10px 26px #154b2b0b;
        }

        .whlib .lib-panel-head {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 12px;

            margin-bottom: 19px;
        }

        .whlib .lib-panel-head h2 {
            margin: 0;
            font-size: 22px;
            color: var(--lib-ink);
        }

        .whlib .lib-muted {
            color: var(--lib-muted);
            font-size: 13px;
            margin: 6px 0 0;
        }

        .whlib .lib-light-btn {
            cursor: pointer;

            border: 1px solid #d3e4d9;
            border-radius: 12px;

            background: #eef7f0;
            color: #246943;

            font-weight: 800;
            padding: 10px 15px;
        }

        .whlib .lib-light-btn:hover {
            background: #def0e4;
        }

        /* SEARCH */

        .whlib .lib-search {
            display: flex;
            align-items: center;
            gap: 12px;

            border: 1px solid #dbe9df;
            border-radius: 15px;

            background: #f8fcf9;

            padding: 0 14px;
            margin-bottom: 20px;
        }

        .whlib .lib-search:focus-within {
            outline: 2px solid #80cba2;
        }

        .whlib .lib-search span {
            font-size: 22px;
        }

        .whlib .lib-search input {
            background: transparent;
            border: 0;
            outline: none;

            min-width: 0;
            width: 100%;

            padding: 16px 0;

            color: #183e2b;
            font: inherit;
        }

        /* CATEGORIES */

        .whlib .lib-categories {
            display: grid;

            grid-template-columns: repeat(
                5,
                minmax(0, 1fr)
            );

            gap: 12px;
        }

        .whlib .lib-category {
            cursor: pointer;

            border: 1px solid #e0eae3;
            border-radius: 19px;

            background: #fafdfa;

            min-width: 0;
            padding: 18px 9px;

            display: grid;
            justify-items: center;
            gap: 8px;

            color: #163e2b;

            transition:
                transform 0.2s,
                border-color 0.2s,
                box-shadow 0.2s;
        }

        .whlib .lib-category:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 20px #184a3015;
        }

        .whlib .lib-category[aria-pressed="true"] {
            border: 2px solid #348a5f;
            background: #effaf2;
        }

        .whlib .lib-bubble {
            width: 58px;
            height: 58px;

            border-radius: 18px;

            display: grid;
            place-items: center;

            font-size: 29px;
            background: #e0f3e6;
        }

        .whlib .lib-category:nth-child(2) .lib-bubble {
            background: #ece6ff;
        }

        .whlib .lib-category:nth-child(3) .lib-bubble {
            background: #e5ebff;
        }

        .whlib .lib-category:nth-child(4) .lib-bubble {
            background: #ffe6ed;
        }

        .whlib .lib-category:nth-child(5) .lib-bubble {
            background: #fff0d5;
        }

        .whlib .lib-category strong {
            text-align: center;
            font-size: 14px;
            line-height: 1.4;
        }

        .whlib .lib-category small {
            color: #809587;
            font-size: 12px;
        }

        /* FILTER TABS */

        .whlib .lib-tabs {
            display: flex;
            align-items: center;
            gap: 8px;
            flex-wrap: wrap;
        }

        .whlib .lib-tab {
            cursor: pointer;

            border: 1px solid #dfe9e1;
            border-radius: 50px;

            color: #516d59;
            background: #eff5f0;

            padding: 8px 13px;

            font-size: 13px;
            font-weight: 800;
        }

        .whlib .lib-tab[aria-pressed="true"] {
            background: #2c7751;
            border-color: #2c7751;
            color: white;
        }

        /* RESOURCE CARDS */

        .whlib .lib-grid {
            display: grid;

            grid-template-columns: repeat(
                2,
                minmax(0, 1fr)
            );

            gap: 15px;
        }

        .whlib .lib-card {
            display: flex;
            flex-direction: column;
            gap: 11px;

            padding: 20px;

            border-radius: 20px;
            border: 1px solid #e2ede5;

            background: linear-gradient(
                145deg,
                #ffffff,
                #f9fcfa
            );

            min-width: 0;

            transition:
                transform 0.2s,
                box-shadow 0.2s;
        }

        .whlib .lib-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 14px 27px #1a503119;
        }

        .whlib .lib-card-head {
            display: flex;
            justify-content: space-between;
            gap: 10px;
            align-items: flex-start;
        }

        .whlib .lib-card-icon {
            display: grid;
            place-items: center;

            font-size: 30px;

            width: 57px;
            height: 57px;

            background: #e4f4ea;
            border-radius: 16px;
        }

        .whlib .lib-card[data-category="Academic Stress"]
        .lib-card-icon {
            background: #eee8ff;
        }

        .whlib .lib-card[data-category="Sleep"]
        .lib-card-icon {
            background: #e7ebff;
        }

        .whlib .lib-card[data-category="Relationships"]
        .lib-card-icon {
            background: #ffe5ea;
        }

        .whlib .lib-card[data-category="Self Confidence"]
        .lib-card-icon {
            background: #fff1d9;
        }

        .whlib .lib-card[data-category="Crisis Support"]
        .lib-card-icon {
            background: #dff2ee;
        }

        /* SAVE FAVORITE */

        .whlib .lib-save {
            cursor: pointer;

            border: 1px solid #dde9e1;
            border-radius: 50%;

            width: 37px;
            height: 37px;

            background: white;
            color: #829588;

            font-size: 22px;
        }

        .whlib .lib-save[aria-pressed="true"] {
            background: #e4f4e9;
            color: #277c4d;
        }

        /* RESOURCE LABELS */

        .whlib .lib-tags {
            display: flex;
            flex-wrap: wrap;
            gap: 6px;
        }

        .whlib .lib-tag {
            font-size: 11px;
            font-weight: 800;

            padding: 6px 9px;
            border-radius: 50px;

            background: #e9f5ed;
            color: #347a52;
        }

        .whlib .lib-tag + .lib-tag {
            background: #f0f2f4;
            color: #697982;
        }

        .whlib .lib-card h3 {
            font-size: 18px;
            color: #173b2b;

            margin: 0;
            line-height: 1.35;
        }

        .whlib .lib-card p {
            font-size: 14px;
            color: #708579;

            line-height: 1.55;
            margin: 0;

            flex: 1;
        }

        .whlib .lib-card-foot {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 10px;

            margin-top: 5px;
        }

        .whlib .lib-card-foot small {
            color: #84988a;
        }

        .whlib .lib-open {
            cursor: pointer;

            background: #2e7951;
            border: 0;

            color: white;

            padding: 10px 14px;
            border-radius: 12px;

            font-weight: 800;
        }

        .whlib .lib-open:hover {
            background: #1d5e3a;
        }

        /* EMPTY STATE */

        .whlib .lib-empty {
            text-align: center;
            color: #718579;
            padding: 38px 16px;
        }

        /* SUPPORT FOOTER */

        .whlib .lib-tip {
            display: flex;
            gap: 15px;
            align-items: center;

            border-radius: 19px;
            background: #e8f5eb;
            border: 1px solid #cee7d6;

            padding: 20px;
            margin-top: 3px;
        }

        .whlib .lib-tip p {
            margin: 5px 0 0;
            color: #66806c;
            line-height: 1.5;
            font-size: 13px;
        }

        .whlib .lib-warning {
            color: #78633e;
            background: #fff7e5;

            border-radius: 12px;
            padding: 12px 16px;

            margin: 0 0 18px;
            font-size: 13px;
        }

        /* RESOURCE POPUP */

        .whlib .lib-dialog-backdrop {
            position: fixed;
            inset: 0;
            z-index: 9999;

            display: grid;
            place-items: center;

            background: #10271cc2;
            padding: 18px;
        }

        .whlib .lib-dialog-backdrop[hidden],
        .whlib [hidden] {
            display: none !important;
        }

        .whlib .lib-dialog {
            position: relative;
            overflow: auto;

            max-height: calc(100vh - 36px);
            width: min(640px, 100%);

            background: white;
            color: #173d2b;

            border-radius: 25px;
            padding: 28px;

            box-shadow: 0 25px 65px #0005;
        }

        .whlib .lib-close {
            position: absolute;
            top: 16px;
            right: 16px;

            cursor: pointer;
            border: 0;

            border-radius: 50%;
            width: 38px;
            height: 38px;

            background: #eef5ef;
            color: #31503b;

            font-size: 22px;
        }

        .whlib .lib-dialog-title {
            font-size: 26px;
            line-height: 1.25;
            margin: 12px 36px 10px 0;
        }

        .whlib .lib-dialog-summary {
            color: #6d8172;
            line-height: 1.6;
            margin: 0 0 18px;
        }

        .whlib .lib-step {
            background: #f4faf6;

            border-left: 4px solid #87cba2;
            border-radius: 12px;

            padding: 14px 16px;
            margin: 11px 0;
        }

        .whlib .lib-step h3 {
            font-size: 15px;
            color: #246a45;
            margin: 0 0 7px;
        }

        .whlib .lib-step p {
            font-size: 14px;
            line-height: 1.65;

            color: #58705e;
            margin: 0;
        }

        /* INTERACTIVE ACTIVITIES */

        .whlib .lib-activity {
            margin: 18px 0;

            background: #eaf6ee;
            border: 1px solid #cfe8d7;

            padding: 17px;
            border-radius: 16px;
        }

        .whlib .lib-activity label {
            display: block;

            font-size: 13px;
            font-weight: 700;

            margin: 12px 0 6px;
        }

        .whlib .lib-activity textarea {
            display: block;

            width: 100%;
            min-height: 70px;

            resize: vertical;
            padding: 10px;

            border: 1px solid #bfdcca;
            border-radius: 10px;

            background: white;
            color: #173d2b;

            font: inherit;
        }

        .whlib .lib-activity p {
            font-size: 12px;
            color: #698171;
        }

        /* BREATHING CIRCLE */

        .whlib .lib-circle {
            margin: 18px auto;

            display: grid;
            place-items: center;

            width: 135px;
            height: 135px;

            border-radius: 50%;

            background: linear-gradient(
                135deg,
                #b6e4c4,
                #6cc396
            );

            font-weight: 800;

            transition: transform 4s ease-in-out;
        }

        .whlib .lib-circle.big {
            transform: scale(1.2);
        }

        .whlib .lib-circle.small {
            transform: scale(0.86);
        }

        /* POPUP BUTTONS */

        .whlib .lib-modal-actions {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin-top: 20px;
        }

        .whlib .lib-link {
            background: #2c7751;
            color: white;

            padding: 11px 15px;
            border-radius: 12px;

            font-weight: 800;
            text-decoration: none;
        }

        .whlib .lib-link:hover {
            background: #205c40;
        }

        /* RESPONSIVE */

        @media (max-width: 1050px) {

            .whlib .lib-categories {
                grid-template-columns: repeat(
                    3,
                    minmax(0, 1fr)
                );
            }
        }

        @media (max-width: 740px) {

            .whlib .lib-grid {
                grid-template-columns: 1fr;
            }

            .whlib .lib-hero {
                padding: 24px;
            }

            .whlib .lib-hero-art {
                display: none;
            }

            .whlib .lib-panel {
                padding: 18px;
            }

            .whlib .lib-panel-head {
                flex-wrap: wrap;
            }
        }

        @media (max-width: 470px) {

            .whlib .lib-categories {
                grid-template-columns: repeat(
                    2,
                    minmax(0, 1fr)
                );
            }

            .whlib .lib-card {
                padding: 16px;
            }
        }

    </style>

</head>

<body class="app-body">

<script src="js/theme.js"></script>
<script src="js/notif-badge.js"></script>

<div class="app-shell">

    <!-- =====================================
         ORIGINAL STUDENT SIDEBAR
    ===================================== -->

    <aside class="sidebar student-sidebar">

        <a
            class="brand-mini sidebar-brand"
            href="index.php"
        >
            <span class="mini-leaf" aria-hidden="true">☘</span>
            <span>WellnessHub</span>
        </a>

        <nav
            class="side-nav"
            aria-label="Student navigation"
        >

            <a href="dashboard.php">
                <span>▣</span> Dashboard
            </a>

            <a href="mood-tracking.php">
                <span>☺</span> Mood Tracking
            </a>

            <a href="journal.php">
                <span>✎</span> Journal
            </a>

            <a
                class="active"
                href="self-help-library.php"
                aria-current="page"
            >
                <span>▤</span> Self-Help Library
            </a>

            <a href="counselling-booking.php">
                <span>♡</span> Book Counselling
            </a>

            <a href="peer-support.php">
                <span>☷</span> Peer Support
            </a>

            <a href="achievements.php">
                <span>★</span> Achievements
            </a>

            <a href="notifications.php">
                <span>🔔</span> Notifications
            </a>

            <a href="settings.php">
                <span>⚙</span> Settings
            </a>

            <a href="logout.php">
                <span>↪</span> Logout
            </a>

        </nav>

    </aside>

    <!-- =====================================
         MAIN PAGE
    ===================================== -->

    <main class="dashboard-main">

        <!-- ORIGINAL HEADER -->

        <header class="topbar">

            <div>

                <p class="eyebrow">
                    Student Side
                </p>

                <h1>
                    Self-Help Library
                </h1>

                <p class="page-subtitle">
                    Browse quick wellness resources and exercises.
                </p>

            </div>

            <div class="topbar-actions">

                <a
                    class="icon-btn notif-bell"
                    href="notifications.php"
                    aria-label="Notifications"
                >
                    🔔

                    <span
                        class="notif-dot"
                        id="notifDot"
                        style="display:none;"
                    ></span>
                </a>

                <a
                    href="profile.php"
                    class="avatar"
                    aria-label="My Profile"
                    <?= $avatarStyle ?>
                >
                    <?=
                        $profilePicture === ''
                            ? libH($initial)
                            : ''
                    ?>
                </a>

            </div>

        </header>

        <!-- =====================================
             CREATIVE LIBRARY CONTENT
        ===================================== -->

        <div class="whlib" id="wellnessLibrary">

            <!-- WELCOME BANNER -->

            <section class="lib-hero">

                <div>

                    <div class="lib-kicker">
                        Your space to recharge
                    </div>

                    <h2>
                        Whatever today feels like,
                        there’s a place to start. ✨
                    </h2>

                    <p>
                        Explore small, practical tools
                        for student life. You can go
                        at your own pace.
                    </p>

                </div>

                <div
                    class="lib-hero-art"
                    aria-hidden="true"
                >
                    🌿
                </div>

            </section>

            <!-- =====================================
                 CATEGORIES
            ===================================== -->

            <section
                class="lib-panel"
                aria-labelledby="libCategoriesTitle"
            >

                <div class="lib-panel-head">

                    <div>

                        <h2 id="libCategoriesTitle">
                            Explore by category
                        </h2>

                        <p class="lib-muted">
                            Pick a topic or search
                            for what you need.
                        </p>

                    </div>

                    <button
                        type="button"
                        class="lib-light-btn"
                        id="libShowAll"
                    >
                        Show All
                    </button>

                </div>

                <!-- SEARCH BAR -->

                <label class="lib-search">

                    <span aria-hidden="true">⌕</span>

                    <input
                        type="search"
                        id="libSearch"
                        placeholder="Search anxiety, exams, sleep, confidence..."
                        aria-label="Search resources"
                    >

                </label>

                <!-- CATEGORY CARDS -->

                <div
                    class="lib-categories"
                    id="libCategories"
                >

                    <button
                        type="button"
                        class="lib-category"
                        data-category="Anxiety"
                        aria-pressed="false"
                    >

                        <span class="lib-bubble">🧠</span>

                        <strong>Anxiety</strong>

                        <small data-count="Anxiety"></small>

                    </button>

                    <button
                        type="button"
                        class="lib-category"
                        data-category="Academic Stress"
                        aria-pressed="false"
                    >

                        <span class="lib-bubble">📚</span>

                        <strong>Academic Stress</strong>

                        <small data-count="Academic Stress"></small>

                    </button>

                    <button
                        type="button"
                        class="lib-category"
                        data-category="Sleep"
                        aria-pressed="false"
                    >

                        <span class="lib-bubble">🌙</span>

                        <strong>Sleep</strong>

                        <small data-count="Sleep"></small>

                    </button>

                    <button
                        type="button"
                        class="lib-category"
                        data-category="Relationships"
                        aria-pressed="false"
                    >

                        <span class="lib-bubble">💗</span>

                        <strong>Relationships</strong>

                        <small data-count="Relationships"></small>

                    </button>

                    <button
                        type="button"
                        class="lib-category"
                        data-category="Self Confidence"
                        aria-pressed="false"
                    >

                        <span class="lib-bubble">🌻</span>

                        <strong>Self Confidence</strong>

                        <small data-count="Self Confidence"></small>

                    </button>

                </div>

            </section>

            <!-- API WARNING -->

            <p
                class="lib-warning"
                id="libApiWarning"
                hidden
            >
                Some additional resources could not load.
                The built-in guides are still available.
            </p>

            <!-- =====================================
                 RESOURCE LIST
            ===================================== -->

            <section
                class="lib-panel"
                id="libResourceSection"
                aria-labelledby="libResourcesTitle"
            >

                <div class="lib-panel-head">

                    <div>

                        <h2 id="libResourcesTitle">
                            All wellness resources
                        </h2>

                        <p
                            class="lib-muted"
                            id="libCount"
                            role="status"
                        ></p>

                    </div>

                    <div class="lib-tabs">

                        <button
                            class="lib-tab"
                            id="libAllTab"
                            type="button"
                            aria-pressed="true"
                        >
                            All
                        </button>

                        <button
                            class="lib-tab"
                            id="libSavedTab"
                            type="button"
                            aria-pressed="false"
                        >
                            ♡ Saved
                        </button>

                    </div>

                </div>

                <div
                    class="lib-grid"
                    id="libGrid"
                ></div>

                <p
                    class="lib-empty"
                    id="libEmpty"
                    hidden
                >
                    No resources found.
                    Try another category or search. 🌱
                </p>

            </section>

            <!-- SUPPORT MESSAGE -->

            <div class="lib-tip">

                <span style="font-size:32px;">
                    💚
                </span>

                <div>

                    <strong>
                        Small steps count.
                    </strong>

                    <p>
                        These exercises support everyday
                        wellbeing, but they are not a substitute
                        for medical or counselling care.
                        If someone is in immediate danger,
                        contact local emergency services.
                    </p>

                </div>

            </div>

            <!-- =====================================
                 INTERACTIVE RESOURCE POPUP
            ===================================== -->

            <div
                class="lib-dialog-backdrop"
                id="libBackdrop"
                hidden
            >

                <section
                    class="lib-dialog"
                    id="libDialog"
                    role="dialog"
                    aria-modal="true"
                    aria-labelledby="libDialogTitle"
                    tabindex="-1"
                >

                    <button
                        class="lib-close"
                        type="button"
                        id="libClose"
                        aria-label="Close guide"
                    >
                        ×
                    </button>

                    <span
                        class="lib-tag"
                        id="libDialogCategory"
                    ></span>

                    <h2
                        class="lib-dialog-title"
                        id="libDialogTitle"
                    ></h2>

                    <p
                        class="lib-dialog-summary"
                        id="libDialogSummary"
                    ></p>

                    <div id="libDialogSections"></div>

                    <div id="libDialogActivity"></div>

                    <div
                        class="lib-modal-actions"
                        id="libDialogActions"
                    >

                        <button
                            class="lib-light-btn"
                            type="button"
                            id="libDone"
                        >
                            Done for now ✓
                        </button>

                    </div>

                </section>

            </div>

        </div>

    </main>

</div>

<!-- =====================================
     SELF-HELP LIBRARY JAVASCRIPT
===================================== -->

<script>

(() => {

    const $ = id => document.getElementById(id);

    // =====================================
    // BUILT-IN RESOURCES
    // =====================================

    const builtIn = [

        {
            id: 'thoughts',
            title: 'CBT Worksheet: Managing Anxiety',
            subtitle: 'A simple worksheet for understanding anxious thoughts and finding a balanced response.',
            category: 'Anxiety',
            type: 'Interactive worksheet',
            icon: '🧠',
            time: '7 min',
            activity: 'thoughts',

            steps: [
                [
                    'Notice the situation',
                    'What happened just before you felt anxious?'
                ],
                [
                    'Check the thought',
                    'What evidence supports the worry, and what evidence does not?'
                ],
                [
                    'Find a balanced thought',
                    'Write a realistic and compassionate alternative to the worrying thought.'
                ]
            ]
        },

        {
            id: 'breathing',
            title: 'Guided Breathing Exercise',
            subtitle: 'Follow a gentle breathing circle at a comfortable pace.',
            category: 'Anxiety',
            type: 'Calming exercise',
            icon: '🌬️',
            time: '3 min',
            activity: 'breathing',

            steps: [
                [
                    'Get comfortable',
                    'Sit or stand comfortably and relax your shoulders.'
                ],
                [
                    'Breathe gently',
                    'Follow the circle only if it feels comfortable; never force your breathing. Stop if you feel dizzy.'
                ]
            ]
        },

        {
            id: 'grounding',
            title: '5–4–3–2–1 Grounding Practice',
            subtitle: 'Bring your attention back to the present with a five-senses activity.',
            category: 'Anxiety',
            type: 'Guided activity',
            icon: '🌿',
            time: '5 min',
            activity: 'grounding',

            steps: [
                [
                    'Notice your surroundings',
                    'Use your senses to notice what is here, now.'
                ],
                [
                    'Take your time',
                    'There is no need to rush or finish every step. Adapt the exercise to suit your needs.'
                ]
            ]
        },

        {
            id: 'study',
            title: 'Study Smarter, Stress Less',
            subtitle: 'Make a manageable study plan instead of trying to do everything at once.',
            category: 'Academic Stress',
            type: 'Practical guide',
            icon: '📚',
            time: '6 min',

            steps: [
                [
                    'Choose three priorities',
                    'Pick your most important task, one helpful task, and one quick win.'
                ],
                [
                    'Break tasks into pieces',
                    'Turn "finish assignment" into "read brief", "write outline", and "draft first section".'
                ],
                [
                    'Take breaks',
                    'Work in manageable periods, pause, stretch, and return when ready.'
                ],
                [
                    'Ask for help',
                    'Speak with lecturers or academic support when you are stuck.'
                ]
            ]
        },

        {
            id: 'exam',
            title: 'Before-Exam Calm Checklist',
            subtitle: 'Simple steps for preparing for an exam without adding extra pressure.',
            category: 'Academic Stress',
            type: 'Checklist',
            icon: '✅',
            time: '4 min',

            steps: [
                [
                    'The day before',
                    'Gather what you need, confirm the location, and allow time for rest.'
                ],
                [
                    'When you arrive',
                    'Give yourself time, relax your shoulders, and focus on the next manageable step.'
                ],
                [
                    'If you get stuck',
                    'Try another question and come back to it when you can.'
                ]
            ]
        },

        {
            id: 'sleep',
            title: 'A Better Night’s Sleep',
            subtitle: 'Gentle ways to create a more consistent sleep routine.',
            category: 'Sleep',
            type: 'Wellness guide',
            icon: '🌙',
            time: '5 min',

            steps: [
                [
                    'Keep a steady schedule',
                    'Try to wake up at a similar time on most days.'
                ],
                [
                    'Wind down',
                    'Step away from demanding work and reduce bright light before bed.'
                ],
                [
                    'Notice caffeine',
                    'If caffeine affects your sleep, avoid it later in the day.'
                ],
                [
                    'Seek help when needed',
                    'Speak to a healthcare professional if sleep difficulties persist.'
                ]
            ]
        },

        {
            id: 'winddown',
            title: 'Quiet Your Mind Before Bed',
            subtitle: 'An easy evening reflection for busy student minds.',
            category: 'Sleep',
            type: 'Reflection',
            icon: '✨',
            time: '4 min',

            steps: [
                [
                    'Write tomorrow’s tasks',
                    'Put reminders on paper rather than holding them in your mind.'
                ],
                [
                    'Name a small win',
                    'Think of one thing you handled well today.'
                ],
                [
                    'Choose a relaxing cue',
                    'Try reading, calm music, or gentle stretching.'
                ]
            ]
        },

        {
            id: 'boundaries',
            title: 'Healthy Boundaries & Connections',
            subtitle: 'Communicate what you need while respecting others.',
            category: 'Relationships',
            type: 'Communication guide',
            icon: '💗',
            time: '6 min',

            steps: [
                [
                    'Know your limits',
                    'Consider what makes you feel respected and comfortable.'
                ],
                [
                    'Use clear words',
                    'For example: "I need some quiet time this evening."'
                ],
                [
                    'Listen in return',
                    'Healthy boundaries respect the needs of both people.'
                ],
                [
                    'Ask for support',
                    'If someone makes you feel unsafe, speak with a trusted professional.'
                ]
            ]
        },

        {
            id: 'friends',
            title: 'Feeling Less Alone on Campus',
            subtitle: 'Realistic ways to build supportive friendships.',
            category: 'Relationships',
            type: 'Support guide',
            icon: '🤝',
            time: '5 min',

            steps: [
                [
                    'Start small',
                    'Say hello after class or join a campus club.'
                ],
                [
                    'Focus on quality',
                    'A supportive friendship is more important than having many contacts.'
                ],
                [
                    'Be patient',
                    'It is normal for connections to take time.'
                ]
            ]
        },

        {
            id: 'confidence',
            title: 'Build Confidence in Small Steps',
            subtitle: 'Practice realistic self-talk and celebrate your progress.',
            category: 'Self Confidence',
            type: 'Growth guide',
            icon: '🌻',
            time: '6 min',

            steps: [
                [
                    'Notice strengths',
                    'Write down three things you have improved or managed.'
                ],
                [
                    'Try a small challenge',
                    'Choose something achievable, such as asking one question in class.'
                ],
                [
                    'Change the inner dialogue',
                    'Try "I’m learning" instead of "I’m not good at this."'
                ],
                [
                    'Recognize progress',
                    'Growth matters more than perfection.'
                ]
            ]
        },

        {
            id: 'kindness',
            title: 'A Kinder Inner Voice',
            subtitle: 'A short self-compassion activity for difficult days.',
            category: 'Self Confidence',
            type: 'Reflection',
            icon: '💛',
            time: '4 min',

            steps: [
                [
                    'Name how you feel',
                    'Try "I feel disappointed" rather than judging yourself.'
                ],
                [
                    'Respond with kindness',
                    'Ask what you would say to a friend in the same situation.'
                ],
                [
                    'Choose one helpful step',
                    'A small next action is enough.'
                ]
            ]
        },

        {
            id: 'sadag',
            title: 'SADAG Mental Health Support',
            subtitle: 'Find South African mental health information and support contacts.',
            category: 'Crisis Support',
            type: 'Support contact',
            icon: '☎️',
            time: 'Any time',

            url: 'https://www.sadag.org/',

            steps: [
                [
                    'For urgent danger',
                    'Contact emergency services immediately if you or someone else is in immediate danger.'
                ],
                [
                    'Talk to someone',
                    'Visit SADAG’s official website for current counselling and support contact information.'
                ]
            ]
        }

    ];

    // =====================================
    // LIBRARY VARIABLES
    // =====================================

    let allResources = [...builtIn];

    let category = 'All';
    let tab = 'All';

    let lastFocus = null;
    let breathTimer = null;

    const savedKey =
        'wellnesshub-saved-resources-' +
        <?= json_encode(
            (string)($_SESSION['user_id'] ?? ''),
            JSON_HEX_TAG |
            JSON_HEX_AMP |
            JSON_HEX_APOS |
            JSON_HEX_QUOT
        ) ?>;

    let saved = [];

    try {

        saved = JSON.parse(
            localStorage.getItem(savedKey) || '[]'
        );

        if (!Array.isArray(saved)) {
            saved = [];
        }

    } catch (error) {
        saved = [];
    }

    // =====================================
    // CREATE HTML ELEMENTS
    // =====================================

    function make(tag, className, text) {

        const node = document.createElement(tag);

        if (className) {
            node.className = className;
        }

        if (text !== undefined) {
            node.textContent = text;
        }

        return node;
    }

    // =====================================
    // SAVE FAVORITES
    // =====================================

    function saveList() {

        try {

            localStorage.setItem(
                savedKey,
                JSON.stringify(saved)
            );

        } catch (error) {
            // Browser storage may be unavailable.
        }
    }

    // =====================================
    // FILTER RESOURCES
    // =====================================

    function filteredResources() {

        const term = $('libSearch')
            .value.trim().toLowerCase();

        return allResources.filter(resource => {

            const categoryMatches =
                category === 'All' ||
                resource.category === category ||
                resource.category === 'Crisis Support';

            const savedMatches =
                tab !== 'Saved' ||
                saved.includes(resource.id);

            const text = [
                resource.title,
                resource.subtitle,
                resource.category,
                resource.type
            ].join(' ').toLowerCase();

            const searchMatches =
                text.includes(term);

            return (
                categoryMatches &&
                savedMatches &&
                searchMatches
            );

        });
    }

    // =====================================
    // DISPLAY RESOURCE CARDS
    // =====================================

    function render() {

        const grid = $('libGrid');

        grid.replaceChildren();

        // CATEGORY BUTTON STATES

        document
            .querySelectorAll('.lib-category')
            .forEach(button => {

                button.setAttribute(
                    'aria-pressed',
                    String(
                        button.dataset.category === category
                    )
                );

            });

        // CATEGORY COUNTS

        document
            .querySelectorAll('[data-count]')
            .forEach(element => {

                const count = allResources.filter(
                    resource =>
                        resource.category ===
                        element.dataset.count
                ).length;

                element.textContent =
                    count + ' ' +
                    (count === 1 ? 'resource' : 'resources');

            });

        // TAB STATES

        $('libAllTab').setAttribute(
            'aria-pressed',
            String(tab === 'All')
        );

        $('libSavedTab').setAttribute(
            'aria-pressed',
            String(tab === 'Saved')
        );

        const visible = filteredResources();

        $('libCount').textContent =
            visible.length + ' ' +
            (visible.length === 1
                ? 'resource'
                : 'resources') +
            ' available';

        // HEADING

        if (tab === 'Saved') {

            $('libResourcesTitle').textContent =
                'Your saved resources';

        } else if (category === 'All') {

            $('libResourcesTitle').textContent =
                'All wellness resources';

        } else {

            $('libResourcesTitle').textContent =
                category + ' resources';
        }

        $('libEmpty').hidden = visible.length > 0;

        // CREATE RESOURCE CARDS

        visible.forEach(resource => {

            const card = make(
                'article',
                'lib-card'
            );

            card.dataset.category = resource.category;

            // TOP ROW

            const top = make(
                'div',
                'lib-card-head'
            );

            const icon = make(
                'span',
                'lib-card-icon',
                resource.icon || '📄'
            );

            icon.setAttribute(
                'aria-hidden',
                'true'
            );

            const isSaved = saved.includes(resource.id);

            const favorite = make(
                'button',
                'lib-save',
                isSaved ? '♥' : '♡'
            );

            favorite.type = 'button';

            favorite.setAttribute(
                'aria-label',
                isSaved
                    ? 'Remove saved resource'
                    : 'Save resource'
            );

            favorite.setAttribute(
                'aria-pressed',
                String(isSaved)
            );

            // FAVORITE BUTTON ACTION

            favorite.addEventListener('click', () => {

                if (saved.includes(resource.id)) {

                    saved = saved.filter(
                        id => id !== resource.id
                    );

                } else {

                    saved = [
                        ...saved,
                        resource.id
                    ];
                }

                saveList();
                render();

            });

            top.append(icon, favorite);

            card.appendChild(top);

            // CATEGORY TAGS

            const tags = make(
                'div',
                'lib-tags'
            );

            tags.append(
                make(
                    'span',
                    'lib-tag',
                    resource.category
                ),
                make(
                    'span',
                    'lib-tag',
                    resource.type
                )
            );

            card.appendChild(tags);

            // TITLE AND DESCRIPTION

            card.append(
                make(
                    'h3',
                    '',
                    resource.title
                ),

                make(
                    'p',
                    '',
                    resource.subtitle
                )
            );

            // FOOTER

            const foot = make(
                'div',
                'lib-card-foot'
            );

            foot.appendChild(
                make(
                    'small',
                    '',
                    resource.time || 'Explore resource'
                )
            );

            const open = make(
                'button',
                'lib-open',
                'Open Guide ↗'
            );

            open.type = 'button';

            open.addEventListener('click', () => {
                openGuide(resource);
            });

            foot.appendChild(open);

            card.appendChild(foot);

            grid.appendChild(card);

        });
    }

    // =====================================
    // CATEGORY BUTTON ACTIONS
    // =====================================

    document
        .querySelectorAll('.lib-category')
        .forEach(button => {

            button.addEventListener('click', () => {

                category = button.dataset.category;
                tab = 'All';

                render();

                $('libResourceSection').scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });

            });

        });

    // SHOW ALL

    $('libShowAll').addEventListener('click', () => {

        category = 'All';
        tab = 'All';

        $('libSearch').value = '';

        render();
    });

    // SEARCH

    $('libSearch').addEventListener(
        'input',
        render
    );

    // ALL TAB

    $('libAllTab').addEventListener('click', () => {

        tab = 'All';
        render();

    });

    // SAVED TAB

    $('libSavedTab').addEventListener('click', () => {

        tab = 'Saved';
        render();

    });

    // =====================================
    // BREATHING EXERCISE
    // =====================================

    function stopBreathing() {

        if (breathTimer !== null) {

            clearInterval(breathTimer);
            breathTimer = null;
        }
    }

    // =====================================
    // OPEN RESOURCE GUIDE
    // =====================================

    function openGuide(resource) {

        lastFocus = document.activeElement;

        stopBreathing();

        $('libDialogCategory').textContent =
            resource.category + ' · ' + resource.type;

        $('libDialogTitle').textContent =
            resource.title;

        $('libDialogSummary').textContent =
            resource.subtitle;

        const sections = $('libDialogSections');

        const activity = $('libDialogActivity');

        const actions = $('libDialogActions');

        sections.replaceChildren();
        activity.replaceChildren();

        // REMOVE PREVIOUS WEBSITE LINK

        actions
            .querySelectorAll('.lib-external')
            .forEach(element => element.remove());

        // BUILD GUIDE SECTIONS

        (resource.steps || []).forEach(
            ([title, description]) => {

                const section = make(
                    'div',
                    'lib-step'
                );

                section.append(
                    make('h3', '', title),
                    make('p', '', description)
                );

                sections.appendChild(section);

            }
        );

        // =================================
        // ANXIETY WORKSHEET
        // =================================

        if (resource.activity === 'thoughts') {

            const box = make(
                'div',
                'lib-activity'
            );

            box.appendChild(
                make(
                    'h3',
                    '',
                    'Try a private thought check-in'
                )
            );

            const questions = [

                'What situation is worrying you?',

                'What thought came to mind?',

                'What is a kinder, more realistic perspective?'

            ];

            questions.forEach(question => {

                const label = make(
                    'label',
                    '',
                    question
                );

                const field = make('textarea');

                field.placeholder = 'Write here...';

                label.appendChild(field);

                box.appendChild(label);

            });

            box.appendChild(
                make(
                    'p',
                    '',
                    'Your answers remain on this screen and are not saved or submitted.'
                )
            );

            activity.appendChild(box);
        }

        // =================================
        // GROUNDING ACTIVITY
        // =================================

        else if (
            resource.activity === 'grounding'
        ) {

            const box = make(
                'div',
                'lib-activity'
            );

            box.appendChild(
                make(
                    'h3',
                    '',
                    'Five senses check-in'
                )
            );

            const items = [

                '5 things you can see',

                '4 things you can feel',

                '3 things you can hear',

                '2 things you can smell',

                '1 thing you can taste'

            ];

            items.forEach(question => {

                const label = make('label');

                const input = make('input');

                input.type = 'checkbox';

                input.style.marginRight = '10px';

                label.append(
                    input,
                    document.createTextNode(question)
                );

                box.appendChild(label);

            });

            activity.appendChild(box);
        }

        // =================================
        // BREATHING ACTIVITY
        // =================================

        else if (
            resource.activity === 'breathing'
        ) {

            const box = make(
                'div',
                'lib-activity'
            );

            box.appendChild(
                make(
                    'h3',
                    '',
                    'Breathe gently with the circle'
                )
            );

            const circle = make(
                'div',
                'lib-circle',
                'Ready'
            );

            const button = make(
                'button',
                'lib-open',
                'Start breathing'
            );

            button.type = 'button';

            button.addEventListener('click', () => {

                if (breathTimer !== null) {

                    stopBreathing();

                    circle.classList.remove(
                        'big',
                        'small'
                    );

                    circle.textContent = 'Ready';

                    button.textContent =
                        'Start breathing';

                    return;
                }

                let inhale = true;

                const tick = () => {

                    circle.classList.toggle(
                        'big',
                        inhale
                    );

                    circle.classList.toggle(
                        'small',
                        !inhale
                    );

                    circle.textContent =
                        inhale
                            ? 'Breathe in'
                            : 'Breathe out';

                    inhale = !inhale;
                };

                button.textContent =
                    'Stop exercise';

                tick();

                breathTimer = setInterval(
                    tick,
                    4000
                );

            });

            box.append(
                circle,

                make(
                    'p',
                    '',
                    'Only follow if comfortable. Stop if you feel lightheaded.'
                ),

                button
            );

            activity.appendChild(box);
        }

        // =================================
        // WEBSITE LINK
        // =================================

        if (
            resource.url &&
            /^https?:\/\//i.test(resource.url)
        ) {

            const link = make(
                'a',
                'lib-link lib-external',
                'Visit resource website ↗'
            );

            link.href = resource.url;

            link.target = '_blank';

            link.rel = 'noopener noreferrer';

            actions.prepend(link);
        }

        // DISPLAY POPUP

        $('libBackdrop').hidden = false;

        document.body.style.overflow = 'hidden';

        $('libClose').focus();
    }

    // =====================================
    // CLOSE RESOURCE GUIDE
    // =====================================

    function closeGuide() {

        stopBreathing();

        $('libBackdrop').hidden = true;

        document.body.style.overflow = '';

        if (
            lastFocus &&
            typeof lastFocus.focus === 'function'
        ) {
            lastFocus.focus();
        }
    }

    $('libClose').addEventListener(
        'click',
        closeGuide
    );

    $('libDone').addEventListener(
        'click',
        closeGuide
    );

    // CLOSE WHEN CLICKING OUTSIDE

    $('libBackdrop').addEventListener(
        'click',
        event => {

            if (
                event.target === $('libBackdrop')
            ) {
                closeGuide();
            }

        }
    );

    // ESCAPE KEY AND FOCUS MANAGEMENT

    document.addEventListener('keydown', event => {

        if ($('libBackdrop').hidden) {
            return;
        }

        if (event.key === 'Escape') {

            closeGuide();
            return;
        }

        if (event.key === 'Tab') {

            const nodes = Array.from(
                $('libDialog').querySelectorAll(
                    'a[href],button:not([disabled]),textarea,input'
                )
            ).filter(
                element =>
                    element.getClientRects().length
            );

            if (!nodes.length) {
                return;
            }

            const first = nodes[0];

            const last = nodes[
                nodes.length - 1
            ];

            if (
                event.shiftKey &&
                document.activeElement === first
            ) {

                event.preventDefault();

                last.focus();

            } else if (
                !event.shiftKey &&
                document.activeElement === last
            ) {

                event.preventDefault();

                first.focus();
            }
        }
    });

    // =====================================
    // START THE PAGE
    // =====================================

    render();

    // =====================================
    // LOAD EXISTING DATABASE RESOURCES
    // =====================================

    fetch(
        'api/demoAPI.php?action=resource_list',
        {
            credentials: 'same-origin'
        }
    )

    .then(async response => {

        if (!response.ok) {
            throw new Error('API unavailable');
        }

        return response.json();
    })

    .then(result => {

        if (
            !result.success ||
            !Array.isArray(result.data?.resources)
        ) {
            throw new Error('Resource query failed');
        }

        const incoming = result.data.resources;

        incoming.forEach(record => {

            const title = String(
                record.title || ''
            ).trim();

            if (!title) {
                return;
            }

            const rawUrl = String(
                record.url || ''
            ).trim();

            const safeUrl =
                /^https?:\/\//i.test(rawUrl)
                    ? rawUrl
                    : '';

            allResources.push({

                id: 'db-' + record.resource_id,

                title: title,

                subtitle: String(
                    record.subtitle ||
                    'Explore this student wellness resource.'
                ),

                category: String(
                    record.category || 'Other'
                ),

                type: String(
                    record.resource_type || 'Resource'
                ),

                icon: String(
                    record.icon || '📄'
                ),

                time: 'From your library',

                url: safeUrl,

                steps: [
                    [
                        'About this resource',

                        String(
                            record.subtitle ||
                            'Use the website link to access the full material when available.'
                        )
                    ]
                ]

            });

        });

        render();

    })

    .catch(() => {

        $('libApiWarning').hidden = false;

    });

})();

</script>

</body>
</html>
