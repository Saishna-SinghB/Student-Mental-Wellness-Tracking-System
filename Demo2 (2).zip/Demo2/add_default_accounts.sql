-- WellnessHub: add (or reset) the default admin and counsellor accounts.
-- For anyone who imported an older wellnesshub.sql that had no admin.
-- Run once in phpMyAdmin (database: wellnesshub). Safe to run again — it just
-- puts the accounts back to these defaults.
--   Admin       Admin@Richfield.ac.za   password: @Admin2026
--   Counsellor  naidoo@richfield.ac.za  password: 12345678

INSERT INTO `users` (`full_name`, `student_number`, `email`, `password_hash`, `role`, `is_active`)
VALUES ('WellnessHub Administrator', NULL, 'Admin@Richfield.ac.za', '$2y$10$Ba.CHifCgHoTnpTxd2s...cnKkwR1dNGCu37ZWgW1TjIj0b9.IPnO', 'admin', 1)
ON DUPLICATE KEY UPDATE `password_hash` = VALUES(`password_hash`), `role` = 'admin', `is_active` = 1;

INSERT INTO `users` (`full_name`, `student_number`, `email`, `password_hash`, `role`, `is_active`)
VALUES ('Dr. Naidoo', NULL, 'naidoo@richfield.ac.za', '$2y$10$n5z4CIUBWlrbTSl16O10Ce8n6ATmtIdvE05PBWB0nPYGeYMbbVIOS', 'counsellor', 1)
ON DUPLICATE KEY UPDATE `password_hash` = VALUES(`password_hash`), `role` = 'counsellor', `is_active` = 1;

-- Link the counsellor account to a bookable counsellor profile (only if missing).
INSERT INTO `counsellors` (`name`, `specialties`, `avatar`, `user_id`)
SELECT 'Dr. Naidoo', 'General Counselling', '🩺', u.`user_id`
FROM `users` u
WHERE u.`email` = 'naidoo@richfield.ac.za'
  AND NOT EXISTS (SELECT 1 FROM `counsellors` c WHERE c.`user_id` = u.`user_id`);
