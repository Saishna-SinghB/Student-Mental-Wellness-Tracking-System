
<?php
/*
 * WELLNESSHUB - RICHFIELD QUALIFICATIONS
 *
 * Central qualification list for:
 * - Student Registration
 * - Admin User Management
 * - Admin Reports
 * - PHP Backend Validation
 *
 * Every qualification uses its FULL NAME.
 */

function qualificationGroups(): array {

    return [

        // HIGHER CERTIFICATES
        'Higher Certificates' => [

            'Higher Certificate in Business Administration (HCBA)',

            'Higher Certificate in Local Government Management (HCLGM)',

            'Higher Certificate in Office Administration (HCOA)',

            'Higher Certificate in Recognition of Prior Learning Activities (RPLA)',

            'Higher Certificate in Information Technology (HCIT)',

            'Higher Certificate in Computer Forensics (HCCF)',

        ],

        // DIPLOMAS
        'Diplomas' => [

            'Diploma in Information Technology (DIT)',

            'Diploma in Business Administration (DBA)',

            'Diploma in Local Government Management (DLGM)',

        ],

        // BACHELOR'S DEGREES
        'Bachelor Degrees' => [

            'Bachelor of Science in Information Technology (BSc IT)',

            'Bachelor of Commerce (BCom)',

            'Bachelor of Commerce (AGA)',

            'Bachelor of Commerce (AGA IT)',

            'Bachelor of Business Administration (BBA)',

            'Bachelor of Public Management (BPM)',

        ],

        // HONOURS
        'Honours Degrees' => [

            'Honours in Bachelor of Science in Information Technology',

        ],

        // POSTGRADUATE
        'Postgraduate Diplomas' => [

            'Postgraduate Diploma in Management (PGDM)',

        ],

        // BRIDGING PROGRAMMES
        'Bridging Programmes' => [

            'BCom (AGA IT) Bridging Programme',

            'BSc Honours in Information Technology Bridging Programme',

            'Management Technology and Research Foundation Bridging Programme',

        ],

        // MASTER'S DEGREES
        'Master Degrees' => [

            'Master of Business Administration (MBA)',

        ],

    ];
}


// GET ALL QUALIFICATIONS AS A FLAT LIST
function qualificationList(): array {

    return array_merge(
        ...array_values(qualificationGroups())
    );

}


// DISPLAY QUALIFICATIONS IN DROPDOWN
function renderQualificationOptions(
    ?string $placeholder = null,
    bool $placeholderDisabled = false
): void {

    if ($placeholder !== null) {

        echo '<option value=""'
            . ($placeholderDisabled ? ' disabled selected' : '')
            . '>'
            . htmlspecialchars(
                $placeholder,
                ENT_QUOTES,
                'UTF-8'
            )
            . "</option>\n";

    }

    foreach (qualificationGroups() as $group => $items) {

        echo '<optgroup label="'
            . htmlspecialchars(
                $group,
                ENT_QUOTES,
                'UTF-8'
            )
            . "\">\n";

        foreach ($items as $qualification) {

            $safeQualification = htmlspecialchars(
                $qualification,
                ENT_QUOTES,
                'UTF-8'
            );

            echo '<option value="'
                . $safeQualification
                . '">'
                . $safeQualification
                . "</option>\n";

        }

        echo "</optgroup>\n";

    }

}

?>
