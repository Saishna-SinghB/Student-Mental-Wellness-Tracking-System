
<?php
require_once __DIR__ . '/admin-auth.php';
require_once __DIR__ . '/demoDB.php';

// ADMIN DETAILS
$adminName = trim(
    (string)($_SESSION['full_name'] ?? 'Admin')
);

$adminFirstName = explode(' ', $adminName)[0];

$adminInitial = strtoupper(
    substr($adminFirstName, 0, 1)
);

// LOAD ADMIN PROFILE PICTURE
$adminPicture = (string)($_SESSION['profile_picture'] ?? '');

try {

    $stmt = $pdo->prepare("
        SELECT profile_picture
        FROM users
        WHERE user_id = ?
        AND role = 'admin'
        LIMIT 1
    ");

    $stmt->execute([$_SESSION['user_id']]);

    $adminUser = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($adminUser) {

        $adminPicture = (string)(
            $adminUser['profile_picture'] ?? ''
        );

        $_SESSION['profile_picture'] = $adminPicture;

    }

} catch (PDOException $e) {

    error_log(
        'Admin profile picture error: ' . $e->getMessage()
    );

}

// VALIDATE PROFILE PICTURE
$hasAdminPicture = preg_match(
    '#^data:image/(?:png|jpeg|gif|webp);base64,[A-Za-z0-9+/=]+$#D',
    $adminPicture
) === 1;

// PREPARE PICTURE STYLE
$adminAvatarStyle = '';

if ($hasAdminPicture) {

    $safePicture = htmlspecialchars(
        $adminPicture,
        ENT_QUOTES,
        'UTF-8'
    );

    $adminAvatarStyle = 'style="background-image:url(\'' .
        $safePicture .
        '\');background-size:cover;background-position:center;"';

}
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8" />

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    />

    <title>User Management — WellnessHub</title>

    <link rel="stylesheet" href="css/style.css" />

    <style>

        /* EXISTING MODAL STYLES */

        .modal-overlay {
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,.45);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 50;
        }

        .modal-box {
            width: min(420px, 90vw);
            max-height: 85vh;
            overflow-y: auto;
        }

        .forgot-message.error {
            color: #c44848;
        }

        .forgot-message.success {
            color: #2f744d;
        }

    </style>

</head>

<body class="app-body admin-body">

<div class="app-shell admin-shell">

    <!-- ADMIN SIDEBAR -->

    <aside class="sidebar admin-sidebar">

        <a
            class="brand-mini sidebar-brand"
            href="index.php"
        >

            <span
                class="mini-leaf"
                aria-hidden="true"
            >
                ☘
            </span>

            <span>WellnessHub</span>

        </a>

        <nav
            class="side-nav"
            aria-label="Admin navigation"
        >

            <a href="admin-dashboard.php">
                <span>▣</span> Dashboard
            </a>

            <a
                class="active"
                href="admin-users.php"
            >
                <span>👥</span> Users
            </a>

            <a href="admin-counsellors.php">
                <span>♡</span> Counsellors
            </a>

            <a href="admin-reports.php">
                <span>📊</span> Reports
            </a>

            <a href="system-logs.php">
                <span>☷</span> System Logs
            </a>

            <a href="admin-settings.php">
                <span>⚙</span> Settings
            </a>

            <!-- MY PROFILE -->

            <a href="admin-profile.php">
                <span>👤</span> My Profile
            </a>

            <a href="logout.php">
                <span>↪</span> Logout
            </a>

        </nav>

    </aside>


    <!-- MAIN CONTENT -->

    <main class="dashboard-main admin-main">

        <!-- HEADER -->

        <header class="topbar admin-topbar">

            <div>

                <p class="eyebrow">
                    Admin Side
                </p>

                <h1>User Management</h1>

                <p class="page-subtitle">
                    Manage student, counsellor and admin accounts.
                </p>

            </div>

            <!-- TOP RIGHT -->

            <div class="topbar-actions">

                <!-- SYSTEM LOGS -->

                <a
                    class="icon-btn admin-icon"
                    href="system-logs.php"
                    aria-label="System logs"
                >
                    🔔
                </a>

                <!-- ADMIN PROFILE PICTURE -->

                <a
                    href="admin-profile.php"
                    class="avatar admin-avatar"
                    title="Click to view My Profile"
                    aria-label="Open My Profile"
                    <?= $adminAvatarStyle ?>
                >

                    <?php if (!$hasAdminPicture): ?>

                        <?= htmlspecialchars(
                            $adminInitial,
                            ENT_QUOTES,
                            'UTF-8'
                        ) ?>

                    <?php endif; ?>

                </a>

            </div>

        </header>


        <!-- USERS SECTION -->

        <section class="panel">

            <div class="panel-heading">

                <h2>Users</h2>

                <div class="inline">

                    <!-- SEARCH -->

                    <input
                        type="search"
                        id="userSearch"
                        placeholder="Search name or email…"
                        style="
                            padding:8px 12px;
                            border:1px solid var(--line);
                            border-radius:8px;
                        "
                    />

                    <!-- ADD USER -->

                    <button
                        class="btn btn-purple btn-small"
                        type="button"
                        id="addUserBtn"
                    >
                        Add User
                    </button>

                </div>

            </div>


            <!-- USERS TABLE -->

            <table class="data-table">

                <thead>

                    <tr>
                        <th></th>
                        <th>Name</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Last Login</th>
                        <th>Action</th>
                    </tr>

                </thead>

                <tbody id="usersTableBody">

                    <tr>

                        <td
                            colspan="6"
                            class="muted"
                        >
                            Loading users…
                        </td>

                    </tr>

                </tbody>

            </table>

        </section>


        <!-- ADD USER MODAL -->

        <div
            id="addUserModal"
            class="modal-overlay"
            style="display:none;"
        >

            <div class="modal-box panel">

                <h2>Add User</h2>

                <!-- FULL NAME -->

                <label class="field">

                    <span>Full Name</span>

                    <input
                        type="text"
                        id="newFullName"
                    />

                </label>


                <!-- ROLE -->

                <label class="field">

                    <span>Role</span>

                    <select id="newRole">

                        <option value="student">
                            Student
                        </option>

                        <option value="counsellor">
                            Counsellor
                        </option>

                        <option value="admin">
                            Admin
                        </option>

                    </select>

                </label>


                <!-- STUDENT NUMBER -->

                <label
                    class="field"
                    id="studentNumberField"
                >

                    <span>Student Number</span>

                    <input
                        type="text"
                        id="newStudentNumber"
                        placeholder="e.g. 402311336"
                    />

                </label>


                <!-- EMAIL -->

                <label class="field">

                    <span>Email</span>

                    <input
                        type="email"
                        id="newEmail"
                    />

                </label>


                <!-- PASSWORD -->

                <label class="field">

                    <span>Password</span>

                    <input
                        type="text"
                        id="newPassword"
                        placeholder="Min 8 characters"
                    />

                </label>


                <!-- HINT -->

                <p
                    class="muted"
                    id="newUserHint"
                >
                    Student email must be
                    studentnumber@my.richfield.ac.za
                </p>


                <!-- MESSAGE -->

                <p
                    id="addUserMessage"
                    class="forgot-message"
                ></p>


                <!-- BUTTONS -->

                <div
                    class="inline"
                    style="margin-top:10px;"
                >

                    <button
                        class="btn btn-ghost"
                        type="button"
                        id="cancelAddUser"
                    >
                        Cancel
                    </button>

                    <button
                        class="btn btn-primary"
                        type="button"
                        id="submitAddUser"
                    >
                        Create Account
                    </button>

                </div>

            </div>

        </div>


        <!-- EDIT USER MODAL -->

        <div
            id="editUserModal"
            class="modal-overlay"
            style="display:none;"
        >

            <div class="modal-box panel">

                <h2>Edit User</h2>


                <!-- USER PROFILE PICTURE PREVIEW -->

                <div
                    class="profile-picture-wrap"
                    style="padding:10px 0 18px;"
                >

                    <div
                        id="editAvatarPreview"
                        class="profile-avatar"
                        style="
                            width:72px;
                            height:72px;
                            font-size:28px;
                        "
                    ></div>

                </div>


                <!-- FULL NAME -->

                <label class="field">

                    <span>Full Name</span>

                    <input
                        type="text"
                        id="editFullName"
                    />

                </label>


                <!-- EMAIL -->

                <label class="field">

                    <span>Email</span>

                    <input
                        type="email"
                        id="editEmail"
                    />

                </label>


                <!-- STUDENT NUMBER -->

                <label
                    class="field"
                    id="editStudentNumberField"
                >

                    <span>Student Number</span>

                    <input
                        type="text"
                        id="editStudentNumber"
                    />

                </label>


                <!-- GENDER -->

                <label class="field">

                    <span>Gender</span>

                    <select id="editGender">

                        <option value="Prefer not to say">
                            Prefer not to say
                        </option>

                        <option value="Male">
                            Male
                        </option>

                        <option value="Female">
                            Female
                        </option>

                        <option value="Non-binary">
                            Non-binary
                        </option>

                    </select>

                </label>


                <!-- QUALIFICATION -->

                <label
                    class="field"
                    id="editQualificationField"
                >

                    <span>Qualification</span>

                    <select id="editQualification">

                        <?php
                        require_once __DIR__ . '/qualifications.php';

                        renderQualificationOptions('Not set');
                        ?>

                    </select>

                </label>


                <!-- ROLE -->

                <label class="field">

                    <span>Role</span>

                    <select id="editRole">

                        <option value="student">
                            Student
                        </option>

                        <option value="counsellor">
                            Counsellor
                        </option>

                        <option value="admin">
                            Admin
                        </option>

                    </select>

                </label>


                <!-- STATUS -->

                <label class="field">

                    <span>Status</span>

                    <select id="editActive">

                        <option value="1">
                            Active
                        </option>

                        <option value="0">
                            Suspended
                        </option>

                    </select>

                </label>


                <!-- EDIT MESSAGE -->

                <p
                    id="editUserMessage"
                    class="forgot-message"
                ></p>


                <!-- EDIT BUTTONS -->

                <div
                    class="inline"
                    style="margin-top:10px;"
                >

                    <button
                        class="btn btn-ghost"
                        type="button"
                        id="cancelEditUser"
                    >
                        Cancel
                    </button>

                    <button
                        class="btn btn-primary"
                        type="button"
                        id="submitEditUser"
                    >
                        Save Changes
                    </button>

                </div>


                <!-- PASSWORD RESET -->

                <hr
                    style="
                        margin:18px 0;
                        border:0;
                        border-top:1px solid var(--line);
                    "
                />

                <p
                    class="muted"
                    style="font-size:13px;"
                >
                    Resetting a password sets it to a known
                    default for that role, which the user
                    can change after logging in.
                </p>

                <button
                    class="btn btn-ghost btn-small"
                    type="button"
                    id="resetPasswordBtn"
                    style="color:#c44848;"
                >
                    Reset Password to Default
                </button>

                <p
                    id="resetPasswordMessage"
                    class="forgot-message"
                ></p>


                <!-- DELETE USER -->

                <hr
                    style="
                        margin:18px 0;
                        border:0;
                        border-top:1px solid var(--line);
                    "
                />

                <p
                    class="muted"
                    style="font-size:13px;"
                >
                    Deleting a student permanently removes
                    all of their mood check-ins, journal
                    entries, posts, and bookings.
                    This cannot be undone.

                    Deleting a counsellor only removes
                    their login; their profile and
                    booking history stay intact.
                </p>

                <button
                    class="btn btn-ghost btn-small"
                    type="button"
                    id="deleteUserBtn"
                    style="
                        color:#fff;
                        background:#c44848;
                    "
                >
                    Delete User
                </button>

                <p
                    id="deleteUserMessage"
                    class="forgot-message"
                ></p>

            </div>

        </div>

    </main>

</div>


<!-- EXISTING JAVASCRIPT -->

<script src="js/admin-users.js"></script>

</body>
</html>
