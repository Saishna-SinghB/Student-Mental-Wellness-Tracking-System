
<?php
require_once __DIR__ . '/counsellor-auth.php';

// Your current XAMPP / MySQL settings
$dbHost = '127.0.0.1';
$dbPort = '3307';
$dbName = 'wellnesshub';
$dbUser = 'root';
$dbPass = '';

function h($text): string {
    return htmlspecialchars((string)$text, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

// Display database resource text as organized cards, without changing saved data.
function displayResourceGuide(string $content, string $resourceTitle): void {
    $parts = preg_split('/\R/u', trim($content)) ?: [];
    $sections = [];
    $heading = 'Overview';
    $number = '';
    $sentences = [];

    $save = function () use (&$sections, &$heading, &$number, &$sentences): void {
        if ($sentences) {
            $sections[] = [
                'heading' => $heading,
                'number' => $number,
                'content' => implode(' ', $sentences)
            ];
        }
        $sentences = [];
    };

    foreach ($parts as $raw) {
        $line = trim($raw);
        if ($line === '' || strcasecmp($line, $resourceTitle) === 0) continue;

        if (preg_match('/^(\d{1,2})[.)]\s+(.+)$/u', $line, $m)) {
            $save();
            $number = str_pad($m[1], 2, '0', STR_PAD_LEFT);
            $heading = ucwords(strtolower($m[2]));
        } elseif (
            strlen($line) < 100 &&
            preg_match('/^[A-Z][A-Z0-9\s\'’&\/\-]+$/u', $line) &&
            strlen($line) > 4
        ) {
            $save();
            $number = '';
            $heading = ucwords(strtolower($line));
        } else {
            $sentences[] = $line;
        }
    }
    $save();

    echo '<div class="saved-sections">';
    foreach ($sections as $section) {
        $isStep = $section['number'] !== '';
        $class = $isStep ? 'saved-step' : 'saved-section';
        if (!$isStep && strtolower($section['heading']) === 'overview') {
            $class .= ' saved-overview';
        }
        echo '<section class="' . $class . '">';
        if ($isStep) {
            echo '<span class="step-number">' . h($section['number']) . '</span>';
            echo '<div class="step-copy">';
        }
        echo '<h4>' . h($section['heading']) . '</h4>';
        echo '<p>' . h($section['content']) . '</p>';
        if ($isStep) echo '</div>';
        echo '</section>';
    }
    echo '</div>';
}

$categories = [
    'Mental Health', 'Stress Management', 'Anxiety Support',
    'Depression Support', 'Academic Support', 'Counselling',
    'Crisis Support', 'Peer Support', 'Other'
];

$icons = [
    'Mental Health' => '🧠',
    'Stress Management' => '🌿',
    'Anxiety Support' => '💙',
    'Depression Support' => '🌻',
    'Academic Support' => '🎓',
    'Counselling' => '🤝',
    'Crisis Support' => '☎',
    'Peer Support' => '👥',
    'Other' => '📘'
];

if (empty($_SESSION['toolkit_csrf'])) {
    $_SESSION['toolkit_csrf'] = bin2hex(random_bytes(32));
}

$pdo = null;
$error = '';
$resources = [];
$showEditor = false;

// CONNECT TO MYSQL
try {
    $pdo = new PDO(
        "mysql:host=$dbHost;port=$dbPort;dbname=$dbName;charset=utf8mb4",
        $dbUser,
        $dbPass,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
        ]
    );

    $pdo->exec("CREATE TABLE IF NOT EXISTS counsellor_toolkit_resources (
        resource_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(150) NOT NULL,
        category VARCHAR(60) NOT NULL,
        description VARCHAR(350) NOT NULL,
        content TEXT NOT NULL,
        resource_url VARCHAR(2048) NULL,
        pdf_name VARCHAR(255) NULL,
        pdf_data MEDIUMBLOB NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    // Keep resources saved in earlier versions of WellnessHub.
    foreach ([
        'pdf_name' => 'VARCHAR(255) NULL',
        'pdf_data' => 'MEDIUMBLOB NULL'
    ] as $col => $type) {
        $check = $pdo->query(
            "SHOW COLUMNS FROM counsellor_toolkit_resources LIKE " .
            $pdo->quote($col)
        );
        if (!$check->fetch()) {
            $pdo->exec(
                "ALTER TABLE counsellor_toolkit_resources ADD COLUMN $col $type"
            );
        }
    }
} catch (PDOException $ex) {
    error_log($ex->getMessage());
    $pdo = null;
    $error = 'Database connection failed. Check XAMPP MySQL and port 3307.';
}

// DOWNLOAD RESOURCE PDF
if (isset($_GET['download'])) {
    $id = filter_var($_GET['download'], FILTER_VALIDATE_INT);

    if (!$pdo || !$id || $id < 1) {
        http_response_code(404);
        exit('File not found');
    }

    $stmt = $pdo->prepare(
        'SELECT pdf_name, pdf_data
         FROM counsellor_toolkit_resources
         WHERE resource_id = ?'
    );

    $stmt->execute([$id]);
    $doc = $stmt->fetch();

    if (!$doc || $doc['pdf_data'] === null || !$doc['pdf_name']) {
        http_response_code(404);
        exit('File not found');
    }

    $name = preg_replace(
        '/[^A-Za-z0-9._-]/',
        '_',
        basename($doc['pdf_name'])
    );

    if (!$name || $name === '.' || $name === '..') {
        $name = 'resource.pdf';
    }

    header('Content-Type: application/pdf');
    header('X-Content-Type-Options: nosniff');
    header('Cache-Control: private, no-store');
    header('Content-Disposition: attachment; filename="' . $name . '"');

    echo $doc['pdf_data'];
    exit;
}

// ADD, EDIT AND DELETE RESOURCES
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = (string)($_POST['resource_action'] ?? '');
    $id = filter_var(
        $_POST['resource_id'] ?? null,
        FILTER_VALIDATE_INT
    );

    $showEditor = $action !== 'delete';

    if (!hash_equals(
        $_SESSION['toolkit_csrf'],
        (string)($_POST['csrf_token'] ?? '')
    )) {
        $error = 'Session expired. Refresh and try again.';

    } elseif (!$pdo) {
        $error = 'Cannot save without MySQL.';

    } elseif (!in_array($action, ['add', 'edit', 'delete'], true)) {
        $error = 'Invalid action.';

    } elseif ($action !== 'add' && (!$id || $id < 1)) {
        $error = 'Invalid resource.';

    } elseif ($action === 'delete') {

        try {
            $stmt = $pdo->prepare(
                'DELETE FROM counsellor_toolkit_resources
                 WHERE resource_id = ?'
            );

            $stmt->execute([$id]);

            header('Location: counsellor-resources.php?status=deleted');
            exit;

        } catch (PDOException $ex) {
            error_log($ex->getMessage());
            $error = 'Could not delete resource.';
        }

    } else {

        $title = trim((string)($_POST['title'] ?? ''));
        $category = (string)($_POST['category'] ?? '');
        $description = trim((string)($_POST['description'] ?? ''));
        $content = trim((string)($_POST['content'] ?? ''));
        $url = trim((string)($_POST['resource_url'] ?? ''));

        $file = $_FILES['resource_pdf'] ?? null;

        $hasFile = is_array($file) &&
            ($file['error'] ?? UPLOAD_ERR_NO_FILE)
            !== UPLOAD_ERR_NO_FILE;

        $pdfName = null;
        $pdfData = null;

        if (
            $title === '' ||
            $description === '' ||
            $content === ''
        ) {
            $error = 'Complete the required fields.';

        } elseif (
            strlen($title) > 150 ||
            strlen($description) > 350 ||
            strlen($content) > 15000
        ) {
            $error = 'One of the fields is too long.';

        } elseif (!in_array($category, $categories, true)) {
            $error = 'Select a valid category.';

        } elseif (
            $url !== '' &&
            (
                strlen($url) > 2048 ||
                !filter_var($url, FILTER_VALIDATE_URL) ||
                !in_array(
                    strtolower((string)parse_url($url, PHP_URL_SCHEME)),
                    ['http', 'https'],
                    true
                )
            )
        ) {
            $error = 'Enter a valid website URL.';

        } elseif ($hasFile) {

            if (
                ($file['error'] ?? null) !== UPLOAD_ERR_OK ||
                !is_uploaded_file($file['tmp_name']) ||
                $file['size'] < 1 ||
                $file['size'] > 5 * 1024 * 1024
            ) {
                $error = 'Choose a PDF smaller than 5 MB.';

            } else {
                $pdfName = basename((string)$file['name']);

                $mime = (new finfo(FILEINFO_MIME_TYPE))
                    ->file($file['tmp_name']);

                $signature = file_get_contents(
                    $file['tmp_name'],
                    false,
                    null,
                    0,
                    5
                );

                if (
                    strtolower(
                        pathinfo($pdfName, PATHINFO_EXTENSION)
                    ) !== 'pdf' ||
                    !in_array(
                        $mime,
                        ['application/pdf', 'application/x-pdf'],
                        true
                    ) ||
                    $signature !== '%PDF-'
                ) {
                    $error = 'Please upload a valid PDF.';

                } else {
                    $pdfData = file_get_contents($file['tmp_name']);

                    if ($pdfData === false) {
                        $error = 'Could not read the PDF.';
                    }
                }
            }
        }

        if ($error === '') {

            try {
                if ($action === 'add') {

                    $stmt = $pdo->prepare(
                        'INSERT INTO counsellor_toolkit_resources
                        (
                            title, category, description,
                            content, resource_url,
                            pdf_name, pdf_data
                        )
                        VALUES (?, ?, ?, ?, ?, ?, ?)'
                    );

                    $stmt->execute([
                        $title,
                        $category,
                        $description,
                        $content,
                        $url ?: null,
                        $pdfName,
                        $pdfData
                    ]);

                } else {

                    $stmt = $pdo->prepare(
                        'SELECT resource_id
                         FROM counsellor_toolkit_resources
                         WHERE resource_id = ?'
                    );

                    $stmt->execute([$id]);

                    if (!$stmt->fetch()) {
                        throw new RuntimeException('Resource missing');
                    }

                    $sql = 'UPDATE counsellor_toolkit_resources SET
                        title = ?,
                        category = ?,
                        description = ?,
                        content = ?,
                        resource_url = ?';

                    $params = [
                        $title,
                        $category,
                        $description,
                        $content,
                        $url ?: null
                    ];

                    if ($hasFile) {
                        $sql .= ', pdf_name = ?, pdf_data = ?';
                        $params[] = $pdfName;
                        $params[] = $pdfData;

                    } elseif (isset($_POST['remove_pdf'])) {
                        $sql .= ', pdf_name = NULL, pdf_data = NULL';
                    }

                    $sql .= ' WHERE resource_id = ?';
                    $params[] = $id;

                    $pdo->prepare($sql)->execute($params);
                }

                header(
                    'Location: counsellor-resources.php?status=' .
                    ($action === 'add' ? 'added' : 'updated')
                );

                exit;

            } catch (Throwable $ex) {
                error_log($ex->getMessage());
                $error = 'Could not save resource.';
            }
        }
    }
}

// LOAD SAVED RESOURCES
if ($pdo) {
    try {
        $resources = $pdo->query(
            'SELECT resource_id, title, category,
                description, content, resource_url, pdf_name
             FROM counsellor_toolkit_resources
             ORDER BY resource_id DESC'
        )->fetchAll();

    } catch (PDOException $ex) {
        error_log($ex->getMessage());
        $error = 'Could not load resources.';
    }
}

$initial = strtoupper(
    substr((string)($_SESSION['full_name'] ?? 'Counsellor'), 0, 1)
);

$statuses = [
    'added' => 'Resource added successfully.',
    'updated' => 'Resource updated successfully.',
    'deleted' => 'Resource deleted successfully.'
];

$status = (string)($_GET['status'] ?? '');
?>

<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Counsellor Resources — WellnessHub</title>

<link rel="stylesheet" href="css/style.css">

<style>

/* HEADER */

.counsellor-body .dark-topbar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 16px;
    flex-wrap: wrap;
}

.counsellor-body .topbar-actions {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-left: auto;
}

.counsellor-body .topbar-actions .icon-btn {
    display: grid;
    place-items: center;
    width: 44px;
    height: 44px;
    font-size: 21px;
    text-decoration: none;
}

.counsellor-body .topbar-actions .avatar {
    display: grid;
    place-items: center;
}

/* RESOURCE FORM */

.tool-controls {
    display: flex;
    gap: 12px;
    margin: 18px 0;
    flex-wrap: wrap;
}

.tool-controls input,
.tool-controls select,
.resource-editor input,
.resource-editor select,
.resource-editor textarea {
    box-sizing: border-box;
    background: #0d192b;
    border: 1px solid #405576;
    color: #f0f6ff;
    padding: 12px;
    border-radius: 9px;
    font: inherit;
}

.tool-controls input {
    flex: 2;
    min-width: 220px;
}

.tool-controls select {
    flex: 1;
    min-width: 180px;
}

.resource-editor {
    display: none;
    padding: 24px;
    border: 1px solid #345475;
    background: #122239;
    border-radius: 14px;
    margin: 18px 0;
}

.resource-editor.open {
    display: block;
}

.resource-editor h3 {
    color: white;
    margin-top: 0;
}

.resource-editor label {
    display: block;
    margin: 15px 0 7px;
    color: #d9e6f7;
    font-weight: 700;
}

.resource-editor input,
.resource-editor select,
.resource-editor textarea {
    width: 100%;
}

.resource-editor input[type=checkbox] {
    width: auto;
}

.resource-editor textarea {
    min-height: 95px;
    resize: vertical;
}

.resource-editor textarea[name=content] {
    min-height: 180px;
}

.editor-actions,
.item-actions,
.referral-actions {
    display: flex;
    gap: 12px;
    flex-wrap: wrap;
    margin-top: 18px;
}

.editor-actions button,
.item-actions button,
.referral-actions button {
    border: 0;
    border-radius: 9px;
    padding: 12px 17px;
    color: white;
    font-weight: 700;
    cursor: pointer;
}

.save-resource {
    background: #2878ce;
}

.cancel-resource {
    background: #485b74;
}

.edit-resource {
    background: #315b95;
}

.delete-resource {
    background: #9b4350;
}

.resource-alert {
    padding: 14px;
    margin: 14px 0;
    border-radius: 9px;
    background: #1e4835;
    color: #c2f5d6;
}

.resource-alert.error {
    background: #532832;
    color: #ffd2da;
}

/* RESOURCE CARDS */

.resource-entry {
    margin-bottom: 12px;
}

.resource-entry[hidden] {
    display: none !important;
}

.resource-entry summary {
    list-style: none;
    cursor: pointer;
}

.resource-entry summary::-webkit-details-marker {
    display: none;
}

.resource-entry .resource-item {
    display: flex;
    align-items: center;
    gap: 16px;
    width: 100%;
    box-sizing: border-box;
}

.resource-entry .resource-item > div {
    flex: 1;
    min-width: 0;
}

.resource-entry h3 {
    color: white;
    margin: 0 0 5px;
}

.resource-entry .resource-item p {
    color: #b3c6dc;
    margin: 0;
}

.resource-entry[open] .resource-arrow {
    transform: rotate(90deg);
}

/* PHONE AND CATEGORY ICONS */

.resource-thumb.toolkit-icon {
    display: grid !important;
    place-items: center !important;
    flex: 0 0 54px;
    width: 54px;
    height: 54px;
    border-radius: 14px;
    background: #294b71 !important;
    color: white !important;
    font-size: 26px;
    line-height: 1;
}

.resource-detail {
    background: #101f35;
    border: 1px solid #304862;
    border-radius: 12px;
    padding: 22px;
    color: #dce9f9;
    line-height: 1.7;
    margin-top: 6px;
}

.resource-detail h4 {
    color: white;
}

.resource-tag {
    display: block;
    color: #97ccff;
    font-size: 13px;
    font-weight: 700;
    margin-bottom: 18px;
}

.no-resources {
    color: #b4c7d9;
    padding: 14px;
}

/* BUILT-IN GUIDES */

.guide-header {
    display: flex;
    align-items: center;
    gap: 15px;
    border-bottom: 1px solid #395471;
    padding-bottom: 20px;
    margin-bottom: 20px;
}

.guide-header .guide-icon {
    display: grid;
    place-items: center;
    background: #294b71;
    width: 56px;
    height: 56px;
    flex: 0 0 56px;
    border-radius: 14px;
    font-size: 27px;
    color: white;
}

.guide-header h2 {
    margin: 0;
    color: white;
    font-size: 23px;
}

.guide-header p {
    margin: 4px 0 0;
    color: #a8bed6;
}

.guide-intro {
    padding: 20px;
    background: #1b304a;
    border-left: 4px solid #559be0;
    border-radius: 11px;
    margin: 18px 0;
    color: #d5e6f8;
}

.guide-step,
.saved-step {
    display: flex;
    gap: 17px;
    background: #192e47;
    border: 1px solid #36516c;
    border-radius: 13px;
    padding: 20px;
    margin: 12px 0;
}

.guide-step > span,
.step-number {
    display: grid;
    place-items: center;
    background: #2a5078;
    color: #bfe1ff;
    flex: 0 0 45px;
    height: 45px;
    border-radius: 11px;
    font-weight: 800;
}

.guide-step h4,
.saved-step h4 {
    margin: 0 0 8px;
    color: white;
}

.guide-step p,
.saved-step p {
    margin: 0;
    line-height: 1.75;
    color: #c8d9eb;
}

.peer-response {
    margin: 22px 0;
    padding: 22px;
    background: #173d37;
    border: 1px solid #357367;
    border-radius: 13px;
}

.peer-response h3 {
    color: #b3f1d7;
    margin: 0 0 8px;
}

.peer-response p {
    margin: 0;
    font-style: italic;
    color: #e1f5ed;
}

.peer-responsibilities {
    padding: 22px;
    border-radius: 13px;
    background: #192c44;
    margin-top: 22px;
}

.peer-responsibilities h3 {
    margin: 0 0 12px;
}

.peer-responsibilities li {
    padding: 4px 0;
}

/* STUDENT REFERRAL FORM */

.referral-document {
    background: #172a43;
    padding: 25px;
    border: 1px solid #385476;
    border-radius: 14px;
}

.referral-title {
    text-align: center;
    padding: 20px 0;
}

.referral-title h3 {
    margin: 0;
    color: white;
    font-size: 25px;
}

.referral-title p {
    margin: 6px 0;
    color: #a9bfd8;
}

.referral-section {
    margin-bottom: 22px;
}

.referral-section h4 {
    color: #8dc5ff;
    border-bottom: 1px solid #36516e;
    padding-bottom: 10px;
}

.referral-section label {
    display: block;
    font-weight: 700;
    margin: 12px 0;
    color: #d8e8fa;
    font-size: 14px;
}

.referral-section input,
.referral-section textarea,
.referral-section select {
    display: block;
    box-sizing: border-box;
    width: 100%;
    margin-top: 8px;
    padding: 13px;
    border: 1px solid #405b7a;
    border-radius: 9px;
    background: #0d1b2e;
    color: white;
    font: inherit;
}

.referral-section textarea {
    min-height: 90px;
    resize: vertical;
}

.referral-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 15px;
}

.referral-footer {
    display: flex;
    justify-content: space-between;
    gap: 10px;
    border-top: 1px solid #3b5270;
    padding-top: 15px;
    color: #a2bad2;
    font-size: 12px;
}

/* BEAUTIFUL SAVED RESOURCE LAYOUT */

.saved-header {
    display: flex;
    align-items: center;
    gap: 16px;
    padding-bottom: 20px;
    border-bottom: 1px solid #36516c;
    margin-bottom: 18px;
}

.saved-header-icon {
    display: grid;
    place-items: center;
    flex: 0 0 56px;
    width: 56px;
    height: 56px;
    background: #294b71;
    border-radius: 13px;
    font-size: 27px;
}

.saved-header h3 {
    margin: 0 0 5px;
    color: white;
    font-size: 23px;
}

.saved-header p {
    margin: 0;
    color: #b7cae0;
    font-size: 14px;
}

.saved-sections {
    display: grid;
    gap: 13px;
}

.saved-section {
    padding: 20px;
    background: #192c44;
    border: 1px solid #36516c;
    border-radius: 13px;
}

.saved-overview {
    background: #1b304a;
    border-left: 4px solid #68b1fa;
}

.saved-section h4 {
    margin: 0 0 10px;
    color: #9cccff;
    font-size: 18px;
}

.saved-section p {
    margin: 0;
    color: #d5e4f3;
    line-height: 1.75;
    white-space: normal;
}

.step-copy {
    min-width: 0;
}

.saved-step h4 {
    font-size: 17px;
}

/* WEBSITE AND PDF LINKS */

.saved-links {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
    gap: 14px;
    margin-top: 20px;
}

.resource-detail a.saved-link {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 16px 18px;
    background: #203b58;
    border: 1px solid #3b5a7e;
    border-radius: 12px;
    text-decoration: none;
    color: white;
    min-width: 0;
}

.resource-detail a.saved-link:hover {
    background: #2a537b;
}

.saved-link-icon {
    font-size: 26px;
}

.saved-link span:last-child {
    min-width: 0;
    overflow-wrap: anywhere;
}

.saved-link strong {
    display: block;
}

.saved-link small {
    display: block;
    color: #b4d2ed;
    font-size: 12px;
    margin-top: 4px;
}

/* MOBILE */

@media(max-width:650px) {
    .referral-grid {
        grid-template-columns: 1fr;
    }

    .resource-detail,
    .referral-document,
    .resource-editor {
        padding: 15px;
    }

    .guide-step,
    .saved-step {
        gap: 12px;
        padding: 15px;
    }

    .tool-controls {
        flex-direction: column;
    }

    .referral-footer {
        flex-direction: column;
    }
}

/* PRINT REFERRAL FORM ONLY */

@media print {
    body * {
        visibility: hidden !important;
    }

    #referralPrintArea,
    #referralPrintArea * {
        visibility: visible !important;
    }

    #referralPrintArea {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        background: white !important;
        color: black !important;
        border: 0;
    }

    #referralPrintArea * {
        color: black !important;
        background: transparent !important;
    }

    #referralPrintArea input,
    #referralPrintArea textarea,
    #referralPrintArea select {
        border: 1px solid #888 !important;
    }
}
</style>
</head>

<body class="app-body dark-body counsellor-body">

<div class="app-shell dark-shell">

<!-- SIDEBAR -->

<aside class="sidebar counsellor-sidebar">

    <a class="brand-mini sidebar-brand" href="index.php">
        <span class="mini-leaf">☘</span>
        <span>WellnessHub</span>
    </a>

    <nav class="side-nav" aria-label="Counsellor navigation">

        <a href="counsellor-dashboard.php">
            <span>▣</span> Dashboard
        </a>

        <a href="counsellor-students.php">
            <span>👥</span> Students
        </a>

        <a href="risk-alerts.php">
            <span>⚠</span> Risk Alerts
        </a>

        <a href="counsellor-appointments.php">
            <span>📅</span> Appointments
        </a>

        <a class="active" href="counsellor-resources.php">
            <span>▤</span> Resources
        </a>

        <a href="logout.php">
            <span>↪</span> Logout
        </a>

    </nav>

</aside>

<!-- MAIN CONTENT -->

<main class="dashboard-main dark-main">

    <header class="topbar dark-topbar">

        <div>
            <p class="eyebrow">Counsellor Side</p>
            <h1>Counsellor Resources</h1>

            <p class="page-subtitle">
                Recommended support resources for referrals.
            </p>
        </div>

        <div class="topbar-actions">

            <a
                class="icon-btn dark-icon"
                href="risk-alerts.php"
                aria-label="Risk alerts"
            >
                🔔
            </a>

            <div class="avatar dark-avatar">
                <?= h($initial) ?>
            </div>

        </div>

    </header>

    <section class="panel">

        <div class="panel-heading">

            <h2>Resource Toolkit</h2>

            <button
                type="button"
                id="addResourceBtn"
                class="btn btn-blue btn-small"
            >
                + Add Resource
            </button>

        </div>

        <!-- MESSAGES -->

        <?php if ($error): ?>
            <div class="resource-alert error" role="alert">
                <?= h($error) ?>
            </div>
        <?php endif; ?>

        <?php if (isset($statuses[$status])): ?>
            <div class="resource-alert" role="status">
                <?= h($statuses[$status]) ?>
            </div>
        <?php endif; ?>

        <!-- ADD RESOURCE FORM -->

        <form
            id="resourceEditor"
            class="resource-editor <?= $showEditor ? 'open' : '' ?>"
            method="post"
            action="counsellor-resources.php"
            enctype="multipart/form-data"
        >

            <h3 id="editorHeading">Add New Resource</h3>

            <input
                type="hidden"
                name="csrf_token"
                value="<?= h($_SESSION['toolkit_csrf']) ?>"
            >

            <input
                type="hidden"
                id="resourceAction"
                name="resource_action"
                value="<?= h($_POST['resource_action'] ?? 'add') ?>"
            >

            <input
                type="hidden"
                id="resourceId"
                name="resource_id"
                value="<?= h($_POST['resource_id'] ?? '') ?>"
            >

            <label for="resourceTitle">Resource Title</label>

            <input
                id="resourceTitle"
                name="title"
                maxlength="150"
                required
                placeholder="e.g. Exam Stress Management Guide"
                value="<?= h($_POST['title'] ?? '') ?>"
            >

            <label for="resourceCategory">Category</label>

            <select id="resourceCategory" name="category">

                <?php foreach ($categories as $category): ?>

                    <option
                        value="<?= h($category) ?>"
                        <?= ($_POST['category'] ?? '') === $category
                            ? 'selected' : '' ?>
                    >
                        <?= h($category) ?>
                    </option>

                <?php endforeach; ?>

            </select>

            <label for="resourceDescription">
                Short Description
            </label>

            <textarea
                id="resourceDescription"
                name="description"
                maxlength="350"
                required
                placeholder="Describe this resource briefly"
            ><?= h($_POST['description'] ?? '') ?></textarea>

            <label for="resourceContent">
                Full Resource Information
            </label>

            <textarea
                id="resourceContent"
                name="content"
                maxlength="15000"
                required
                placeholder="Enter advice or instructions here"
            ><?= h($_POST['content'] ?? '') ?></textarea>

            <label for="resourceUrl">
                Website Link (Optional)
            </label>

            <input
                id="resourceUrl"
                name="resource_url"
                type="url"
                placeholder="https://example.org"
                value="<?= h($_POST['resource_url'] ?? '') ?>"
            >

            <label for="resourcePdf">
                Attach PDF (Optional, maximum 5 MB)
            </label>

            <input
                id="resourcePdf"
                name="resource_pdf"
                type="file"
                accept=".pdf,application/pdf"
            >

            <div id="existingPdfBox" hidden>

                <label>
                    <input type="checkbox" name="remove_pdf">
                    Remove existing PDF
                </label>

            </div>

            <p style="color:#a6b9d3;font-size:13px">
                Only add general counselling resources.
                Do not upload confidential student records.
            </p>

            <div class="editor-actions">

                <button
                    class="save-resource"
                    type="submit"
                    <?= !$pdo ? 'disabled' : '' ?>
                >
                    Save Resource
                </button>

                <button
                    class="cancel-resource"
                    type="button"
                    id="cancelResourceBtn"
                >
                    Cancel
                </button>

            </div>

        </form>

        <!-- SEARCH AND CATEGORY FILTER -->

        <div class="tool-controls">

            <input
                id="resourceSearch"
                type="search"
                placeholder="Search resources..."
                aria-label="Search resources"
            >

            <select
                id="categoryFilter"
                aria-label="Filter resources"
            >

                <option value="">All categories</option>

                <?php foreach ($categories as $category): ?>

                    <option value="<?= h($category) ?>">
                        <?= h($category) ?>
                    </option>

                <?php endforeach; ?>

            </select>

        </div>

        <div class="resource-list" id="resourceList">

            <!-- CRISIS ESCALATION PROTOCOL -->

            <details
                class="resource-entry"
                data-category="Crisis Support"
                data-search="crisis escalation protocol high risk safety emergency"
            >

                <summary class="resource-item">

                    <span class="resource-thumb toolkit-icon">
                        ☎
                    </span>

                    <div>
                        <h3>Crisis Escalation Protocol</h3>

                        <p>
                            Guidance for responding to high-risk alerts
                        </p>
                    </div>

                    <span class="resource-arrow">›</span>

                </summary>

                <div class="resource-detail">

                    <span class="resource-tag">
                        Crisis Support
                    </span>

                    <div class="guide-header">

                        <span class="guide-icon">☎</span>

                        <div>
                            <h2>Crisis Escalation Protocol</h2>
                            <p>WellnessHub Counselling Services</p>
                        </div>

                    </div>

                    <div class="guide-intro">
                        Structured guidance for identifying,
                        assessing and responding to serious
                        emotional distress or potential safety risks.
                        Follow the institution's approved
                        emergency procedures.
                    </div>

                    <?php
                    $crisisSteps = [
                        'Identify and Assess the Crisis' =>
                            'Assess immediate safety and identify serious emotional distress or urgent risk using institutional assessment procedures.',

                        'Prioritize Student Safety' =>
                            'If immediate danger is suspected, activate the institutional emergency response procedure and contact appropriate emergency services.',

                        'Notify Appropriate Personnel' =>
                            'Escalate serious concerns to authorized clinical supervisors or the crisis response team.',

                        'Maintain Confidentiality' =>
                            'Protect personal and mental health information, sharing only what is lawfully permitted or required for intervention.',

                        'Document the Incident' =>
                            'Record assessments, actions, referrals and follow-up in an approved secure records system.',

                        'Arrange Follow-Up Support' =>
                            'Coordinate appropriate counselling, professional referrals and ongoing student support.',

                        'Review and Monitor' =>
                            'Review with authorized professionals and confirm follow-up actions are completed.'
                    ];

                    foreach ($crisisSteps as $name => $description):
                    ?>

                        <div class="guide-step">

                            <span>
                                <?= str_pad(
                                    (string)(
                                        array_search(
                                            $name,
                                            array_keys($crisisSteps),
                                            true
                                        ) + 1
                                    ),
                                    2,
                                    '0',
                                    STR_PAD_LEFT
                                ) ?>
                            </span>

                            <div>
                                <h4><?= h($name) ?></h4>
                                <p><?= h($description) ?></p>
                            </div>

                        </div>

                    <?php endforeach; ?>

                </div>

            </details>

            <!-- STUDENT REFERRAL FORM -->

            <details
                class="resource-entry"
                data-category="Counselling"
                data-search="student referral form counselling documentation print"
            >

                <summary class="resource-item">

                    <span class="resource-thumb toolkit-icon">
                        📄
                    </span>

                    <div>
                        <h3>Student Referral Form</h3>
                        <p>
                            Counselling referral and support documentation
                        </p>
                    </div>

                    <span class="resource-arrow">›</span>

                </summary>

                <div class="resource-detail">

                    <span class="resource-tag">
                        Counselling
                    </span>

                    <div
                        class="referral-document"
                        id="referralPrintArea"
                    >

                        <div class="guide-header">

                            <span class="guide-icon">☘</span>

                            <div>
                                <h2>WellnessHub</h2>
                                <p>Counselling Services</p>
                            </div>

                        </div>

                        <div class="referral-title">

                            <h3>Student Referral Form</h3>

                            <p>
                                Student Counselling and Wellness Support
                            </p>

                        </div>

                        <div class="referral-section">

                            <h4>01. Student Information</h4>

                            <div class="referral-grid">

                                <label>
                                    Student Reference

                                    <input
                                        id="refStudent"
                                        placeholder="Student reference"
                                    >
                                </label>

                                <label>
                                    Referral Date

                                    <input
                                        id="refDate"
                                        type="date"
                                    >
                                </label>

                            </div>

                            <label>
                                Referring Counsellor

                                <input
                                    id="refCounsellor"
                                    placeholder="Counsellor name"
                                >
                            </label>

                        </div>

                        <div class="referral-section">

                            <h4>02. Referral Information</h4>

                            <label>
                                Reason for Referral

                                <textarea
                                    id="refReason"
                                    placeholder="Reason for referral"
                                ></textarea>
                            </label>

                            <label>
                                Support Requested

                                <select id="refSupport">

                                    <option value="">
                                        Select support required
                                    </option>

                                    <option>Individual Counselling</option>
                                    <option>Academic Stress Support</option>
                                    <option>Anxiety Support</option>
                                    <option>Emotional Wellness Support</option>
                                    <option>Crisis Intervention</option>
                                    <option>External Professional Referral</option>
                                    <option>Other Support</option>

                                </select>

                            </label>

                        </div>

                        <div class="referral-section">

                            <h4>
                                03. Consent and Authorization
                            </h4>

                            <label>
                                Consent or Other Lawful Basis

                                <textarea
                                    id="refConsent"
                                    placeholder="Applicable authorization"
                                ></textarea>
                            </label>

                        </div>

                        <div class="referral-section">

                            <h4>04. Follow-Up Plan</h4>

                            <label>
                                Follow-Up Arrangements

                                <textarea
                                    id="refFollowup"
                                    placeholder="Recommended next steps"
                                ></textarea>
                            </label>

                        </div>

                        <div class="referral-footer">

                            <span>
                                WellnessHub Counselling Services
                            </span>

                            <span>
                                Confidential Student Information
                            </span>

                        </div>

                    </div>

                    <div class="referral-actions">

                        <button
                            type="button"
                            class="save-resource"
                            id="printReferralBtn"
                        >
                            🖨 Print Referral Form
                        </button>

                        <button
                            type="button"
                            class="cancel-resource"
                            id="clearReferralBtn"
                        >
                            Clear Form
                        </button>

                    </div>

                </div>

            </details>

            <!-- PEER SUPPORT MODERATION -->

            <details
                class="resource-entry"
                data-category="Peer Support"
                data-search="peer support moderation guide privacy respect bullying communication"
            >

                <summary class="resource-item">

                    <span class="resource-thumb toolkit-icon">
                        🤝
                    </span>

                    <div>
                        <h3>Peer Support Moderation Guide</h3>

                        <p>
                            Moderation guidelines and supportive communication
                        </p>
                    </div>

                    <span class="resource-arrow">›</span>

                </summary>

                <div class="resource-detail">

                    <span class="resource-tag">
                        Peer Support
                    </span>

                    <div class="guide-header">

                        <span class="guide-icon">🤝</span>

                        <div>
                            <h2>Peer Support Moderation</h2>
                            <p>WellnessHub Counselling Services</p>
                        </div>

                    </div>

                    <div class="guide-intro">

                        <h4>Overview</h4>

                        Peer support moderation creates a safe,
                        inclusive environment where students can
                        share experiences, encourage one another
                        and access mental wellness support.

                    </div>

                    <h3 style="margin:24px 0 12px;color:white">
                        Moderation Guidelines
                    </h3>

                    <?php
                    $peerSteps = [
                        'Respectful Communication' =>
                            'Encourage students to communicate respectfully, demonstrate empathy and support each other without judgment.',

                        'Protect Student Privacy' =>
                            'Do not request sensitive personal or medical information in public discussions. Direct students to private support channels.',

                        'Address Inappropriate Behaviour' =>
                            'Respond to bullying, harassment, harmful comments and unauthorized disclosure under institutional procedures.',

                        'Escalate Safety Concerns' =>
                            'Identify immediate dangers or serious distress and escalate concerns through approved crisis response procedures.',

                        'Encourage Professional Support' =>
                            'Explain available counselling services and encourage professional assistance when needed.'
                    ];

                    $peerNum = 0;

                    foreach ($peerSteps as $name => $description):
                        $peerNum++;
                    ?>

                        <div class="guide-step">

                            <span>
                                <?= str_pad(
                                    (string)$peerNum,
                                    2,
                                    '0',
                                    STR_PAD_LEFT
                                ) ?>
                            </span>

                            <div>
                                <h4><?= h($name) ?></h4>
                                <p><?= h($description) ?></p>
                            </div>

                        </div>

                    <?php endforeach; ?>

                    <div class="peer-response">

                        <h3>
                            💬 Supportive Counsellor Response
                        </h3>

                        <p>
                            “Thank you for sharing your experience.
                            We appreciate your openness.
                            If you would like to talk privately,
                            a WellnessHub counsellor can help you
                            explore the support options available.”
                        </p>

                    </div>

                    <div class="peer-responsibilities">

                        <h3>Moderator Responsibilities</h3>

                        <ul>
                            <li>Maintain a welcoming, respectful environment.</li>
                            <li>Protect confidential student information.</li>
                            <li>Identify inappropriate or potentially harmful content.</li>
                            <li>Refer serious concerns to authorized professionals.</li>
                            <li>Follow applicable privacy and institutional procedures.</li>
                        </ul>

                    </div>

                </div>

            </details>

            <!-- SAVED MYSQL RESOURCES -->

            <?php foreach ($resources as $item): ?>

                <details
                    class="resource-entry"
                    data-category="<?= h($item['category']) ?>"
                    data-search="<?= h(
                        $item['title'] . ' ' .
                        $item['description'] . ' ' .
                        $item['content']
                    ) ?>"
                >

                    <summary class="resource-item">

                        <span class="resource-thumb toolkit-icon">
                            <?= h(
                                $icons[$item['category']] ?? '📘'
                            ) ?>
                        </span>

                        <div>

                            <h3>
                                <?= h($item['title']) ?>
                            </h3>

                            <p>
                                <?= h($item['description']) ?>
                            </p>

                        </div>

                        <span class="resource-arrow">›</span>

                    </summary>

                    <div class="resource-detail">

                        <span class="resource-tag">
                            <?= h($item['category']) ?>
                        </span>

                        <div class="saved-header">

                            <span class="saved-header-icon">
                                <?= h(
                                    $icons[$item['category']] ?? '📘'
                                ) ?>
                            </span>

                            <div>

                                <h3>
                                    <?= h($item['title']) ?>
                                </h3>

                                <p>
                                    <?= h($item['description']) ?>
                                </p>

                            </div>

                        </div>

                        <!-- FORMATTED RESOURCE CONTENT -->

                        <?php
                            displayResourceGuide(
                                $item['content'],
                                $item['title']
                            );
                        ?>

                        <!-- WEBSITE AND PDF -->

                        <?php if (
                            $item['resource_url'] ||
                            $item['pdf_name']
                        ): ?>

                            <div class="saved-links">

                                <?php if ($item['resource_url']): ?>

                                    <a
                                        class="saved-link"
                                        href="<?= h($item['resource_url']) ?>"
                                        target="_blank"
                                        rel="noopener noreferrer"
                                    >

                                        <span class="saved-link-icon">
                                            🌐
                                        </span>

                                        <span>
                                            <strong>
                                                Visit Resource Website
                                            </strong>

                                            <small>
                                                Open related support website
                                            </small>
                                        </span>

                                    </a>

                                <?php endif; ?>

                                <?php if ($item['pdf_name']): ?>

                                    <a
                                        class="saved-link"
                                        href="counsellor-resources.php?download=<?= (int)$item['resource_id'] ?>"
                                    >

                                        <span class="saved-link-icon">
                                            📄
                                        </span>

                                        <span>

                                            <strong>
                                                Download Resource PDF
                                            </strong>

                                            <small>
                                                <?= h($item['pdf_name']) ?>
                                            </small>

                                        </span>

                                    </a>

                                <?php endif; ?>

                            </div>

                        <?php endif; ?>

                        <!-- EDIT AND DELETE -->

                        <div class="item-actions">

                            <button
                                type="button"
                                class="edit-resource editEntry"
                                data-id="<?= (int)$item['resource_id'] ?>"
                            >
                                Edit Resource
                            </button>

                            <form
                                method="post"
                                action="counsellor-resources.php"
                                class="deleteForm"
                            >

                                <input
                                    type="hidden"
                                    name="csrf_token"
                                    value="<?= h($_SESSION['toolkit_csrf']) ?>"
                                >

                                <input
                                    type="hidden"
                                    name="resource_action"
                                    value="delete"
                                >

                                <input
                                    type="hidden"
                                    name="resource_id"
                                    value="<?= (int)$item['resource_id'] ?>"
                                >

                                <button
                                    type="submit"
                                    class="delete-resource"
                                >
                                    Delete Resource
                                </button>

                            </form>

                        </div>

                    </div>

                </details>

            <?php endforeach; ?>

        </div>

        <p
            id="noResults"
            class="no-resources"
            hidden
        >
            No resources match your search.
        </p>

    </section>

</main>

</div>

<script>

// DATABASE RESOURCE RECORDS
const records = <?= json_encode(
    array_column($resources, null, 'resource_id'),
    JSON_HEX_TAG |
    JSON_HEX_AMP |
    JSON_HEX_APOS |
    JSON_HEX_QUOT |
    JSON_INVALID_UTF8_SUBSTITUTE
) ?: '{}' ?>;

const editor = document.getElementById('resourceEditor');
const actionInput = document.getElementById('resourceAction');
const idInput = document.getElementById('resourceId');
const addButton = document.getElementById('addResourceBtn');

// SHOW RESOURCE FORM
function showEditor(open) {

    editor.classList.toggle('open', open);

    if (open) {
        editor.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
        });

        document.getElementById('resourceTitle').focus();
    }
}

// ADD RESOURCE
addButton.addEventListener('click', () => {

    editor.reset();

    actionInput.value = 'add';
    idInput.value = '';

    document.getElementById(
        'editorHeading'
    ).textContent = 'Add New Resource';

    document.getElementById(
        'existingPdfBox'
    ).hidden = true;

    showEditor(true);
});

// CANCEL
document.getElementById(
    'cancelResourceBtn'
).addEventListener('click', () => {

    editor.reset();
    showEditor(false);

});

// EDIT RESOURCE
document.querySelectorAll(
    '.editEntry'
).forEach(button => {

    button.addEventListener('click', () => {

        const item = records[button.dataset.id];

        if (!item) return;

        editor.reset();

        actionInput.value = 'edit';
        idInput.value = item.resource_id;

        document.getElementById(
            'editorHeading'
        ).textContent = 'Edit Resource';

        document.getElementById('resourceTitle').value =
            item.title;

        document.getElementById('resourceCategory').value =
            item.category;

        document.getElementById('resourceDescription').value =
            item.description;

        document.getElementById('resourceContent').value =
            item.content;

        document.getElementById('resourceUrl').value =
            item.resource_url || '';

        document.getElementById(
            'existingPdfBox'
        ).hidden = !item.pdf_name;

        showEditor(true);

    });

});

// DELETE RESOURCE
document.querySelectorAll(
    '.deleteForm'
).forEach(form => {

    form.addEventListener('submit', event => {

        if (!confirm(
            'Delete this resource for all counsellors?'
        )) {
            event.preventDefault();
        }

    });

});

// SEARCH AND FILTER
function filterResources() {

    const query = document.getElementById(
        'resourceSearch'
    ).value.toLowerCase().trim();

    const category = document.getElementById(
        'categoryFilter'
    ).value;

    let visible = 0;

    document.querySelectorAll(
        '.resource-entry'
    ).forEach(item => {

        const match =
            (!query ||
                item.dataset.search.toLowerCase().includes(query))
            &&
            (!category ||
                item.dataset.category === category);

        item.hidden = !match;

        if (match) visible++;

    });

    document.getElementById(
        'noResults'
    ).hidden = visible > 0;
}

document.getElementById(
    'resourceSearch'
).addEventListener(
    'input',
    filterResources
);

document.getElementById(
    'categoryFilter'
).addEventListener(
    'change',
    filterResources
);

// PRINT REFERRAL
document.getElementById(
    'printReferralBtn'
).addEventListener('click', () => {

    window.print();

});

// CLEAR REFERRAL
document.getElementById(
    'clearReferralBtn'
).addEventListener('click', () => {

    if (!confirm(
        'Clear all referral form fields?'
    )) {
        return;
    }

    document.querySelectorAll(
        '#referralPrintArea input,' +
        '#referralPrintArea textarea,' +
        '#referralPrintArea select'
    ).forEach(input => {

        input.value = '';

    });

});

</script>

</body>
</html>
