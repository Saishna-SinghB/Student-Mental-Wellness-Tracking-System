-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 09, 2026 at 11:58 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wellnesshub`
--

-- --------------------------------------------------------

--
-- Table structure for table `activities`
--

CREATE TABLE `activities` (
  `activity_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `activity_type` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `auditlog`
--

CREATE TABLE `auditlog` (
  `log_id` int(11) NOT NULL,
  `actor_user_id` int(11) DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `target_table` varchar(50) DEFAULT NULL,
  `target_id` int(11) DEFAULT NULL,
  `details` varchar(500) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `booking_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `counsellor_id` int(11) NOT NULL,
  `session_date` date NOT NULL,
  `session_time` time NOT NULL,
  `status` enum('booked','cancelled','completed') NOT NULL DEFAULT 'booked',
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `counsellors`
--

CREATE TABLE `counsellors` (
  `counsellor_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `specialties` varchar(255) DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `journal_entries`
--

CREATE TABLE `journal_entries` (
  `entry_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `content` mediumtext NOT NULL,
  `emotion` enum('Grateful','Calm','Hopeful','Anxious','Frustrated') DEFAULT NULL,
  `alert_tier` enum('normal','critical') NOT NULL DEFAULT 'normal',
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `mood_checkins`
--

CREATE TABLE `mood_checkins` (
  `checkin_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `mood` enum('great','good','okay','low','struggling') NOT NULL,
  `stress_level` tinyint(3) UNSIGNED NOT NULL,
  `checkin_date` date NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ;

--
-- Dumping data for table `mood_checkins`
--

INSERT INTO `mood_checkins` (`checkin_id`, `user_id`, `mood`, `stress_level`, `checkin_date`, `created_at`, `updated_at`) VALUES
(1, 1, 'struggling', 8, '2026-09-09', '2026-09-09 23:50:56', '2026-09-09 23:50:56');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `notification_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `title` varchar(150) NOT NULL,
  `message` varchar(500) NOT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_codes`
--

CREATE TABLE `password_reset_codes` (
  `reset_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `code_hash` varchar(255) NOT NULL,
  `expires_at` datetime NOT NULL,
  `used` tinyint(1) NOT NULL DEFAULT 0,
  `attempts` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `verified_at` datetime DEFAULT NULL,
  `reset_token_hash` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `platform_settings`
--
-- Single-row table for global platform toggles. Currently just
-- audit_logging_enabled — a global kill switch for ALL audit logging
-- (see the note above createAuditLog() in demoAPI.php: there is no
-- carve-out that always logs security-critical actions regardless).

CREATE TABLE `platform_settings` (
  `id` tinyint(4) NOT NULL DEFAULT 1,
  `audit_logging_enabled` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `platform_settings` (`id`, `audit_logging_enabled`) VALUES (1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `content` text NOT NULL,
  `category` enum('Support','Vent','Advice','Encouragement') NOT NULL DEFAULT 'Support',
  `is_removed` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `post_likes`
--

CREATE TABLE `post_likes` (
  `like_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `post_replies`
--

CREATE TABLE `post_replies` (
  `reply_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `content` text NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `post_reports`
--

CREATE TABLE `post_reports` (
  `report_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `reviewed` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `risk_alerts`
--
-- Real heuristic-based detection (see syncRiskAlerts() in demoAPI.php):
-- flags a student when a mood_checkin shows struggling/low mood or
-- stress_level >= 8 in the last 7 days, or a journal entry matches a
-- crisis keyword in the last 30 days. UNIQUE(source, source_id) makes
-- re-running the sync an upsert rather than creating duplicate alerts.
--

CREATE TABLE `risk_alerts` (
  `alert_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `source` enum('mood_checkin','journal_entry') NOT NULL,
  `source_id` int(11) NOT NULL,
  `severity` enum('medium','high') NOT NULL,
  `reason` varchar(255) NOT NULL,
  `status` enum('open','in_progress','resolved') NOT NULL DEFAULT 'open',
  `handled_by` int(11) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `resolved_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `counsellor_notes`
--
-- NOTE: counsellor_id here stores users.user_id of the logged-in
-- counsellor (their account id), NOT counsellors.counsellor_id. Naming
-- is a little confusing but internally consistent with how
-- handleCounsellorNoteSave() writes to it.
--

CREATE TABLE `counsellor_notes` (
  `note_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `counsellor_id` int(11) NOT NULL,
  `note` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `resources`
--

CREATE TABLE `resources` (
  `resource_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `subtitle` varchar(255) DEFAULT NULL,
  `category` enum('Anxiety','Academic Stress','Sleep','Relationships','Self Confidence','Crisis Support') NOT NULL,
  `resource_type` enum('pdf','audio','meditation','contact') NOT NULL,
  `icon` varchar(10) NOT NULL,
  `url` varchar(500) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `resources`
--

INSERT INTO `resources` (`resource_id`, `title`, `subtitle`, `category`, `resource_type`, `icon`, `url`, `created_at`) VALUES
(1, 'CBT Worksheet: Managing Anxiety', 'PDF worksheet · 10 min read', 'Anxiety', 'pdf', '📄', NULL, '2026-09-09 23:20:40'),
(2, 'Guided Breathing Exercise', 'Audio exercise · 5 min', 'Anxiety', 'audio', '🎧', NULL, '2026-09-09 23:20:40'),
(3, 'Meditation for Students', 'Audio · 10 min', 'Sleep', 'meditation', '🧘', NULL, '2026-09-09 23:20:40'),
(4, 'SADAG Crisis Contacts', '24/7 Suicide Crisis Helpline: 0800 567 567', 'Crisis Support', 'contact', '☎', 'tel:0800567567', '2026-09-09 23:20:40');

-- --------------------------------------------------------

--
-- Table structure for table `riskalerts`
--

CREATE TABLE `riskalerts` (
  `alert_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `source_type` enum('mood_checkin','journal_entry','post') NOT NULL,
  `source_id` int(11) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `status` enum('open','reviewing','resolved') NOT NULL DEFAULT 'open',
  `reviewed_by` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `resolved_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `student_number` varchar(50) DEFAULT NULL,
  `email` varchar(150) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('student','counsellor','admin') NOT NULL DEFAULT 'student',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `last_login_at` datetime DEFAULT NULL,
  `profile_picture` mediumtext DEFAULT NULL,
  `gender` enum('Male','Female','Non-binary','Prefer not to say') DEFAULT NULL,
  `qualification` varchar(120) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `full_name`, `student_number`, `email`, `password_hash`, `role`, `gender`, `qualification`, `is_active`, `last_login_at`, `created_at`) VALUES
(1, 'Samika Moodley', '402311523', '402311523@richfield.ac.za', '$2y$10$fi51f4WPPSEyvX/zb1tS2Op1XHRRqlTQXqGK0vErccqm4kQB4CEjK', 'student', NULL, 'Diploma in Information Technology (DIT)', 1, (CURDATE() - INTERVAL 5 DAY + INTERVAL 9 HOUR), '2026-09-09 23:43:07'),
(2, 'WellnessHub Administrator', NULL, 'Admin@Richfield.ac.za', '$2y$10$Wafm6cmKcT7Bsonwwvxm5etaT87vE87.63neoWdWX8GGkuoyg2bte', 'admin', NULL, NULL, 1, (CURDATE() - INTERVAL 0 DAY + INTERVAL 8 HOUR), '2026-09-09 23:43:07'),
(3, 'Dr. Naidoo', NULL, 'naidoo@richfield.ac.za', '$2y$10$ahWc7rOGxYw76a/ZPNAZ4uLfa021DKbMwiyO4csBUOFlOMP.PBmNO', 'counsellor', 'Prefer not to say', NULL, 1, (CURDATE() - INTERVAL 0 DAY + INTERVAL 12 HOUR), '2026-09-09 23:43:07'),
(4, 'Ms. Zanele Khumalo', NULL, 'zanele.khumalo@mindspace.example', '$2y$10$WhY/TaRVH22KZmLeJP0zoeYxMg69NbExz4cQA4cUYJRJIpYJd7OTW', 'counsellor', 'Female', NULL, 1, (CURDATE() - INTERVAL 0 DAY + INTERVAL 10 HOUR), '2026-09-09 23:43:07'),
(5, 'Mr. Pieter van der Merwe', NULL, 'pieter@counselcare.example', '$2y$10$WhY/TaRVH22KZmLeJP0zoeYxMg69NbExz4cQA4cUYJRJIpYJd7OTW', 'counsellor', 'Male', NULL, 1, (CURDATE() - INTERVAL 3 DAY + INTERVAL 16 HOUR), '2026-09-09 23:43:07'),
(6, 'Dr. Aisha Patel', NULL, 'aisha.patel@richfield.ac.za', '$2y$10$WhY/TaRVH22KZmLeJP0zoeYxMg69NbExz4cQA4cUYJRJIpYJd7OTW', 'counsellor', 'Female', NULL, 1, (CURDATE() - INTERVAL 3 DAY + INTERVAL 16 HOUR), '2026-09-09 23:43:07'),
(7, 'Mr. Sibusiso Dlamini', NULL, 'sibusiso@talkhub.example', '$2y$10$WhY/TaRVH22KZmLeJP0zoeYxMg69NbExz4cQA4cUYJRJIpYJd7OTW', 'counsellor', 'Male', NULL, 1, (CURDATE() - INTERVAL 3 DAY + INTERVAL 10 HOUR), '2026-09-09 23:43:07'),
(8, 'Thandiwe Mokoena', '402410101', '402410101@my.richfield.ac.za', '$2y$10$.D6wqdkpHTyI3BV1nyNMSu.Bhsl6ciMAWpcdg8dwqgnd3Ec4Dg5ai', 'student', 'Female', 'Bachelor of Science in Information Technology (BSc IT)', 1, (CURDATE() - INTERVAL 0 DAY + INTERVAL 7 HOUR), (CURDATE() - INTERVAL 140 DAY + INTERVAL 9 HOUR)),
(9, 'Lwazi Zulu', '402410102', '402410102@my.richfield.ac.za', '$2y$10$.D6wqdkpHTyI3BV1nyNMSu.Bhsl6ciMAWpcdg8dwqgnd3Ec4Dg5ai', 'student', 'Male', 'Diploma in Information Technology (DIT)', 1, (CURDATE() - INTERVAL 1 DAY + INTERVAL 8 HOUR), (CURDATE() - INTERVAL 98 DAY + INTERVAL 9 HOUR)),
(10, 'Nokuthula Dube', '402410103', '402410103@my.richfield.ac.za', '$2y$10$.D6wqdkpHTyI3BV1nyNMSu.Bhsl6ciMAWpcdg8dwqgnd3Ec4Dg5ai', 'student', 'Female', 'Bachelor of Commerce (BCom)', 1, (CURDATE() - INTERVAL 0 DAY + INTERVAL 14 HOUR), (CURDATE() - INTERVAL 63 DAY + INTERVAL 15 HOUR)),
(11, 'Ryan Govender', '402410104', '402410104@my.richfield.ac.za', '$2y$10$.D6wqdkpHTyI3BV1nyNMSu.Bhsl6ciMAWpcdg8dwqgnd3Ec4Dg5ai', 'student', 'Male', 'Diploma in Business Administration (DBA)', 1, (CURDATE() - INTERVAL 2 DAY + INTERVAL 17 HOUR), (CURDATE() - INTERVAL 102 DAY + INTERVAL 11 HOUR)),
(12, 'Ayesha Khan', '402410105', '402410105@my.richfield.ac.za', '$2y$10$.D6wqdkpHTyI3BV1nyNMSu.Bhsl6ciMAWpcdg8dwqgnd3Ec4Dg5ai', 'student', 'Female', 'Bachelor of Business Administration (BBA)', 1, (CURDATE() - INTERVAL 0 DAY + INTERVAL 13 HOUR), (CURDATE() - INTERVAL 94 DAY + INTERVAL 13 HOUR)),
(13, 'Sipho Ndlovu', '402410106', '402410106@my.richfield.ac.za', '$2y$10$.D6wqdkpHTyI3BV1nyNMSu.Bhsl6ciMAWpcdg8dwqgnd3Ec4Dg5ai', 'student', 'Male', 'Higher Certificate in Information Technology (HCIT)', 1, (CURDATE() - INTERVAL 3 DAY + INTERVAL 12 HOUR), (CURDATE() - INTERVAL 165 DAY + INTERVAL 14 HOUR)),
(14, 'Megan Naidoo', '402410107', '402410107@my.richfield.ac.za', '$2y$10$.D6wqdkpHTyI3BV1nyNMSu.Bhsl6ciMAWpcdg8dwqgnd3Ec4Dg5ai', 'student', 'Female', 'Bachelor of Public Management (BPM)', 1, (CURDATE() - INTERVAL 1 DAY + INTERVAL 18 HOUR), (CURDATE() - INTERVAL 127 DAY + INTERVAL 9 HOUR)),
(15, 'Tumelo Sithole', '402410108', '402410108@my.richfield.ac.za', '$2y$10$.D6wqdkpHTyI3BV1nyNMSu.Bhsl6ciMAWpcdg8dwqgnd3Ec4Dg5ai', 'student', 'Non-binary', 'Diploma in Local Government Management (DLGM)', 1, (CURDATE() - INTERVAL 0 DAY + INTERVAL 18 HOUR), (CURDATE() - INTERVAL 105 DAY + INTERVAL 9 HOUR)),
(16, 'Kagiso Molefe', '402410109', '402410109@my.richfield.ac.za', '$2y$10$.D6wqdkpHTyI3BV1nyNMSu.Bhsl6ciMAWpcdg8dwqgnd3Ec4Dg5ai', 'student', 'Male', 'Bachelor of Commerce (AGA)', 1, (CURDATE() - INTERVAL 0 DAY + INTERVAL 15 HOUR), (CURDATE() - INTERVAL 130 DAY + INTERVAL 12 HOUR)),
(17, 'Priya Reddy', '402410110', '402410110@my.richfield.ac.za', '$2y$10$.D6wqdkpHTyI3BV1nyNMSu.Bhsl6ciMAWpcdg8dwqgnd3Ec4Dg5ai', 'student', 'Female', 'Higher Certificate in Business Administration (HCBA)', 1, (CURDATE() - INTERVAL 1 DAY + INTERVAL 11 HOUR), (CURDATE() - INTERVAL 120 DAY + INTERVAL 10 HOUR)),
(18, 'Mandla Khumalo', '402410111', '402410111@my.richfield.ac.za', '$2y$10$.D6wqdkpHTyI3BV1nyNMSu.Bhsl6ciMAWpcdg8dwqgnd3Ec4Dg5ai', 'student', 'Male', 'Postgraduate Diploma in Management (PGDM)', 1, (CURDATE() - INTERVAL 4 DAY + INTERVAL 17 HOUR), (CURDATE() - INTERVAL 152 DAY + INTERVAL 17 HOUR)),
(19, 'Zoe Peters', '402410112', '402410112@my.richfield.ac.za', '$2y$10$.D6wqdkpHTyI3BV1nyNMSu.Bhsl6ciMAWpcdg8dwqgnd3Ec4Dg5ai', 'student', 'Prefer not to say', 'Bachelor of Commerce (AGA IT)', 1, (CURDATE() - INTERVAL 2 DAY + INTERVAL 11 HOUR), (CURDATE() - INTERVAL 65 DAY + INTERVAL 13 HOUR));


-- --------------------------------------------------------

--
-- Table structure for table `user_settings`
--

CREATE TABLE `user_settings` (
  `user_id` int(11) NOT NULL,
  `dark_mode` tinyint(1) NOT NULL DEFAULT 0,
  `booking_reminders` tinyint(1) NOT NULL DEFAULT 1,
  `weekly_mood_email` tinyint(1) NOT NULL DEFAULT 1,
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `weeklymoodsummary`
--

CREATE TABLE `weeklymoodsummary` (
  `summary_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `week_start` date NOT NULL,
  `avg_mood_score` decimal(3,1) DEFAULT NULL,
  `avg_stress_level` decimal(3,1) DEFAULT NULL,
  `checkin_count` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Demo data for the remaining tables
--

INSERT INTO `counsellors` (`counsellor_id`, `name`, `specialties`, `avatar`, `user_id`) VALUES
(1, 'Dr. Naidoo', 'General Counselling', '🩺', 3),
(2, 'Ms. Zanele Khumalo', 'Anxiety, Stress Management', '🌿', 4),
(3, 'Mr. Pieter van der Merwe', 'Depression, Academic Pressure', '💬', 5),
(4, 'Dr. Aisha Patel', 'Trauma, Relationships', '🧘', 6),
(5, 'Mr. Sibusiso Dlamini', 'Career Guidance, Substance Use', '🧭', 7);

INSERT INTO `mood_checkins` (`checkin_id`, `user_id`, `mood`, `stress_level`, `checkin_date`, `created_at`, `updated_at`) VALUES
(2, 8, 'good', 4, (CURDATE() - INTERVAL 0 DAY), (CURDATE() - INTERVAL 0 DAY + INTERVAL 15 HOUR), (CURDATE() - INTERVAL 0 DAY + INTERVAL 14 HOUR)),
(3, 8, 'okay', 6, (CURDATE() - INTERVAL 1 DAY), (CURDATE() - INTERVAL 1 DAY + INTERVAL 21 HOUR), (CURDATE() - INTERVAL 1 DAY + INTERVAL 14 HOUR)),
(4, 8, 'okay', 6, (CURDATE() - INTERVAL 2 DAY), (CURDATE() - INTERVAL 2 DAY + INTERVAL 21 HOUR), (CURDATE() - INTERVAL 2 DAY + INTERVAL 14 HOUR)),
(5, 8, 'good', 2, (CURDATE() - INTERVAL 3 DAY), (CURDATE() - INTERVAL 3 DAY + INTERVAL 20 HOUR), (CURDATE() - INTERVAL 3 DAY + INTERVAL 7 HOUR)),
(6, 8, 'okay', 5, (CURDATE() - INTERVAL 5 DAY), (CURDATE() - INTERVAL 5 DAY + INTERVAL 14 HOUR), (CURDATE() - INTERVAL 5 DAY + INTERVAL 9 HOUR)),
(7, 8, 'okay', 6, (CURDATE() - INTERVAL 6 DAY), (CURDATE() - INTERVAL 6 DAY + INTERVAL 18 HOUR), (CURDATE() - INTERVAL 6 DAY + INTERVAL 14 HOUR)),
(8, 8, 'low', 8, (CURDATE() - INTERVAL 11 DAY), (CURDATE() - INTERVAL 11 DAY + INTERVAL 19 HOUR), (CURDATE() - INTERVAL 11 DAY + INTERVAL 17 HOUR)),
(9, 8, 'okay', 5, (CURDATE() - INTERVAL 12 DAY), (CURDATE() - INTERVAL 12 DAY + INTERVAL 10 HOUR), (CURDATE() - INTERVAL 12 DAY + INTERVAL 11 HOUR)),
(10, 8, 'okay', 5, (CURDATE() - INTERVAL 14 DAY), (CURDATE() - INTERVAL 14 DAY + INTERVAL 19 HOUR), (CURDATE() - INTERVAL 14 DAY + INTERVAL 15 HOUR)),
(11, 8, 'good', 3, (CURDATE() - INTERVAL 16 DAY), (CURDATE() - INTERVAL 16 DAY + INTERVAL 15 HOUR), (CURDATE() - INTERVAL 16 DAY + INTERVAL 19 HOUR)),
(12, 8, 'okay', 5, (CURDATE() - INTERVAL 19 DAY), (CURDATE() - INTERVAL 19 DAY + INTERVAL 14 HOUR), (CURDATE() - INTERVAL 19 DAY + INTERVAL 21 HOUR)),
(13, 8, 'low', 7, (CURDATE() - INTERVAL 21 DAY), (CURDATE() - INTERVAL 21 DAY + INTERVAL 14 HOUR), (CURDATE() - INTERVAL 21 DAY + INTERVAL 21 HOUR)),
(14, 8, 'good', 3, (CURDATE() - INTERVAL 25 DAY), (CURDATE() - INTERVAL 25 DAY + INTERVAL 12 HOUR), (CURDATE() - INTERVAL 25 DAY + INTERVAL 8 HOUR)),
(15, 8, 'great', 1, (CURDATE() - INTERVAL 26 DAY), (CURDATE() - INTERVAL 26 DAY + INTERVAL 8 HOUR), (CURDATE() - INTERVAL 26 DAY + INTERVAL 7 HOUR)),
(16, 8, 'okay', 6, (CURDATE() - INTERVAL 27 DAY), (CURDATE() - INTERVAL 27 DAY + INTERVAL 19 HOUR), (CURDATE() - INTERVAL 27 DAY + INTERVAL 10 HOUR)),
(17, 8, 'okay', 5, (CURDATE() - INTERVAL 28 DAY), (CURDATE() - INTERVAL 28 DAY + INTERVAL 17 HOUR), (CURDATE() - INTERVAL 28 DAY + INTERVAL 19 HOUR)),
(18, 8, 'good', 4, (CURDATE() - INTERVAL 29 DAY), (CURDATE() - INTERVAL 29 DAY + INTERVAL 16 HOUR), (CURDATE() - INTERVAL 29 DAY + INTERVAL 19 HOUR)),
(19, 8, 'good', 4, (CURDATE() - INTERVAL 35 DAY), (CURDATE() - INTERVAL 35 DAY + INTERVAL 15 HOUR), (CURDATE() - INTERVAL 35 DAY + INTERVAL 11 HOUR)),
(20, 8, 'okay', 6, (CURDATE() - INTERVAL 36 DAY), (CURDATE() - INTERVAL 36 DAY + INTERVAL 11 HOUR), (CURDATE() - INTERVAL 36 DAY + INTERVAL 15 HOUR)),
(21, 8, 'good', 2, (CURDATE() - INTERVAL 37 DAY), (CURDATE() - INTERVAL 37 DAY + INTERVAL 13 HOUR), (CURDATE() - INTERVAL 37 DAY + INTERVAL 7 HOUR)),
(22, 8, 'okay', 6, (CURDATE() - INTERVAL 39 DAY), (CURDATE() - INTERVAL 39 DAY + INTERVAL 12 HOUR), (CURDATE() - INTERVAL 39 DAY + INTERVAL 21 HOUR)),
(23, 8, 'good', 3, (CURDATE() - INTERVAL 41 DAY), (CURDATE() - INTERVAL 41 DAY + INTERVAL 14 HOUR), (CURDATE() - INTERVAL 41 DAY + INTERVAL 12 HOUR)),
(24, 8, 'good', 2, (CURDATE() - INTERVAL 43 DAY), (CURDATE() - INTERVAL 43 DAY + INTERVAL 9 HOUR), (CURDATE() - INTERVAL 43 DAY + INTERVAL 16 HOUR)),
(25, 8, 'good', 4, (CURDATE() - INTERVAL 45 DAY), (CURDATE() - INTERVAL 45 DAY + INTERVAL 18 HOUR), (CURDATE() - INTERVAL 45 DAY + INTERVAL 8 HOUR)),
(26, 8, 'great', 3, (CURDATE() - INTERVAL 47 DAY), (CURDATE() - INTERVAL 47 DAY + INTERVAL 15 HOUR), (CURDATE() - INTERVAL 47 DAY + INTERVAL 21 HOUR)),
(27, 8, 'great', 3, (CURDATE() - INTERVAL 49 DAY), (CURDATE() - INTERVAL 49 DAY + INTERVAL 17 HOUR), (CURDATE() - INTERVAL 49 DAY + INTERVAL 21 HOUR)),
(28, 8, 'good', 4, (CURDATE() - INTERVAL 50 DAY), (CURDATE() - INTERVAL 50 DAY + INTERVAL 21 HOUR), (CURDATE() - INTERVAL 50 DAY + INTERVAL 9 HOUR)),
(29, 8, 'good', 3, (CURDATE() - INTERVAL 51 DAY), (CURDATE() - INTERVAL 51 DAY + INTERVAL 15 HOUR), (CURDATE() - INTERVAL 51 DAY + INTERVAL 13 HOUR)),
(30, 8, 'great', 2, (CURDATE() - INTERVAL 53 DAY), (CURDATE() - INTERVAL 53 DAY + INTERVAL 14 HOUR), (CURDATE() - INTERVAL 53 DAY + INTERVAL 19 HOUR)),
(31, 8, 'good', 3, (CURDATE() - INTERVAL 55 DAY), (CURDATE() - INTERVAL 55 DAY + INTERVAL 8 HOUR), (CURDATE() - INTERVAL 55 DAY + INTERVAL 15 HOUR)),
(32, 9, 'okay', 4, (CURDATE() - INTERVAL 0 DAY), (CURDATE() - INTERVAL 0 DAY + INTERVAL 10 HOUR), (CURDATE() - INTERVAL 0 DAY + INTERVAL 7 HOUR)),
(33, 9, 'okay', 6, (CURDATE() - INTERVAL 2 DAY), (CURDATE() - INTERVAL 2 DAY + INTERVAL 9 HOUR), (CURDATE() - INTERVAL 2 DAY + INTERVAL 7 HOUR)),
(34, 9, 'okay', 6, (CURDATE() - INTERVAL 3 DAY), (CURDATE() - INTERVAL 3 DAY + INTERVAL 19 HOUR), (CURDATE() - INTERVAL 3 DAY + INTERVAL 15 HOUR)),
(35, 9, 'good', 4, (CURDATE() - INTERVAL 4 DAY), (CURDATE() - INTERVAL 4 DAY + INTERVAL 18 HOUR), (CURDATE() - INTERVAL 4 DAY + INTERVAL 10 HOUR)),
(36, 9, 'okay', 4, (CURDATE() - INTERVAL 5 DAY), (CURDATE() - INTERVAL 5 DAY + INTERVAL 8 HOUR), (CURDATE() - INTERVAL 5 DAY + INTERVAL 19 HOUR)),
(37, 9, 'good', 4, (CURDATE() - INTERVAL 6 DAY), (CURDATE() - INTERVAL 6 DAY + INTERVAL 7 HOUR), (CURDATE() - INTERVAL 6 DAY + INTERVAL 19 HOUR)),
(38, 9, 'okay', 4, (CURDATE() - INTERVAL 7 DAY), (CURDATE() - INTERVAL 7 DAY + INTERVAL 15 HOUR), (CURDATE() - INTERVAL 7 DAY + INTERVAL 12 HOUR)),
(39, 9, 'good', 3, (CURDATE() - INTERVAL 8 DAY), (CURDATE() - INTERVAL 8 DAY + INTERVAL 9 HOUR), (CURDATE() - INTERVAL 8 DAY + INTERVAL 11 HOUR)),
(40, 9, 'low', 7, (CURDATE() - INTERVAL 9 DAY), (CURDATE() - INTERVAL 9 DAY + INTERVAL 13 HOUR), (CURDATE() - INTERVAL 9 DAY + INTERVAL 7 HOUR)),
(41, 9, 'okay', 4, (CURDATE() - INTERVAL 10 DAY), (CURDATE() - INTERVAL 10 DAY + INTERVAL 17 HOUR), (CURDATE() - INTERVAL 10 DAY + INTERVAL 15 HOUR)),
(42, 9, 'okay', 5, (CURDATE() - INTERVAL 11 DAY), (CURDATE() - INTERVAL 11 DAY + INTERVAL 16 HOUR), (CURDATE() - INTERVAL 11 DAY + INTERVAL 17 HOUR)),
(43, 9, 'okay', 4, (CURDATE() - INTERVAL 13 DAY), (CURDATE() - INTERVAL 13 DAY + INTERVAL 16 HOUR), (CURDATE() - INTERVAL 13 DAY + INTERVAL 14 HOUR)),
(44, 9, 'good', 3, (CURDATE() - INTERVAL 14 DAY), (CURDATE() - INTERVAL 14 DAY + INTERVAL 20 HOUR), (CURDATE() - INTERVAL 14 DAY + INTERVAL 15 HOUR)),
(45, 9, 'okay', 6, (CURDATE() - INTERVAL 17 DAY), (CURDATE() - INTERVAL 17 DAY + INTERVAL 18 HOUR), (CURDATE() - INTERVAL 17 DAY + INTERVAL 13 HOUR)),
(46, 9, 'low', 6, (CURDATE() - INTERVAL 19 DAY), (CURDATE() - INTERVAL 19 DAY + INTERVAL 11 HOUR), (CURDATE() - INTERVAL 19 DAY + INTERVAL 19 HOUR)),
(47, 9, 'great', 2, (CURDATE() - INTERVAL 20 DAY), (CURDATE() - INTERVAL 20 DAY + INTERVAL 10 HOUR), (CURDATE() - INTERVAL 20 DAY + INTERVAL 15 HOUR)),
(48, 9, 'good', 2, (CURDATE() - INTERVAL 21 DAY), (CURDATE() - INTERVAL 21 DAY + INTERVAL 8 HOUR), (CURDATE() - INTERVAL 21 DAY + INTERVAL 7 HOUR)),
(49, 9, 'okay', 6, (CURDATE() - INTERVAL 22 DAY), (CURDATE() - INTERVAL 22 DAY + INTERVAL 11 HOUR), (CURDATE() - INTERVAL 22 DAY + INTERVAL 7 HOUR)),
(50, 9, 'okay', 5, (CURDATE() - INTERVAL 23 DAY), (CURDATE() - INTERVAL 23 DAY + INTERVAL 10 HOUR), (CURDATE() - INTERVAL 23 DAY + INTERVAL 19 HOUR)),
(51, 9, 'good', 4, (CURDATE() - INTERVAL 24 DAY), (CURDATE() - INTERVAL 24 DAY + INTERVAL 7 HOUR), (CURDATE() - INTERVAL 24 DAY + INTERVAL 17 HOUR)),
(52, 9, 'low', 6, (CURDATE() - INTERVAL 26 DAY), (CURDATE() - INTERVAL 26 DAY + INTERVAL 10 HOUR), (CURDATE() - INTERVAL 26 DAY + INTERVAL 7 HOUR)),
(53, 9, 'okay', 5, (CURDATE() - INTERVAL 27 DAY), (CURDATE() - INTERVAL 27 DAY + INTERVAL 9 HOUR), (CURDATE() - INTERVAL 27 DAY + INTERVAL 17 HOUR)),
(54, 9, 'okay', 6, (CURDATE() - INTERVAL 28 DAY), (CURDATE() - INTERVAL 28 DAY + INTERVAL 20 HOUR), (CURDATE() - INTERVAL 28 DAY + INTERVAL 20 HOUR)),
(55, 9, 'okay', 6, (CURDATE() - INTERVAL 29 DAY), (CURDATE() - INTERVAL 29 DAY + INTERVAL 12 HOUR), (CURDATE() - INTERVAL 29 DAY + INTERVAL 7 HOUR)),
(56, 9, 'okay', 4, (CURDATE() - INTERVAL 31 DAY), (CURDATE() - INTERVAL 31 DAY + INTERVAL 17 HOUR), (CURDATE() - INTERVAL 31 DAY + INTERVAL 15 HOUR)),
(57, 9, 'struggling', 8, (CURDATE() - INTERVAL 35 DAY), (CURDATE() - INTERVAL 35 DAY + INTERVAL 15 HOUR), (CURDATE() - INTERVAL 35 DAY + INTERVAL 20 HOUR)),
(58, 9, 'okay', 5, (CURDATE() - INTERVAL 36 DAY), (CURDATE() - INTERVAL 36 DAY + INTERVAL 17 HOUR), (CURDATE() - INTERVAL 36 DAY + INTERVAL 14 HOUR)),
(59, 9, 'okay', 4, (CURDATE() - INTERVAL 38 DAY), (CURDATE() - INTERVAL 38 DAY + INTERVAL 9 HOUR), (CURDATE() - INTERVAL 38 DAY + INTERVAL 17 HOUR)),
(60, 9, 'great', 2, (CURDATE() - INTERVAL 39 DAY), (CURDATE() - INTERVAL 39 DAY + INTERVAL 20 HOUR), (CURDATE() - INTERVAL 39 DAY + INTERVAL 20 HOUR)),
(61, 9, 'good', 3, (CURDATE() - INTERVAL 41 DAY), (CURDATE() - INTERVAL 41 DAY + INTERVAL 12 HOUR), (CURDATE() - INTERVAL 41 DAY + INTERVAL 15 HOUR)),
(62, 9, 'struggling', 8, (CURDATE() - INTERVAL 43 DAY), (CURDATE() - INTERVAL 43 DAY + INTERVAL 15 HOUR), (CURDATE() - INTERVAL 43 DAY + INTERVAL 10 HOUR)),
(63, 9, 'okay', 6, (CURDATE() - INTERVAL 46 DAY), (CURDATE() - INTERVAL 46 DAY + INTERVAL 15 HOUR), (CURDATE() - INTERVAL 46 DAY + INTERVAL 19 HOUR)),
(64, 9, 'good', 4, (CURDATE() - INTERVAL 48 DAY), (CURDATE() - INTERVAL 48 DAY + INTERVAL 13 HOUR), (CURDATE() - INTERVAL 48 DAY + INTERVAL 12 HOUR)),
(65, 9, 'low', 6, (CURDATE() - INTERVAL 50 DAY), (CURDATE() - INTERVAL 50 DAY + INTERVAL 9 HOUR), (CURDATE() - INTERVAL 50 DAY + INTERVAL 21 HOUR)),
(66, 9, 'okay', 5, (CURDATE() - INTERVAL 51 DAY), (CURDATE() - INTERVAL 51 DAY + INTERVAL 10 HOUR), (CURDATE() - INTERVAL 51 DAY + INTERVAL 18 HOUR)),
(67, 10, 'good', 4, (CURDATE() - INTERVAL 0 DAY), (CURDATE() - INTERVAL 0 DAY + INTERVAL 9 HOUR), (CURDATE() - INTERVAL 0 DAY + INTERVAL 18 HOUR)),
(68, 10, 'great', 1, (CURDATE() - INTERVAL 1 DAY), (CURDATE() - INTERVAL 1 DAY + INTERVAL 7 HOUR), (CURDATE() - INTERVAL 1 DAY + INTERVAL 21 HOUR)),
(69, 10, 'good', 2, (CURDATE() - INTERVAL 2 DAY), (CURDATE() - INTERVAL 2 DAY + INTERVAL 20 HOUR), (CURDATE() - INTERVAL 2 DAY + INTERVAL 12 HOUR)),
(70, 10, 'great', 3, (CURDATE() - INTERVAL 3 DAY), (CURDATE() - INTERVAL 3 DAY + INTERVAL 16 HOUR), (CURDATE() - INTERVAL 3 DAY + INTERVAL 10 HOUR)),
(71, 10, 'great', 3, (CURDATE() - INTERVAL 4 DAY), (CURDATE() - INTERVAL 4 DAY + INTERVAL 8 HOUR), (CURDATE() - INTERVAL 4 DAY + INTERVAL 13 HOUR)),
(72, 10, 'great', 2, (CURDATE() - INTERVAL 5 DAY), (CURDATE() - INTERVAL 5 DAY + INTERVAL 21 HOUR), (CURDATE() - INTERVAL 5 DAY + INTERVAL 14 HOUR)),
(73, 10, 'good', 4, (CURDATE() - INTERVAL 6 DAY), (CURDATE() - INTERVAL 6 DAY + INTERVAL 20 HOUR), (CURDATE() - INTERVAL 6 DAY + INTERVAL 14 HOUR)),
(74, 10, 'okay', 5, (CURDATE() - INTERVAL 8 DAY), (CURDATE() - INTERVAL 8 DAY + INTERVAL 19 HOUR), (CURDATE() - INTERVAL 8 DAY + INTERVAL 11 HOUR)),
(75, 10, 'great', 2, (CURDATE() - INTERVAL 9 DAY), (CURDATE() - INTERVAL 9 DAY + INTERVAL 15 HOUR), (CURDATE() - INTERVAL 9 DAY + INTERVAL 15 HOUR)),
(76, 10, 'good', 3, (CURDATE() - INTERVAL 10 DAY), (CURDATE() - INTERVAL 10 DAY + INTERVAL 13 HOUR), (CURDATE() - INTERVAL 10 DAY + INTERVAL 12 HOUR)),
(77, 10, 'great', 3, (CURDATE() - INTERVAL 11 DAY), (CURDATE() - INTERVAL 11 DAY + INTERVAL 21 HOUR), (CURDATE() - INTERVAL 11 DAY + INTERVAL 12 HOUR)),
(78, 10, 'good', 2, (CURDATE() - INTERVAL 13 DAY), (CURDATE() - INTERVAL 13 DAY + INTERVAL 9 HOUR), (CURDATE() - INTERVAL 13 DAY + INTERVAL 14 HOUR)),
(79, 10, 'good', 3, (CURDATE() - INTERVAL 16 DAY), (CURDATE() - INTERVAL 16 DAY + INTERVAL 11 HOUR), (CURDATE() - INTERVAL 16 DAY + INTERVAL 20 HOUR)),
(80, 10, 'great', 2, (CURDATE() - INTERVAL 18 DAY), (CURDATE() - INTERVAL 18 DAY + INTERVAL 9 HOUR), (CURDATE() - INTERVAL 18 DAY + INTERVAL 15 HOUR)),
(81, 10, 'good', 3, (CURDATE() - INTERVAL 20 DAY), (CURDATE() - INTERVAL 20 DAY + INTERVAL 7 HOUR), (CURDATE() - INTERVAL 20 DAY + INTERVAL 15 HOUR)),
(82, 10, 'okay', 6, (CURDATE() - INTERVAL 23 DAY), (CURDATE() - INTERVAL 23 DAY + INTERVAL 20 HOUR), (CURDATE() - INTERVAL 23 DAY + INTERVAL 17 HOUR)),
(83, 10, 'great', 2, (CURDATE() - INTERVAL 26 DAY), (CURDATE() - INTERVAL 26 DAY + INTERVAL 7 HOUR), (CURDATE() - INTERVAL 26 DAY + INTERVAL 21 HOUR)),
(84, 10, 'great', 3, (CURDATE() - INTERVAL 27 DAY), (CURDATE() - INTERVAL 27 DAY + INTERVAL 11 HOUR), (CURDATE() - INTERVAL 27 DAY + INTERVAL 9 HOUR)),
(85, 10, 'great', 2, (CURDATE() - INTERVAL 28 DAY), (CURDATE() - INTERVAL 28 DAY + INTERVAL 20 HOUR), (CURDATE() - INTERVAL 28 DAY + INTERVAL 21 HOUR)),
(86, 10, 'good', 4, (CURDATE() - INTERVAL 29 DAY), (CURDATE() - INTERVAL 29 DAY + INTERVAL 8 HOUR), (CURDATE() - INTERVAL 29 DAY + INTERVAL 17 HOUR)),
(87, 10, 'great', 2, (CURDATE() - INTERVAL 31 DAY), (CURDATE() - INTERVAL 31 DAY + INTERVAL 15 HOUR), (CURDATE() - INTERVAL 31 DAY + INTERVAL 11 HOUR)),
(88, 10, 'great', 1, (CURDATE() - INTERVAL 33 DAY), (CURDATE() - INTERVAL 33 DAY + INTERVAL 8 HOUR), (CURDATE() - INTERVAL 33 DAY + INTERVAL 9 HOUR)),
(89, 10, 'great', 3, (CURDATE() - INTERVAL 34 DAY), (CURDATE() - INTERVAL 34 DAY + INTERVAL 17 HOUR), (CURDATE() - INTERVAL 34 DAY + INTERVAL 9 HOUR)),
(90, 10, 'great', 3, (CURDATE() - INTERVAL 36 DAY), (CURDATE() - INTERVAL 36 DAY + INTERVAL 15 HOUR), (CURDATE() - INTERVAL 36 DAY + INTERVAL 9 HOUR)),
(91, 10, 'great', 1, (CURDATE() - INTERVAL 37 DAY), (CURDATE() - INTERVAL 37 DAY + INTERVAL 15 HOUR), (CURDATE() - INTERVAL 37 DAY + INTERVAL 18 HOUR)),
(92, 10, 'great', 3, (CURDATE() - INTERVAL 39 DAY), (CURDATE() - INTERVAL 39 DAY + INTERVAL 12 HOUR), (CURDATE() - INTERVAL 39 DAY + INTERVAL 12 HOUR)),
(93, 10, 'great', 2, (CURDATE() - INTERVAL 40 DAY), (CURDATE() - INTERVAL 40 DAY + INTERVAL 20 HOUR), (CURDATE() - INTERVAL 40 DAY + INTERVAL 11 HOUR)),
(94, 10, 'great', 2, (CURDATE() - INTERVAL 41 DAY), (CURDATE() - INTERVAL 41 DAY + INTERVAL 11 HOUR), (CURDATE() - INTERVAL 41 DAY + INTERVAL 20 HOUR)),
(95, 10, 'good', 3, (CURDATE() - INTERVAL 43 DAY), (CURDATE() - INTERVAL 43 DAY + INTERVAL 11 HOUR), (CURDATE() - INTERVAL 43 DAY + INTERVAL 10 HOUR)),
(96, 11, 'okay', 5, (CURDATE() - INTERVAL 0 DAY), (CURDATE() - INTERVAL 0 DAY + INTERVAL 9 HOUR), (CURDATE() - INTERVAL 0 DAY + INTERVAL 8 HOUR)),
(97, 11, 'good', 4, (CURDATE() - INTERVAL 2 DAY), (CURDATE() - INTERVAL 2 DAY + INTERVAL 15 HOUR), (CURDATE() - INTERVAL 2 DAY + INTERVAL 20 HOUR)),
(98, 11, 'okay', 4, (CURDATE() - INTERVAL 3 DAY), (CURDATE() - INTERVAL 3 DAY + INTERVAL 7 HOUR), (CURDATE() - INTERVAL 3 DAY + INTERVAL 14 HOUR)),
(99, 11, 'okay', 4, (CURDATE() - INTERVAL 4 DAY), (CURDATE() - INTERVAL 4 DAY + INTERVAL 15 HOUR), (CURDATE() - INTERVAL 4 DAY + INTERVAL 10 HOUR)),
(100, 11, 'okay', 5, (CURDATE() - INTERVAL 5 DAY), (CURDATE() - INTERVAL 5 DAY + INTERVAL 9 HOUR), (CURDATE() - INTERVAL 5 DAY + INTERVAL 15 HOUR)),
(101, 11, 'okay', 6, (CURDATE() - INTERVAL 6 DAY), (CURDATE() - INTERVAL 6 DAY + INTERVAL 13 HOUR), (CURDATE() - INTERVAL 6 DAY + INTERVAL 15 HOUR)),
(102, 11, 'good', 4, (CURDATE() - INTERVAL 7 DAY), (CURDATE() - INTERVAL 7 DAY + INTERVAL 18 HOUR), (CURDATE() - INTERVAL 7 DAY + INTERVAL 9 HOUR)),
(103, 11, 'okay', 4, (CURDATE() - INTERVAL 9 DAY), (CURDATE() - INTERVAL 9 DAY + INTERVAL 19 HOUR), (CURDATE() - INTERVAL 9 DAY + INTERVAL 17 HOUR)),
(104, 11, 'low', 6, (CURDATE() - INTERVAL 11 DAY), (CURDATE() - INTERVAL 11 DAY + INTERVAL 11 HOUR), (CURDATE() - INTERVAL 11 DAY + INTERVAL 15 HOUR)),
(105, 11, 'low', 7, (CURDATE() - INTERVAL 12 DAY), (CURDATE() - INTERVAL 12 DAY + INTERVAL 19 HOUR), (CURDATE() - INTERVAL 12 DAY + INTERVAL 9 HOUR)),
(106, 11, 'low', 6, (CURDATE() - INTERVAL 14 DAY), (CURDATE() - INTERVAL 14 DAY + INTERVAL 11 HOUR), (CURDATE() - INTERVAL 14 DAY + INTERVAL 10 HOUR)),
(107, 11, 'good', 4, (CURDATE() - INTERVAL 15 DAY), (CURDATE() - INTERVAL 15 DAY + INTERVAL 18 HOUR), (CURDATE() - INTERVAL 15 DAY + INTERVAL 13 HOUR)),
(108, 11, 'okay', 4, (CURDATE() - INTERVAL 16 DAY), (CURDATE() - INTERVAL 16 DAY + INTERVAL 14 HOUR), (CURDATE() - INTERVAL 16 DAY + INTERVAL 7 HOUR)),
(109, 11, 'low', 8, (CURDATE() - INTERVAL 17 DAY), (CURDATE() - INTERVAL 17 DAY + INTERVAL 20 HOUR), (CURDATE() - INTERVAL 17 DAY + INTERVAL 20 HOUR)),
(110, 11, 'good', 2, (CURDATE() - INTERVAL 18 DAY), (CURDATE() - INTERVAL 18 DAY + INTERVAL 20 HOUR), (CURDATE() - INTERVAL 18 DAY + INTERVAL 20 HOUR)),
(111, 11, 'good', 2, (CURDATE() - INTERVAL 19 DAY), (CURDATE() - INTERVAL 19 DAY + INTERVAL 10 HOUR), (CURDATE() - INTERVAL 19 DAY + INTERVAL 10 HOUR)),
(112, 11, 'okay', 5, (CURDATE() - INTERVAL 21 DAY), (CURDATE() - INTERVAL 21 DAY + INTERVAL 18 HOUR), (CURDATE() - INTERVAL 21 DAY + INTERVAL 13 HOUR)),
(113, 11, 'good', 3, (CURDATE() - INTERVAL 22 DAY), (CURDATE() - INTERVAL 22 DAY + INTERVAL 17 HOUR), (CURDATE() - INTERVAL 22 DAY + INTERVAL 18 HOUR)),
(114, 11, 'okay', 4, (CURDATE() - INTERVAL 23 DAY), (CURDATE() - INTERVAL 23 DAY + INTERVAL 21 HOUR), (CURDATE() - INTERVAL 23 DAY + INTERVAL 21 HOUR)),
(115, 11, 'okay', 5, (CURDATE() - INTERVAL 24 DAY), (CURDATE() - INTERVAL 24 DAY + INTERVAL 18 HOUR), (CURDATE() - INTERVAL 24 DAY + INTERVAL 17 HOUR)),
(116, 11, 'good', 4, (CURDATE() - INTERVAL 25 DAY), (CURDATE() - INTERVAL 25 DAY + INTERVAL 13 HOUR), (CURDATE() - INTERVAL 25 DAY + INTERVAL 10 HOUR)),
(117, 11, 'good', 4, (CURDATE() - INTERVAL 28 DAY), (CURDATE() - INTERVAL 28 DAY + INTERVAL 19 HOUR), (CURDATE() - INTERVAL 28 DAY + INTERVAL 11 HOUR)),
(118, 11, 'great', 3, (CURDATE() - INTERVAL 29 DAY), (CURDATE() - INTERVAL 29 DAY + INTERVAL 14 HOUR), (CURDATE() - INTERVAL 29 DAY + INTERVAL 21 HOUR)),
(119, 11, 'struggling', 8, (CURDATE() - INTERVAL 30 DAY), (CURDATE() - INTERVAL 30 DAY + INTERVAL 19 HOUR), (CURDATE() - INTERVAL 30 DAY + INTERVAL 9 HOUR)),
(120, 11, 'okay', 6, (CURDATE() - INTERVAL 33 DAY), (CURDATE() - INTERVAL 33 DAY + INTERVAL 17 HOUR), (CURDATE() - INTERVAL 33 DAY + INTERVAL 15 HOUR)),
(121, 11, 'okay', 5, (CURDATE() - INTERVAL 34 DAY), (CURDATE() - INTERVAL 34 DAY + INTERVAL 14 HOUR), (CURDATE() - INTERVAL 34 DAY + INTERVAL 12 HOUR)),
(122, 11, 'great', 3, (CURDATE() - INTERVAL 40 DAY), (CURDATE() - INTERVAL 40 DAY + INTERVAL 21 HOUR), (CURDATE() - INTERVAL 40 DAY + INTERVAL 14 HOUR)),
(123, 11, 'okay', 5, (CURDATE() - INTERVAL 42 DAY), (CURDATE() - INTERVAL 42 DAY + INTERVAL 16 HOUR), (CURDATE() - INTERVAL 42 DAY + INTERVAL 14 HOUR)),
(124, 11, 'great', 2, (CURDATE() - INTERVAL 44 DAY), (CURDATE() - INTERVAL 44 DAY + INTERVAL 8 HOUR), (CURDATE() - INTERVAL 44 DAY + INTERVAL 9 HOUR)),
(125, 11, 'okay', 4, (CURDATE() - INTERVAL 46 DAY), (CURDATE() - INTERVAL 46 DAY + INTERVAL 19 HOUR), (CURDATE() - INTERVAL 46 DAY + INTERVAL 16 HOUR)),
(126, 11, 'low', 6, (CURDATE() - INTERVAL 50 DAY), (CURDATE() - INTERVAL 50 DAY + INTERVAL 12 HOUR), (CURDATE() - INTERVAL 50 DAY + INTERVAL 18 HOUR)),
(127, 11, 'low', 7, (CURDATE() - INTERVAL 53 DAY), (CURDATE() - INTERVAL 53 DAY + INTERVAL 7 HOUR), (CURDATE() - INTERVAL 53 DAY + INTERVAL 14 HOUR)),
(128, 11, 'good', 2, (CURDATE() - INTERVAL 54 DAY), (CURDATE() - INTERVAL 54 DAY + INTERVAL 16 HOUR), (CURDATE() - INTERVAL 54 DAY + INTERVAL 14 HOUR)),
(129, 12, 'low', 7, (CURDATE() - INTERVAL 0 DAY), (CURDATE() - INTERVAL 0 DAY + INTERVAL 18 HOUR), (CURDATE() - INTERVAL 0 DAY + INTERVAL 7 HOUR)),
(130, 12, 'low', 8, (CURDATE() - INTERVAL 1 DAY), (CURDATE() - INTERVAL 1 DAY + INTERVAL 12 HOUR), (CURDATE() - INTERVAL 1 DAY + INTERVAL 11 HOUR)),
(131, 12, 'low', 7, (CURDATE() - INTERVAL 2 DAY), (CURDATE() - INTERVAL 2 DAY + INTERVAL 16 HOUR), (CURDATE() - INTERVAL 2 DAY + INTERVAL 20 HOUR)),
(132, 12, 'okay', 5, (CURDATE() - INTERVAL 3 DAY), (CURDATE() - INTERVAL 3 DAY + INTERVAL 19 HOUR), (CURDATE() - INTERVAL 3 DAY + INTERVAL 10 HOUR)),
(133, 12, 'okay', 4, (CURDATE() - INTERVAL 4 DAY), (CURDATE() - INTERVAL 4 DAY + INTERVAL 19 HOUR), (CURDATE() - INTERVAL 4 DAY + INTERVAL 8 HOUR)),
(134, 12, 'okay', 4, (CURDATE() - INTERVAL 5 DAY), (CURDATE() - INTERVAL 5 DAY + INTERVAL 10 HOUR), (CURDATE() - INTERVAL 5 DAY + INTERVAL 7 HOUR)),
(135, 12, 'okay', 5, (CURDATE() - INTERVAL 6 DAY), (CURDATE() - INTERVAL 6 DAY + INTERVAL 8 HOUR), (CURDATE() - INTERVAL 6 DAY + INTERVAL 11 HOUR)),
(136, 12, 'good', 4, (CURDATE() - INTERVAL 7 DAY), (CURDATE() - INTERVAL 7 DAY + INTERVAL 19 HOUR), (CURDATE() - INTERVAL 7 DAY + INTERVAL 18 HOUR)),
(137, 12, 'good', 2, (CURDATE() - INTERVAL 8 DAY), (CURDATE() - INTERVAL 8 DAY + INTERVAL 12 HOUR), (CURDATE() - INTERVAL 8 DAY + INTERVAL 21 HOUR)),
(138, 12, 'low', 7, (CURDATE() - INTERVAL 9 DAY), (CURDATE() - INTERVAL 9 DAY + INTERVAL 21 HOUR), (CURDATE() - INTERVAL 9 DAY + INTERVAL 21 HOUR)),
(139, 12, 'good', 3, (CURDATE() - INTERVAL 11 DAY), (CURDATE() - INTERVAL 11 DAY + INTERVAL 8 HOUR), (CURDATE() - INTERVAL 11 DAY + INTERVAL 9 HOUR)),
(140, 12, 'okay', 4, (CURDATE() - INTERVAL 13 DAY), (CURDATE() - INTERVAL 13 DAY + INTERVAL 14 HOUR), (CURDATE() - INTERVAL 13 DAY + INTERVAL 21 HOUR)),
(141, 12, 'okay', 4, (CURDATE() - INTERVAL 14 DAY), (CURDATE() - INTERVAL 14 DAY + INTERVAL 15 HOUR), (CURDATE() - INTERVAL 14 DAY + INTERVAL 17 HOUR)),
(142, 12, 'good', 2, (CURDATE() - INTERVAL 15 DAY), (CURDATE() - INTERVAL 15 DAY + INTERVAL 15 HOUR), (CURDATE() - INTERVAL 15 DAY + INTERVAL 12 HOUR)),
(143, 12, 'great', 1, (CURDATE() - INTERVAL 16 DAY), (CURDATE() - INTERVAL 16 DAY + INTERVAL 7 HOUR), (CURDATE() - INTERVAL 16 DAY + INTERVAL 13 HOUR)),
(144, 12, 'okay', 4, (CURDATE() - INTERVAL 17 DAY), (CURDATE() - INTERVAL 17 DAY + INTERVAL 9 HOUR), (CURDATE() - INTERVAL 17 DAY + INTERVAL 10 HOUR)),
(145, 12, 'okay', 5, (CURDATE() - INTERVAL 18 DAY), (CURDATE() - INTERVAL 18 DAY + INTERVAL 11 HOUR), (CURDATE() - INTERVAL 18 DAY + INTERVAL 17 HOUR)),
(146, 12, 'great', 1, (CURDATE() - INTERVAL 20 DAY), (CURDATE() - INTERVAL 20 DAY + INTERVAL 16 HOUR), (CURDATE() - INTERVAL 20 DAY + INTERVAL 20 HOUR)),
(147, 12, 'okay', 6, (CURDATE() - INTERVAL 21 DAY), (CURDATE() - INTERVAL 21 DAY + INTERVAL 9 HOUR), (CURDATE() - INTERVAL 21 DAY + INTERVAL 17 HOUR)),
(148, 12, 'great', 2, (CURDATE() - INTERVAL 23 DAY), (CURDATE() - INTERVAL 23 DAY + INTERVAL 8 HOUR), (CURDATE() - INTERVAL 23 DAY + INTERVAL 18 HOUR)),
(149, 12, 'good', 4, (CURDATE() - INTERVAL 24 DAY), (CURDATE() - INTERVAL 24 DAY + INTERVAL 12 HOUR), (CURDATE() - INTERVAL 24 DAY + INTERVAL 8 HOUR)),
(150, 12, 'good', 3, (CURDATE() - INTERVAL 26 DAY), (CURDATE() - INTERVAL 26 DAY + INTERVAL 21 HOUR), (CURDATE() - INTERVAL 26 DAY + INTERVAL 10 HOUR)),
(151, 12, 'low', 6, (CURDATE() - INTERVAL 28 DAY), (CURDATE() - INTERVAL 28 DAY + INTERVAL 11 HOUR), (CURDATE() - INTERVAL 28 DAY + INTERVAL 18 HOUR)),
(152, 12, 'good', 4, (CURDATE() - INTERVAL 29 DAY), (CURDATE() - INTERVAL 29 DAY + INTERVAL 9 HOUR), (CURDATE() - INTERVAL 29 DAY + INTERVAL 18 HOUR)),
(153, 12, 'okay', 4, (CURDATE() - INTERVAL 30 DAY), (CURDATE() - INTERVAL 30 DAY + INTERVAL 16 HOUR), (CURDATE() - INTERVAL 30 DAY + INTERVAL 15 HOUR)),
(154, 12, 'great', 3, (CURDATE() - INTERVAL 32 DAY), (CURDATE() - INTERVAL 32 DAY + INTERVAL 11 HOUR), (CURDATE() - INTERVAL 32 DAY + INTERVAL 9 HOUR)),
(155, 12, 'good', 3, (CURDATE() - INTERVAL 33 DAY), (CURDATE() - INTERVAL 33 DAY + INTERVAL 9 HOUR), (CURDATE() - INTERVAL 33 DAY + INTERVAL 13 HOUR)),
(156, 12, 'great', 2, (CURDATE() - INTERVAL 35 DAY), (CURDATE() - INTERVAL 35 DAY + INTERVAL 14 HOUR), (CURDATE() - INTERVAL 35 DAY + INTERVAL 19 HOUR)),
(157, 12, 'good', 3, (CURDATE() - INTERVAL 36 DAY), (CURDATE() - INTERVAL 36 DAY + INTERVAL 18 HOUR), (CURDATE() - INTERVAL 36 DAY + INTERVAL 20 HOUR)),
(158, 12, 'okay', 5, (CURDATE() - INTERVAL 37 DAY), (CURDATE() - INTERVAL 37 DAY + INTERVAL 11 HOUR), (CURDATE() - INTERVAL 37 DAY + INTERVAL 20 HOUR)),
(159, 12, 'okay', 4, (CURDATE() - INTERVAL 38 DAY), (CURDATE() - INTERVAL 38 DAY + INTERVAL 10 HOUR), (CURDATE() - INTERVAL 38 DAY + INTERVAL 10 HOUR)),
(160, 12, 'low', 6, (CURDATE() - INTERVAL 40 DAY), (CURDATE() - INTERVAL 40 DAY + INTERVAL 20 HOUR), (CURDATE() - INTERVAL 40 DAY + INTERVAL 18 HOUR)),
(161, 12, 'good', 4, (CURDATE() - INTERVAL 42 DAY), (CURDATE() - INTERVAL 42 DAY + INTERVAL 12 HOUR), (CURDATE() - INTERVAL 42 DAY + INTERVAL 17 HOUR)),
(162, 12, 'low', 8, (CURDATE() - INTERVAL 44 DAY), (CURDATE() - INTERVAL 44 DAY + INTERVAL 13 HOUR), (CURDATE() - INTERVAL 44 DAY + INTERVAL 18 HOUR)),
(163, 12, 'good', 2, (CURDATE() - INTERVAL 45 DAY), (CURDATE() - INTERVAL 45 DAY + INTERVAL 15 HOUR), (CURDATE() - INTERVAL 45 DAY + INTERVAL 11 HOUR)),
(164, 12, 'great', 1, (CURDATE() - INTERVAL 46 DAY), (CURDATE() - INTERVAL 46 DAY + INTERVAL 20 HOUR), (CURDATE() - INTERVAL 46 DAY + INTERVAL 13 HOUR)),
(165, 12, 'okay', 6, (CURDATE() - INTERVAL 48 DAY), (CURDATE() - INTERVAL 48 DAY + INTERVAL 7 HOUR), (CURDATE() - INTERVAL 48 DAY + INTERVAL 16 HOUR)),
(166, 12, 'good', 3, (CURDATE() - INTERVAL 49 DAY), (CURDATE() - INTERVAL 49 DAY + INTERVAL 15 HOUR), (CURDATE() - INTERVAL 49 DAY + INTERVAL 11 HOUR)),
(167, 12, 'okay', 6, (CURDATE() - INTERVAL 51 DAY), (CURDATE() - INTERVAL 51 DAY + INTERVAL 11 HOUR), (CURDATE() - INTERVAL 51 DAY + INTERVAL 19 HOUR)),
(168, 13, 'good', 3, (CURDATE() - INTERVAL 0 DAY), (CURDATE() - INTERVAL 0 DAY + INTERVAL 15 HOUR), (CURDATE() - INTERVAL 0 DAY + INTERVAL 13 HOUR)),
(169, 13, 'okay', 4, (CURDATE() - INTERVAL 1 DAY), (CURDATE() - INTERVAL 1 DAY + INTERVAL 15 HOUR), (CURDATE() - INTERVAL 1 DAY + INTERVAL 16 HOUR)),
(170, 13, 'okay', 4, (CURDATE() - INTERVAL 2 DAY), (CURDATE() - INTERVAL 2 DAY + INTERVAL 8 HOUR), (CURDATE() - INTERVAL 2 DAY + INTERVAL 10 HOUR)),
(171, 13, 'okay', 4, (CURDATE() - INTERVAL 3 DAY), (CURDATE() - INTERVAL 3 DAY + INTERVAL 13 HOUR), (CURDATE() - INTERVAL 3 DAY + INTERVAL 15 HOUR)),
(172, 13, 'good', 2, (CURDATE() - INTERVAL 4 DAY), (CURDATE() - INTERVAL 4 DAY + INTERVAL 8 HOUR), (CURDATE() - INTERVAL 4 DAY + INTERVAL 10 HOUR)),
(173, 13, 'okay', 6, (CURDATE() - INTERVAL 5 DAY), (CURDATE() - INTERVAL 5 DAY + INTERVAL 21 HOUR), (CURDATE() - INTERVAL 5 DAY + INTERVAL 17 HOUR)),
(174, 13, 'okay', 4, (CURDATE() - INTERVAL 6 DAY), (CURDATE() - INTERVAL 6 DAY + INTERVAL 8 HOUR), (CURDATE() - INTERVAL 6 DAY + INTERVAL 21 HOUR)),
(175, 13, 'good', 4, (CURDATE() - INTERVAL 7 DAY), (CURDATE() - INTERVAL 7 DAY + INTERVAL 13 HOUR), (CURDATE() - INTERVAL 7 DAY + INTERVAL 8 HOUR)),
(176, 13, 'good', 4, (CURDATE() - INTERVAL 8 DAY), (CURDATE() - INTERVAL 8 DAY + INTERVAL 20 HOUR), (CURDATE() - INTERVAL 8 DAY + INTERVAL 14 HOUR)),
(177, 13, 'good', 2, (CURDATE() - INTERVAL 9 DAY), (CURDATE() - INTERVAL 9 DAY + INTERVAL 9 HOUR), (CURDATE() - INTERVAL 9 DAY + INTERVAL 14 HOUR)),
(178, 13, 'good', 4, (CURDATE() - INTERVAL 10 DAY), (CURDATE() - INTERVAL 10 DAY + INTERVAL 19 HOUR), (CURDATE() - INTERVAL 10 DAY + INTERVAL 13 HOUR)),
(179, 13, 'okay', 4, (CURDATE() - INTERVAL 12 DAY), (CURDATE() - INTERVAL 12 DAY + INTERVAL 14 HOUR), (CURDATE() - INTERVAL 12 DAY + INTERVAL 14 HOUR)),
(180, 13, 'okay', 4, (CURDATE() - INTERVAL 13 DAY), (CURDATE() - INTERVAL 13 DAY + INTERVAL 13 HOUR), (CURDATE() - INTERVAL 13 DAY + INTERVAL 9 HOUR)),
(181, 13, 'okay', 6, (CURDATE() - INTERVAL 14 DAY), (CURDATE() - INTERVAL 14 DAY + INTERVAL 10 HOUR), (CURDATE() - INTERVAL 14 DAY + INTERVAL 13 HOUR)),
(182, 13, 'great', 1, (CURDATE() - INTERVAL 15 DAY), (CURDATE() - INTERVAL 15 DAY + INTERVAL 16 HOUR), (CURDATE() - INTERVAL 15 DAY + INTERVAL 16 HOUR)),
(183, 13, 'okay', 6, (CURDATE() - INTERVAL 17 DAY), (CURDATE() - INTERVAL 17 DAY + INTERVAL 10 HOUR), (CURDATE() - INTERVAL 17 DAY + INTERVAL 12 HOUR)),
(184, 13, 'good', 4, (CURDATE() - INTERVAL 19 DAY), (CURDATE() - INTERVAL 19 DAY + INTERVAL 11 HOUR), (CURDATE() - INTERVAL 19 DAY + INTERVAL 12 HOUR)),
(185, 13, 'okay', 4, (CURDATE() - INTERVAL 20 DAY), (CURDATE() - INTERVAL 20 DAY + INTERVAL 18 HOUR), (CURDATE() - INTERVAL 20 DAY + INTERVAL 20 HOUR)),
(186, 13, 'okay', 4, (CURDATE() - INTERVAL 21 DAY), (CURDATE() - INTERVAL 21 DAY + INTERVAL 15 HOUR), (CURDATE() - INTERVAL 21 DAY + INTERVAL 16 HOUR)),
(187, 13, 'okay', 5, (CURDATE() - INTERVAL 22 DAY), (CURDATE() - INTERVAL 22 DAY + INTERVAL 10 HOUR), (CURDATE() - INTERVAL 22 DAY + INTERVAL 18 HOUR)),
(188, 13, 'okay', 5, (CURDATE() - INTERVAL 25 DAY), (CURDATE() - INTERVAL 25 DAY + INTERVAL 11 HOUR), (CURDATE() - INTERVAL 25 DAY + INTERVAL 8 HOUR)),
(189, 13, 'okay', 5, (CURDATE() - INTERVAL 27 DAY), (CURDATE() - INTERVAL 27 DAY + INTERVAL 18 HOUR), (CURDATE() - INTERVAL 27 DAY + INTERVAL 12 HOUR)),
(190, 13, 'okay', 6, (CURDATE() - INTERVAL 30 DAY), (CURDATE() - INTERVAL 30 DAY + INTERVAL 14 HOUR), (CURDATE() - INTERVAL 30 DAY + INTERVAL 16 HOUR)),
(191, 13, 'okay', 5, (CURDATE() - INTERVAL 31 DAY), (CURDATE() - INTERVAL 31 DAY + INTERVAL 19 HOUR), (CURDATE() - INTERVAL 31 DAY + INTERVAL 17 HOUR)),
(192, 13, 'okay', 4, (CURDATE() - INTERVAL 32 DAY), (CURDATE() - INTERVAL 32 DAY + INTERVAL 19 HOUR), (CURDATE() - INTERVAL 32 DAY + INTERVAL 12 HOUR)),
(193, 13, 'good', 3, (CURDATE() - INTERVAL 33 DAY), (CURDATE() - INTERVAL 33 DAY + INTERVAL 7 HOUR), (CURDATE() - INTERVAL 33 DAY + INTERVAL 12 HOUR)),
(194, 13, 'great', 3, (CURDATE() - INTERVAL 34 DAY), (CURDATE() - INTERVAL 34 DAY + INTERVAL 11 HOUR), (CURDATE() - INTERVAL 34 DAY + INTERVAL 15 HOUR)),
(195, 13, 'good', 3, (CURDATE() - INTERVAL 37 DAY), (CURDATE() - INTERVAL 37 DAY + INTERVAL 21 HOUR), (CURDATE() - INTERVAL 37 DAY + INTERVAL 20 HOUR)),
(196, 13, 'good', 2, (CURDATE() - INTERVAL 39 DAY), (CURDATE() - INTERVAL 39 DAY + INTERVAL 9 HOUR), (CURDATE() - INTERVAL 39 DAY + INTERVAL 7 HOUR)),
(197, 13, 'okay', 6, (CURDATE() - INTERVAL 44 DAY), (CURDATE() - INTERVAL 44 DAY + INTERVAL 7 HOUR), (CURDATE() - INTERVAL 44 DAY + INTERVAL 11 HOUR)),
(198, 13, 'good', 4, (CURDATE() - INTERVAL 45 DAY), (CURDATE() - INTERVAL 45 DAY + INTERVAL 8 HOUR), (CURDATE() - INTERVAL 45 DAY + INTERVAL 21 HOUR)),
(199, 13, 'struggling', 10, (CURDATE() - INTERVAL 46 DAY), (CURDATE() - INTERVAL 46 DAY + INTERVAL 18 HOUR), (CURDATE() - INTERVAL 46 DAY + INTERVAL 13 HOUR)),
(200, 13, 'low', 8, (CURDATE() - INTERVAL 47 DAY), (CURDATE() - INTERVAL 47 DAY + INTERVAL 7 HOUR), (CURDATE() - INTERVAL 47 DAY + INTERVAL 19 HOUR)),
(201, 13, 'okay', 5, (CURDATE() - INTERVAL 49 DAY), (CURDATE() - INTERVAL 49 DAY + INTERVAL 10 HOUR), (CURDATE() - INTERVAL 49 DAY + INTERVAL 21 HOUR)),
(202, 13, 'good', 4, (CURDATE() - INTERVAL 50 DAY), (CURDATE() - INTERVAL 50 DAY + INTERVAL 9 HOUR), (CURDATE() - INTERVAL 50 DAY + INTERVAL 16 HOUR)),
(203, 13, 'okay', 6, (CURDATE() - INTERVAL 51 DAY), (CURDATE() - INTERVAL 51 DAY + INTERVAL 13 HOUR), (CURDATE() - INTERVAL 51 DAY + INTERVAL 20 HOUR)),
(204, 13, 'good', 2, (CURDATE() - INTERVAL 52 DAY), (CURDATE() - INTERVAL 52 DAY + INTERVAL 11 HOUR), (CURDATE() - INTERVAL 52 DAY + INTERVAL 19 HOUR)),
(205, 13, 'okay', 6, (CURDATE() - INTERVAL 55 DAY), (CURDATE() - INTERVAL 55 DAY + INTERVAL 16 HOUR), (CURDATE() - INTERVAL 55 DAY + INTERVAL 9 HOUR)),
(206, 14, 'okay', 5, (CURDATE() - INTERVAL 0 DAY), (CURDATE() - INTERVAL 0 DAY + INTERVAL 7 HOUR), (CURDATE() - INTERVAL 0 DAY + INTERVAL 21 HOUR)),
(207, 14, 'great', 2, (CURDATE() - INTERVAL 1 DAY), (CURDATE() - INTERVAL 1 DAY + INTERVAL 8 HOUR), (CURDATE() - INTERVAL 1 DAY + INTERVAL 20 HOUR)),
(208, 14, 'good', 2, (CURDATE() - INTERVAL 3 DAY), (CURDATE() - INTERVAL 3 DAY + INTERVAL 10 HOUR), (CURDATE() - INTERVAL 3 DAY + INTERVAL 12 HOUR)),
(209, 14, 'good', 4, (CURDATE() - INTERVAL 4 DAY), (CURDATE() - INTERVAL 4 DAY + INTERVAL 8 HOUR), (CURDATE() - INTERVAL 4 DAY + INTERVAL 18 HOUR)),
(210, 14, 'okay', 4, (CURDATE() - INTERVAL 5 DAY), (CURDATE() - INTERVAL 5 DAY + INTERVAL 9 HOUR), (CURDATE() - INTERVAL 5 DAY + INTERVAL 9 HOUR)),
(211, 14, 'great', 2, (CURDATE() - INTERVAL 6 DAY), (CURDATE() - INTERVAL 6 DAY + INTERVAL 16 HOUR), (CURDATE() - INTERVAL 6 DAY + INTERVAL 17 HOUR)),
(212, 14, 'okay', 5, (CURDATE() - INTERVAL 7 DAY), (CURDATE() - INTERVAL 7 DAY + INTERVAL 14 HOUR), (CURDATE() - INTERVAL 7 DAY + INTERVAL 8 HOUR)),
(213, 14, 'good', 4, (CURDATE() - INTERVAL 9 DAY), (CURDATE() - INTERVAL 9 DAY + INTERVAL 7 HOUR), (CURDATE() - INTERVAL 9 DAY + INTERVAL 15 HOUR)),
(214, 14, 'okay', 5, (CURDATE() - INTERVAL 10 DAY), (CURDATE() - INTERVAL 10 DAY + INTERVAL 17 HOUR), (CURDATE() - INTERVAL 10 DAY + INTERVAL 21 HOUR)),
(215, 14, 'good', 3, (CURDATE() - INTERVAL 11 DAY), (CURDATE() - INTERVAL 11 DAY + INTERVAL 21 HOUR), (CURDATE() - INTERVAL 11 DAY + INTERVAL 19 HOUR)),
(216, 14, 'low', 7, (CURDATE() - INTERVAL 14 DAY), (CURDATE() - INTERVAL 14 DAY + INTERVAL 8 HOUR), (CURDATE() - INTERVAL 14 DAY + INTERVAL 14 HOUR)),
(217, 14, 'low', 8, (CURDATE() - INTERVAL 15 DAY), (CURDATE() - INTERVAL 15 DAY + INTERVAL 21 HOUR), (CURDATE() - INTERVAL 15 DAY + INTERVAL 20 HOUR)),
(218, 14, 'okay', 4, (CURDATE() - INTERVAL 16 DAY), (CURDATE() - INTERVAL 16 DAY + INTERVAL 21 HOUR), (CURDATE() - INTERVAL 16 DAY + INTERVAL 10 HOUR)),
(219, 14, 'good', 4, (CURDATE() - INTERVAL 19 DAY), (CURDATE() - INTERVAL 19 DAY + INTERVAL 20 HOUR), (CURDATE() - INTERVAL 19 DAY + INTERVAL 12 HOUR)),
(220, 14, 'good', 3, (CURDATE() - INTERVAL 20 DAY), (CURDATE() - INTERVAL 20 DAY + INTERVAL 17 HOUR), (CURDATE() - INTERVAL 20 DAY + INTERVAL 12 HOUR)),
(221, 14, 'great', 3, (CURDATE() - INTERVAL 21 DAY), (CURDATE() - INTERVAL 21 DAY + INTERVAL 16 HOUR), (CURDATE() - INTERVAL 21 DAY + INTERVAL 18 HOUR)),
(222, 14, 'good', 2, (CURDATE() - INTERVAL 22 DAY), (CURDATE() - INTERVAL 22 DAY + INTERVAL 17 HOUR), (CURDATE() - INTERVAL 22 DAY + INTERVAL 17 HOUR)),
(223, 14, 'good', 3, (CURDATE() - INTERVAL 23 DAY), (CURDATE() - INTERVAL 23 DAY + INTERVAL 15 HOUR), (CURDATE() - INTERVAL 23 DAY + INTERVAL 17 HOUR)),
(224, 14, 'good', 2, (CURDATE() - INTERVAL 24 DAY), (CURDATE() - INTERVAL 24 DAY + INTERVAL 17 HOUR), (CURDATE() - INTERVAL 24 DAY + INTERVAL 17 HOUR)),
(225, 14, 'great', 3, (CURDATE() - INTERVAL 27 DAY), (CURDATE() - INTERVAL 27 DAY + INTERVAL 7 HOUR), (CURDATE() - INTERVAL 27 DAY + INTERVAL 14 HOUR)),
(226, 14, 'good', 4, (CURDATE() - INTERVAL 28 DAY), (CURDATE() - INTERVAL 28 DAY + INTERVAL 21 HOUR), (CURDATE() - INTERVAL 28 DAY + INTERVAL 17 HOUR)),
(227, 14, 'good', 2, (CURDATE() - INTERVAL 31 DAY), (CURDATE() - INTERVAL 31 DAY + INTERVAL 11 HOUR), (CURDATE() - INTERVAL 31 DAY + INTERVAL 10 HOUR)),
(228, 14, 'great', 3, (CURDATE() - INTERVAL 32 DAY), (CURDATE() - INTERVAL 32 DAY + INTERVAL 15 HOUR), (CURDATE() - INTERVAL 32 DAY + INTERVAL 14 HOUR)),
(229, 14, 'okay', 6, (CURDATE() - INTERVAL 33 DAY), (CURDATE() - INTERVAL 33 DAY + INTERVAL 9 HOUR), (CURDATE() - INTERVAL 33 DAY + INTERVAL 20 HOUR)),
(230, 14, 'great', 2, (CURDATE() - INTERVAL 34 DAY), (CURDATE() - INTERVAL 34 DAY + INTERVAL 11 HOUR), (CURDATE() - INTERVAL 34 DAY + INTERVAL 13 HOUR)),
(231, 14, 'okay', 4, (CURDATE() - INTERVAL 37 DAY), (CURDATE() - INTERVAL 37 DAY + INTERVAL 16 HOUR), (CURDATE() - INTERVAL 37 DAY + INTERVAL 15 HOUR)),
(232, 14, 'low', 6, (CURDATE() - INTERVAL 41 DAY), (CURDATE() - INTERVAL 41 DAY + INTERVAL 18 HOUR), (CURDATE() - INTERVAL 41 DAY + INTERVAL 21 HOUR)),
(233, 14, 'great', 2, (CURDATE() - INTERVAL 44 DAY), (CURDATE() - INTERVAL 44 DAY + INTERVAL 9 HOUR), (CURDATE() - INTERVAL 44 DAY + INTERVAL 8 HOUR)),
(234, 14, 'okay', 5, (CURDATE() - INTERVAL 45 DAY), (CURDATE() - INTERVAL 45 DAY + INTERVAL 16 HOUR), (CURDATE() - INTERVAL 45 DAY + INTERVAL 13 HOUR)),
(235, 14, 'okay', 6, (CURDATE() - INTERVAL 46 DAY), (CURDATE() - INTERVAL 46 DAY + INTERVAL 21 HOUR), (CURDATE() - INTERVAL 46 DAY + INTERVAL 20 HOUR)),
(236, 14, 'great', 2, (CURDATE() - INTERVAL 47 DAY), (CURDATE() - INTERVAL 47 DAY + INTERVAL 12 HOUR), (CURDATE() - INTERVAL 47 DAY + INTERVAL 18 HOUR)),
(237, 14, 'good', 2, (CURDATE() - INTERVAL 53 DAY), (CURDATE() - INTERVAL 53 DAY + INTERVAL 18 HOUR), (CURDATE() - INTERVAL 53 DAY + INTERVAL 7 HOUR)),
(238, 14, 'okay', 5, (CURDATE() - INTERVAL 55 DAY), (CURDATE() - INTERVAL 55 DAY + INTERVAL 10 HOUR), (CURDATE() - INTERVAL 55 DAY + INTERVAL 11 HOUR)),
(239, 15, 'low', 6, (CURDATE() - INTERVAL 0 DAY), (CURDATE() - INTERVAL 0 DAY + INTERVAL 16 HOUR), (CURDATE() - INTERVAL 0 DAY + INTERVAL 21 HOUR)),
(240, 15, 'low', 8, (CURDATE() - INTERVAL 1 DAY), (CURDATE() - INTERVAL 1 DAY + INTERVAL 19 HOUR), (CURDATE() - INTERVAL 1 DAY + INTERVAL 18 HOUR)),
(241, 15, 'low', 7, (CURDATE() - INTERVAL 2 DAY), (CURDATE() - INTERVAL 2 DAY + INTERVAL 19 HOUR), (CURDATE() - INTERVAL 2 DAY + INTERVAL 11 HOUR)),
(242, 15, 'okay', 6, (CURDATE() - INTERVAL 3 DAY), (CURDATE() - INTERVAL 3 DAY + INTERVAL 12 HOUR), (CURDATE() - INTERVAL 3 DAY + INTERVAL 13 HOUR)),
(243, 15, 'okay', 4, (CURDATE() - INTERVAL 4 DAY), (CURDATE() - INTERVAL 4 DAY + INTERVAL 8 HOUR), (CURDATE() - INTERVAL 4 DAY + INTERVAL 7 HOUR)),
(244, 15, 'good', 3, (CURDATE() - INTERVAL 5 DAY), (CURDATE() - INTERVAL 5 DAY + INTERVAL 17 HOUR), (CURDATE() - INTERVAL 5 DAY + INTERVAL 9 HOUR)),
(245, 15, 'okay', 6, (CURDATE() - INTERVAL 6 DAY), (CURDATE() - INTERVAL 6 DAY + INTERVAL 8 HOUR), (CURDATE() - INTERVAL 6 DAY + INTERVAL 14 HOUR)),
(246, 15, 'low', 7, (CURDATE() - INTERVAL 8 DAY), (CURDATE() - INTERVAL 8 DAY + INTERVAL 10 HOUR), (CURDATE() - INTERVAL 8 DAY + INTERVAL 7 HOUR)),
(247, 15, 'great', 3, (CURDATE() - INTERVAL 9 DAY), (CURDATE() - INTERVAL 9 DAY + INTERVAL 15 HOUR), (CURDATE() - INTERVAL 9 DAY + INTERVAL 14 HOUR)),
(248, 15, 'okay', 5, (CURDATE() - INTERVAL 10 DAY), (CURDATE() - INTERVAL 10 DAY + INTERVAL 18 HOUR), (CURDATE() - INTERVAL 10 DAY + INTERVAL 13 HOUR)),
(249, 15, 'great', 1, (CURDATE() - INTERVAL 13 DAY), (CURDATE() - INTERVAL 13 DAY + INTERVAL 9 HOUR), (CURDATE() - INTERVAL 13 DAY + INTERVAL 7 HOUR)),
(250, 15, 'great', 2, (CURDATE() - INTERVAL 14 DAY), (CURDATE() - INTERVAL 14 DAY + INTERVAL 7 HOUR), (CURDATE() - INTERVAL 14 DAY + INTERVAL 17 HOUR)),
(251, 15, 'good', 3, (CURDATE() - INTERVAL 15 DAY), (CURDATE() - INTERVAL 15 DAY + INTERVAL 10 HOUR), (CURDATE() - INTERVAL 15 DAY + INTERVAL 19 HOUR)),
(252, 15, 'good', 2, (CURDATE() - INTERVAL 16 DAY), (CURDATE() - INTERVAL 16 DAY + INTERVAL 12 HOUR), (CURDATE() - INTERVAL 16 DAY + INTERVAL 21 HOUR)),
(253, 15, 'good', 2, (CURDATE() - INTERVAL 17 DAY), (CURDATE() - INTERVAL 17 DAY + INTERVAL 8 HOUR), (CURDATE() - INTERVAL 17 DAY + INTERVAL 21 HOUR)),
(254, 15, 'okay', 4, (CURDATE() - INTERVAL 19 DAY), (CURDATE() - INTERVAL 19 DAY + INTERVAL 19 HOUR), (CURDATE() - INTERVAL 19 DAY + INTERVAL 16 HOUR)),
(255, 15, 'good', 3, (CURDATE() - INTERVAL 21 DAY), (CURDATE() - INTERVAL 21 DAY + INTERVAL 16 HOUR), (CURDATE() - INTERVAL 21 DAY + INTERVAL 18 HOUR)),
(256, 15, 'great', 3, (CURDATE() - INTERVAL 22 DAY), (CURDATE() - INTERVAL 22 DAY + INTERVAL 20 HOUR), (CURDATE() - INTERVAL 22 DAY + INTERVAL 15 HOUR)),
(257, 15, 'great', 2, (CURDATE() - INTERVAL 23 DAY), (CURDATE() - INTERVAL 23 DAY + INTERVAL 7 HOUR), (CURDATE() - INTERVAL 23 DAY + INTERVAL 20 HOUR)),
(258, 15, 'okay', 6, (CURDATE() - INTERVAL 24 DAY), (CURDATE() - INTERVAL 24 DAY + INTERVAL 13 HOUR), (CURDATE() - INTERVAL 24 DAY + INTERVAL 8 HOUR)),
(259, 15, 'great', 3, (CURDATE() - INTERVAL 25 DAY), (CURDATE() - INTERVAL 25 DAY + INTERVAL 20 HOUR), (CURDATE() - INTERVAL 25 DAY + INTERVAL 21 HOUR)),
(260, 15, 'good', 3, (CURDATE() - INTERVAL 26 DAY), (CURDATE() - INTERVAL 26 DAY + INTERVAL 21 HOUR), (CURDATE() - INTERVAL 26 DAY + INTERVAL 7 HOUR)),
(261, 15, 'good', 3, (CURDATE() - INTERVAL 28 DAY), (CURDATE() - INTERVAL 28 DAY + INTERVAL 7 HOUR), (CURDATE() - INTERVAL 28 DAY + INTERVAL 13 HOUR)),
(262, 15, 'okay', 4, (CURDATE() - INTERVAL 29 DAY), (CURDATE() - INTERVAL 29 DAY + INTERVAL 13 HOUR), (CURDATE() - INTERVAL 29 DAY + INTERVAL 14 HOUR)),
(263, 15, 'great', 2, (CURDATE() - INTERVAL 30 DAY), (CURDATE() - INTERVAL 30 DAY + INTERVAL 16 HOUR), (CURDATE() - INTERVAL 30 DAY + INTERVAL 14 HOUR)),
(264, 15, 'great', 2, (CURDATE() - INTERVAL 31 DAY), (CURDATE() - INTERVAL 31 DAY + INTERVAL 8 HOUR), (CURDATE() - INTERVAL 31 DAY + INTERVAL 14 HOUR)),
(265, 15, 'low', 7, (CURDATE() - INTERVAL 36 DAY), (CURDATE() - INTERVAL 36 DAY + INTERVAL 13 HOUR), (CURDATE() - INTERVAL 36 DAY + INTERVAL 19 HOUR)),
(266, 15, 'good', 4, (CURDATE() - INTERVAL 37 DAY), (CURDATE() - INTERVAL 37 DAY + INTERVAL 20 HOUR), (CURDATE() - INTERVAL 37 DAY + INTERVAL 16 HOUR)),
(267, 15, 'okay', 4, (CURDATE() - INTERVAL 39 DAY), (CURDATE() - INTERVAL 39 DAY + INTERVAL 18 HOUR), (CURDATE() - INTERVAL 39 DAY + INTERVAL 18 HOUR)),
(268, 15, 'great', 2, (CURDATE() - INTERVAL 40 DAY), (CURDATE() - INTERVAL 40 DAY + INTERVAL 9 HOUR), (CURDATE() - INTERVAL 40 DAY + INTERVAL 13 HOUR)),
(269, 15, 'good', 2, (CURDATE() - INTERVAL 41 DAY), (CURDATE() - INTERVAL 41 DAY + INTERVAL 19 HOUR), (CURDATE() - INTERVAL 41 DAY + INTERVAL 21 HOUR)),
(270, 15, 'low', 6, (CURDATE() - INTERVAL 45 DAY), (CURDATE() - INTERVAL 45 DAY + INTERVAL 15 HOUR), (CURDATE() - INTERVAL 45 DAY + INTERVAL 15 HOUR)),
(271, 15, 'great', 3, (CURDATE() - INTERVAL 48 DAY), (CURDATE() - INTERVAL 48 DAY + INTERVAL 7 HOUR), (CURDATE() - INTERVAL 48 DAY + INTERVAL 20 HOUR)),
(272, 15, 'okay', 5, (CURDATE() - INTERVAL 49 DAY), (CURDATE() - INTERVAL 49 DAY + INTERVAL 20 HOUR), (CURDATE() - INTERVAL 49 DAY + INTERVAL 9 HOUR)),
(273, 15, 'okay', 6, (CURDATE() - INTERVAL 50 DAY), (CURDATE() - INTERVAL 50 DAY + INTERVAL 10 HOUR), (CURDATE() - INTERVAL 50 DAY + INTERVAL 17 HOUR)),
(274, 15, 'okay', 5, (CURDATE() - INTERVAL 51 DAY), (CURDATE() - INTERVAL 51 DAY + INTERVAL 13 HOUR), (CURDATE() - INTERVAL 51 DAY + INTERVAL 18 HOUR)),
(275, 15, 'great', 3, (CURDATE() - INTERVAL 52 DAY), (CURDATE() - INTERVAL 52 DAY + INTERVAL 13 HOUR), (CURDATE() - INTERVAL 52 DAY + INTERVAL 17 HOUR)),
(276, 15, 'good', 3, (CURDATE() - INTERVAL 53 DAY), (CURDATE() - INTERVAL 53 DAY + INTERVAL 13 HOUR), (CURDATE() - INTERVAL 53 DAY + INTERVAL 7 HOUR)),
(277, 15, 'great', 3, (CURDATE() - INTERVAL 54 DAY), (CURDATE() - INTERVAL 54 DAY + INTERVAL 13 HOUR), (CURDATE() - INTERVAL 54 DAY + INTERVAL 19 HOUR)),
(278, 16, 'struggling', 8, (CURDATE() - INTERVAL 0 DAY), (CURDATE() - INTERVAL 0 DAY + INTERVAL 9 HOUR), (CURDATE() - INTERVAL 0 DAY + INTERVAL 14 HOUR)),
(279, 16, 'struggling', 9, (CURDATE() - INTERVAL 1 DAY), (CURDATE() - INTERVAL 1 DAY + INTERVAL 7 HOUR), (CURDATE() - INTERVAL 1 DAY + INTERVAL 8 HOUR)),
(280, 16, 'okay', 4, (CURDATE() - INTERVAL 2 DAY), (CURDATE() - INTERVAL 2 DAY + INTERVAL 18 HOUR), (CURDATE() - INTERVAL 2 DAY + INTERVAL 18 HOUR)),
(281, 16, 'okay', 5, (CURDATE() - INTERVAL 4 DAY), (CURDATE() - INTERVAL 4 DAY + INTERVAL 8 HOUR), (CURDATE() - INTERVAL 4 DAY + INTERVAL 18 HOUR)),
(282, 16, 'okay', 6, (CURDATE() - INTERVAL 5 DAY), (CURDATE() - INTERVAL 5 DAY + INTERVAL 8 HOUR), (CURDATE() - INTERVAL 5 DAY + INTERVAL 9 HOUR)),
(283, 16, 'okay', 6, (CURDATE() - INTERVAL 6 DAY), (CURDATE() - INTERVAL 6 DAY + INTERVAL 12 HOUR), (CURDATE() - INTERVAL 6 DAY + INTERVAL 8 HOUR)),
(284, 16, 'okay', 6, (CURDATE() - INTERVAL 7 DAY), (CURDATE() - INTERVAL 7 DAY + INTERVAL 17 HOUR), (CURDATE() - INTERVAL 7 DAY + INTERVAL 13 HOUR)),
(285, 16, 'low', 6, (CURDATE() - INTERVAL 9 DAY), (CURDATE() - INTERVAL 9 DAY + INTERVAL 13 HOUR), (CURDATE() - INTERVAL 9 DAY + INTERVAL 8 HOUR)),
(286, 16, 'low', 6, (CURDATE() - INTERVAL 10 DAY), (CURDATE() - INTERVAL 10 DAY + INTERVAL 9 HOUR), (CURDATE() - INTERVAL 10 DAY + INTERVAL 12 HOUR)),
(287, 16, 'low', 6, (CURDATE() - INTERVAL 11 DAY), (CURDATE() - INTERVAL 11 DAY + INTERVAL 12 HOUR), (CURDATE() - INTERVAL 11 DAY + INTERVAL 18 HOUR)),
(288, 16, 'low', 8, (CURDATE() - INTERVAL 12 DAY), (CURDATE() - INTERVAL 12 DAY + INTERVAL 17 HOUR), (CURDATE() - INTERVAL 12 DAY + INTERVAL 11 HOUR)),
(289, 16, 'low', 6, (CURDATE() - INTERVAL 16 DAY), (CURDATE() - INTERVAL 16 DAY + INTERVAL 19 HOUR), (CURDATE() - INTERVAL 16 DAY + INTERVAL 10 HOUR)),
(290, 16, 'low', 7, (CURDATE() - INTERVAL 18 DAY), (CURDATE() - INTERVAL 18 DAY + INTERVAL 19 HOUR), (CURDATE() - INTERVAL 18 DAY + INTERVAL 9 HOUR)),
(291, 16, 'good', 4, (CURDATE() - INTERVAL 21 DAY), (CURDATE() - INTERVAL 21 DAY + INTERVAL 21 HOUR), (CURDATE() - INTERVAL 21 DAY + INTERVAL 17 HOUR)),
(292, 16, 'low', 8, (CURDATE() - INTERVAL 23 DAY), (CURDATE() - INTERVAL 23 DAY + INTERVAL 14 HOUR), (CURDATE() - INTERVAL 23 DAY + INTERVAL 14 HOUR)),
(293, 16, 'great', 2, (CURDATE() - INTERVAL 24 DAY), (CURDATE() - INTERVAL 24 DAY + INTERVAL 21 HOUR), (CURDATE() - INTERVAL 24 DAY + INTERVAL 9 HOUR)),
(294, 16, 'okay', 5, (CURDATE() - INTERVAL 25 DAY), (CURDATE() - INTERVAL 25 DAY + INTERVAL 17 HOUR), (CURDATE() - INTERVAL 25 DAY + INTERVAL 9 HOUR)),
(295, 16, 'good', 2, (CURDATE() - INTERVAL 26 DAY), (CURDATE() - INTERVAL 26 DAY + INTERVAL 17 HOUR), (CURDATE() - INTERVAL 26 DAY + INTERVAL 18 HOUR)),
(296, 16, 'low', 7, (CURDATE() - INTERVAL 27 DAY), (CURDATE() - INTERVAL 27 DAY + INTERVAL 11 HOUR), (CURDATE() - INTERVAL 27 DAY + INTERVAL 11 HOUR)),
(297, 16, 'good', 4, (CURDATE() - INTERVAL 29 DAY), (CURDATE() - INTERVAL 29 DAY + INTERVAL 14 HOUR), (CURDATE() - INTERVAL 29 DAY + INTERVAL 8 HOUR)),
(298, 16, 'okay', 6, (CURDATE() - INTERVAL 30 DAY), (CURDATE() - INTERVAL 30 DAY + INTERVAL 12 HOUR), (CURDATE() - INTERVAL 30 DAY + INTERVAL 12 HOUR)),
(299, 16, 'good', 3, (CURDATE() - INTERVAL 31 DAY), (CURDATE() - INTERVAL 31 DAY + INTERVAL 7 HOUR), (CURDATE() - INTERVAL 31 DAY + INTERVAL 16 HOUR)),
(300, 16, 'good', 2, (CURDATE() - INTERVAL 32 DAY), (CURDATE() - INTERVAL 32 DAY + INTERVAL 10 HOUR), (CURDATE() - INTERVAL 32 DAY + INTERVAL 10 HOUR)),
(301, 16, 'good', 2, (CURDATE() - INTERVAL 37 DAY), (CURDATE() - INTERVAL 37 DAY + INTERVAL 16 HOUR), (CURDATE() - INTERVAL 37 DAY + INTERVAL 19 HOUR)),
(302, 16, 'good', 4, (CURDATE() - INTERVAL 39 DAY), (CURDATE() - INTERVAL 39 DAY + INTERVAL 11 HOUR), (CURDATE() - INTERVAL 39 DAY + INTERVAL 19 HOUR)),
(303, 16, 'good', 2, (CURDATE() - INTERVAL 42 DAY), (CURDATE() - INTERVAL 42 DAY + INTERVAL 20 HOUR), (CURDATE() - INTERVAL 42 DAY + INTERVAL 20 HOUR)),
(304, 16, 'great', 2, (CURDATE() - INTERVAL 45 DAY), (CURDATE() - INTERVAL 45 DAY + INTERVAL 13 HOUR), (CURDATE() - INTERVAL 45 DAY + INTERVAL 15 HOUR)),
(305, 16, 'okay', 6, (CURDATE() - INTERVAL 47 DAY), (CURDATE() - INTERVAL 47 DAY + INTERVAL 7 HOUR), (CURDATE() - INTERVAL 47 DAY + INTERVAL 14 HOUR)),
(306, 16, 'low', 8, (CURDATE() - INTERVAL 49 DAY), (CURDATE() - INTERVAL 49 DAY + INTERVAL 13 HOUR), (CURDATE() - INTERVAL 49 DAY + INTERVAL 9 HOUR)),
(307, 16, 'low', 7, (CURDATE() - INTERVAL 51 DAY), (CURDATE() - INTERVAL 51 DAY + INTERVAL 16 HOUR), (CURDATE() - INTERVAL 51 DAY + INTERVAL 12 HOUR)),
(308, 16, 'okay', 5, (CURDATE() - INTERVAL 52 DAY), (CURDATE() - INTERVAL 52 DAY + INTERVAL 8 HOUR), (CURDATE() - INTERVAL 52 DAY + INTERVAL 8 HOUR)),
(309, 16, 'okay', 5, (CURDATE() - INTERVAL 53 DAY), (CURDATE() - INTERVAL 53 DAY + INTERVAL 13 HOUR), (CURDATE() - INTERVAL 53 DAY + INTERVAL 17 HOUR)),
(310, 16, 'okay', 4, (CURDATE() - INTERVAL 54 DAY), (CURDATE() - INTERVAL 54 DAY + INTERVAL 9 HOUR), (CURDATE() - INTERVAL 54 DAY + INTERVAL 20 HOUR)),
(311, 16, 'low', 8, (CURDATE() - INTERVAL 55 DAY), (CURDATE() - INTERVAL 55 DAY + INTERVAL 21 HOUR), (CURDATE() - INTERVAL 55 DAY + INTERVAL 19 HOUR)),
(312, 17, 'okay', 6, (CURDATE() - INTERVAL 0 DAY), (CURDATE() - INTERVAL 0 DAY + INTERVAL 11 HOUR), (CURDATE() - INTERVAL 0 DAY + INTERVAL 11 HOUR)),
(313, 17, 'great', 3, (CURDATE() - INTERVAL 1 DAY), (CURDATE() - INTERVAL 1 DAY + INTERVAL 13 HOUR), (CURDATE() - INTERVAL 1 DAY + INTERVAL 18 HOUR)),
(314, 17, 'great', 2, (CURDATE() - INTERVAL 3 DAY), (CURDATE() - INTERVAL 3 DAY + INTERVAL 19 HOUR), (CURDATE() - INTERVAL 3 DAY + INTERVAL 14 HOUR)),
(315, 17, 'great', 1, (CURDATE() - INTERVAL 4 DAY), (CURDATE() - INTERVAL 4 DAY + INTERVAL 9 HOUR), (CURDATE() - INTERVAL 4 DAY + INTERVAL 17 HOUR)),
(316, 17, 'great', 2, (CURDATE() - INTERVAL 5 DAY), (CURDATE() - INTERVAL 5 DAY + INTERVAL 14 HOUR), (CURDATE() - INTERVAL 5 DAY + INTERVAL 16 HOUR)),
(317, 17, 'good', 2, (CURDATE() - INTERVAL 6 DAY), (CURDATE() - INTERVAL 6 DAY + INTERVAL 20 HOUR), (CURDATE() - INTERVAL 6 DAY + INTERVAL 19 HOUR)),
(318, 17, 'good', 4, (CURDATE() - INTERVAL 8 DAY), (CURDATE() - INTERVAL 8 DAY + INTERVAL 13 HOUR), (CURDATE() - INTERVAL 8 DAY + INTERVAL 14 HOUR)),
(319, 17, 'great', 3, (CURDATE() - INTERVAL 9 DAY), (CURDATE() - INTERVAL 9 DAY + INTERVAL 21 HOUR), (CURDATE() - INTERVAL 9 DAY + INTERVAL 16 HOUR)),
(320, 17, 'great', 1, (CURDATE() - INTERVAL 10 DAY), (CURDATE() - INTERVAL 10 DAY + INTERVAL 9 HOUR), (CURDATE() - INTERVAL 10 DAY + INTERVAL 18 HOUR)),
(321, 17, 'great', 3, (CURDATE() - INTERVAL 11 DAY), (CURDATE() - INTERVAL 11 DAY + INTERVAL 9 HOUR), (CURDATE() - INTERVAL 11 DAY + INTERVAL 21 HOUR)),
(322, 17, 'great', 1, (CURDATE() - INTERVAL 12 DAY), (CURDATE() - INTERVAL 12 DAY + INTERVAL 19 HOUR), (CURDATE() - INTERVAL 12 DAY + INTERVAL 8 HOUR)),
(323, 17, 'good', 3, (CURDATE() - INTERVAL 13 DAY), (CURDATE() - INTERVAL 13 DAY + INTERVAL 8 HOUR), (CURDATE() - INTERVAL 13 DAY + INTERVAL 12 HOUR)),
(324, 17, 'great', 3, (CURDATE() - INTERVAL 17 DAY), (CURDATE() - INTERVAL 17 DAY + INTERVAL 9 HOUR), (CURDATE() - INTERVAL 17 DAY + INTERVAL 7 HOUR)),
(325, 17, 'great', 2, (CURDATE() - INTERVAL 18 DAY), (CURDATE() - INTERVAL 18 DAY + INTERVAL 14 HOUR), (CURDATE() - INTERVAL 18 DAY + INTERVAL 16 HOUR)),
(326, 17, 'great', 2, (CURDATE() - INTERVAL 19 DAY), (CURDATE() - INTERVAL 19 DAY + INTERVAL 10 HOUR), (CURDATE() - INTERVAL 19 DAY + INTERVAL 11 HOUR)),
(327, 17, 'good', 4, (CURDATE() - INTERVAL 20 DAY), (CURDATE() - INTERVAL 20 DAY + INTERVAL 13 HOUR), (CURDATE() - INTERVAL 20 DAY + INTERVAL 21 HOUR)),
(328, 17, 'great', 2, (CURDATE() - INTERVAL 22 DAY), (CURDATE() - INTERVAL 22 DAY + INTERVAL 12 HOUR), (CURDATE() - INTERVAL 22 DAY + INTERVAL 16 HOUR)),
(329, 17, 'okay', 5, (CURDATE() - INTERVAL 24 DAY), (CURDATE() - INTERVAL 24 DAY + INTERVAL 12 HOUR), (CURDATE() - INTERVAL 24 DAY + INTERVAL 20 HOUR)),
(330, 17, 'good', 2, (CURDATE() - INTERVAL 25 DAY), (CURDATE() - INTERVAL 25 DAY + INTERVAL 7 HOUR), (CURDATE() - INTERVAL 25 DAY + INTERVAL 14 HOUR)),
(331, 17, 'great', 2, (CURDATE() - INTERVAL 26 DAY), (CURDATE() - INTERVAL 26 DAY + INTERVAL 15 HOUR), (CURDATE() - INTERVAL 26 DAY + INTERVAL 8 HOUR)),
(332, 17, 'great', 2, (CURDATE() - INTERVAL 28 DAY), (CURDATE() - INTERVAL 28 DAY + INTERVAL 13 HOUR), (CURDATE() - INTERVAL 28 DAY + INTERVAL 7 HOUR)),
(333, 17, 'good', 2, (CURDATE() - INTERVAL 29 DAY), (CURDATE() - INTERVAL 29 DAY + INTERVAL 21 HOUR), (CURDATE() - INTERVAL 29 DAY + INTERVAL 14 HOUR)),
(334, 17, 'great', 1, (CURDATE() - INTERVAL 36 DAY), (CURDATE() - INTERVAL 36 DAY + INTERVAL 8 HOUR), (CURDATE() - INTERVAL 36 DAY + INTERVAL 16 HOUR)),
(335, 17, 'great', 2, (CURDATE() - INTERVAL 39 DAY), (CURDATE() - INTERVAL 39 DAY + INTERVAL 11 HOUR), (CURDATE() - INTERVAL 39 DAY + INTERVAL 13 HOUR)),
(336, 17, 'great', 2, (CURDATE() - INTERVAL 40 DAY), (CURDATE() - INTERVAL 40 DAY + INTERVAL 12 HOUR), (CURDATE() - INTERVAL 40 DAY + INTERVAL 18 HOUR)),
(337, 17, 'great', 3, (CURDATE() - INTERVAL 45 DAY), (CURDATE() - INTERVAL 45 DAY + INTERVAL 7 HOUR), (CURDATE() - INTERVAL 45 DAY + INTERVAL 20 HOUR)),
(338, 17, 'great', 3, (CURDATE() - INTERVAL 48 DAY), (CURDATE() - INTERVAL 48 DAY + INTERVAL 15 HOUR), (CURDATE() - INTERVAL 48 DAY + INTERVAL 16 HOUR)),
(339, 17, 'great', 1, (CURDATE() - INTERVAL 51 DAY), (CURDATE() - INTERVAL 51 DAY + INTERVAL 19 HOUR), (CURDATE() - INTERVAL 51 DAY + INTERVAL 11 HOUR)),
(340, 17, 'great', 3, (CURDATE() - INTERVAL 52 DAY), (CURDATE() - INTERVAL 52 DAY + INTERVAL 13 HOUR), (CURDATE() - INTERVAL 52 DAY + INTERVAL 17 HOUR)),
(341, 17, 'low', 7, (CURDATE() - INTERVAL 54 DAY), (CURDATE() - INTERVAL 54 DAY + INTERVAL 15 HOUR), (CURDATE() - INTERVAL 54 DAY + INTERVAL 12 HOUR)),
(342, 18, 'okay', 6, (CURDATE() - INTERVAL 0 DAY), (CURDATE() - INTERVAL 0 DAY + INTERVAL 15 HOUR), (CURDATE() - INTERVAL 0 DAY + INTERVAL 7 HOUR)),
(343, 18, 'okay', 4, (CURDATE() - INTERVAL 1 DAY), (CURDATE() - INTERVAL 1 DAY + INTERVAL 18 HOUR), (CURDATE() - INTERVAL 1 DAY + INTERVAL 13 HOUR)),
(344, 18, 'okay', 5, (CURDATE() - INTERVAL 2 DAY), (CURDATE() - INTERVAL 2 DAY + INTERVAL 18 HOUR), (CURDATE() - INTERVAL 2 DAY + INTERVAL 19 HOUR)),
(345, 18, 'good', 3, (CURDATE() - INTERVAL 3 DAY), (CURDATE() - INTERVAL 3 DAY + INTERVAL 12 HOUR), (CURDATE() - INTERVAL 3 DAY + INTERVAL 19 HOUR)),
(346, 18, 'okay', 5, (CURDATE() - INTERVAL 4 DAY), (CURDATE() - INTERVAL 4 DAY + INTERVAL 18 HOUR), (CURDATE() - INTERVAL 4 DAY + INTERVAL 10 HOUR)),
(347, 18, 'okay', 4, (CURDATE() - INTERVAL 5 DAY), (CURDATE() - INTERVAL 5 DAY + INTERVAL 12 HOUR), (CURDATE() - INTERVAL 5 DAY + INTERVAL 14 HOUR)),
(348, 18, 'okay', 5, (CURDATE() - INTERVAL 6 DAY), (CURDATE() - INTERVAL 6 DAY + INTERVAL 9 HOUR), (CURDATE() - INTERVAL 6 DAY + INTERVAL 13 HOUR)),
(349, 18, 'okay', 4, (CURDATE() - INTERVAL 7 DAY), (CURDATE() - INTERVAL 7 DAY + INTERVAL 17 HOUR), (CURDATE() - INTERVAL 7 DAY + INTERVAL 11 HOUR)),
(350, 18, 'low', 6, (CURDATE() - INTERVAL 9 DAY), (CURDATE() - INTERVAL 9 DAY + INTERVAL 21 HOUR), (CURDATE() - INTERVAL 9 DAY + INTERVAL 11 HOUR)),
(351, 18, 'good', 3, (CURDATE() - INTERVAL 10 DAY), (CURDATE() - INTERVAL 10 DAY + INTERVAL 14 HOUR), (CURDATE() - INTERVAL 10 DAY + INTERVAL 13 HOUR)),
(352, 18, 'okay', 6, (CURDATE() - INTERVAL 11 DAY), (CURDATE() - INTERVAL 11 DAY + INTERVAL 13 HOUR), (CURDATE() - INTERVAL 11 DAY + INTERVAL 17 HOUR)),
(353, 18, 'okay', 6, (CURDATE() - INTERVAL 12 DAY), (CURDATE() - INTERVAL 12 DAY + INTERVAL 11 HOUR), (CURDATE() - INTERVAL 12 DAY + INTERVAL 8 HOUR)),
(354, 18, 'low', 6, (CURDATE() - INTERVAL 13 DAY), (CURDATE() - INTERVAL 13 DAY + INTERVAL 17 HOUR), (CURDATE() - INTERVAL 13 DAY + INTERVAL 17 HOUR)),
(355, 18, 'low', 8, (CURDATE() - INTERVAL 14 DAY), (CURDATE() - INTERVAL 14 DAY + INTERVAL 17 HOUR), (CURDATE() - INTERVAL 14 DAY + INTERVAL 12 HOUR)),
(356, 18, 'low', 6, (CURDATE() - INTERVAL 15 DAY), (CURDATE() - INTERVAL 15 DAY + INTERVAL 20 HOUR), (CURDATE() - INTERVAL 15 DAY + INTERVAL 16 HOUR)),
(357, 18, 'okay', 5, (CURDATE() - INTERVAL 21 DAY), (CURDATE() - INTERVAL 21 DAY + INTERVAL 13 HOUR), (CURDATE() - INTERVAL 21 DAY + INTERVAL 14 HOUR)),
(358, 18, 'good', 4, (CURDATE() - INTERVAL 22 DAY), (CURDATE() - INTERVAL 22 DAY + INTERVAL 11 HOUR), (CURDATE() - INTERVAL 22 DAY + INTERVAL 18 HOUR)),
(359, 18, 'good', 2, (CURDATE() - INTERVAL 23 DAY), (CURDATE() - INTERVAL 23 DAY + INTERVAL 21 HOUR), (CURDATE() - INTERVAL 23 DAY + INTERVAL 21 HOUR)),
(360, 18, 'good', 3, (CURDATE() - INTERVAL 24 DAY), (CURDATE() - INTERVAL 24 DAY + INTERVAL 9 HOUR), (CURDATE() - INTERVAL 24 DAY + INTERVAL 17 HOUR)),
(361, 18, 'okay', 6, (CURDATE() - INTERVAL 27 DAY), (CURDATE() - INTERVAL 27 DAY + INTERVAL 14 HOUR), (CURDATE() - INTERVAL 27 DAY + INTERVAL 19 HOUR)),
(362, 18, 'okay', 5, (CURDATE() - INTERVAL 28 DAY), (CURDATE() - INTERVAL 28 DAY + INTERVAL 13 HOUR), (CURDATE() - INTERVAL 28 DAY + INTERVAL 15 HOUR)),
(363, 18, 'okay', 6, (CURDATE() - INTERVAL 29 DAY), (CURDATE() - INTERVAL 29 DAY + INTERVAL 13 HOUR), (CURDATE() - INTERVAL 29 DAY + INTERVAL 19 HOUR)),
(364, 18, 'low', 8, (CURDATE() - INTERVAL 31 DAY), (CURDATE() - INTERVAL 31 DAY + INTERVAL 12 HOUR), (CURDATE() - INTERVAL 31 DAY + INTERVAL 12 HOUR)),
(365, 18, 'great', 2, (CURDATE() - INTERVAL 32 DAY), (CURDATE() - INTERVAL 32 DAY + INTERVAL 12 HOUR), (CURDATE() - INTERVAL 32 DAY + INTERVAL 19 HOUR)),
(366, 18, 'low', 8, (CURDATE() - INTERVAL 33 DAY), (CURDATE() - INTERVAL 33 DAY + INTERVAL 21 HOUR), (CURDATE() - INTERVAL 33 DAY + INTERVAL 17 HOUR)),
(367, 18, 'okay', 6, (CURDATE() - INTERVAL 38 DAY), (CURDATE() - INTERVAL 38 DAY + INTERVAL 12 HOUR), (CURDATE() - INTERVAL 38 DAY + INTERVAL 10 HOUR)),
(368, 18, 'good', 3, (CURDATE() - INTERVAL 39 DAY), (CURDATE() - INTERVAL 39 DAY + INTERVAL 21 HOUR), (CURDATE() - INTERVAL 39 DAY + INTERVAL 15 HOUR)),
(369, 18, 'good', 2, (CURDATE() - INTERVAL 40 DAY), (CURDATE() - INTERVAL 40 DAY + INTERVAL 13 HOUR), (CURDATE() - INTERVAL 40 DAY + INTERVAL 17 HOUR)),
(370, 18, 'good', 2, (CURDATE() - INTERVAL 41 DAY), (CURDATE() - INTERVAL 41 DAY + INTERVAL 16 HOUR), (CURDATE() - INTERVAL 41 DAY + INTERVAL 8 HOUR)),
(371, 18, 'okay', 4, (CURDATE() - INTERVAL 42 DAY), (CURDATE() - INTERVAL 42 DAY + INTERVAL 19 HOUR), (CURDATE() - INTERVAL 42 DAY + INTERVAL 12 HOUR)),
(372, 18, 'okay', 5, (CURDATE() - INTERVAL 43 DAY), (CURDATE() - INTERVAL 43 DAY + INTERVAL 20 HOUR), (CURDATE() - INTERVAL 43 DAY + INTERVAL 14 HOUR)),
(373, 18, 'okay', 6, (CURDATE() - INTERVAL 44 DAY), (CURDATE() - INTERVAL 44 DAY + INTERVAL 11 HOUR), (CURDATE() - INTERVAL 44 DAY + INTERVAL 12 HOUR)),
(374, 18, 'good', 3, (CURDATE() - INTERVAL 45 DAY), (CURDATE() - INTERVAL 45 DAY + INTERVAL 16 HOUR), (CURDATE() - INTERVAL 45 DAY + INTERVAL 21 HOUR)),
(375, 18, 'okay', 4, (CURDATE() - INTERVAL 48 DAY), (CURDATE() - INTERVAL 48 DAY + INTERVAL 14 HOUR), (CURDATE() - INTERVAL 48 DAY + INTERVAL 8 HOUR)),
(376, 18, 'struggling', 9, (CURDATE() - INTERVAL 51 DAY), (CURDATE() - INTERVAL 51 DAY + INTERVAL 10 HOUR), (CURDATE() - INTERVAL 51 DAY + INTERVAL 12 HOUR)),
(377, 18, 'okay', 6, (CURDATE() - INTERVAL 53 DAY), (CURDATE() - INTERVAL 53 DAY + INTERVAL 14 HOUR), (CURDATE() - INTERVAL 53 DAY + INTERVAL 10 HOUR)),
(378, 18, 'low', 8, (CURDATE() - INTERVAL 54 DAY), (CURDATE() - INTERVAL 54 DAY + INTERVAL 11 HOUR), (CURDATE() - INTERVAL 54 DAY + INTERVAL 14 HOUR)),
(379, 18, 'good', 2, (CURDATE() - INTERVAL 55 DAY), (CURDATE() - INTERVAL 55 DAY + INTERVAL 8 HOUR), (CURDATE() - INTERVAL 55 DAY + INTERVAL 9 HOUR)),
(380, 19, 'okay', 6, (CURDATE() - INTERVAL 1 DAY), (CURDATE() - INTERVAL 1 DAY + INTERVAL 21 HOUR), (CURDATE() - INTERVAL 1 DAY + INTERVAL 21 HOUR)),
(381, 19, 'great', 2, (CURDATE() - INTERVAL 2 DAY), (CURDATE() - INTERVAL 2 DAY + INTERVAL 11 HOUR), (CURDATE() - INTERVAL 2 DAY + INTERVAL 11 HOUR)),
(382, 19, 'good', 2, (CURDATE() - INTERVAL 3 DAY), (CURDATE() - INTERVAL 3 DAY + INTERVAL 16 HOUR), (CURDATE() - INTERVAL 3 DAY + INTERVAL 19 HOUR)),
(383, 19, 'great', 1, (CURDATE() - INTERVAL 4 DAY), (CURDATE() - INTERVAL 4 DAY + INTERVAL 20 HOUR), (CURDATE() - INTERVAL 4 DAY + INTERVAL 8 HOUR)),
(384, 19, 'good', 4, (CURDATE() - INTERVAL 6 DAY), (CURDATE() - INTERVAL 6 DAY + INTERVAL 21 HOUR), (CURDATE() - INTERVAL 6 DAY + INTERVAL 19 HOUR)),
(385, 19, 'good', 4, (CURDATE() - INTERVAL 7 DAY), (CURDATE() - INTERVAL 7 DAY + INTERVAL 16 HOUR), (CURDATE() - INTERVAL 7 DAY + INTERVAL 12 HOUR)),
(386, 19, 'good', 3, (CURDATE() - INTERVAL 9 DAY), (CURDATE() - INTERVAL 9 DAY + INTERVAL 15 HOUR), (CURDATE() - INTERVAL 9 DAY + INTERVAL 13 HOUR)),
(387, 19, 'good', 2, (CURDATE() - INTERVAL 10 DAY), (CURDATE() - INTERVAL 10 DAY + INTERVAL 12 HOUR), (CURDATE() - INTERVAL 10 DAY + INTERVAL 18 HOUR)),
(388, 19, 'good', 2, (CURDATE() - INTERVAL 12 DAY), (CURDATE() - INTERVAL 12 DAY + INTERVAL 13 HOUR), (CURDATE() - INTERVAL 12 DAY + INTERVAL 12 HOUR)),
(389, 19, 'okay', 6, (CURDATE() - INTERVAL 14 DAY), (CURDATE() - INTERVAL 14 DAY + INTERVAL 13 HOUR), (CURDATE() - INTERVAL 14 DAY + INTERVAL 9 HOUR)),
(390, 19, 'low', 7, (CURDATE() - INTERVAL 15 DAY), (CURDATE() - INTERVAL 15 DAY + INTERVAL 15 HOUR), (CURDATE() - INTERVAL 15 DAY + INTERVAL 10 HOUR)),
(391, 19, 'good', 2, (CURDATE() - INTERVAL 16 DAY), (CURDATE() - INTERVAL 16 DAY + INTERVAL 9 HOUR), (CURDATE() - INTERVAL 16 DAY + INTERVAL 14 HOUR)),
(392, 19, 'great', 2, (CURDATE() - INTERVAL 18 DAY), (CURDATE() - INTERVAL 18 DAY + INTERVAL 12 HOUR), (CURDATE() - INTERVAL 18 DAY + INTERVAL 18 HOUR)),
(393, 19, 'good', 2, (CURDATE() - INTERVAL 19 DAY), (CURDATE() - INTERVAL 19 DAY + INTERVAL 20 HOUR), (CURDATE() - INTERVAL 19 DAY + INTERVAL 17 HOUR)),
(394, 19, 'low', 8, (CURDATE() - INTERVAL 20 DAY), (CURDATE() - INTERVAL 20 DAY + INTERVAL 7 HOUR), (CURDATE() - INTERVAL 20 DAY + INTERVAL 14 HOUR)),
(395, 19, 'good', 3, (CURDATE() - INTERVAL 21 DAY), (CURDATE() - INTERVAL 21 DAY + INTERVAL 12 HOUR), (CURDATE() - INTERVAL 21 DAY + INTERVAL 14 HOUR)),
(396, 19, 'good', 2, (CURDATE() - INTERVAL 24 DAY), (CURDATE() - INTERVAL 24 DAY + INTERVAL 7 HOUR), (CURDATE() - INTERVAL 24 DAY + INTERVAL 21 HOUR)),
(397, 19, 'good', 2, (CURDATE() - INTERVAL 26 DAY), (CURDATE() - INTERVAL 26 DAY + INTERVAL 15 HOUR), (CURDATE() - INTERVAL 26 DAY + INTERVAL 16 HOUR)),
(398, 19, 'good', 3, (CURDATE() - INTERVAL 27 DAY), (CURDATE() - INTERVAL 27 DAY + INTERVAL 10 HOUR), (CURDATE() - INTERVAL 27 DAY + INTERVAL 7 HOUR)),
(399, 19, 'okay', 4, (CURDATE() - INTERVAL 29 DAY), (CURDATE() - INTERVAL 29 DAY + INTERVAL 18 HOUR), (CURDATE() - INTERVAL 29 DAY + INTERVAL 13 HOUR)),
(400, 19, 'great', 2, (CURDATE() - INTERVAL 30 DAY), (CURDATE() - INTERVAL 30 DAY + INTERVAL 12 HOUR), (CURDATE() - INTERVAL 30 DAY + INTERVAL 12 HOUR)),
(401, 19, 'good', 2, (CURDATE() - INTERVAL 31 DAY), (CURDATE() - INTERVAL 31 DAY + INTERVAL 19 HOUR), (CURDATE() - INTERVAL 31 DAY + INTERVAL 11 HOUR)),
(402, 19, 'good', 2, (CURDATE() - INTERVAL 32 DAY), (CURDATE() - INTERVAL 32 DAY + INTERVAL 16 HOUR), (CURDATE() - INTERVAL 32 DAY + INTERVAL 21 HOUR)),
(403, 19, 'great', 3, (CURDATE() - INTERVAL 38 DAY), (CURDATE() - INTERVAL 38 DAY + INTERVAL 8 HOUR), (CURDATE() - INTERVAL 38 DAY + INTERVAL 14 HOUR)),
(404, 19, 'okay', 4, (CURDATE() - INTERVAL 39 DAY), (CURDATE() - INTERVAL 39 DAY + INTERVAL 17 HOUR), (CURDATE() - INTERVAL 39 DAY + INTERVAL 10 HOUR)),
(405, 19, 'good', 3, (CURDATE() - INTERVAL 41 DAY), (CURDATE() - INTERVAL 41 DAY + INTERVAL 9 HOUR), (CURDATE() - INTERVAL 41 DAY + INTERVAL 20 HOUR)),
(406, 19, 'good', 3, (CURDATE() - INTERVAL 44 DAY), (CURDATE() - INTERVAL 44 DAY + INTERVAL 18 HOUR), (CURDATE() - INTERVAL 44 DAY + INTERVAL 19 HOUR)),
(407, 19, 'good', 2, (CURDATE() - INTERVAL 45 DAY), (CURDATE() - INTERVAL 45 DAY + INTERVAL 19 HOUR), (CURDATE() - INTERVAL 45 DAY + INTERVAL 18 HOUR)),
(408, 19, 'good', 4, (CURDATE() - INTERVAL 47 DAY), (CURDATE() - INTERVAL 47 DAY + INTERVAL 19 HOUR), (CURDATE() - INTERVAL 47 DAY + INTERVAL 15 HOUR)),
(409, 19, 'good', 4, (CURDATE() - INTERVAL 51 DAY), (CURDATE() - INTERVAL 51 DAY + INTERVAL 18 HOUR), (CURDATE() - INTERVAL 51 DAY + INTERVAL 14 HOUR)),
(410, 19, 'good', 4, (CURDATE() - INTERVAL 52 DAY), (CURDATE() - INTERVAL 52 DAY + INTERVAL 13 HOUR), (CURDATE() - INTERVAL 52 DAY + INTERVAL 9 HOUR)),
(411, 19, 'good', 3, (CURDATE() - INTERVAL 53 DAY), (CURDATE() - INTERVAL 53 DAY + INTERVAL 12 HOUR), (CURDATE() - INTERVAL 53 DAY + INTERVAL 9 HOUR)),
(412, 19, 'good', 4, (CURDATE() - INTERVAL 54 DAY), (CURDATE() - INTERVAL 54 DAY + INTERVAL 19 HOUR), (CURDATE() - INTERVAL 54 DAY + INTERVAL 7 HOUR)),
(413, 19, 'good', 4, (CURDATE() - INTERVAL 55 DAY), (CURDATE() - INTERVAL 55 DAY + INTERVAL 8 HOUR), (CURDATE() - INTERVAL 55 DAY + INTERVAL 14 HOUR));

INSERT INTO `journal_entries` (`entry_id`, `user_id`, `content`, `emotion`, `alert_tier`, `created_at`) VALUES
(1, 8, 'Finished my first prototype today. It was stressful but I am proud of how it turned out.', 'Hopeful', 'normal', (CURDATE() - INTERVAL 1 DAY + INTERVAL 10 HOUR)),
(2, 8, 'Went for a walk after lectures and it cleared my head. I should do this more often.', 'Calm', 'normal', (CURDATE() - INTERVAL 6 DAY + INTERVAL 14 HOUR)),
(3, 9, 'Three tests next week and I keep putting off studying. I need a proper plan.', 'Anxious', 'normal', (CURDATE() - INTERVAL 0 DAY + INTERVAL 9 HOUR)),
(4, 9, 'Group project members are not replying. I feel like I am carrying everything.', 'Frustrated', 'normal', (CURDATE() - INTERVAL 4 DAY + INTERVAL 12 HOUR)),
(5, 10, 'My study group helped me understand accounting concepts. So thankful for them.', 'Grateful', 'normal', (CURDATE() - INTERVAL 2 DAY + INTERVAL 18 HOUR)),
(6, 10, 'Got a good mark on my assignment. Feeling motivated for the rest of the semester.', 'Hopeful', 'normal', (CURDATE() - INTERVAL 9 DAY + INTERVAL 18 HOUR)),
(7, 11, 'Quiet weekend, caught up on sleep and chores. Feeling steady.', 'Calm', 'normal', (CURDATE() - INTERVAL 3 DAY + INTERVAL 10 HOUR)),
(8, 12, 'I have been feeling very overwhelmed lately and cannot focus in class.', 'Anxious', 'normal', (CURDATE() - INTERVAL 1 DAY + INTERVAL 10 HOUR)),
(9, 12, 'Everything feels harder than it should. I do not have energy for anything.', 'Frustrated', 'normal', (CURDATE() - INTERVAL 5 DAY + INTERVAL 13 HOUR)),
(10, 13, 'Started learning HTML on my own. Small steps but I am enjoying it.', 'Hopeful', 'normal', (CURDATE() - INTERVAL 7 DAY + INTERVAL 9 HOUR)),
(11, 14, 'My lecturer gave helpful feedback today. It made me feel seen.', 'Grateful', 'normal', (CURDATE() - INTERVAL 2 DAY + INTERVAL 13 HOUR)),
(12, 15, 'I have been avoiding my friends because I feel like a burden. Not sure why I feel this way.', 'Anxious', 'normal', (CURDATE() - INTERVAL 0 DAY + INTERVAL 10 HOUR)),
(13, 15, 'Another sleepless night. I cannot switch my thoughts off.', 'Frustrated', 'normal', (CURDATE() - INTERVAL 3 DAY + INTERVAL 9 HOUR)),
(14, 16, 'I have been thinking about suicide and I do not know who to talk to. I feel so alone.', 'Anxious', 'critical', (CURDATE() - INTERVAL 0 DAY + INTERVAL 14 HOUR)),
(15, 16, 'Failed another test. I feel like I am letting my family down.', 'Frustrated', 'normal', (CURDATE() - INTERVAL 2 DAY + INTERVAL 18 HOUR)),
(16, 17, 'Had a lovely call with my mother. Feeling very supported today.', 'Grateful', 'normal', (CURDATE() - INTERVAL 1 DAY + INTERVAL 13 HOUR)),
(17, 17, 'Excited about the upcoming break and catching up with friends.', 'Hopeful', 'normal', (CURDATE() - INTERVAL 8 DAY + INTERVAL 15 HOUR)),
(18, 18, 'Balancing work and studies is tough but I am managing with a timetable.', 'Calm', 'normal', (CURDATE() - INTERVAL 2 DAY + INTERVAL 14 HOUR)),
(19, 18, 'Presentation next week. My nerves are getting the better of me.', 'Anxious', 'normal', (CURDATE() - INTERVAL 10 DAY + INTERVAL 15 HOUR)),
(20, 19, 'Joined the peer support space and it already feels welcoming.', 'Hopeful', 'normal', (CURDATE() - INTERVAL 1 DAY + INTERVAL 19 HOUR)),
(21, 19, 'Friends surprised me with a small celebration. I feel appreciated.', 'Grateful', 'normal', (CURDATE() - INTERVAL 6 DAY + INTERVAL 20 HOUR)),
(22, 14, 'Meditated for ten minutes before studying. Worth repeating.', 'Calm', 'normal', (CURDATE() - INTERVAL 12 DAY + INTERVAL 13 HOUR)),
(23, 10, 'Sunday with family, good food and rest. Recharged.', 'Grateful', 'normal', (CURDATE() - INTERVAL 15 DAY + INTERVAL 18 HOUR)),
(24, 11, 'Load shedding ruined my study plan again. Annoyed but trying to adapt.', 'Frustrated', 'normal', (CURDATE() - INTERVAL 11 DAY + INTERVAL 20 HOUR));

INSERT INTO `bookings` (`booking_id`, `user_id`, `counsellor_id`, `session_date`, `session_time`, `status`, `created_at`) VALUES
(1, 8, 1, (CURDATE() - INTERVAL (21 + CASE WEEKDAY(CURDATE() - INTERVAL 21 DAY) WHEN 5 THEN 1 WHEN 6 THEN 2 ELSE 0 END) DAY), '09:00:00', 'completed', (CURDATE() - INTERVAL 24 DAY + INTERVAL 10 HOUR)),
(2, 12, 1, (CURDATE() - INTERVAL (14 + CASE WEEKDAY(CURDATE() - INTERVAL 14 DAY) WHEN 5 THEN 1 WHEN 6 THEN 2 ELSE 0 END) DAY), '11:30:00', 'completed', (CURDATE() - INTERVAL 17 DAY + INTERVAL 10 HOUR)),
(3, 16, 1, (CURDATE() - INTERVAL (7 + CASE WEEKDAY(CURDATE() - INTERVAL 7 DAY) WHEN 5 THEN 1 WHEN 6 THEN 2 ELSE 0 END) DAY), '14:00:00', 'completed', (CURDATE() - INTERVAL 10 DAY + INTERVAL 10 HOUR)),
(4, 16, 1, (CURDATE() + INTERVAL (2 + CASE WEEKDAY(CURDATE() + INTERVAL 2 DAY) WHEN 5 THEN 2 WHEN 6 THEN 1 ELSE 0 END) DAY), '09:00:00', 'booked', (CURDATE() - INTERVAL 5 DAY + INTERVAL 10 HOUR)),
(5, 9, 2, (CURDATE() - INTERVAL (18 + CASE WEEKDAY(CURDATE() - INTERVAL 18 DAY) WHEN 5 THEN 1 WHEN 6 THEN 2 ELSE 0 END) DAY), '11:30:00', 'completed', (CURDATE() - INTERVAL 21 DAY + INTERVAL 10 HOUR)),
(6, 15, 2, (CURDATE() - INTERVAL (10 + CASE WEEKDAY(CURDATE() - INTERVAL 10 DAY) WHEN 5 THEN 1 WHEN 6 THEN 2 ELSE 0 END) DAY), '09:00:00', 'completed', (CURDATE() - INTERVAL 13 DAY + INTERVAL 10 HOUR)),
(7, 9, 2, (CURDATE() + INTERVAL (3 + CASE WEEKDAY(CURDATE() + INTERVAL 3 DAY) WHEN 5 THEN 2 WHEN 6 THEN 1 ELSE 0 END) DAY), '11:30:00', 'booked', (CURDATE() - INTERVAL 6 DAY + INTERVAL 10 HOUR)),
(8, 12, 2, (CURDATE() + INTERVAL (6 + CASE WEEKDAY(CURDATE() + INTERVAL 6 DAY) WHEN 5 THEN 2 WHEN 6 THEN 1 ELSE 0 END) DAY), '14:00:00', 'booked', (CURDATE() - INTERVAL 9 DAY + INTERVAL 10 HOUR)),
(9, 16, 3, (CURDATE() - INTERVAL (12 + CASE WEEKDAY(CURDATE() - INTERVAL 12 DAY) WHEN 5 THEN 1 WHEN 6 THEN 2 ELSE 0 END) DAY), '14:00:00', 'completed', (CURDATE() - INTERVAL 15 DAY + INTERVAL 10 HOUR)),
(10, 11, 3, (CURDATE() - INTERVAL (6 + CASE WEEKDAY(CURDATE() - INTERVAL 6 DAY) WHEN 5 THEN 1 WHEN 6 THEN 2 ELSE 0 END) DAY), '15:30:00', 'completed', (CURDATE() - INTERVAL 9 DAY + INTERVAL 10 HOUR)),
(11, 18, 3, (CURDATE() + INTERVAL (4 + CASE WEEKDAY(CURDATE() + INTERVAL 4 DAY) WHEN 5 THEN 2 WHEN 6 THEN 1 ELSE 0 END) DAY), '09:00:00', 'booked', (CURDATE() - INTERVAL 7 DAY + INTERVAL 10 HOUR)),
(12, 16, 3, (CURDATE() + INTERVAL (9 + CASE WEEKDAY(CURDATE() + INTERVAL 9 DAY) WHEN 5 THEN 2 WHEN 6 THEN 1 ELSE 0 END) DAY), '14:00:00', 'booked', (CURDATE() - INTERVAL 12 DAY + INTERVAL 10 HOUR)),
(13, 15, 4, (CURDATE() - INTERVAL (9 + CASE WEEKDAY(CURDATE() - INTERVAL 9 DAY) WHEN 5 THEN 1 WHEN 6 THEN 2 ELSE 0 END) DAY), '11:30:00', 'completed', (CURDATE() - INTERVAL 12 DAY + INTERVAL 10 HOUR)),
(14, 14, 4, (CURDATE() - INTERVAL (3 + CASE WEEKDAY(CURDATE() - INTERVAL 3 DAY) WHEN 5 THEN 1 WHEN 6 THEN 2 ELSE 0 END) DAY), '14:00:00', 'cancelled', (CURDATE() - INTERVAL 6 DAY + INTERVAL 10 HOUR)),
(15, 19, 4, (CURDATE() + INTERVAL (5 + CASE WEEKDAY(CURDATE() + INTERVAL 5 DAY) WHEN 5 THEN 2 WHEN 6 THEN 1 ELSE 0 END) DAY), '15:30:00', 'booked', (CURDATE() - INTERVAL 8 DAY + INTERVAL 10 HOUR)),
(16, 13, 5, (CURDATE() - INTERVAL (15 + CASE WEEKDAY(CURDATE() - INTERVAL 15 DAY) WHEN 5 THEN 1 WHEN 6 THEN 2 ELSE 0 END) DAY), '09:00:00', 'completed', (CURDATE() - INTERVAL 18 DAY + INTERVAL 10 HOUR)),
(17, 10, 5, (CURDATE() - INTERVAL (5 + CASE WEEKDAY(CURDATE() - INTERVAL 5 DAY) WHEN 5 THEN 1 WHEN 6 THEN 2 ELSE 0 END) DAY), '11:30:00', 'completed', (CURDATE() - INTERVAL 8 DAY + INTERVAL 10 HOUR)),
(18, 17, 5, (CURDATE() + INTERVAL (7 + CASE WEEKDAY(CURDATE() + INTERVAL 7 DAY) WHEN 5 THEN 2 WHEN 6 THEN 1 ELSE 0 END) DAY), '14:00:00', 'booked', (CURDATE() - INTERVAL 10 DAY + INTERVAL 10 HOUR)),
(19, 13, 5, (CURDATE() + INTERVAL (12 + CASE WEEKDAY(CURDATE() + INTERVAL 12 DAY) WHEN 5 THEN 2 WHEN 6 THEN 1 ELSE 0 END) DAY), '09:00:00', 'cancelled', (CURDATE() - INTERVAL 15 DAY + INTERVAL 10 HOUR)),
(20, 15, 1, (CURDATE() + INTERVAL (0 + CASE WEEKDAY(CURDATE() + INTERVAL 0 DAY) WHEN 5 THEN 2 WHEN 6 THEN 1 ELSE 0 END) DAY), '15:30:00', 'booked', (CURDATE() - INTERVAL 3 DAY + INTERVAL 10 HOUR));

INSERT INTO `counsellor_notes` (`note_id`, `user_id`, `counsellor_id`, `note`, `created_at`) VALUES
(1, 16, 1, 'First session. Student reports sleep disruption and academic pressure. Agreed on weekly check-ins; shared campus support contacts.', (CURDATE() - INTERVAL 7 DAY + INTERVAL 15 HOUR)),
(2, 12, 1, 'Discussed feeling overwhelmed. Introduced a simple weekly planner and breathing exercise. Follow-up booked.', (CURDATE() - INTERVAL 14 DAY + INTERVAL 15 HOUR)),
(3, 15, 4, 'Student describes withdrawing from friends. Explored small social steps; will review progress next session.', (CURDATE() - INTERVAL 9 DAY + INTERVAL 15 HOUR));

INSERT INTO `posts` (`post_id`, `user_id`, `content`, `category`, `is_removed`, `created_at`) VALUES
(1, 8, 'Does anyone have tips for staying calm before a big presentation? Mine is next week.', 'Support', 0, (CURDATE() - INTERVAL 6 DAY + INTERVAL 10 HOUR)),
(2, 10, 'Reminder that rest is productive too. Be kind to yourselves this week.', 'Encouragement', 0, (CURDATE() - INTERVAL 5 DAY + INTERVAL 14 HOUR)),
(3, 12, 'Feeling a bit overwhelmed with deadlines. Just needed to say it out loud.', 'Vent', 0, (CURDATE() - INTERVAL 4 DAY + INTERVAL 8 HOUR)),
(4, 17, 'What helped me: a 25 minute study block, then a proper break. Try it out!', 'Advice', 0, (CURDATE() - INTERVAL 4 DAY + INTERVAL 13 HOUR)),
(5, 19, 'New here! Looking for a study group for the PGDM modules.', 'Support', 0, (CURDATE() - INTERVAL 3 DAY + INTERVAL 16 HOUR)),
(6, 9, 'Group work is draining when only half the team shows up.', 'Vent', 0, (CURDATE() - INTERVAL 2 DAY + INTERVAL 18 HOUR)),
(7, 14, 'Small wins count. I finally cleared my inbox today.', 'Encouragement', 0, (CURDATE() - INTERVAL 2 DAY + INTERVAL 19 HOUR)),
(8, 13, 'Free online resources helped me with programming basics. Happy to share.', 'Advice', 0, (CURDATE() - INTERVAL 1 DAY + INTERVAL 9 HOUR));

INSERT INTO `post_replies` (`reply_id`, `post_id`, `user_id`, `content`, `created_at`) VALUES
(1, 1, 10, 'Breathe slowly and practise out loud once. You will do great!', (CURDATE() - INTERVAL 5 DAY + INTERVAL 17 HOUR)),
(2, 1, 14, 'I do a short walk before presenting. It really calms me.', (CURDATE() - INTERVAL 5 DAY + INTERVAL 17 HOUR)),
(3, 3, 17, 'You are not alone, deadlines pile up for all of us. Take it one task at a time.', (CURDATE() - INTERVAL 4 DAY + INTERVAL 20 HOUR)),
(4, 3, 8, 'Sending you strength. Have you tried writing a short to-do list?', (CURDATE() - INTERVAL 3 DAY + INTERVAL 14 HOUR)),
(5, 4, 12, 'Thanks for sharing, I will try this today.', (CURDATE() - INTERVAL 3 DAY + INTERVAL 17 HOUR)),
(6, 5, 13, 'I am in! Message me when you are ready to start.', (CURDATE() - INTERVAL 2 DAY + INTERVAL 21 HOUR)),
(7, 6, 19, 'Sorry you are dealing with that. Maybe set clear roles at the start?', (CURDATE() - INTERVAL 1 DAY + INTERVAL 18 HOUR)),
(8, 6, 11, 'Same here. Clear deadlines per person helped our team.', (CURDATE() - INTERVAL 1 DAY + INTERVAL 21 HOUR)),
(9, 7, 8, 'Love this. Celebrating small wins is underrated.', (CURDATE() - INTERVAL 1 DAY + INTERVAL 12 HOUR)),
(10, 2, 9, 'Needed this today, thank you.', (CURDATE() - INTERVAL 4 DAY + INTERVAL 17 HOUR));

INSERT INTO `post_likes` (`like_id`, `post_id`, `user_id`, `created_at`) VALUES
(1, 1, 9, (CURDATE() - INTERVAL 2 DAY + INTERVAL 19 HOUR)),
(2, 1, 11, (CURDATE() - INTERVAL 4 DAY + INTERVAL 14 HOUR)),
(3, 1, 14, (CURDATE() - INTERVAL 5 DAY + INTERVAL 14 HOUR)),
(4, 1, 15, (CURDATE() - INTERVAL 0 DAY + INTERVAL 10 HOUR)),
(5, 2, 11, (CURDATE() - INTERVAL 3 DAY + INTERVAL 18 HOUR)),
(6, 2, 15, (CURDATE() - INTERVAL 4 DAY + INTERVAL 11 HOUR)),
(7, 4, 10, (CURDATE() - INTERVAL 3 DAY + INTERVAL 13 HOUR)),
(8, 4, 14, (CURDATE() - INTERVAL 2 DAY + INTERVAL 19 HOUR)),
(9, 4, 15, (CURDATE() - INTERVAL 3 DAY + INTERVAL 12 HOUR)),
(10, 5, 10, (CURDATE() - INTERVAL 0 DAY + INTERVAL 13 HOUR)),
(11, 5, 15, (CURDATE() - INTERVAL 2 DAY + INTERVAL 15 HOUR)),
(12, 6, 15, (CURDATE() - INTERVAL 3 DAY + INTERVAL 18 HOUR)),
(13, 7, 12, (CURDATE() - INTERVAL 1 DAY + INTERVAL 11 HOUR)),
(14, 7, 15, (CURDATE() - INTERVAL 5 DAY + INTERVAL 11 HOUR)),
(15, 7, 16, (CURDATE() - INTERVAL 3 DAY + INTERVAL 12 HOUR)),
(16, 7, 17, (CURDATE() - INTERVAL 5 DAY + INTERVAL 20 HOUR)),
(17, 7, 19, (CURDATE() - INTERVAL 1 DAY + INTERVAL 14 HOUR)),
(18, 8, 8, (CURDATE() - INTERVAL 5 DAY + INTERVAL 14 HOUR)),
(19, 8, 16, (CURDATE() - INTERVAL 5 DAY + INTERVAL 11 HOUR)),
(20, 8, 19, (CURDATE() - INTERVAL 0 DAY + INTERVAL 20 HOUR));

INSERT INTO `post_reports` (`report_id`, `post_id`, `user_id`, `reviewed`, `created_at`) VALUES
(1, 6, 11, 0, (CURDATE() - INTERVAL 1 DAY + INTERVAL 12 HOUR));

INSERT INTO `notifications` (`notification_id`, `user_id`, `type`, `title`, `message`, `is_read`, `created_at`) VALUES
(1, 8, 'booking_created', 'Counselling session booked', 'Your session with Dr. Naidoo has been booked.', 0, (CURDATE() - INTERVAL 21 DAY + INTERVAL 11 HOUR)),
(2, 16, 'booking_created', 'Counselling session booked', 'Your session with Mr. Pieter van der Merwe has been booked.', 0, (CURDATE() - INTERVAL 1 DAY + INTERVAL 11 HOUR)),
(3, 16, 'booking_created', 'Counselling session booked', 'Your session with Dr. Naidoo has been booked.', 1, (CURDATE() - INTERVAL 2 DAY + INTERVAL 11 HOUR)),
(4, 12, 'booking_created', 'Counselling session booked', 'Your session with Ms. Zanele Khumalo has been booked.', 0, (CURDATE() - INTERVAL 1 DAY + INTERVAL 11 HOUR)),
(5, 9, 'booking_created', 'Counselling session booked', 'Your session with Ms. Zanele Khumalo has been booked.', 0, (CURDATE() - INTERVAL 2 DAY + INTERVAL 11 HOUR)),
(6, 14, 'booking_cancelled', 'Counselling session cancelled', 'Your session with Dr. Aisha Patel was cancelled.', 1, (CURDATE() - INTERVAL 3 DAY + INTERVAL 11 HOUR)),
(7, 13, 'booking_cancelled', 'Counselling session cancelled', 'Your session with Mr. Sibusiso Dlamini was cancelled.', 0, (CURDATE() - INTERVAL 0 DAY + INTERVAL 11 HOUR)),
(8, 19, 'booking_created', 'Counselling session booked', 'Your session with Dr. Aisha Patel has been booked.', 0, (CURDATE() - INTERVAL 4 DAY + INTERVAL 11 HOUR)),
(9, 17, 'booking_created', 'Counselling session booked', 'Your session with Mr. Sibusiso Dlamini has been booked.', 1, (CURDATE() - INTERVAL 5 DAY + INTERVAL 11 HOUR)),
(10, 18, 'booking_created', 'Counselling session booked', 'Your session with Mr. Pieter van der Merwe has been booked.', 0, (CURDATE() - INTERVAL 4 DAY + INTERVAL 11 HOUR));

INSERT INTO `user_settings` (`user_id`, `dark_mode`, `booking_reminders`, `weekly_mood_email`) VALUES
(8, 1, 1, 1),
(10, 0, 1, 0),
(16, 1, 1, 1);

INSERT INTO `auditlog` (`log_id`, `actor_user_id`, `action`, `target_table`, `target_id`, `details`, `created_at`) VALUES
(1, 2, 'login_success', 'users', 2, 'Admin login successful.', (CURDATE() - INTERVAL 0 DAY + INTERVAL 8 HOUR)),
(2, 3, 'login_success', 'users', 3, 'Counsellor login successful.', (CURDATE() - INTERVAL 0 DAY + INTERVAL 9 HOUR)),
(3, NULL, 'login_failed', 'users', NULL, 'Failed login attempt for unknown@my.richfield.ac.za.', (CURDATE() - INTERVAL 1 DAY + INTERVAL 10 HOUR)),
(4, 4, 'login_success', 'users', 4, 'Counsellor login successful.', (CURDATE() - INTERVAL 1 DAY + INTERVAL 9 HOUR)),
(5, 8, 'login_success', 'users', 8, 'Student login successful.', (CURDATE() - INTERVAL 0 DAY + INTERVAL 7 HOUR)),
(6, 16, 'login_success', 'users', 16, 'Student login successful.', (CURDATE() - INTERVAL 0 DAY + INTERVAL 8 HOUR)),
(7, 12, 'login_success', 'users', 12, 'Student login successful.', (CURDATE() - INTERVAL 0 DAY + INTERVAL 9 HOUR)),
(8, 2, 'user_updated', 'users', 12, 'Admin updated user profile (qualification updated).', (CURDATE() - INTERVAL 2 DAY + INTERVAL 10 HOUR)),
(9, 2, 'report_exported', 'users', NULL, 'Exported monthly report as PDF.', (CURDATE() - INTERVAL 3 DAY + INTERVAL 11 HOUR)),
(10, 2, 'login_success', 'users', 2, 'Admin login successful.', (CURDATE() - INTERVAL 3 DAY + INTERVAL 8 HOUR)),
(11, 5, 'login_success', 'users', 5, 'Counsellor login successful.', (CURDATE() - INTERVAL 2 DAY + INTERVAL 10 HOUR)),
(12, 15, 'login_success', 'users', 15, 'Student login successful.', (CURDATE() - INTERVAL 1 DAY + INTERVAL 9 HOUR)),
(13, NULL, 'login_failed', 'users', NULL, 'Failed login attempt for admin@wrong.test.', (CURDATE() - INTERVAL 4 DAY + INTERVAL 22 HOUR)),
(14, 6, 'login_success', 'users', 6, 'Counsellor login successful.', (CURDATE() - INTERVAL 4 DAY + INTERVAL 9 HOUR)),
(15, 2, 'counsellor_created', 'users', 7, 'Admin created counsellor account for Mr. Sibusiso Dlamini.', (CURDATE() - INTERVAL 6 DAY + INTERVAL 13 HOUR)),
(16, 10, 'password_changed', 'users', 10, 'User changed their own password.', (CURDATE() - INTERVAL 5 DAY + INTERVAL 18 HOUR)),
(17, 17, 'login_success', 'users', 17, 'Student login successful.', (CURDATE() - INTERVAL 1 DAY + INTERVAL 16 HOUR));

INSERT INTO `risk_alerts` (`alert_id`, `user_id`, `source`, `source_id`, `severity`, `reason`, `status`, `handled_by`, `note`, `created_at`, `resolved_at`) VALUES
(1, 12, 'mood_checkin', 138, 'medium', 'Logged a "low" mood check-in recently.', 'resolved', 3, 'Followed up by phone; student booked a session and is coping better.', (CURDATE() - INTERVAL 9 DAY), (CURDATE() - INTERVAL 8 DAY)),
(2, 15, 'mood_checkin', 246, 'medium', 'Logged a "low" mood check-in recently.', 'resolved', 6, 'Checked in with student, shared campus support contacts.', (CURDATE() - INTERVAL 8 DAY), (CURDATE() - INTERVAL 6 DAY)),
(3, 11, 'mood_checkin', 105, 'medium', 'Logged a "low" mood check-in recently.', 'in_progress', 3, 'Reaching out to arrange a short chat.', (CURDATE() - INTERVAL 12 DAY), NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activities`
--
ALTER TABLE `activities`
  ADD PRIMARY KEY (`activity_id`),
  ADD KEY `idx_activities_user_date` (`user_id`,`created_at`);

--
-- Indexes for table `auditlog`
--
ALTER TABLE `auditlog`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `idx_auditlog_actor_date` (`actor_user_id`,`created_at`);

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`booking_id`),
  ADD KEY `idx_bookings_counsellor_slot` (`counsellor_id`,`session_date`,`session_time`),
  ADD KEY `idx_bookings_user_status` (`user_id`,`status`,`session_date`);

--
-- Indexes for table `counsellors`
--
ALTER TABLE `counsellors`
  ADD PRIMARY KEY (`counsellor_id`),
  ADD UNIQUE KEY `idx_counsellors_user` (`user_id`);

--
-- Indexes for table `journal_entries`
--
ALTER TABLE `journal_entries`
  ADD PRIMARY KEY (`entry_id`),
  ADD KEY `idx_journal_user_date` (`user_id`,`created_at`),
  ADD KEY `idx_journal_alert_tier` (`alert_tier`);

--
-- Indexes for table `mood_checkins`
--
ALTER TABLE `mood_checkins`
  ADD PRIMARY KEY (`checkin_id`),
  ADD UNIQUE KEY `uniq_user_day` (`user_id`,`checkin_date`),
  ADD KEY `idx_checkin_user_date` (`user_id`,`checkin_date`),
  ADD KEY `idx_mood_checkins_date_mood` (`checkin_date`,`mood`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`notification_id`),
  ADD KEY `idx_notifications_user` (`user_id`,`is_read`,`created_at`);

--
-- Indexes for table `password_reset_codes`
--
ALTER TABLE `password_reset_codes`
  ADD PRIMARY KEY (`reset_id`),
  ADD KEY `idx_prc_user` (`user_id`);

--
-- Indexes for table `platform_settings`
--
ALTER TABLE `platform_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`post_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `idx_posts_created` (`created_at`);

--
-- Indexes for table `post_likes`
--
ALTER TABLE `post_likes`
  ADD PRIMARY KEY (`like_id`),
  ADD UNIQUE KEY `uniq_post_user_like` (`post_id`,`user_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `post_replies`
--
ALTER TABLE `post_replies`
  ADD PRIMARY KEY (`reply_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `post_reports`
--
ALTER TABLE `post_reports`
  ADD PRIMARY KEY (`report_id`),
  ADD UNIQUE KEY `uniq_post_user_report` (`post_id`,`user_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `risk_alerts`
--
ALTER TABLE `risk_alerts`
  ADD PRIMARY KEY (`alert_id`),
  ADD UNIQUE KEY `uq_alert_source` (`source`,`source_id`),
  ADD KEY `fk_risk_alerts_user` (`user_id`),
  ADD KEY `fk_risk_alerts_handler` (`handled_by`);

--
-- Indexes for table `counsellor_notes`
--
ALTER TABLE `counsellor_notes`
  ADD PRIMARY KEY (`note_id`),
  ADD KEY `fk_notes_user` (`user_id`),
  ADD KEY `fk_notes_counsellor` (`counsellor_id`);

--
-- Indexes for table `resources`
--
ALTER TABLE `resources`
  ADD PRIMARY KEY (`resource_id`),
  ADD KEY `idx_resources_category` (`category`);

--
-- Indexes for table `riskalerts`
--
ALTER TABLE `riskalerts`
  ADD PRIMARY KEY (`alert_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `reviewed_by` (`reviewed_by`),
  ADD KEY `idx_riskalerts_status` (`status`,`created_at`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `uq_users_email` (`email`),
  ADD UNIQUE KEY `student_number` (`student_number`);

--
-- Indexes for table `user_settings`
--
ALTER TABLE `user_settings`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `weeklymoodsummary`
--
ALTER TABLE `weeklymoodsummary`
  ADD PRIMARY KEY (`summary_id`),
  ADD UNIQUE KEY `uniq_user_week` (`user_id`,`week_start`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activities`
--
ALTER TABLE `activities`
  MODIFY `activity_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auditlog`
--
ALTER TABLE `auditlog`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `booking_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `counsellors`
--
ALTER TABLE `counsellors`
  MODIFY `counsellor_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `journal_entries`
--
ALTER TABLE `journal_entries`
  MODIFY `entry_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `mood_checkins`
--
ALTER TABLE `mood_checkins`
  MODIFY `checkin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=414;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `notification_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `password_reset_codes`
--
ALTER TABLE `password_reset_codes`
  MODIFY `reset_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `post_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `post_likes`
--
ALTER TABLE `post_likes`
  MODIFY `like_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `post_replies`
--
ALTER TABLE `post_replies`
  MODIFY `reply_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `post_reports`
--
ALTER TABLE `post_reports`
  MODIFY `report_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `risk_alerts`
--
ALTER TABLE `risk_alerts`
  MODIFY `alert_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `counsellor_notes`
--
ALTER TABLE `counsellor_notes`
  MODIFY `note_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `resources`
--
ALTER TABLE `resources`
  MODIFY `resource_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `riskalerts`
--
ALTER TABLE `riskalerts`
  MODIFY `alert_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `weeklymoodsummary`
--
ALTER TABLE `weeklymoodsummary`
  MODIFY `summary_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `activities`
--
ALTER TABLE `activities`
  ADD CONSTRAINT `activities_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `auditlog`
--
ALTER TABLE `auditlog`
  ADD CONSTRAINT `auditlog_ibfk_1` FOREIGN KEY (`actor_user_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL;

--
-- Constraints for table `bookings`
--
ALTER TABLE `bookings`
  ADD CONSTRAINT `bookings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `bookings_ibfk_2` FOREIGN KEY (`counsellor_id`) REFERENCES `counsellors` (`counsellor_id`) ON DELETE CASCADE;

--
-- Constraints for table `counsellors`
--
ALTER TABLE `counsellors`
  ADD CONSTRAINT `counsellors_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL;

--
-- Constraints for table `journal_entries`
--
ALTER TABLE `journal_entries`
  ADD CONSTRAINT `journal_entries_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `mood_checkins`
--
ALTER TABLE `mood_checkins`
  ADD CONSTRAINT `fk_checkin_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `password_reset_codes`
--
ALTER TABLE `password_reset_codes`
  ADD CONSTRAINT `password_reset_codes_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `posts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `post_likes`
--
ALTER TABLE `post_likes`
  ADD CONSTRAINT `post_likes_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `posts` (`post_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `post_likes_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `post_replies`
--
ALTER TABLE `post_replies`
  ADD CONSTRAINT `post_replies_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `posts` (`post_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `post_replies_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `post_reports`
--
ALTER TABLE `post_reports`
  ADD CONSTRAINT `post_reports_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `posts` (`post_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `post_reports_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `risk_alerts` (note: distinct from the older,
-- unused `riskalerts` table below — see syncRiskAlerts() in demoAPI.php)
--
ALTER TABLE `risk_alerts`
  ADD CONSTRAINT `fk_risk_alerts_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_risk_alerts_handler` FOREIGN KEY (`handled_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL;

--
-- Constraints for table `counsellor_notes`
--
ALTER TABLE `counsellor_notes`
  ADD CONSTRAINT `fk_notes_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_notes_counsellor` FOREIGN KEY (`counsellor_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `riskalerts`
--
ALTER TABLE `riskalerts`
  ADD CONSTRAINT `riskalerts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `riskalerts_ibfk_2` FOREIGN KEY (`reviewed_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL;

--
-- Constraints for table `user_settings`
--
ALTER TABLE `user_settings`
  ADD CONSTRAINT `user_settings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `weeklymoodsummary`
--
ALTER TABLE `weeklymoodsummary`
  ADD CONSTRAINT `weeklymoodsummary_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
