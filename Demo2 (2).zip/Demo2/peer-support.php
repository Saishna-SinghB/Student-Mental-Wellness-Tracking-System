<?php require_once __DIR__ . '/auth-check.php'; ?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <script>
        if (localStorage.getItem("wellnesshub_dark_mode") === "1") {
            document.documentElement.classList.add("theme-pending-dark");
        }
    </script>

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Peer Support Board — WellnessHub</title>

    <link rel="stylesheet" href="css/style.css">

    <style>

        /* PEER SUPPORT */

        #feedTabs .tab-btn {
            cursor: pointer;
            background: transparent;
            border: none;
            border-bottom: 3px solid transparent;
            font: inherit;
            padding: 10px 14px;
            color: var(--muted, #9cb8d4);
            font-size: 13px;
        }

        #feedTabs .tab-btn.active {
            color: var(--green-700, #58b780);
            border-bottom-color: var(--green-700, #58b780);
            font-weight: bold;
        }

        .post-box .field > span {
            color: inherit;
            font-weight: bold;
        }

        #postContent {
            width: 100%;
            min-height: 120px;
            box-sizing: border-box;
        }

        .post-actions button {
            cursor: pointer;
            border: none;
            background: transparent;
            color: inherit;
            font: inherit;
            padding: 5px 8px;
        }

        .post-actions button.liked {
            color: #e87878;
            font-weight: bold;
        }

        .post-actions button:disabled {
            opacity: 0.5;
        }

        .reply-thread {
            margin-top: 10px;
            padding-top: 10px;
            border-top: 1px solid var(--line, #40546a);
            display: none;
        }

        .reply-item {
            font-size: 13px;
            color: var(--muted, #a8bfd5);
            margin-bottom: 8px;
        }

        .reply-input {
            display: flex;
            gap: 8px;
            margin-top: 8px;
        }

        .reply-input input {
            flex: 1;
            min-width: 0;
            padding: 8px 10px;
            border: 1px solid var(--line, #40546a);
            border-radius: 8px;
            font: inherit;
        }

        .peer-message {
            margin-top: 10px;
            font-size: 13px;
            font-weight: bold;
        }

        .peer-message.error {
            color: #f58b8b;
        }

        .peer-message.success {
            color: #77dba2;
        }

        /* EXTRA FEATURES SWITCH */

        .peer-dark-toggle {
            position: relative;
            display: inline-block;
            width: 65px;
            height: 35px;
            border: none;
            border-radius: 30px;
            background: #65758a;
            cursor: pointer;
            transition: background 0.3s;
            flex-shrink: 0;
        }

        .peer-dark-toggle::after {
            content: "";
            position: absolute;
            top: 4px;
            left: 4px;
            width: 27px;
            height: 27px;
            background: white;
            border-radius: 50%;
            transition: transform 0.3s;
        }

        .peer-dark-toggle.on,
        body.dark-body .peer-dark-toggle {
            background: #38895f;
        }

        .peer-dark-toggle.on::after,
        body.dark-body .peer-dark-toggle::after {
            transform: translateX(30px);
        }

    </style>

</head>

<body class="app-body">

<script src="js/theme.js"></script>
<script src="js/notif-badge.js"></script>

<div class="app-shell">

    <!-- SIDEBAR -->

    <aside class="sidebar student-sidebar">

        <a class="brand-mini sidebar-brand" href="index.php">
            <span class="mini-leaf" aria-hidden="true">☘</span>
            <span>WellnessHub</span>
        </a>

        <nav class="side-nav" aria-label="Student navigation">

            <a href="dashboard.php">
                <span>▣</span> Dashboard
            </a>

            <a href="mood-tracking.php">
                <span>☺</span> Mood Tracking
            </a>

            <a href="journal.php">
                <span>✎</span> Journal
            </a>

            <a href="self-help-library.php">
                <span>▤</span> Self-Help Library
            </a>

            <a href="counselling-booking.php">
                <span>♡</span> Book Counselling
            </a>

            <a class="active" href="peer-support.php">
                <span>☷</span> Peer Support
            </a>

            <a href="achievements.php">
                <span>★</span> Achievements
            </a>

            <a href="notifications.php">
                <span>🔔</span> Notifications
            </a>

            <a href="settings.php">
                <span>⚙</span> Settings
            </a>

            <a href="logout.php">
                <span>↪</span> Logout
            </a>

        </nav>

    </aside>

    <!-- MAIN CONTENT -->

    <main class="dashboard-main">

        <header class="topbar">

            <div>

                <p class="eyebrow">Student Side</p>

                <h1>Peer Support Board</h1>

                <p class="page-subtitle">
                    Share your thoughts anonymously.
                    You are not alone.
                </p>

            </div>

            <div class="topbar-actions">

                <a
                    class="icon-btn notif-bell"
                    href="notifications.php"
                    aria-label="Notifications">

                    🔔

                    <span
                        class="notif-dot"
                        id="notifDot"
                        style="display:none;">
                    </span>

                </a>

                <?php

                    $firstName = explode(
                        ' ',
                        $_SESSION['full_name'] ?? 'Student'
                    )[0];

                    $avatarStyle = !empty($_SESSION['profile_picture'])
                        ? ' style="background-image:url(\'' .
                          htmlspecialchars(
                              $_SESSION['profile_picture'],
                              ENT_QUOTES
                          ) .
                          '\'); background-size:cover; background-position:center;"'
                        : '';

                ?>

                <a
                    href="profile.php"
                    class="avatar"
                    aria-label="My Profile"
                    <?= $avatarStyle ?>>

                    <?= empty($_SESSION['profile_picture'])
                        ? htmlspecialchars(
                            strtoupper(substr($firstName, 0, 1))
                          )
                        : '' ?>

                </a>

            </div>

        </header>

        <section class="two-col">

            <!-- LEFT SIDE -->

            <div class="stack">

                <!-- CREATE POST -->

                <article class="panel post-box">

                    <div class="panel-heading">

                        <h2>Anonymous Peer Support Board</h2>

                        <span class="pill pill-green">
                            Moderated
                        </span>

                    </div>

                    <label class="field" for="postContent">

                        <span>What is on your mind?</span>

                        <textarea
                            id="postContent"
                            maxlength="2000"
                            placeholder="Share anonymously with the community..."></textarea>

                    </label>

                    <div
                        class="inline"
                        style="margin-top:8px;">

                        <select
                            id="postCategory"
                            class="btn btn-ghost btn-small"
                            aria-label="Post category">

                            <option value="Support">
                                Support
                            </option>

                            <option value="Vent">
                                Vent
                            </option>

                            <option value="Advice">
                                Advice
                            </option>

                            <option value="Encouragement">
                                Encouragement
                            </option>

                        </select>

                        <button
                            class="btn btn-primary"
                            type="button"
                            id="postBtn">

                            Post Anonymously

                        </button>

                    </div>

                    <p
                        class="peer-message"
                        id="postMessage"
                        role="status"
                        aria-live="polite">
                    </p>

                </article>

                <!-- POST FEED -->

                <article class="panel">

                    <div class="tabs" id="feedTabs">

                        <button
                            type="button"
                            class="tab-btn active"
                            data-tab="recent">

                            Recent

                        </button>

                        <button
                            type="button"
                            class="tab-btn"
                            data-tab="popular">

                            Popular

                        </button>

                        <button
                            type="button"
                            class="tab-btn"
                            data-tab="mine">

                            My Posts

                        </button>

                    </div>

                    <div
                        class="stack"
                        id="postFeed"
                        aria-live="polite">

                        <p class="muted">
                            Loading posts...
                        </p>

                    </div>

                </article>

            </div>

            <!-- RIGHT SIDE -->

            <aside class="extra-feature-stack">

                <!-- EXTRA FEATURES -->

                <div class="feature-card">

                    <div class="spread">

                        <strong>
                            Extra Features
                        </strong>

                        <button
                            type="button"
                            id="peerDarkModeBtn"
                            class="peer-dark-toggle"
                            role="switch"
                            aria-checked="false"
                            aria-label="Toggle Dark Mode"
                            onclick="togglePeerDarkMode()">
                        </button>

                    </div>

                    <p>
                        Turn Dark Mode on or off
                        for comfortable viewing.
                    </p>

                    <a
                        class="btn btn-small"
                        href="settings.php">

                        View Settings

                    </a>

                </div>

                <!-- WEEKLY MOOD SUMMARY -->

                <div class="feature-card purple-feature">

                    <strong>
                        Weekly Mood Summary
                    </strong>

                    <p>
                        View your weekly mood summary.
                    </p>

                    <a
                        class="btn btn-small"
                        href="weekly-summary.php">

                        View Example

                    </a>

                </div>

                <!-- HELP -->

                <div class="feature-card red-feature">

                    <strong>
                        Need Help Now?
                    </strong>

                    <p>
                        You are not alone.
                        Contact SADAG 24/7 Helpline.
                    </p>

                    <a
                        class="btn btn-small"
                        href="tel:0800567567">

                        Call Now

                    </a>

                </div>

            </aside>

        </section>

    </main>

</div>

<!-- PEER SUPPORT -->

<script src="js/peer-support.js"></script>

<!-- EXTRA FEATURES DARK MODE -->

<script>

function updatePeerDarkSwitch() {

    const button = document.getElementById('peerDarkModeBtn');

    if (!button) return;

    const isDark = document.body.classList.contains('dark-body');

    button.classList.toggle('on', isDark);

    button.setAttribute(
        'aria-checked',
        String(isDark)
    );

}


// TOGGLE DARK MODE

async function togglePeerDarkMode() {

    const currentlyDark =
        document.body.classList.contains('dark-body');

    const newMode = !currentlyDark;

    // Change the theme immediately
    if (
        window.WellnessHubTheme &&
        typeof window.WellnessHubTheme.applyTheme === 'function'
    ) {

        window.WellnessHubTheme.applyTheme(newMode);

    } else {

        alert('The theme.js file could not be loaded.');

        return;

    }

    // Save the local preference
    localStorage.setItem(
        'wellnesshub_dark_mode',
        newMode ? '1' : '0'
    );

    updatePeerDarkSwitch();


    // Save to the database

    try {

        const settingsResponse = await fetch(
            'api/demoAPI.php?action=settings_get'
        );

        const settingsResult = await settingsResponse.json();

        if (!settingsResponse.ok || !settingsResult.success) {

            throw new Error(
                settingsResult.message || 'Could not load settings.'
            );

        }

        const settings = settingsResult.data;

        const saveResponse = await fetch(
            'api/demoAPI.php?action=settings_update',
            {
                method: 'POST',

                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },

                body: new URLSearchParams({

                    dark_mode: newMode ? '1' : '0',

                    booking_reminders:
                        settings.booking_reminders ? '1' : '0',

                    weekly_mood_email:
                        settings.weekly_mood_email ? '1' : '0'

                })
            }
        );

        const saveResult = await saveResponse.json();

        if (!saveResponse.ok || !saveResult.success) {

            throw new Error(
                saveResult.message || 'Could not save settings.'
            );

        }

    } catch (error) {

        console.error('Dark Mode save error:', error);

        alert(
            'Dark Mode changed, but could not be saved. ' +
            'It may reset when you refresh the page.'
        );

    }

}


// KEEP SWITCH SYNCHRONIZED WITH THE THEME

document.addEventListener('DOMContentLoaded', () => {

    updatePeerDarkSwitch();

    const observer = new MutationObserver(() => {

        updatePeerDarkSwitch();

    });

    observer.observe(document.body, {

        attributes: true,

        attributeFilter: ['class']

    });

});

</script>

</body>

</html>