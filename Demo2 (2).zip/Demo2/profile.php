
<?php require_once __DIR__ . '/auth-check.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>My Profile — WellnessHub</title>
  <link rel="stylesheet" href="css/style.css" />

  <style>

    /* SMALLER CENTERED PROFILE CARD */
    .dashboard-main > .profile-panel {
      width: 100%;
      max-width: 620px;
      margin: 25px auto 0;
      padding: 30px;
      box-sizing: border-box;
    }

    /* PROFILE PICTURE SECTION */
    .profile-picture-wrap {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 12px;
      padding: 15px 0 22px;
      text-align: center;
    }

    /* SMALLER PROFILE AVATAR */
    .profile-avatar {
      width: 160px;
      height: 160px;
      border-radius: 50%;
      object-fit: cover;
      background: #4b73d9;
      color: #ffffff;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 58px;
      font-weight: 800;
      overflow: hidden;
    }

    /* STUDENT INFORMATION */
    .profile-field {
      margin-bottom: 22px;
    }

    .profile-field span {
      display: block;
      font-size: 13px;
      font-weight: 800;
      color: var(--muted);
      text-transform: uppercase;
      letter-spacing: .04em;
      margin-bottom: 6px;
    }

    .profile-field strong {
      font-size: 18px;
      font-weight: 700;
      overflow-wrap: anywhere;
    }

    /* UPLOAD AND REMOVE BUTTONS */
    .profile-picture-wrap .inline {
      display: flex;
      align-items: center;
      justify-content: center;
      flex-wrap: wrap;
      gap: 10px;
    }

    /* PROFILE MESSAGES */
    .profile-message {
      font-size: 13px;
      font-weight: 700;
      margin-top: 8px;
    }

    .profile-message.error {
      color: #c44848;
    }

    .profile-message.success {
      color: #2f744d;
    }

    /* RESPONSIVE DESIGN */
    @media (max-width: 768px) {

      .dashboard-main > .profile-panel {
        width: 100%;
        max-width: 100%;
        margin: 20px auto 0;
        padding: 22px;
      }

      .profile-avatar {
        width: 130px;
        height: 130px;
        font-size: 48px;
      }

      .profile-field strong {
        font-size: 16px;
      }

      .profile-field span {
        font-size: 12px;
      }

    }

  </style>
</head>

<body class="app-body">

  <script src="js/theme.js"></script>

  <div class="app-shell">

    <!-- STUDENT SIDEBAR -->
    <aside class="sidebar student-sidebar">

      <a class="brand-mini sidebar-brand" href="index.php">
        <span class="mini-leaf" aria-hidden="true">☘</span>
        <span>WellnessHub</span>
      </a>

      <nav class="side-nav" aria-label="Student navigation">

        <a href="dashboard.php">
          <span>▣</span> Dashboard
        </a>

        <a href="mood-tracking.php">
          <span>☺</span> Mood Tracking
        </a>

        <a href="journal.php">
          <span>✎</span> Journal
        </a>

        <a href="self-help-library.php">
          <span>▤</span> Self-Help Library
        </a>

        <a href="counselling-booking.php">
          <span>♡</span> Book Counselling
        </a>

        <a href="peer-support.php">
          <span>☷</span> Peer Support
        </a>

        <a href="achievements.php">
          <span>★</span> Achievements
        </a>

        <a href="notifications.php">
          <span>🔔</span> Notifications
        </a>

        <a href="settings.php">
          <span>⚙</span> Settings
        </a>

        <a href="logout.php">
          <span>↪</span> Logout
        </a>

      </nav>

    </aside>

    <!-- MAIN CONTENT -->
    <main class="dashboard-main">

      <!-- HEADER -->
      <header class="topbar">

        <div>
          <p class="eyebrow">Student Side</p>
          <h1>My Profile</h1>
          <p class="page-subtitle">
            Your account details and profile picture.
          </p>
        </div>

        <div class="topbar-actions">

          <!-- NOTIFICATIONS -->
          <a
            class="icon-btn"
            href="notifications.php"
            aria-label="Notifications"
          >
            🔔
          </a>

          <!-- STUDENT INITIAL -->
          <?php
            $firstName = explode(' ', $_SESSION['full_name'])[0];

            $initial = htmlspecialchars(
              strtoupper(substr($firstName, 0, 1))
            );
          ?>

          <div class="avatar">
            <?= $initial ?>
          </div>

        </div>

      </header>

      <!-- CENTERED PROFILE CARD -->
      <section class="panel profile-panel">

        <!-- PROFILE PICTURE -->
        <div class="profile-picture-wrap">

          <div
            id="avatarPreview"
            class="profile-avatar"
          >
            <?= $initial ?>
          </div>

          <!-- HIDDEN FILE INPUT -->
          <input
            type="file"
            id="pictureInput"
            accept="image/png,image/jpeg,image/gif,image/webp"
            style="display:none;"
          />

          <!-- PICTURE BUTTONS -->
          <div class="inline">

            <button
              class="btn btn-ghost btn-small"
              type="button"
              id="uploadBtn"
            >
              Upload Picture
            </button>

            <button
              class="btn btn-ghost btn-small"
              type="button"
              id="removeBtn"
              style="display:none;"
            >
              Remove Picture
            </button>

          </div>

          <!-- UPLOAD MESSAGE -->
          <p
            id="pictureMessage"
            class="profile-message"
            aria-live="polite"
          ></p>

        </div>

        <!-- FULL NAME -->
        <div class="profile-field">

          <span>Full Name</span>

          <strong id="profileFullName">
            Loading…
          </strong>

        </div>

        <!-- STUDENT NUMBER -->
        <div class="profile-field">

          <span>Student Number</span>

          <strong id="profileStudentNumber">
            Loading…
          </strong>

        </div>

        <!-- EMAIL ADDRESS -->
        <div class="profile-field">

          <span>Email Address</span>

          <strong id="profileEmail">
            Loading…
          </strong>

        </div>

        <!-- GENDER -->
        <div class="profile-field">

          <span>Gender</span>

          <strong id="profileGender">
            Loading…
          </strong>

        </div>

      </section>

    </main>

  </div>

  <!-- PROFILE JAVASCRIPT -->
  <script src="js/profile.js"></script>

</body>
</html>
