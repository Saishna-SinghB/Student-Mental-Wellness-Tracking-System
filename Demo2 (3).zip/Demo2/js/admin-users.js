// admin-users.js — loaded by admin-users.php

let allUsers = [];

function formatLastLogin(datetime) {
  if (!datetime) return 'Never';

  const d = new Date(datetime.replace(' ', 'T'));
  const today = new Date();

  if (d.toDateString() === today.toDateString()) {
    return 'Today';
  }

  const yesterday = new Date(today);
  yesterday.setDate(yesterday.getDate() - 1);

  if (d.toDateString() === yesterday.toDateString()) {
    return 'Yesterday';
  }

  return d.toLocaleDateString('default', {
    day: 'numeric',
    month: 'short',
    year: 'numeric'
  });
}

function statusPill(isActive) {
  return isActive
    ? '<span class="pill pill-green">Active</span>'
    : '<span class="pill pill-red">Suspended</span>';
}

function roleLabel(role) {
  return role.charAt(0).toUpperCase() + role.slice(1);
}

// DISPLAY USERS
function renderUsers(users) {
  const tbody = document.getElementById('usersTableBody');
  tbody.innerHTML = '';

  if (users.length === 0) {
    tbody.innerHTML =
      '<tr><td colspan="6" class="muted">No users found.</td></tr>';
    return;
  }

  users.forEach(u => {
    const tr = document.createElement('tr');

    // PROFILE PICTURE
    const avatarTd = document.createElement('td');
    const avatarEl = document.createElement('div');

    avatarEl.className = 'avatar';
    avatarEl.style.cursor = 'pointer';
    avatarEl.title = 'View / edit this user';

    if (u.profile_picture) {
      avatarEl.style.backgroundImage = `url("${u.profile_picture}")`;
      avatarEl.style.backgroundSize = 'cover';
      avatarEl.style.backgroundPosition = 'center';
    } else {
      avatarEl.textContent =
        u.full_name.trim().charAt(0).toUpperCase();
    }

    avatarEl.addEventListener('click', () => openEditModal(u));
    avatarTd.appendChild(avatarEl);

    // NAME
    const nameTd = document.createElement('td');
    nameTd.textContent = u.full_name;

    // ROLE
    const roleTd = document.createElement('td');
    roleTd.textContent = roleLabel(u.role);

    // STATUS
    const statusTd = document.createElement('td');
    statusTd.innerHTML = statusPill(u.is_active);

    // LAST LOGIN
    const lastLoginTd = document.createElement('td');
    lastLoginTd.textContent = formatLastLogin(u.last_login_at);

    // EDIT BUTTON
    const actionTd = document.createElement('td');
    const editBtn = document.createElement('button');

    editBtn.className = 'btn btn-ghost btn-small';
    editBtn.textContent = 'Edit';

    editBtn.addEventListener('click', () => openEditModal(u));
    actionTd.appendChild(editBtn);

    tr.appendChild(avatarTd);
    tr.appendChild(nameTd);
    tr.appendChild(roleTd);
    tr.appendChild(statusTd);
    tr.appendChild(lastLoginTd);
    tr.appendChild(actionTd);

    tbody.appendChild(tr);
  });
}

// LOAD USERS
async function loadUsers(query) {
  const tbody = document.getElementById('usersTableBody');

  tbody.innerHTML =
    '<tr><td colspan="6" class="muted">Loading users…</td></tr>';

  try {
    const url =
      'api/demoAPI.php?action=admin_user_list' +
      (query ? '&q=' + encodeURIComponent(query) : '');

    const res = await fetch(url);
    const data = await res.json();

    if (!data.success) {
      const tr = document.createElement('tr');
      const td = document.createElement('td');
      td.colSpan = 6;
      td.className = 'muted';
      td.textContent = data.message || 'Could not load users.';
      tr.appendChild(td);
      tbody.replaceChildren(tr);
      return;
    }

    allUsers = data.data.users;
    renderUsers(allUsers);

  } catch (err) {
    tbody.innerHTML =
      '<tr><td colspan="6" class="muted">Could not reach the server.</td></tr>';
  }
}

// ADD USER MODAL
function toggleStudentField() {
  const role = document.getElementById('newRole').value;
  const isStudent = role === 'student';

  document.getElementById('studentNumberField').style.display =
    isStudent ? '' : 'none';

  document.getElementById('newUserHint').textContent =
    isStudent
      ? 'Student email must be studentnumber@my.richfield.ac.za'
      : role === 'counsellor'
        ? 'Counsellors can use any email address (external counsellors are fine). Password must start with "123".'
        : '';
}

function openAddModal() {
  document.getElementById('newFullName').value = '';
  document.getElementById('newRole').value = 'student';
  document.getElementById('newStudentNumber').value = '';
  document.getElementById('newEmail').value = '';
  document.getElementById('newPassword').value = '';
  document.getElementById('addUserMessage').textContent = '';

  toggleStudentField();

  document.getElementById('addUserModal').style.display = 'flex';
}

// CREATE USER
async function submitAddUser() {
  const msg = document.getElementById('addUserMessage');

  msg.className = 'forgot-message';
  msg.textContent = '';

  const body = new URLSearchParams({
    full_name: document.getElementById('newFullName').value.trim(),
    role: document.getElementById('newRole').value,
    student_number: document.getElementById('newStudentNumber').value.trim(),
    email: document.getElementById('newEmail').value.trim(),
    password: document.getElementById('newPassword').value
  });

  try {
    const res = await fetch(
      'api/demoAPI.php?action=admin_user_create',
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        body
      }
    );

    const data = await res.json();

    if (!data.success) {
      msg.classList.add('error');
      msg.textContent = data.message;
      return;
    }

    document.getElementById('addUserModal').style.display = 'none';

    loadUsers(
      document.getElementById('userSearch').value.trim()
    );

  } catch (err) {
    msg.classList.add('error');
    msg.textContent = 'Could not reach the server.';
  }
}

// EDIT USER
let editingUserId = null;

function toggleEditStudentField() {
  const isStudent =
    document.getElementById('editRole').value === 'student';

  document.getElementById('editStudentNumberField').style.display =
    isStudent ? '' : 'none';

  document.getElementById('editQualificationField').style.display =
    isStudent ? '' : 'none';
}

function openEditModal(user) {
  editingUserId = user.user_id;

  const avatar = document.getElementById('editAvatarPreview');

  if (user.profile_picture) {
    avatar.style.backgroundImage = `url("${user.profile_picture}")`;
    avatar.style.backgroundSize = 'cover';
    avatar.style.backgroundPosition = 'center';
    avatar.textContent = '';
  } else {
    avatar.style.backgroundImage = 'none';
    avatar.textContent =
      user.full_name.trim().charAt(0).toUpperCase();
  }

  document.getElementById('editFullName').value = user.full_name;
  document.getElementById('editEmail').value = user.email;

  document.getElementById('editStudentNumber').value =
    user.student_number || '';

  document.getElementById('editGender').value =
    user.gender || 'Prefer not to say';

  document.getElementById('editQualification').value =
    user.qualification || '';

  document.getElementById('editRole').value = user.role;

  document.getElementById('editActive').value =
    user.is_active ? '1' : '0';

  document.getElementById('editUserMessage').textContent = '';
  document.getElementById('deleteUserMessage').textContent = '';

  toggleEditStudentField();

  document.getElementById('editUserModal').style.display = 'flex';
}

// SAVE USER CHANGES
async function submitEditUser() {
  const msg = document.getElementById('editUserMessage');

  msg.className = 'forgot-message';
  msg.textContent = '';

  const body = new URLSearchParams({
    user_id: editingUserId,
    full_name: document.getElementById('editFullName').value.trim(),
    email: document.getElementById('editEmail').value.trim(),
    student_number:
      document.getElementById('editStudentNumber').value.trim(),
    gender: document.getElementById('editGender').value,
    qualification:
      document.getElementById('editRole').value === 'student'
        ? document.getElementById('editQualification').value
        : '',
    role: document.getElementById('editRole').value,
    is_active: document.getElementById('editActive').value
  });

  try {
    const res = await fetch(
      'api/demoAPI.php?action=admin_user_update',
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        body
      }
    );

    const data = await res.json();

    if (!data.success) {
      msg.classList.add('error');
      msg.textContent = data.message;
      return;
    }

    document.getElementById('editUserModal').style.display = 'none';

    loadUsers(
      document.getElementById('userSearch').value.trim()
    );

  } catch (err) {
    msg.classList.add('error');
    msg.textContent = 'Could not reach the server.';
  }
}

// PAGE BUTTONS
document.addEventListener('DOMContentLoaded', () => {

  loadUsers('');

  // SEARCH USERS
  let searchTimer;

  document.getElementById('userSearch').addEventListener(
    'input',
    (e) => {
      clearTimeout(searchTimer);

      searchTimer = setTimeout(
        () => loadUsers(e.target.value.trim()),
        300
      );
    }
  );

  // ADD USER
  document.getElementById('addUserBtn').addEventListener(
    'click',
    openAddModal
  );

  document.getElementById('cancelAddUser').addEventListener(
    'click',
    () => {
      document.getElementById('addUserModal').style.display = 'none';
    }
  );

  document.getElementById('submitAddUser').addEventListener(
    'click',
    submitAddUser
  );

  document.getElementById('newRole').addEventListener(
    'change',
    toggleStudentField
  );

  // EDIT USER
  document.getElementById('cancelEditUser').addEventListener(
    'click',
    () => {
      document.getElementById('editUserModal').style.display = 'none';
    }
  );

  document.getElementById('submitEditUser').addEventListener(
    'click',
    submitEditUser
  );

  document.getElementById('editRole').addEventListener(
    'change',
    toggleEditStudentField
  );

  // DELETE USER
  document.getElementById('deleteUserBtn').addEventListener(
    'click',
    async () => {
      const msg = document.getElementById('deleteUserMessage');

      msg.className = 'forgot-message';
      msg.textContent = '';

      const name = document.getElementById('editFullName').value;
      const role = document.getElementById('editRole').value;

      const warning = role === 'student'
        ? `Permanently delete ${name}? This will also delete all of their mood check-ins, journal entries, posts, and bookings. This cannot be undone.`
        : `Permanently delete ${name}'s account? Their profile and history will stay intact, but they will no longer be able to log in.`;

      if (!confirm(warning)) return;

      try {
        const res = await fetch(
          'api/demoAPI.php?action=admin_user_delete',
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: new URLSearchParams({
              user_id: editingUserId
            })
          }
        );

        const data = await res.json();

        if (!data.success) {
          msg.classList.add('error');
          msg.textContent = data.message;
          return;
        }

        document.getElementById('editUserModal').style.display = 'none';

        loadUsers(
          document.getElementById('userSearch').value.trim()
        );

      } catch (err) {
        msg.classList.add('error');
        msg.textContent = 'Could not reach the server.';
      }
    }
  );

});