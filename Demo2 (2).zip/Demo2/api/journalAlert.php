<?php
require_once __DIR__ . '/threatLexicon.php';

function saveJournalWithAlert(PDO $pdo, int $userId, string $content, ?string $emotion): array {
    $alertTier = screenJournalText($content) ? 'critical' : 'normal';

    $stmt = $pdo->prepare('
        INSERT INTO journal_entries (user_id, content, emotion, alert_tier)
        VALUES (:user_id, :content, :emotion, :alert_tier)
    ');
    $stmt->execute([
        ':user_id' => $userId,
        ':content' => $content,
        ':emotion' => $emotion,
        ':alert_tier' => $alertTier,
    ]);

    $entryId = (int) $pdo->lastInsertId();

    // Use the database's own timestamp so what the student sees now matches
    // what the list shows later (PHP and MySQL can be in different timezones).
    $stmt = $pdo->prepare('SELECT created_at FROM journal_entries WHERE entry_id = :id');
    $stmt->execute([':id' => $entryId]);
    $createdAt = $stmt->fetchColumn() ?: date('Y-m-d H:i:s');

    // Raise the counsellor alert immediately, instead of waiting for a
    // counsellor to open a page. If this fails the entry is still saved, and
    // syncCriticalJournalAlerts() will create the alert on the next sync.
    if ($alertTier === 'critical') {
        try {
            $stmt = $pdo->prepare('
                INSERT INTO risk_alerts (user_id, source, source_id, severity, reason)
                VALUES (:user_id, "journal_entry", :source_id, "high", :reason)
                ON DUPLICATE KEY UPDATE severity = VALUES(severity), reason = VALUES(reason)
            ');
            $stmt->execute([
                ':user_id' => $userId,
                ':source_id' => $entryId,
                ':reason' => 'Journal entry from ' . date('Y-m-d', strtotime($createdAt)) . ' was placed in the critical alert tier by the screening engine.',
            ]);
        } catch (Throwable $e) {
            error_log('Could not create the critical journal alert immediately: ' . $e->getMessage());
        }
    }

    return [
        'entry_id' => $entryId,
        'content' => $content,
        'emotion' => $emotion,
        'created_at' => $createdAt,
        'crisis_alert' => $alertTier === 'critical',
    ];
}

function syncCriticalJournalAlerts(PDO $pdo): void {
    $rows = $pdo->query("
        SELECT entry_id, user_id, created_at
        FROM journal_entries
        WHERE alert_tier = 'critical'
          AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
    ")->fetchAll();

    $insert = $pdo->prepare('
        INSERT INTO risk_alerts (user_id, source, source_id, severity, reason)
        VALUES (:user_id, "journal_entry", :source_id, "high", :reason)
        ON DUPLICATE KEY UPDATE severity = VALUES(severity), reason = VALUES(reason)
    ');

    foreach ($rows as $row) {
        $insert->execute([
            ':user_id' => $row['user_id'],
            ':source_id' => $row['entry_id'],
            ':reason' => 'Journal entry from ' . date('Y-m-d', strtotime($row['created_at'])) . ' was placed in the critical alert tier by the screening engine.',
        ]);
    }
}
