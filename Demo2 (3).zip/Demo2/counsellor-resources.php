<?php
require_once __DIR__ . '/counsellor-auth.php';

$dbHost = '127.0.0.1';
$dbPort = '3307';
$dbName = 'wellnesshub';
$dbUser = 'root';
$dbPass = '';

function h($value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

$categories = [
    'Mental Health', 'Stress Management', 'Anxiety Support',
    'Depression Support', 'Academic Support', 'Counselling',
    'Crisis Support', 'Peer Support', 'Other'
];

$icons = [
    'Mental Health' => '🧠',
    'Stress Management' => '🌿',
    'Anxiety Support' => '💙',
    'Depression Support' => '🌻',
    'Academic Support' => '🎓',
    'Counselling' => '🤝',
    'Crisis Support' => '☎',
    'Peer Support' => '👥',
    'Other' => '📘'
];

if (empty($_SESSION['toolkit_csrf'])) {
    $_SESSION['toolkit_csrf'] = bin2hex(random_bytes(32));
}

$pdo = null;
$error = '';
$resources = [];
$profilePicture = '';
$showEditor = false;

try {
    $pdo = new PDO(
        "mysql:host=$dbHost;port=$dbPort;dbname=$dbName;charset=utf8mb4",
        $dbUser,
        $dbPass,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
        ]
    );

    $pdo->exec("CREATE TABLE IF NOT EXISTS counsellor_toolkit_resources (
        resource_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(150) NOT NULL,
        category VARCHAR(60) NOT NULL,
        description VARCHAR(350) NOT NULL,
        content TEXT NOT NULL,
        resource_url VARCHAR(2048) NULL,
        pdf_name VARCHAR(255) NULL,
        pdf_data MEDIUMBLOB NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    foreach ([
        'pdf_name' => 'VARCHAR(255) NULL',
        'pdf_data' => 'MEDIUMBLOB NULL'
    ] as $column => $definition) {
        $check = $pdo->query(
            "SHOW COLUMNS FROM counsellor_toolkit_resources LIKE " .
            $pdo->quote($column)
        );

        if (!$check->fetch()) {
            $pdo->exec(
                "ALTER TABLE counsellor_toolkit_resources ADD COLUMN $column $definition"
            );
        }
    }

    // Load the counsellor's saved picture.
    $stmt = $pdo->prepare(
        "SELECT profile_picture FROM users
         WHERE user_id = ? AND role = 'counsellor' LIMIT 1"
    );

    $stmt->execute([$_SESSION['user_id']]);
    $account = $stmt->fetch();

    if ($account) {
        $profilePicture = (string)($account['profile_picture'] ?? '');
        $_SESSION['profile_picture'] = $profilePicture;
    }

} catch (PDOException $e) {
    error_log($e->getMessage());
    $error = 'Database connection failed. Check XAMPP and MySQL port 3307.';
    $profilePicture = (string)($_SESSION['profile_picture'] ?? '');
    $pdo = null;
}

// Download a saved resource PDF.
if (isset($_GET['download'])) {
    $id = filter_var($_GET['download'], FILTER_VALIDATE_INT);

    if (!$pdo || !$id || $id < 1) {
        http_response_code(404);
        exit('PDF not found.');
    }

    $stmt = $pdo->prepare(
        'SELECT pdf_name, pdf_data
         FROM counsellor_toolkit_resources WHERE resource_id = ?'
    );

    $stmt->execute([$id]);
    $pdf = $stmt->fetch();

    if (!$pdf || !$pdf['pdf_name'] || $pdf['pdf_data'] === null) {
        http_response_code(404);
        exit('PDF not found.');
    }

    $filename = preg_replace(
        '/[^A-Za-z0-9._-]/',
        '_',
        basename($pdf['pdf_name'])
    );

    header('Content-Type: application/pdf');
    header('X-Content-Type-Options: nosniff');
    header('Cache-Control: private, no-store');
    header('Content-Disposition: attachment; filename="' . $filename . '"');

    echo $pdf['pdf_data'];
    exit;
}

// Add, edit or delete a resource.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = (string)($_POST['resource_action'] ?? '');
    $id = filter_var($_POST['resource_id'] ?? null, FILTER_VALIDATE_INT);
    $showEditor = $action !== 'delete';

    if (!hash_equals(
        $_SESSION['toolkit_csrf'],
        (string)($_POST['csrf_token'] ?? '')
    )) {
        $error = 'Session expired. Refresh the page and try again.';
    } elseif (!$pdo) {
        $error = 'Database is unavailable.';
    } elseif (!in_array($action, ['add', 'edit', 'delete'], true)) {
        $error = 'Invalid action.';
    } elseif ($action !== 'add' && (!$id || $id < 1)) {
        $error = 'Invalid resource.';
    } elseif ($action === 'delete') {
        try {
            $stmt = $pdo->prepare(
                'DELETE FROM counsellor_toolkit_resources WHERE resource_id = ?'
            );
            $stmt->execute([$id]);

            header('Location: counsellor-resources.php?status=deleted');
            exit;
        } catch (PDOException $e) {
            error_log($e->getMessage());
            $error = 'Could not delete resource.';
        }
    } else {
        $title = trim((string)($_POST['title'] ?? ''));
        $category = (string)($_POST['category'] ?? '');
        $description = trim((string)($_POST['description'] ?? ''));
        $content = trim((string)($_POST['content'] ?? ''));
        $url = trim((string)($_POST['resource_url'] ?? ''));

        $file = $_FILES['resource_pdf'] ?? null;
        $hasFile = is_array($file) &&
            ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE;

        $pdfName = null;
        $pdfData = null;

        if ($title === '' || $description === '' || $content === '') {
            $error = 'Complete all required fields.';
        } elseif (
            strlen($title) > 150 ||
            strlen($description) > 350 ||
            strlen($content) > 15000
        ) {
            $error = 'One of the fields is too long.';
        } elseif (!in_array($category, $categories, true)) {
            $error = 'Select a valid category.';
        } elseif (
            $url !== '' &&
            (
                strlen($url) > 2048 ||
                !filter_var($url, FILTER_VALIDATE_URL) ||
                !in_array(
                    strtolower((string)parse_url($url, PHP_URL_SCHEME)),
                    ['http', 'https'],
                    true
                )
            )
        ) {
            $error = 'Enter a valid website URL.';
        } elseif ($hasFile) {
            if (
                ($file['error'] ?? null) !== UPLOAD_ERR_OK ||
                !is_uploaded_file($file['tmp_name']) ||
                $file['size'] < 1 ||
                $file['size'] > 5 * 1024 * 1024
            ) {
                $error = 'Choose a PDF smaller than 5 MB.';
            } else {
                $pdfName = basename((string)$file['name']);
                $mime = (new finfo(FILEINFO_MIME_TYPE))
                    ->file($file['tmp_name']);

                $signature = file_get_contents(
                    $file['tmp_name'],
                    false,
                    null,
                    0,
                    5
                );

                if (
                    strtolower(pathinfo($pdfName, PATHINFO_EXTENSION)) !== 'pdf' ||
                    !in_array($mime, ['application/pdf', 'application/x-pdf'], true) ||
                    $signature !== '%PDF-'
                ) {
                    $error = 'Please select a valid PDF.';
                } else {
                    $pdfData = file_get_contents($file['tmp_name']);

                    if ($pdfData === false) {
                        $error = 'Could not read the PDF.';
                    }
                }
            }
        }

        if ($error === '') {
            try {
                if ($action === 'add') {
                    $stmt = $pdo->prepare(
                        'INSERT INTO counsellor_toolkit_resources
                        (title, category, description, content,
                         resource_url, pdf_name, pdf_data)
                         VALUES (?, ?, ?, ?, ?, ?, ?)'
                    );

                    $stmt->execute([
                        $title, $category, $description, $content,
                        $url ?: null, $pdfName, $pdfData
                    ]);
                } else {
                    $check = $pdo->prepare(
                        'SELECT resource_id FROM counsellor_toolkit_resources
                         WHERE resource_id = ?'
                    );
                    $check->execute([$id]);

                    if (!$check->fetch()) {
                        throw new RuntimeException('Resource not found.');
                    }

                    $sql = 'UPDATE counsellor_toolkit_resources SET
                        title = ?, category = ?, description = ?,
                        content = ?, resource_url = ?';

                    $params = [
                        $title, $category, $description,
                        $content, $url ?: null
                    ];

                    if ($hasFile) {
                        $sql .= ', pdf_name = ?, pdf_data = ?';
                        $params[] = $pdfName;
                        $params[] = $pdfData;
                    } elseif (isset($_POST['remove_pdf'])) {
                        $sql .= ', pdf_name = NULL, pdf_data = NULL';
                    }

                    $sql .= ' WHERE resource_id = ?';
                    $params[] = $id;

                    $pdo->prepare($sql)->execute($params);
                }

                header(
                    'Location: counsellor-resources.php?status=' .
                    ($action === 'add' ? 'added' : 'updated')
                );
                exit;

            } catch (Throwable $e) {
                error_log($e->getMessage());
                $error = 'Could not save resource.';
            }
        }
    }
}

// Load resources.
if ($pdo) {
    try {
        $resources = $pdo->query(
            'SELECT resource_id, title, category, description,
                    content, resource_url, pdf_name
             FROM counsellor_toolkit_resources
             ORDER BY resource_id DESC'
        )->fetchAll();
    } catch (PDOException $e) {
        error_log($e->getMessage());
        $error = 'Could not load resources.';
    }
}

// Profile picture.
$initial = strtoupper(
    substr(trim((string)($_SESSION['full_name'] ?? 'Counsellor')), 0, 1)
);

$hasPhoto = preg_match(
    '#^data:image/(?:jpeg|png|gif|webp);base64,[A-Za-z0-9+/=]+$#D',
    $profilePicture
) === 1;

$avatarStyle = $hasPhoto
    ? 'background-image:url(\'' . h($profilePicture) .
      '\');background-size:cover;background-position:center;'
    : '';

$messages = [
    'added' => 'Resource added successfully.',
    'updated' => 'Resource updated successfully.',
    'deleted' => 'Resource deleted successfully.'
];

$status = (string)($_GET['status'] ?? '');

function displayResourceGuide(string $content): void {
    $lines = preg_split('/\R/u', trim($content)) ?: [];

    echo '<div class="saved-sections">';

    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === '') continue;

        if (preg_match('/^(\d+)[.)]\s+(.+)$/u', $line, $match)) {
            echo '<h4>' . h($match[1] . '. ' . $match[2]) . '</h4>';
        } else {
            echo '<p>' . h($line) . '</p>';
        }
    }

    echo '</div>';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Counsellor Resources — WellnessHub</title>
<link rel="stylesheet" href="css/style.css">

<style>
.tool-controls{display:flex;gap:12px;margin:18px 0;flex-wrap:wrap}
.tool-controls input,.tool-controls select,.resource-editor input,
.resource-editor select,.resource-editor textarea{
    background:#0d192b;border:1px solid #405576;color:#f0f6ff;
    padding:12px;border-radius:9px;font:inherit;box-sizing:border-box
}
.tool-controls input{flex:2;min-width:220px}
.tool-controls select{flex:1;min-width:180px}
.resource-editor{
    display:none;padding:24px;border:1px solid #345475;
    background:#122239;border-radius:14px;margin:18px 0
}
.resource-editor.open{display:block}
.resource-editor h3{color:#fff}
.resource-editor label{
    display:block;margin:15px 0 7px;color:#d9e6f7;font-weight:700
}
.resource-editor input,.resource-editor select,.resource-editor textarea{
    width:100%
}
.resource-editor input[type=checkbox]{width:auto}
.resource-editor textarea{min-height:100px;resize:vertical}
.resource-editor textarea[name=content]{min-height:180px}
.editor-actions,.item-actions,.referral-actions{
    display:flex;gap:12px;flex-wrap:wrap;margin-top:18px
}
.editor-actions button,.item-actions button,.referral-actions button{
    border:0;border-radius:9px;padding:12px 17px;
    color:#fff;font-weight:700;cursor:pointer
}
.save-resource{background:#2878ce}
.cancel-resource{background:#485b74}
.edit-resource{background:#315b95}
.delete-resource{background:#9b4350}
.resource-alert{
    padding:14px;margin:14px 0;border-radius:9px;
    background:#1e4835;color:#c2f5d6
}
.resource-alert.error{background:#532832;color:#ffd2da}
.resource-entry{margin-bottom:12px}
.resource-entry[hidden]{display:none!important}
.resource-entry summary{list-style:none;cursor:pointer}
.resource-entry summary::-webkit-details-marker{display:none}
.resource-entry .resource-item{
    display:flex;align-items:center;gap:16px;width:100%
}
.resource-entry .resource-item>div{flex:1;min-width:0}
.resource-entry h3{color:#fff;margin:0 0 5px}
.resource-entry .resource-item p{color:#b3c6dc;margin:0}
.resource-entry[open] .resource-arrow{transform:rotate(90deg)}
.resource-thumb.toolkit-icon{
    display:grid;place-items:center;flex:0 0 54px;
    width:54px;height:54px;border-radius:14px;
    background:#294b71!important;color:#fff!important;font-size:26px
}
.resource-detail{
    background:#101f35;border:1px solid #304862;
    border-radius:12px;padding:22px;color:#dce9f9;
    line-height:1.7;margin-top:6px
}
.resource-tag{
    display:block;color:#97ccff;font-size:13px;
    font-weight:700;margin-bottom:18px
}
.guide-header{
    display:flex;align-items:center;gap:15px;
    border-bottom:1px solid #395471;padding-bottom:20px;margin-bottom:20px
}
.guide-icon{
    display:grid;place-items:center;background:#294b71;
    width:56px;height:56px;flex:0 0 56px;
    border-radius:14px;font-size:27px
}
.guide-header h2{margin:0;color:#fff}
.guide-header p{color:#a8bed6;margin:4px 0}
.guide-intro{
    padding:20px;background:#1b304a;
    border-left:4px solid #559be0;border-radius:11px;margin:18px 0
}
.guide-step{
    display:flex;gap:17px;background:#192e47;
    border:1px solid #36516c;border-radius:13px;
    padding:20px;margin:12px 0
}
.guide-step>span{
    display:grid;place-items:center;background:#2a5078;
    color:#bfe1ff;flex:0 0 45px;height:45px;
    border-radius:11px;font-weight:800
}
.guide-step h4{margin:0 0 8px;color:#fff}
.guide-step p{margin:0;color:#c8d9eb}
.referral-document{
    background:#172a43;padding:25px;
    border:1px solid #385476;border-radius:14px
}
.referral-title{text-align:center;padding:20px 0}
.referral-title h3{font-size:25px;color:#fff;margin:0}
.referral-section{margin-bottom:22px}
.referral-section h4{
    color:#8dc5ff;border-bottom:1px solid #36516e;padding-bottom:10px
}
.referral-section label{
    display:block;font-weight:700;margin:12px 0;
    color:#d8e8fa;font-size:14px
}
.referral-section input,.referral-section textarea,
.referral-section select{
    display:block;box-sizing:border-box;width:100%;
    margin-top:8px;padding:13px;border:1px solid #405b7a;
    border-radius:9px;background:#0d1b2e;color:#fff;font:inherit
}
.referral-section textarea{min-height:90px;resize:vertical}
.referral-grid{display:grid;grid-template-columns:1fr 1fr;gap:15px}
.referral-footer{
    display:flex;justify-content:space-between;gap:10px;
    border-top:1px solid #3b5270;padding-top:15px;
    color:#a2bad2;font-size:12px
}
.peer-response{
    padding:22px;background:#173d37;
    border:1px solid #357367;border-radius:13px;margin:22px 0
}
.peer-response h3{color:#b3f1d7}
.peer-response p{font-style:italic;color:#e1f5ed}
.peer-responsibilities{padding:22px;background:#192c44;border-radius:13px}
.saved-sections{display:grid;gap:10px}
.saved-sections h4{
    color:#9cccff;background:#192c44;
    padding:12px;border-radius:9px;margin:5px 0
}
.saved-sections p{margin:0;padding:6px;color:#d5e4f3}
.saved-links{display:flex;gap:12px;flex-wrap:wrap;margin-top:18px}
.saved-link{
    padding:14px;border-radius:11px;
    background:#203b58;border:1px solid #3b5a7e;color:#fff
}
.saved-link:hover{color:#fff;background:#2a537b}
.no-resources{color:#b4c7d9;padding:14px}
@media(max-width:650px){
    .referral-grid{grid-template-columns:1fr}
    .tool-controls,.referral-footer{flex-direction:column}
    .resource-detail,.referral-document,.resource-editor{padding:15px}
}
@media print{
    body *{visibility:hidden!important}
    #referralPrintArea,#referralPrintArea *{visibility:visible!important}
    #referralPrintArea{
        position:absolute;top:0;left:0;width:100%;
        background:white!important;color:black!important;border:0
    }
    #referralPrintArea *{
        color:black!important;background:transparent!important
    }
}
</style>
</head>

<body class="app-body dark-body counsellor-body">

<div class="app-shell dark-shell">

<aside class="sidebar counsellor-sidebar">
    <a class="brand-mini sidebar-brand" href="index.php">
        <span class="mini-leaf">☘</span>
        <span>WellnessHub</span>
    </a>

    <nav class="side-nav" aria-label="Counsellor navigation">
        <a href="counsellor-dashboard.php"><span>▣</span> Dashboard</a>
        <a href="counsellor-students.php"><span>👥</span> Students</a>
        <a href="risk-alerts.php"><span>⚠</span> Risk Alerts</a>
        <a href="counsellor-appointments.php"><span>📅</span> Appointments</a>
        <a class="active" href="counsellor-resources.php"><span>▤</span> Resources</a>
        <a href="counsellor-profile.php"><span>👤</span> My Profile</a>
        <a href="logout.php"><span>↪</span> Logout</a>
    </nav>
</aside>

<main class="dashboard-main dark-main">

<header class="topbar dark-topbar">
    <div>
        <p class="eyebrow">Counsellor Side</p>
        <h1>Counsellor Resources</h1>
        <p class="page-subtitle">
            Recommended support resources for referrals.
        </p>
    </div>

    <div class="topbar-actions">
        <a class="icon-btn dark-icon"
           href="risk-alerts.php"
           aria-label="Risk alerts">🔔</a>

        <a href="counsellor-profile.php"
           class="avatar dark-avatar"
           title="Click to view My Profile"
           aria-label="Open My Profile"
           style="<?= $avatarStyle ?>">
            <?php if (!$hasPhoto): ?>
                <?= h($initial) ?>
            <?php endif; ?>
        </a>
    </div>
</header>

<section class="panel">

<div class="panel-heading">
    <h2>Resource Toolkit</h2>

    <button type="button"
            id="addResourceBtn"
            class="btn btn-blue btn-small">
        + Add Resource
    </button>
</div>

<?php if ($error): ?>
    <div class="resource-alert error" role="alert">
        <?= h($error) ?>
    </div>
<?php endif; ?>

<?php if (isset($messages[$status])): ?>
    <div class="resource-alert" role="status">
        <?= h($messages[$status]) ?>
    </div>
<?php endif; ?>

<!-- ADD AND EDIT RESOURCE -->
<form id="resourceEditor"
      class="resource-editor <?= $showEditor ? 'open' : '' ?>"
      method="post"
      action="counsellor-resources.php"
      enctype="multipart/form-data">

    <h3 id="editorHeading">Add New Resource</h3>

    <input type="hidden"
           name="csrf_token"
           value="<?= h($_SESSION['toolkit_csrf']) ?>">

    <input type="hidden"
           id="resourceAction"
           name="resource_action"
           value="<?= h($_POST['resource_action'] ?? 'add') ?>">

    <input type="hidden"
           id="resourceId"
           name="resource_id"
           value="<?= h($_POST['resource_id'] ?? '') ?>">

    <label for="resourceTitle">Resource Title</label>
    <input id="resourceTitle"
           name="title"
           maxlength="150"
           required
           placeholder="e.g. Exam Stress Management Guide"
           value="<?= h($_POST['title'] ?? '') ?>">

    <label for="resourceCategory">Category</label>
    <select id="resourceCategory" name="category">
        <?php foreach ($categories as $category): ?>
            <option value="<?= h($category) ?>">
                <?= h($category) ?>
            </option>
        <?php endforeach; ?>
    </select>

    <label for="resourceDescription">Short Description</label>
    <textarea id="resourceDescription"
              name="description"
              maxlength="350"
              required><?= h($_POST['description'] ?? '') ?></textarea>

    <label for="resourceContent">Full Resource Information</label>
    <textarea id="resourceContent"
              name="content"
              maxlength="15000"
              required><?= h($_POST['content'] ?? '') ?></textarea>

    <label for="resourceUrl">Website Link (Optional)</label>
    <input type="url"
           id="resourceUrl"
           name="resource_url"
           placeholder="https://example.org"
           value="<?= h($_POST['resource_url'] ?? '') ?>">

    <label for="resourcePdf">Attach PDF (Optional, maximum 5 MB)</label>
    <input type="file"
           id="resourcePdf"
           name="resource_pdf"
           accept=".pdf,application/pdf">

    <div id="existingPdfBox" hidden>
        <label>
            <input type="checkbox" name="remove_pdf">
            Remove existing PDF
        </label>
    </div>

    <p class="muted">
        Add general counselling resources only.
        Do not upload confidential student records.
    </p>

    <div class="editor-actions">
        <button type="submit"
                class="save-resource"
                <?= !$pdo ? 'disabled' : '' ?>>
            Save Resource
        </button>

        <button type="button"
                class="cancel-resource"
                id="cancelResourceBtn">
            Cancel
        </button>
    </div>
</form>

<!-- SEARCH -->
<div class="tool-controls">

    <input id="resourceSearch"
           type="search"
           placeholder="Search resources..."
           aria-label="Search resources">

    <select id="categoryFilter"
            aria-label="Filter resources">

        <option value="">All categories</option>

        <?php foreach ($categories as $category): ?>
            <option value="<?= h($category) ?>">
                <?= h($category) ?>
            </option>
        <?php endforeach; ?>

    </select>

</div>

<div class="resource-list" id="resourceList">

<!-- CRISIS ESCALATION -->
<details class="resource-entry"
         data-category="Crisis Support"
         data-search="crisis escalation protocol high risk safety emergency">

    <summary class="resource-item">
        <span class="resource-thumb toolkit-icon">☎</span>
        <div>
            <h3>Crisis Escalation Protocol</h3>
            <p>Guidance for responding to high-risk alerts</p>
        </div>
        <span class="resource-arrow">›</span>
    </summary>

    <div class="resource-detail">
        <span class="resource-tag">Crisis Support</span>

        <div class="guide-header">
            <span class="guide-icon">☎</span>
            <div>
                <h2>Crisis Escalation Protocol</h2>
                <p>WellnessHub Counselling Services</p>
            </div>
        </div>

        <div class="guide-intro">
            Structured guidance for identifying, assessing,
            and responding to serious emotional distress or safety risks.
            Follow your institution's approved emergency procedures.
        </div>

        <?php
        $crisisSteps = [
            'Identify and Assess the Crisis' =>
                'Assess immediate safety and emotional distress using approved procedures.',
            'Prioritize Student Safety' =>
                'Activate emergency procedures when immediate danger is suspected.',
            'Notify Appropriate Personnel' =>
                'Escalate concerns to authorized clinical supervisors or the crisis team.',
            'Maintain Confidentiality' =>
                'Share sensitive information only when lawfully permitted or necessary.',
            'Document the Incident' =>
                'Record assessments, actions, referrals and follow-up securely.',
            'Arrange Follow-Up Support' =>
                'Coordinate counselling and appropriate professional referrals.',
            'Review and Monitor' =>
                'Confirm that required follow-up actions have been completed.'
        ];

        $stepNumber = 0;

        foreach ($crisisSteps as $name => $description):
            $stepNumber++;
        ?>
            <div class="guide-step">
                <span><?= str_pad((string)$stepNumber, 2, '0', STR_PAD_LEFT) ?></span>
                <div>
                    <h4><?= h($name) ?></h4>
                    <p><?= h($description) ?></p>
                </div>
            </div>
        <?php endforeach; ?>

    </div>
</details>

<!-- STUDENT REFERRAL FORM -->
<details class="resource-entry"
         data-category="Counselling"
         data-search="student referral form counselling documentation print">

    <summary class="resource-item">
        <span class="resource-thumb toolkit-icon">📄</span>
        <div>
            <h3>Student Referral Form</h3>
            <p>Counselling referral and support documentation</p>
        </div>
        <span class="resource-arrow">›</span>
    </summary>

    <div class="resource-detail">
        <span class="resource-tag">Counselling</span>

        <div class="referral-document" id="referralPrintArea">

            <div class="guide-header">
                <span class="guide-icon">☘</span>
                <div>
                    <h2>WellnessHub</h2>
                    <p>Counselling Services</p>
                </div>
            </div>

            <div class="referral-title">
                <h3>Student Referral Form</h3>
                <p>Student Counselling and Wellness Support</p>
            </div>

            <div class="referral-section">
                <h4>01. Student Information</h4>

                <div class="referral-grid">
                    <label>
                        Student Reference
                        <input id="refStudent"
                               placeholder="Student reference">
                    </label>

                    <label>
                        Referral Date
                        <input id="refDate" type="date">
                    </label>
                </div>

                <label>
                    Referring Counsellor
                    <input id="refCounsellor"
                           placeholder="Counsellor name">
                </label>
            </div>

            <div class="referral-section">
                <h4>02. Referral Information</h4>

                <label>
                    Reason for Referral
                    <textarea id="refReason"
                              placeholder="Reason for referral"></textarea>
                </label>

                <label>
                    Support Requested
                    <select id="refSupport">
                        <option value="">Select support required</option>
                        <option>Individual Counselling</option>
                        <option>Academic Stress Support</option>
                        <option>Anxiety Support</option>
                        <option>Emotional Wellness Support</option>
                        <option>Crisis Intervention</option>
                        <option>External Professional Referral</option>
                        <option>Other Support</option>
                    </select>
                </label>
            </div>

            <div class="referral-section">
                <h4>03. Consent and Authorization</h4>

                <label>
                    Consent or Other Lawful Basis
                    <textarea id="refConsent"
                              placeholder="Applicable authorization"></textarea>
                </label>
            </div>

            <div class="referral-section">
                <h4>04. Follow-Up Plan</h4>

                <label>
                    Follow-Up Arrangements
                    <textarea id="refFollowup"
                              placeholder="Recommended next steps"></textarea>
                </label>
            </div>

            <div class="referral-footer">
                <span>WellnessHub Counselling Services</span>
                <span>Confidential Student Information</span>
            </div>

        </div>

        <div class="referral-actions">
            <button type="button"
                    class="save-resource"
                    id="printReferralBtn">
                🖨 Print Referral Form
            </button>

            <button type="button"
                    class="cancel-resource"
                    id="clearReferralBtn">
                Clear Form
            </button>
        </div>
    </div>
</details>

<!-- PEER SUPPORT -->
<details class="resource-entry"
         data-category="Peer Support"
         data-search="peer support moderation guide privacy respect bullying communication">

    <summary class="resource-item">
        <span class="resource-thumb toolkit-icon">🤝</span>
        <div>
            <h3>Peer Support Moderation Guide</h3>
            <p>Moderation guidelines and supportive communication</p>
        </div>
        <span class="resource-arrow">›</span>
    </summary>

    <div class="resource-detail">
        <span class="resource-tag">Peer Support</span>

        <div class="guide-header">
            <span class="guide-icon">🤝</span>
            <div>
                <h2>Peer Support Moderation</h2>
                <p>WellnessHub Counselling Services</p>
            </div>
        </div>

        <div class="guide-intro">
            Peer support moderation creates a safe and inclusive
            environment where students can share experiences,
            encourage one another, and access support.
        </div>

        <?php
        $peerSteps = [
            'Respectful Communication' =>
                'Encourage empathy and supportive communication without judgment.',
            'Protect Student Privacy' =>
                'Do not request sensitive personal information in public discussions.',
            'Address Inappropriate Behaviour' =>
                'Respond to bullying, harassment and harmful comments.',
            'Escalate Safety Concerns' =>
                'Refer urgent concerns through approved crisis procedures.',
            'Encourage Professional Support' =>
                'Explain available counselling services when appropriate.'
        ];

        $peerNumber = 0;

        foreach ($peerSteps as $name => $description):
            $peerNumber++;
        ?>
            <div class="guide-step">
                <span><?= str_pad((string)$peerNumber, 2, '0', STR_PAD_LEFT) ?></span>
                <div>
                    <h4><?= h($name) ?></h4>
                    <p><?= h($description) ?></p>
                </div>
            </div>
        <?php endforeach; ?>

        <div class="peer-response">
            <h3>💬 Supportive Counsellor Response</h3>
            <p>
                “Thank you for sharing your experience.
                We appreciate your openness. If you would like
                to talk privately, a WellnessHub counsellor can help.”
            </p>
        </div>

        <div class="peer-responsibilities">
            <h3>Moderator Responsibilities</h3>
            <ul>
                <li>Maintain a respectful environment.</li>
                <li>Protect student privacy.</li>
                <li>Identify harmful or inappropriate content.</li>
                <li>Refer serious concerns to professionals.</li>
                <li>Follow institutional procedures.</li>
            </ul>
        </div>
    </div>
</details>

<!-- DATABASE RESOURCES -->
<?php foreach ($resources as $item): ?>

<details class="resource-entry"
         data-category="<?= h($item['category']) ?>"
         data-search="<?= h(
             $item['title'] . ' ' .
             $item['description'] . ' ' .
             $item['content']
         ) ?>">

    <summary class="resource-item">
        <span class="resource-thumb toolkit-icon">
            <?= h($icons[$item['category']] ?? '📘') ?>
        </span>

        <div>
            <h3><?= h($item['title']) ?></h3>
            <p><?= h($item['description']) ?></p>
        </div>

        <span class="resource-arrow">›</span>
    </summary>

    <div class="resource-detail">
        <span class="resource-tag">
            <?= h($item['category']) ?>
        </span>

        <h2><?= h($item['title']) ?></h2>
        <p><?= h($item['description']) ?></p>

        <?php displayResourceGuide($item['content']); ?>

        <div class="saved-links">

            <?php if ($item['resource_url']): ?>
                <a class="saved-link"
                   href="<?= h($item['resource_url']) ?>"
                   target="_blank"
                   rel="noopener noreferrer">
                    🌐 Visit Resource Website
                </a>
            <?php endif; ?>

            <?php if ($item['pdf_name']): ?>
                <a class="saved-link"
                   href="counsellor-resources.php?download=<?= (int)$item['resource_id'] ?>">
                    📄 Download Resource PDF
                </a>
            <?php endif; ?>

        </div>

        <div class="item-actions">
            <button type="button"
                    class="edit-resource editEntry"
                    data-id="<?= (int)$item['resource_id'] ?>">
                Edit Resource
            </button>

            <form class="deleteForm"
                  method="post"
                  action="counsellor-resources.php">

                <input type="hidden"
                       name="csrf_token"
                       value="<?= h($_SESSION['toolkit_csrf']) ?>">

                <input type="hidden"
                       name="resource_action"
                       value="delete">

                <input type="hidden"
                       name="resource_id"
                       value="<?= (int)$item['resource_id'] ?>">

                <button type="submit" class="delete-resource">
                    Delete Resource
                </button>
            </form>
        </div>
    </div>
</details>

<?php endforeach; ?>

</div>

<p id="noResults" class="no-resources" hidden>
    No resources match your search.
</p>

</section>
</main>
</div>

<script>
const records = <?= json_encode(
    array_column($resources, null, 'resource_id'),
    JSON_HEX_TAG |
    JSON_HEX_AMP |
    JSON_HEX_APOS |
    JSON_HEX_QUOT |
    JSON_INVALID_UTF8_SUBSTITUTE
) ?: '{}' ?>;

const editor = document.getElementById('resourceEditor');
const actionInput = document.getElementById('resourceAction');
const idInput = document.getElementById('resourceId');

function showEditor(open) {
    editor.classList.toggle('open', open);

    if (open) {
        editor.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
        });
        document.getElementById('resourceTitle').focus();
    }
}

// ADD RESOURCE
document.getElementById('addResourceBtn').addEventListener('click', () => {
    editor.reset();
    actionInput.value = 'add';
    idInput.value = '';

    document.getElementById('editorHeading').textContent =
        'Add New Resource';

    document.getElementById('existingPdfBox').hidden = true;
    showEditor(true);
});

// CANCEL
document.getElementById('cancelResourceBtn').addEventListener('click', () => {
    editor.reset();
    showEditor(false);
});

// EDIT
document.querySelectorAll('.editEntry').forEach(button => {
    button.addEventListener('click', () => {
        const item = records[button.dataset.id];
        if (!item) return;

        editor.reset();

        actionInput.value = 'edit';
        idInput.value = item.resource_id;

        document.getElementById('editorHeading').textContent =
            'Edit Resource';

        document.getElementById('resourceTitle').value = item.title;
        document.getElementById('resourceCategory').value = item.category;
        document.getElementById('resourceDescription').value = item.description;
        document.getElementById('resourceContent').value = item.content;
        document.getElementById('resourceUrl').value = item.resource_url || '';

        document.getElementById('existingPdfBox').hidden = !item.pdf_name;

        showEditor(true);
    });
});

// DELETE CONFIRMATION
document.querySelectorAll('.deleteForm').forEach(form => {
    form.addEventListener('submit', event => {
        if (!confirm('Delete this resource for all counsellors?')) {
            event.preventDefault();
        }
    });
});

// SEARCH
function filterResources() {
    const query = document.getElementById('resourceSearch')
        .value.toLowerCase().trim();

    const category = document.getElementById('categoryFilter').value;

    let visible = 0;

    document.querySelectorAll('.resource-entry').forEach(item => {
        const matches =
            (!query || item.dataset.search.toLowerCase().includes(query)) &&
            (!category || item.dataset.category === category);

        item.hidden = !matches;

        if (matches) visible++;
    });

    document.getElementById('noResults').hidden = visible > 0;
}

document.getElementById('resourceSearch')
    .addEventListener('input', filterResources);

document.getElementById('categoryFilter')
    .addEventListener('change', filterResources);

// PRINT
document.getElementById('printReferralBtn')
    .addEventListener('click', () => window.print());

// CLEAR FORM
document.getElementById('clearReferralBtn').addEventListener('click', () => {
    if (!confirm('Clear all referral form fields?')) return;

    document.querySelectorAll(
        '#referralPrintArea input, ' +
        '#referralPrintArea textarea, ' +
        '#referralPrintArea select'
    ).forEach(input => {
        input.value = '';
    });
});
</script>

</body>
</html>