<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    />

    <title>Create Account — WellnessHub</title>

    <link rel="stylesheet" href="css/style.css" />

    <style>
        /* WELLNESSHUB REGISTRATION STYLES */

        .banner {
            padding: 12px 14px;
            border-radius: 10px;
            font-size: 13px;
            font-weight: 700;
            margin-bottom: 16px;
            display: none;
        }

        .banner.error {
            background: rgba(243,109,109,.12);
            color: #ad3434;
            display: block;
        }

        .banner.success {
            background: rgba(87,166,111,.15);
            color: #1d563b;
            display: block;
        }

        .field-error {
            color: #ad3434;
            font-size: 12px;
            font-weight: 650;
            min-height: 16px;
        }

        .check-row a {
            color: #287c4b;
            font-weight: 600;
            text-decoration: none;
        }

        .check-row a:hover {
            text-decoration: underline;
        }

        /* =========================================
           PASSWORD INPUT WITH EYE ICON
        ========================================= */

        .password-input-wrapper {
            position: relative;
            display: block;
            width: 100%;
        }

        .password-input-wrapper input {
            width: 100%;
            box-sizing: border-box;
            padding-right: 60px !important;
        }

        /* EYE BUTTON */

        .password-toggle {
            position: absolute;
            top: 50%;
            right: 12px;

            transform: translateY(-50%);

            display: flex;
            justify-content: center;
            align-items: center;

            width: 44px;
            height: 44px;

            padding: 0;

            border: none;
            border-radius: 10px;

            background: transparent;
            color: #2e7d50;

            cursor: pointer;
            z-index: 2;

            transition:
                background 0.2s ease,
                color 0.2s ease;
        }

        .password-toggle:hover {
            background: rgba(46,125,80,0.10);
            color: #185a37;
        }

        .password-toggle:focus-visible {
            outline: 2px solid #2e7d50;
            outline-offset: 2px;
        }

        .password-toggle svg {
            width: 24px;
            height: 24px;

            fill: none;
            stroke: currentColor;
            stroke-width: 2;

            stroke-linecap: round;
            stroke-linejoin: round;
        }

        /* MOBILE */

        @media (max-width: 600px) {

            .password-toggle {
                right: 8px;
            }

            .password-input-wrapper input {
                padding-right: 55px !important;
            }

        }

    </style>
</head>

<body>

<main class="auth-screen">

    <section class="auth-card register-card">

        <!-- CREATE ACCOUNT TOP LABEL -->

        <div class="auth-number">
            CREATE ACCOUNT
        </div>

        <!-- WELLNESSHUB BRAND -->

        <div class="brand-mini">

            <span
                class="mini-leaf"
                aria-hidden="true">
                ☘
            </span>

            <span>WellnessHub</span>

        </div>

        <!-- CREATE ACCOUNT HEADING -->

        <header class="auth-header">

            <h1>Create Account</h1>

            <p>Join WellnessHub</p>

        </header>

        <!-- REGISTRATION MESSAGES -->

        <div
            id="formBanner"
            class="banner"
            role="status"
            aria-live="polite">
        </div>

        <!-- REGISTRATION FORM -->

        <form
            class="auth-form"
            id="registerForm"
            novalidate
        >

            <!-- FULL NAME -->

            <label class="field">

                <span>Full Name</span>

                <input
                    type="text"
                    id="fullName"
                    name="full_name"
                    placeholder="Name Surname"
                    autocomplete="name"
                    required
                    pattern="^[A-Za-z]{3,}(\s[A-Za-z]{3,})+$"
                    title="Enter your name and surname, e.g. Name Surname"
                />

                <div
                    class="field-error"
                    id="fullName-error">
                </div>

            </label>

            <!-- GENDER -->

            <label class="field">

                <span>Gender</span>

                <select
                    id="gender"
                    name="gender"
                >

                    <option value="Prefer not to say">
                        Prefer not to say
                    </option>

                    <option value="Male">
                        Male
                    </option>

                    <option value="Female">
                        Female
                    </option>

                    <option value="Non-binary">
                        Non-binary
                    </option>

                </select>

            </label>

            <!-- RICHFIELD QUALIFICATIONS -->

            <label class="field">

                <span>Qualification</span>

                <select
                    id="qualification"
                    name="qualification"
                    required
                >

                    <?php

                    require_once __DIR__ . '/qualifications.php';

                    renderQualificationOptions(
                        'Select your qualification',
                        true
                    );

                    ?>

                </select>

                <div
                    class="field-error"
                    id="qualification-error">
                </div>

            </label>

            <!-- STUDENT NUMBER -->

            <label class="field">

                <span>Student Number</span>

                <input
                    type="text"
                    id="studentNumber"
                    name="student_number"
                    placeholder="Enter your student number"
                    required
                    pattern="^402\d{6}$"
                    title="Student number must be 9 digits starting with 402"
                    inputmode="numeric"
                    maxlength="9"
                />

                <div
                    class="field-error"
                    id="studentNumber-error">
                </div>

            </label>

            <!-- UNIVERSITY EMAIL -->

            <label class="field">

                <span>University Email</span>

                <input
                    type="email"
                    id="email"
                    name="email"
                    placeholder="Enter your Richfield email address"
                    autocomplete="email"
                    required
                    pattern="^402\d{6}@my\.richfield\.ac\.za$"
                    title="Email must be your student number followed by @my.richfield.ac.za"
                />

                <div
                    class="field-error"
                    id="email-error">
                </div>

            </label>

            <!-- =====================================
                 PASSWORD WITH EYE ICON
            ====================================== -->

            <label class="field">

                <span>Password</span>

                <div class="password-input-wrapper">

                    <input
                        type="password"
                        id="password"
                        name="password"
                        placeholder="••••••••"
                        autocomplete="new-password"
                        required
                        minlength="8"
                        pattern="^(?=.*[A-Z])(?=.*[^A-Za-z0-9\s]).{8,}$"
                        title="At least 8 characters, including one uppercase letter and one special character"
                    />

                    <!-- SHOW PASSWORD BUTTON -->

                    <button
                        type="button"
                        class="password-toggle"
                        id="togglePassword"
                        aria-label="Show password"
                        aria-controls="password"
                        aria-pressed="false"
                        title="Show password">
                    </button>

                </div>

                <div
                    class="field-error"
                    id="password-error">
                </div>

            </label>

            <!-- =====================================
                 CONFIRM PASSWORD WITH EYE ICON
            ====================================== -->

            <label class="field">

                <span>Confirm Password</span>

                <div class="password-input-wrapper">

                    <input
                        type="password"
                        id="confirmPassword"
                        name="confirm_password"
                        placeholder="••••••••"
                        autocomplete="new-password"
                        required
                    />

                    <!-- SHOW CONFIRM PASSWORD BUTTON -->

                    <button
                        type="button"
                        class="password-toggle"
                        id="toggleConfirmPassword"
                        aria-label="Show confirmation password"
                        aria-controls="confirmPassword"
                        aria-pressed="false"
                        title="Show confirmation password">
                    </button>

                </div>

                <div
                    class="field-error"
                    id="confirmPassword-error">
                </div>

            </label>

            <!-- POPIA AGREEMENT -->

            <label class="check-row">

                <input
                    type="checkbox"
                    id="popiaAgree"
                    name="popiaAgree"
                    required
                />

                <span>

                    I have read and agree to the

                    <a
                        href="popia.php"
                        target="_blank"
                        rel="noopener noreferrer">

                        WellnessHub POPIA Privacy Policy

                    </a>

                </span>

            </label>

            <div
                class="field-error"
                id="popiaAgree-error">
            </div>

            <!-- CREATE ACCOUNT BUTTON -->

            <button
                class="btn btn-primary btn-full"
                type="submit"
                id="submitBtn">

                Create Account

            </button>

        </form>

        <!-- LOGIN LINK -->

        <p class="form-footer">

            Already have an account?

            <a href="login.php">
                Login
            </a>

        </p>

    </section>

</main>

<!-- ==========================================
     EXISTING REGISTRATION JAVASCRIPT
========================================== -->

<script src="js/register.js"></script>


<!-- ==========================================
     SHOW / HIDE PASSWORD JAVASCRIPT
========================================== -->

<script>

document.addEventListener("DOMContentLoaded", function () {

    // ==========================================
    // EYE ICON SVG
    // ==========================================

    const eyeOpen = `
        <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
            aria-hidden="true">

            <path
                d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12">
            </path>

            <circle
                cx="12"
                cy="12"
                r="3">
            </circle>

        </svg>
    `;

    // ==========================================
    // CROSSED EYE ICON
    // ==========================================

    const eyeClosed = `
        <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
            aria-hidden="true">

            <path
                d="M3 3l18 18">
            </path>

            <path
                d="M10.6 5.1A11.2 11.2 0 0 1 12 5c6.5 0 10 7 10 7a15 15 0 0 1-3.2 4.1">
            </path>

            <path
                d="M6.3 6.3C3.5 8.2 2 12 2 12s3.5 7 10 7c1.8 0 3.4-.5 4.8-1.3">
            </path>

            <path
                d="M10 10a3 3 0 0 0 4 4">
            </path>

        </svg>
    `;


    // ==========================================
    // REUSABLE PASSWORD TOGGLE FUNCTION
    // ==========================================

    function setupPasswordToggle(
        inputId,
        buttonId,
        passwordLabel
    ) {

        const passwordInput =
            document.getElementById(inputId);

        const toggleButton =
            document.getElementById(buttonId);


        // Stop if an element does not exist
        if (!passwordInput || !toggleButton) {
            return;
        }


        // Initially show the eye icon
        toggleButton.innerHTML = eyeOpen;


        // Handle eye button clicks
        toggleButton.addEventListener("click", function (event) {

            event.preventDefault();

            const passwordIsHidden =
                passwordInput.type === "password";


            if (passwordIsHidden) {

                // SHOW PASSWORD
                passwordInput.type = "text";

                // Change icon
                toggleButton.innerHTML = eyeClosed;

                // Update accessibility information
                toggleButton.setAttribute(
                    "aria-label",
                    "Hide " + passwordLabel
                );

                toggleButton.setAttribute(
                    "aria-pressed",
                    "true"
                );

                toggleButton.title =
                    "Hide " + passwordLabel;

            } else {

                // HIDE PASSWORD
                passwordInput.type = "password";

                // Change icon
                toggleButton.innerHTML = eyeOpen;

                // Update accessibility information
                toggleButton.setAttribute(
                    "aria-label",
                    "Show " + passwordLabel
                );

                toggleButton.setAttribute(
                    "aria-pressed",
                    "false"
                );

                toggleButton.title =
                    "Show " + passwordLabel;

            }

        });

    }


    // ==========================================
    // PASSWORD FIELD
    // ==========================================

    setupPasswordToggle(
        "password",
        "togglePassword",
        "password"
    );


    // ==========================================
    // CONFIRM PASSWORD FIELD
    // ==========================================

    setupPasswordToggle(
        "confirmPassword",
        "toggleConfirmPassword",
        "confirmation password"
    );

});

</script>

</body>
</html>