// WellnessHub — counselling booking with month/year calendar navigation.
// Keep this file at js/counselling-booking.js.

const MONTH_NAMES = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'
];

function formatDateLocal(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function formatDisplayDate(dateStr) {
  const date = new Date(`${dateStr}T00:00:00`);
  return date.toLocaleDateString('en-ZA', {
    weekday: 'long', day: 'numeric', month: 'long', year: 'numeric'
  });
}

let counsellors = [];
let selectedCounsellorId = null;
let selectedDate = null;
let selectedTime = null;
let upcomingBookings = [];
let appointmentLookupFailed = true;
let bookingInProgress = false;
let cancellationInProgress = false;

const initialDate = new Date();
let displayedMonth = initialDate.getMonth();
let displayedYear = initialDate.getFullYear();
let slotRequestVersion = 0;

document.addEventListener('DOMContentLoaded', async () => {
  createBookingMessage();
  setupCalendarNavigation();
  renderCalendar();

  document.getElementById('counsellorSelect').addEventListener('change', (event) => {
    selectedCounsellorId = event.target.value || null;
    selectedTime = null;
    showCounsellorCard();
    resetSlots();

    if (selectedCounsellorId && selectedDate) {
      loadSlots();
    } else if (selectedDate) {
      document.getElementById('slotList').textContent = 'Choose a counsellor first.';
    }
  });

  document.getElementById('bookBtn').addEventListener('click', bookSession);
  await Promise.all([loadCounsellors(), loadAppointments()]);
});

// Display feedback next to the Book Session button.
function createBookingMessage() {
  if (document.getElementById('bookingFeedback')) return;

  const message = document.createElement('div');
  message.id = 'bookingFeedback';
  message.setAttribute('role', 'status');
  message.setAttribute('aria-live', 'polite');
  message.style.cssText = [
    'display:none',
    'padding:13px 16px',
    'margin:14px 0',
    'border-radius:12px',
    'font-size:15px',
    'line-height:1.5',
    'color:#ffffff',
    'background:#23436a',
    'border:1px solid #477bb5'
  ].join(';');

  const bookButton = document.getElementById('bookBtn');
  bookButton.parentNode.insertBefore(message, bookButton);
}

function showBookingMessage(text, type = 'info') {
  const message = document.getElementById('bookingFeedback');
  if (!message) return;

  const styles = {
    info: ['#23436a', '#477bb5'],
    success: ['#175a43', '#3b9875'],
    error: ['#773544', '#c36a7d']
  };
  const [background, border] = styles[type] || styles.info;
  message.style.display = 'block';
  message.style.background = background;
  message.style.borderColor = border;
  message.textContent = text;
}

function updateBookingButton() {
  const button = document.getElementById('bookBtn');
  button.disabled = Boolean(
    !selectedCounsellorId || !selectedDate || !selectedTime ||
    appointmentLookupFailed ||
    bookingInProgress || cancellationInProgress
  );
  button.textContent = bookingInProgress ? 'Booking…' : 'Book Session';
}

function setupCalendarNavigation() {
  const monthSelect = document.getElementById('calendarMonthSelect');
  const yearSelect = document.getElementById('calendarYearSelect');

  MONTH_NAMES.forEach((name, index) => {
    const option = document.createElement('option');
    option.value = String(index);
    option.textContent = name;
    monthSelect.appendChild(option);
  });

  document.getElementById('previousMonthBtn').addEventListener('click', () => {
    changeVisibleMonth(displayedYear, displayedMonth - 1);
  });

  document.getElementById('nextMonthBtn').addEventListener('click', () => {
    changeVisibleMonth(displayedYear, displayedMonth + 1);
  });

  monthSelect.addEventListener('change', () => {
    changeVisibleMonth(displayedYear, Number(monthSelect.value));
  });

  yearSelect.addEventListener('change', () => {
    changeVisibleMonth(Number(yearSelect.value), displayedMonth);
  });
}

function updateCalendarSelectors() {
  const monthSelect = document.getElementById('calendarMonthSelect');
  const yearSelect = document.getElementById('calendarYearSelect');
  const currentYear = new Date().getFullYear();

  // Include the previous year for viewing, and future years for booking.
  const firstYear = Math.min(currentYear - 1, displayedYear);
  const lastYear = Math.max(currentYear + 5, displayedYear);

  yearSelect.replaceChildren();
  for (let year = firstYear; year <= lastYear; year++) {
    const option = document.createElement('option');
    option.value = String(year);
    option.textContent = String(year);
    yearSelect.appendChild(option);
  }

  monthSelect.value = String(displayedMonth);
  yearSelect.value = String(displayedYear);
}

function changeVisibleMonth(year, month) {
  const next = new Date(year, month, 1);
  displayedYear = next.getFullYear();
  displayedMonth = next.getMonth();

  // Never leave an invisible date or an old time slot selected.
  selectedDate = null;
  selectedTime = null;
  document.getElementById('selectedDateLabel').textContent =
    'Pick a counsellor and a date to see available times.';
  resetSlots();
  renderCalendar();
}

function renderCalendar() {
  const grid = document.getElementById('calendarGrid');
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  document.getElementById('calendarMonthLabel').textContent =
    `${MONTH_NAMES[displayedMonth]} ${displayedYear}`;
  updateCalendarSelectors();

  // Rebuild the calendar, including weekdays, so months never overlap.
  grid.replaceChildren();
  ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].forEach((name) => {
    const heading = document.createElement('div');
    heading.className = 'day-name';
    heading.textContent = name;
    grid.appendChild(heading);
  });

  const firstWeekday = new Date(displayedYear, displayedMonth, 1).getDay();
  const daysInMonth = new Date(displayedYear, displayedMonth + 1, 0).getDate();

  for (let i = 0; i < firstWeekday; i++) {
    const blank = document.createElement('div');
    blank.className = 'calendar-day calendar-empty';
    blank.setAttribute('aria-hidden', 'true');
    grid.appendChild(blank);
  }

  for (let day = 1; day <= daysInMonth; day++) {
    const date = new Date(displayedYear, displayedMonth, day);
    const dateStr = formatDateLocal(date);
    const isPast = date < today;
    const isWeekend = date.getDay() === 0 || date.getDay() === 6;
    const isToday = date.getTime() === today.getTime();

    const cell = document.createElement('button');
    cell.type = 'button';
    cell.textContent = String(day);
    cell.className = 'calendar-day';
    cell.setAttribute('aria-label', formatDisplayDate(dateStr));

    if (isToday) cell.classList.add('today');

    if (isPast || isWeekend) {
      cell.disabled = true;
      cell.title = isPast ? 'Past dates cannot be booked' : 'No weekend appointments';
    } else {
      cell.classList.add('filled');
      cell.addEventListener('click', () => selectDate(dateStr, cell));
    }

    if (selectedDate === dateStr) {
      cell.classList.add('selected');
    }

    grid.appendChild(cell);
  }
}

function selectDate(dateStr, cell) {
  selectedDate = dateStr;
  selectedTime = null;
  resetSlots();

  document.querySelectorAll('#calendarGrid .calendar-day.selected').forEach((day) => {
    day.classList.remove('selected');
  });
  cell.classList.add('selected');

  document.getElementById('selectedDateLabel').textContent = formatDisplayDate(dateStr);

  if (selectedCounsellorId) {
    loadSlots();
  } else {
    document.getElementById('slotList').textContent = 'Choose a counsellor first.';
  }
}

function resetSlots() {
  slotRequestVersion++;
  selectedTime = null;
  document.getElementById('slotList').replaceChildren();
  updateBookingButton();
}

async function loadCounsellors() {
  const select = document.getElementById('counsellorSelect');

  try {
    const response = await fetch('api/demoAPI.php?action=counsellor_list', { cache: 'no-store' });
    const payload = await response.json();
    if (!response.ok || !payload.success) {
      throw new Error(payload.message || 'Could not load counsellors.');
    }

    counsellors = Array.isArray(payload.data.counsellors) ? payload.data.counsellors : [];
    select.replaceChildren();

    const prompt = document.createElement('option');
    prompt.value = '';
    prompt.textContent = 'Choose a counsellor…';
    select.appendChild(prompt);

    counsellors.forEach((counsellor) => {
      const option = document.createElement('option');
      option.value = String(counsellor.counsellor_id);
      option.textContent = counsellor.name;
      select.appendChild(option);
    });
  } catch (error) {
    select.replaceChildren();
    const option = document.createElement('option');
    option.value = '';
    option.textContent = 'Could not load counsellors';
    select.appendChild(option);
    console.error('Counsellor loading failed:', error);
  }
}

function showCounsellorCard() {
  const card = document.getElementById('counsellorCard');
  const counsellor = counsellors.find((item) =>
    String(item.counsellor_id) === String(selectedCounsellorId)
  );

  if (!counsellor) {
    card.style.display = 'none';
    return;
  }

  document.getElementById('counsellorFace').textContent = counsellor.avatar || '💬';
  document.getElementById('counsellorName').textContent = counsellor.name || '';
  document.getElementById('counsellorGender').textContent = counsellor.gender || '';
  document.getElementById('counsellorSpecialties').textContent = counsellor.specialties || '';
  card.style.display = '';
}

async function loadSlots() {
  if (!selectedCounsellorId || !selectedDate) return;

  const requestVersion = ++slotRequestVersion;
  const counsellorId = selectedCounsellorId;
  const date = selectedDate;
  const list = document.getElementById('slotList');
  list.textContent = 'Loading available times…';
  selectedTime = null;
  updateBookingButton();

  try {
    const params = new URLSearchParams({
      action: 'slot_list',
      counsellor_id: String(counsellorId),
      date
    });
    const response = await fetch(`api/demoAPI.php?${params}`, { cache: 'no-store' });
    const payload = await response.json();

    // Ignore an old response if another month/date/counsellor was selected.
    if (requestVersion !== slotRequestVersion) return;

    list.replaceChildren();
    if (!response.ok || !payload.success) {
      list.textContent = payload.message || 'Could not load available times.';
      return;
    }

    const slots = Array.isArray(payload.data.slots) ? payload.data.slots : [];
    if (slots.length === 0) {
      list.textContent = 'No appointments available on this date.';
      return;
    }

    slots.forEach((slot) => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'slot';
      button.textContent = slot.time;
      button.disabled = !slot.available;

      if (slot.available) {
        button.addEventListener('click', () => {
          list.querySelectorAll('.slot.selected').forEach((item) =>
            item.classList.remove('selected')
          );
          button.classList.add('selected');
          selectedTime = slot.time;
          updateBookingButton();
        });
      }
      list.appendChild(button);
    });
  } catch (error) {
    if (requestVersion !== slotRequestVersion) return;
    list.textContent = 'Could not reach the server. Please try again.';
    console.error('Loading available times failed:', error);
  }
}

async function bookSession() {
  if (bookingInProgress || cancellationInProgress) return;
  if (appointmentLookupFailed) {
    showBookingMessage('Could not check your appointments. Refresh the page before booking.', 'error');
    return;
  }
  if (!selectedCounsellorId || !selectedDate || !selectedTime) return;

  // This is a convenience check; the server also enforces it independently.
  const alreadyAtTime = upcomingBookings.some((booking) =>
    booking.session_date === selectedDate &&
    String(booking.session_time).slice(0, 5) === selectedTime
  );
  if (alreadyAtTime) {
    showBookingMessage('You already have an appointment at that date and time. Choose another slot.', 'error');
    return;
  }

  const dateToBook = selectedDate;
  const timeToBook = selectedTime;
  const counsellorIdToBook = selectedCounsellorId;
  bookingInProgress = true;
  updateBookingButton();

  try {
    const response = await fetch('api/demoAPI.php?action=booking_create', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        counsellor_id: String(counsellorIdToBook),
        date: dateToBook,
        time: timeToBook
      })
    });
    const payload = await response.json();

    if (!response.ok || !payload.success) {
      showBookingMessage(payload.message || 'Could not book this session.', 'error');
      await loadAppointments();
      if (selectedCounsellorId && selectedDate) await loadSlots();
      return;
    }

    // Keep a local confirmation immediately. If refreshing the list fails,
    // this known successful booking must still be visible.
    upcomingBookings.push({
      booking_id: payload.data?.booking_id,
      counsellor_id: counsellorIdToBook,
      session_date: dateToBook,
      session_time: timeToBook + ':00',
      counsellor_name: counsellors.find(c => String(c.counsellor_id) === String(counsellorIdToBook))?.name || 'your counsellor',
      avatar: '💬'
    });
    upcomingBookings.sort((a, b) =>
      `${a.session_date} ${a.session_time}`.localeCompare(`${b.session_date} ${b.session_time}`)
    );
    appointmentLookupFailed = false;
    renderAppointments();
    updateBookingButton();

    showBookingMessage(
      `Appointment booked successfully for ${formatDisplayDate(dateToBook)} at ${timeToBook}. ` +
      'You can book another counsellor or another time. Your appointments are listed below.',
      'success'
    );
    await loadAppointments();
    if (selectedCounsellorId && selectedDate) await loadSlots();
  } catch (error) {
    appointmentLookupFailed = true;
    showBookingMessage(
      'The booking status could not be confirmed. Refresh and check My Upcoming Appointments before trying again.',
      'error'
    );
    console.error('Booking failed:', error);
  } finally {
    bookingInProgress = false;
    updateBookingButton();
  }
}

function renderAppointments() {
  const list = document.getElementById('appointmentsList');
  const emptyMessage = document.getElementById('noAppointmentMsg');
  list.replaceChildren();
  emptyMessage.style.display = upcomingBookings.length ? 'none' : '';

  for (const booking of upcomingBookings) {
    const card = document.createElement('div');
    card.className = 'multi-appointment-card';
    card.dataset.bookingId = String(booking.booking_id);

    const details = document.createElement('div');
    details.className = 'appt-details';
    const face = document.createElement('div');
    face.className = 'face green-face';
    face.textContent = booking.avatar || '💬';

    const text = document.createElement('div');
    const date = document.createElement('strong');
    date.textContent = `${formatDisplayDate(booking.session_date)} · ${String(booking.session_time).slice(0, 5)}`;
    const counsellor = document.createElement('p');
    counsellor.className = 'muted';
    counsellor.textContent = booking.counsellor_name;
    text.appendChild(date);
    text.appendChild(counsellor);
    details.appendChild(face);
    details.appendChild(text);

    const actions = document.createElement('div');
    actions.className = 'appt-actions';
    const rescheduleBtn = document.createElement('button');
    rescheduleBtn.type = 'button';
    rescheduleBtn.className = 'btn btn-ghost btn-small';
    rescheduleBtn.textContent = 'Reschedule';
    rescheduleBtn.disabled = bookingInProgress || cancellationInProgress;
    rescheduleBtn.addEventListener('click', () => rescheduleAppointment(booking.booking_id));

    const cancelBtn = document.createElement('button');
    cancelBtn.type = 'button';
    cancelBtn.className = 'btn btn-danger btn-small';
    cancelBtn.textContent = 'Cancel';
    cancelBtn.disabled = bookingInProgress || cancellationInProgress;
    cancelBtn.addEventListener('click', () => cancelAppointment(booking.booking_id));
    actions.appendChild(rescheduleBtn);
    actions.appendChild(cancelBtn);

    card.appendChild(details);
    card.appendChild(actions);
    list.appendChild(card);
  }
}

async function loadAppointments() {
  try {
    const response = await fetch('api/demoAPI.php?action=booking_list', { cache: 'no-store' });
    const payload = await response.json();
    if (!response.ok || !payload.success || !Array.isArray(payload.data?.bookings)) {
      throw new Error(payload.message || 'Could not load upcoming appointments.');
    }

    upcomingBookings = payload.data.bookings;
    appointmentLookupFailed = false;
    renderAppointments();
    updateBookingButton();
    return true;
  } catch (error) {
    appointmentLookupFailed = true;
    updateBookingButton();
    showBookingMessage('Could not load upcoming appointments. Check that demoAPI.php contains the booking_list action.', 'error');
    console.error('Loading upcoming appointments failed:', error);
    return false;
  }
}

async function rescheduleAppointment(bookingId) {
  const booking = upcomingBookings.find((item) => String(item.booking_id) === String(bookingId));
  if (!booking) return;
  if (!confirm(
    `Reschedule the appointment with ${booking.counsellor_name}? ` +
    'Your existing session will be cancelled first, then you can choose a new date and time.'
  )) return;

  const cancelled = await cancelAppointment(bookingId, true);
  if (!cancelled) return;

  const select = document.getElementById('counsellorSelect');
  if (booking.counsellor_id) {
    select.value = String(booking.counsellor_id);
    selectedCounsellorId = String(booking.counsellor_id);
    showCounsellorCard();
  }
  selectedDate = null;
  resetSlots();
  renderCalendar();
  document.getElementById('selectedDateLabel').textContent =
    'Choose your replacement date and time.';
  showBookingMessage('Old appointment cancelled. Select a new date and time, then press Book Session.', 'success');
  select.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

async function cancelAppointment(bookingId, isReschedule = false) {
  if (cancellationInProgress || bookingInProgress) return false;
  const booking = upcomingBookings.find((item) => String(item.booking_id) === String(bookingId));
  if (!booking) return false;

  if (!isReschedule && !confirm(
    `Cancel your appointment with ${booking.counsellor_name} on ` +
    `${formatDisplayDate(booking.session_date)} at ${String(booking.session_time).slice(0, 5)}?`
  )) return false;

  cancellationInProgress = true;
  updateBookingButton();
  renderAppointments();

  try {
    const response = await fetch('api/demoAPI.php?action=booking_cancel', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ booking_id: String(bookingId) })
    });
    const payload = await response.json();
    if (!response.ok || !payload.success) {
      showBookingMessage(payload.message || 'Could not cancel this appointment.', 'error');
      return false;
    }

    // Delete only the requested card, keeping all other appointments intact.
    upcomingBookings = upcomingBookings.filter((item) => String(item.booking_id) !== String(bookingId));
    renderAppointments();
    if (!isReschedule) {
      showBookingMessage('Selected appointment cancelled. Your other sessions are still booked.', 'success');
    }
    await loadAppointments();
    if (selectedCounsellorId && selectedDate) await loadSlots();
    return true;
  } catch (error) {
    appointmentLookupFailed = true;
    showBookingMessage('Cancellation status could not be confirmed. Refresh and check your appointments.', 'error');
    console.error('Cancelling appointment failed:', error);
    return false;
  } finally {
    cancellationInProgress = false;
    updateBookingButton();
    renderAppointments();
  }
}
