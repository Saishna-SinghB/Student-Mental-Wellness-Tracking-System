<?php require_once __DIR__ . '/auth-check.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <script>
    if (localStorage.getItem('wellnesshub_dark_mode') === '1') {
      document.documentElement.classList.add('theme-pending-dark');
    }
  </script>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Settings — WellnessHub</title>
  <link rel="stylesheet" href="css/style.css" />
  <style>
    /* Only real settings are clickable. Privacy indicators stay locked on. */
    .switch { cursor: pointer; }
    .switch.disabled { cursor: not-allowed; opacity: .6; }
  </style>
</head>

<body class="app-body">
  <script src="js/theme.js"></script>
  <script src="js/notif-badge.js"></script>

  <div class="app-shell">
    <aside class="sidebar student-sidebar">
      <a class="brand-mini sidebar-brand" href="index.php">
        <span class="mini-leaf" aria-hidden="true">☘</span>
        <span>WellnessHub</span>
      </a>

      <nav class="side-nav" aria-label="Student navigation">
        <a href="dashboard.php"><span>▣</span> Dashboard</a>
        <a href="mood-tracking.php"><span>☺</span> Mood Tracking</a>
        <a href="journal.php"><span>✎</span> Journal</a>
        <a href="self-help-library.php"><span>▤</span> Self-Help Library</a>
        <a href="counselling-booking.php"><span>♡</span> Book Counselling</a>
        <a href="peer-support.php"><span>☷</span> Peer Support</a>
        <a href="achievements.php"><span>★</span> Achievements</a>
        <a href="notifications.php"><span>🔔</span> Notifications</a>
        <a class="active" href="settings.php"><span>⚙</span> Settings</a>
        <a href="logout.php"><span>↪</span> Logout</a>
      </nav>
    </aside>

    <main class="dashboard-main">
      <header class="topbar">
        <div>
          <p class="eyebrow">Student Side</p>
          <h1>Settings</h1>
          <p class="page-subtitle">Manage privacy, notifications and display preferences.</p>
        </div>

        <div class="topbar-actions">
          <a class="icon-btn notif-bell" href="notifications.php" aria-label="Notifications">🔔<span class="notif-dot" id="notifDot" style="display:none;"></span></a>
          <?php $firstName = explode(' ', $_SESSION['full_name'])[0]; ?>
          <?php $avatarStyle = !empty($_SESSION['profile_picture']) ? ' style="background-image:url(\'' . htmlspecialchars($_SESSION['profile_picture'], ENT_QUOTES) . '\'); background-size:cover; background-position:center;"' : ''; ?>
          <a href="profile.php" class="avatar" aria-label="My Profile"<?= $avatarStyle ?>><?= empty($_SESSION['profile_picture']) ? htmlspecialchars(strtoupper(substr($firstName, 0, 1))) : '' ?></a>
        </div>
      </header>

      <section class="two-col">
        <article class="panel">
          <h2>Privacy &amp; Security</h2>

          <div class="setting-row">
            <div>
              <strong>POPIA privacy protection</strong>
              <p class="muted">Keep journal entries and mood logs private.</p>
            </div>
            <span class="switch on disabled" title="Always on — this is not a changeable preference."></span>
          </div>

          <div class="setting-row">
            <div>
              <strong>Anonymous peer support</strong>
              <p class="muted">Hide your name when posting.</p>
            </div>
            <span class="switch on disabled" title="Always on — posts are shown without your name. Account IDs are retained for moderation."></span>
          </div>

          <!-- Only a link; the actual form is on change-password.php. -->
          <div class="setting-row">
            <div>
              <strong>Account password</strong>
              <p class="muted">Open the separate Change Password page.</p>
            </div>
            <a class="btn btn-primary btn-small" href="change-password.php">Change</a>
          </div>
        </article>

        <article class="panel">
          <h2>Display &amp; Notifications</h2>

          <div class="setting-row">
            <div>
              <strong>Dark mode</strong>
              <p class="muted">Use dark mode for night-time journaling.</p>
            </div>
            <span class="switch" id="switchDarkMode" data-key="dark_mode"></span>
          </div>

          <div class="setting-row">
            <div>
              <strong>Booking reminders</strong>
              <p class="muted">Receive counselling appointment reminders.</p>
            </div>
            <span class="switch" id="switchBookingReminders" data-key="booking_reminders"></span>
          </div>

          <div class="setting-row">
            <div>
              <strong>Weekly mood email</strong>
              <p class="muted">Receive Monday mood summaries.</p>
            </div>
            <span class="switch" id="switchWeeklyEmail" data-key="weekly_mood_email" title="Preference saved; actual weekly email delivery is not yet implemented."></span>
          </div>
        </article>
      </section>
    </main>
  </div>

  <script src="js/settings.js"></script>
</body>
</html>
