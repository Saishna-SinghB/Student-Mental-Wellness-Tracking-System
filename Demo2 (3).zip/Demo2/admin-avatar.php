<?php
// ADMIN PROFILE PICTURE

$adminName = trim(
    (string)($_SESSION['full_name'] ?? 'Admin')
);

$adminInitial = strtoupper(
    substr($adminName, 0, 1)
);

$adminPhoto = $_SESSION['profile_picture'] ?? '';

$hasAdminPhoto = is_string($adminPhoto)
    && preg_match(
        '#^data:image/(?:png|jpeg|gif|webp);base64,[A-Za-z0-9+/=]+$#D',
        $adminPhoto
    ) === 1;
?>

<a
    href="admin-profile.php"
    class="avatar admin-avatar"
    title="Click to view My Profile"
    aria-label="Open My Profile"
>
    <?php if ($hasAdminPhoto): ?>

        <img
            src="<?= htmlspecialchars(
                $adminPhoto,
                ENT_QUOTES,
                'UTF-8'
            ) ?>"
            alt="Admin profile picture"
            style="
                width:100%;
                height:100%;
                object-fit:cover;
                border-radius:50%;
                display:block;
            "
        >

    <?php else: ?>

        <?= htmlspecialchars(
            $adminInitial,
            ENT_QUOTES,
            'UTF-8'
        ) ?>

    <?php endif; ?>
</a>