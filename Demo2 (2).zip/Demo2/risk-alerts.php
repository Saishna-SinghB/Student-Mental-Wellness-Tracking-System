
<?php
require_once __DIR__ . '/counsellor-auth.php';

$counsellorName = trim(
    (string)($_SESSION['full_name'] ?? 'Counsellor')
);

$counsellorInitial = strtoupper(
    substr($counsellorName, 0, 1)
);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Crisis Detection / Risk Alerts — WellnessHub</title>

    <link rel="stylesheet" href="css/style.css">

    <style>
        /* REFRESH BUTTON */

        .risk-refresh-btn {
            background: #2468b6;
            color: #ffffff;
            border: 1px solid #438be0;
            border-radius: 12px;
            padding: 11px 18px;
            font-size: 14px;
            font-weight: 800;
            cursor: pointer;
        }

        .risk-refresh-btn:hover {
            background: #3483d4;
        }

        .risk-refresh-btn:disabled {
            opacity: 0.6;
            cursor: wait;
        }

        /* REVIEW BUTTON */

        .risk-item {
            cursor: pointer;
            transition: border-color 0.2s ease;
        }

        .risk-item:hover {
            border-color: #559fea;
        }

        .risk-item.selected-risk {
            outline: 2px solid #68aaff;
            outline-offset: 2px;
        }

        .risk-review-btn {
            background: #275c9b !important;
            color: #ffffff !important;
            border: 1px solid #4685c7 !important;
            border-radius: 12px;
            padding: 12px 20px;
            font-weight: 800;
            cursor: pointer;
        }

        .risk-review-btn:hover {
            background: #377dc3 !important;
        }

        /* ACTION NOTE */

        .risk-note-textarea {
            width: 100%;
            min-height: 150px;
            padding: 16px;
            background: #0c1a2e;
            color: #ffffff;
            border: 1px solid #385474;
            border-radius: 14px;
            resize: vertical;
            font-size: 15px;
        }

        .risk-note-textarea::placeholder {
            color: #97aabe;
        }

        .risk-note-textarea:focus {
            outline: 2px solid #62a6f5;
            outline-offset: 2px;
        }

        .risk-action-buttons {
            display: flex;
            gap: 12px;
            margin-top: 18px;
        }

        /* MARK IN PROGRESS */

        #markInProgressBtn {
            background: #187b81;
            color: #ffffff;
            border: 1px solid #2ca6a8;
            border-radius: 13px;
            font-weight: 800;
            padding: 14px 18px;
            cursor: pointer;
        }

        #markInProgressBtn:hover:not(:disabled) {
            background: #20999c;
        }

        /* RESOLVE BUTTON */

        #resolveBtn {
            background: #286cc4;
            color: #ffffff;
            border: 1px solid #4b91e5;
            border-radius: 13px;
            font-weight: 800;
            padding: 14px 18px;
            cursor: pointer;
        }

        #resolveBtn:hover:not(:disabled) {
            background: #3987e0;
        }

        /* DISABLED BUTTONS */

        #markInProgressBtn:disabled,
        #resolveBtn:disabled {
            opacity: 0.48;
            cursor: not-allowed;
        }

        /* FEEDBACK MESSAGES */

        .risk-feedback {
            margin: 14px 0;
            font-size: 14px;
            color: #b9d3ee;
        }

        .risk-feedback.success {
            color: #8ce9b3;
        }

        .risk-feedback.error {
            color: #ffabab;
        }

        .risk-feedback.info {
            color: #b9d3ee;
        }

        @media (max-width: 768px) {
            .risk-action-buttons {
                flex-direction: column;
            }
        }
    </style>
</head>

<body class="app-body dark-body counsellor-body">

<div class="app-shell dark-shell">

    <!-- COUNSELLOR SIDEBAR -->

    <aside class="sidebar counsellor-sidebar">

        <a class="brand-mini sidebar-brand" href="index.php">
            <span class="mini-leaf" aria-hidden="true">☘</span>
            <span>WellnessHub</span>
        </a>

        <nav
            class="side-nav"
            aria-label="Counsellor navigation"
        >

            <a href="counsellor-dashboard.php">
                <span>▣</span> Dashboard
            </a>

            <a href="counsellor-students.php">
                <span>👥</span> Students
            </a>

            <a
                class="active"
                href="risk-alerts.php"
            >
                <span>⚠</span> Risk Alerts
            </a>

            <a href="counsellor-appointments.php">
                <span>📅</span> Appointments
            </a>

            <a href="counsellor-resources.php">
                <span>▤</span> Resources
            </a>

            <a href="logout.php">
                <span>↪</span> Logout
            </a>

        </nav>

    </aside>

    <!-- MAIN CONTENT -->

    <main class="dashboard-main dark-main">

        <header class="topbar dark-topbar">

            <div>
                <p class="eyebrow">Counsellor Side</p>

                <h1>Crisis Detection / Risk Alerts</h1>

                <p class="page-subtitle">
                    Early warning alerts from mood trends
                    and journal risk markers.
                </p>
            </div>

            <div class="topbar-actions">

                <a
                    class="icon-btn dark-icon"
                    href="risk-alerts.php"
                    aria-label="Alerts"
                >
                    🔔
                </a>

                <div class="avatar dark-avatar">
                    <?= htmlspecialchars(
                        $counsellorInitial,
                        ENT_QUOTES,
                        'UTF-8'
                    ) ?>
                </div>

            </div>

        </header>

        <section class="two-col">

            <!-- ALERTS PANEL -->

            <article class="panel">

                <div class="panel-heading">

                    <h2>
                        AI Alerts
                        <span
                            class="pill pill-red"
                            id="alertCount"
                        >
                            0
                        </span>
                    </h2>

                    <button
                        class="risk-refresh-btn"
                        id="refreshBtn"
                        type="button"
                    >
                        🔄 Refresh
                    </button>

                </div>

                <p
                    id="riskFeedback"
                    class="risk-feedback"
                    role="status"
                    aria-live="polite"
                >
                    Loading alerts...
                </p>

                <div class="risk-list" id="riskList">

                    <p
                        class="muted"
                        id="riskEmpty"
                        style="display:none;"
                    >
                        No active risk alerts right now.
                    </p>

                </div>

            </article>

            <!-- ACTION NOTE PANEL -->

            <article class="panel">

                <h2>Action Note</h2>

                <p
                    class="page-subtitle"
                    id="selectedStudentLabel"
                >
                    Select an alert on the left to act on it.
                </p>

                <input
                    type="hidden"
                    id="selectedAlertId"
                    value=""
                >

                <label class="field">

                    <span>Next Step / Follow-up Note</span>

                    <textarea
                        class="risk-note-textarea"
                        id="actionNote"
                        placeholder="Add an internal note for follow-up..."
                    ></textarea>

                </label>

                <div class="risk-action-buttons">

                    <button
                        type="button"
                        class="btn btn-full"
                        id="markInProgressBtn"
                        disabled
                    >
                        Mark In Progress
                    </button>

                    <button
                        type="button"
                        class="btn btn-full"
                        id="resolveBtn"
                        disabled
                    >
                        Resolve & Save Note
                    </button>

                </div>

                <p
                    id="actionFeedback"
                    class="risk-feedback"
                    role="status"
                    aria-live="polite"
                ></p>

            </article>

        </section>

    </main>

</div>

<script src="js/risk-alerts.js"></script>

</body>
</html>
