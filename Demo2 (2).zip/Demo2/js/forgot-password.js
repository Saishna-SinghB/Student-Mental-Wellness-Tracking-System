
document.addEventListener("DOMContentLoaded", () => {

    const API = "api/demoAPI.php";
    const RESEND_SECONDS = 60;

    const EMAIL_KEY = "userResetEmail";
    const TOKEN_KEY = "userResetToken";

    const $ = id => document.getElementById(id);

    // STEPS
    const emailStep = $("emailStep");
    const codeStep = $("codeStep");
    const passwordStep = $("passwordStep");
    const successStep = $("successStep");

    // FORMS
    const forgotEmailForm = $("forgotEmailForm");
    const verificationForm = $("verificationForm");
    const newPasswordForm = $("newPasswordForm");

    // INPUTS
    const resetEmail = $("resetEmail");
    const verificationCode = $("verificationCode");
    const newPassword = $("newPassword");
    const confirmPassword = $("confirmPassword");

    // MESSAGES
    const emailMessage = $("emailMessage");
    const codeMessage = $("codeMessage");
    const passwordMessage = $("passwordMessage");

    // BUTTONS
    const resendButton = $("resendCode");
    const backToEmailButton = $("backToEmail");

    // OTHER ELEMENTS
    const progress = $("fpSteps");
    const sentTo = $("sentTo");

    const devCodeBox = $("devCodeBox");
    const devCodeValue = $("devCodeValue");
    const devCodeUse = $("devCodeUse");

    // PASSWORD REQUIREMENTS
    const passwordHelp = $("passwordHelp");
    const lengthRequirement = $("lengthRequirement");
    const capitalRequirement = $("capitalRequirement");
    const specialRequirement = $("specialRequirement");

    // REMOVE OLD COUNSELLOR PREFIX REQUIREMENT
    const prefixRequirement = $("prefixRequirement");

    if (prefixRequirement) {
        prefixRequirement.remove();
    }

    // SAME MESSAGE FOR ALL USERS
    if (passwordHelp) {
        passwordHelp.textContent =
            "Choose a strong password you haven’t used before.";
    }

    // SHOW STEP
    function showStep(step) {

        [emailStep, codeStep, passwordStep, successStep]
            .forEach(item => {
                item.classList.remove("active-step");
            });

        step.classList.add("active-step");

        const positions = {
            emailStep: 1,
            codeStep: 2,
            passwordStep: 3,
            successStep: 4
        };

        const position = positions[step.id];

        if (progress) {
            progress.querySelectorAll("li").forEach(li => {

                const number = Number(li.dataset.step);

                li.classList.toggle("done", number < position);
                li.classList.toggle("current", number === position);

            });
        }

        if (step === codeStep && sentTo) {
            sentTo.textContent =
                savedEmail() || "your email address";
        }

        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });
    }

    // SHOW MESSAGE
    function showMessage(element, message, type) {

        element.textContent = message;
        element.classList.remove("error", "success");
        element.classList.add(type);
    }

    // CLEAR MESSAGE
    function clearMessage(element) {

        element.textContent = "";
        element.classList.remove("error", "success");
    }

    // VALID EMAIL
    function validEmail(email) {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    }

    // API REQUEST
    async function post(action, fields) {

        const response = await fetch(
            API + "?action=" + action,
            {
                method: "POST",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                body: new URLSearchParams(fields)
            }
        );

        return response.json();
    }

    // DISABLE SUBMIT BUTTONS DURING REQUEST
    function setBusy(form, busy) {

        form.querySelectorAll('button[type="submit"]')
            .forEach(button => {
                button.disabled = busy;
            });
    }

    // DEVELOPMENT VERIFICATION CODE
    function showDevCode(result) {

        if (!devCodeBox) return;

        const code = result?.data?.dev_code;

        if (code) {
            devCodeValue.textContent = code;
            devCodeBox.hidden = false;
        } else {
            devCodeValue.textContent = "------";
            devCodeBox.hidden = true;
        }
    }

    if (devCodeUse) {

        devCodeUse.addEventListener("click", () => {

            verificationCode.value =
                devCodeValue.textContent.replace(/\D/g, "");

            verificationCode.focus();
        });
    }

    // SAVED EMAIL
    function savedEmail() {
        return sessionStorage.getItem(EMAIL_KEY);
    }

    // RESTART PASSWORD RESET
    function restartFlow(message) {

        sessionStorage.removeItem(EMAIL_KEY);
        sessionStorage.removeItem(TOKEN_KEY);
        sessionStorage.removeItem("userResetRole");

        showStep(emailStep);

        showMessage(emailMessage, message, "error");
    }

    // RESEND TIMER
    let cooldownTimer = null;

    function startCooldown() {

        let seconds = RESEND_SECONDS;

        resendButton.disabled = true;

        clearInterval(cooldownTimer);

        function tick() {

            if (seconds <= 0) {

                clearInterval(cooldownTimer);

                resendButton.disabled = false;
                resendButton.textContent = "Resend Code";

                return;
            }

            resendButton.textContent =
                `Resend Code (${seconds}s)`;

            seconds--;
        }

        tick();

        cooldownTimer = setInterval(tick, 1000);
    }

    // STEP 1: SEND VERIFICATION CODE
    forgotEmailForm.addEventListener("submit", async event => {

        event.preventDefault();

        clearMessage(emailMessage);

        const email = resetEmail.value.trim().toLowerCase();

        if (!email) {

            showMessage(
                emailMessage,
                "Please enter your email address.",
                "error"
            );

            return;
        }

        if (!validEmail(email)) {

            showMessage(
                emailMessage,
                "Please enter a valid email address.",
                "error"
            );

            return;
        }

        setBusy(forgotEmailForm, true);

        try {

            const result = await post(
                "forgot_password_request",
                { email }
            );

            if (!result.success) {

                showMessage(
                    emailMessage,
                    result.message || "Unable to send code.",
                    "error"
                );

                return;
            }

            sessionStorage.setItem(EMAIL_KEY, email);
            sessionStorage.removeItem(TOKEN_KEY);
            sessionStorage.removeItem("userResetRole");

            showMessage(
                emailMessage,
                "If that account exists, a verification code has been sent.",
                "success"
            );

            showDevCode(result);

            setTimeout(() => {

                showStep(codeStep);

                clearMessage(codeMessage);

                verificationCode.value = "";
                verificationCode.focus();

                startCooldown();

            }, 700);

        } catch (error) {

            showMessage(
                emailMessage,
                "Could not reach the server.",
                "error"
            );

        } finally {

            setBusy(forgotEmailForm, false);
        }
    });

    // STEP 2: VERIFY CODE
    verificationCode.addEventListener("input", () => {

        verificationCode.value =
            verificationCode.value.replace(/\D/g, "").slice(0, 6);

    });

    verificationForm.addEventListener("submit", async event => {

        event.preventDefault();

        clearMessage(codeMessage);

        const enteredCode = verificationCode.value.trim();

        if (enteredCode.length !== 6) {

            showMessage(
                codeMessage,
                "Please enter the complete 6-digit code.",
                "error"
            );

            return;
        }

        const email = savedEmail();

        if (!email) {

            restartFlow(
                "Your session expired. Please enter your email again."
            );

            return;
        }

        setBusy(verificationForm, true);

        try {

            const result = await post(
                "forgot_password_verify",
                {
                    email,
                    code: enteredCode
                }
            );

            if (!result.success) {

                showMessage(
                    codeMessage,
                    result.message || "Invalid code.",
                    "error"
                );

                return;
            }

            if (!result.data?.reset_token) {

                showMessage(
                    codeMessage,
                    "Reset token missing. Please request a new code.",
                    "error"
                );

                return;
            }

            sessionStorage.setItem(
                TOKEN_KEY,
                result.data.reset_token
            );

            showDevCode(null);

            showMessage(
                codeMessage,
                "Account verified successfully.",
                "success"
            );

            setTimeout(() => {

                showStep(passwordStep);
                newPassword.focus();

            }, 600);

        } catch (error) {

            showMessage(
                codeMessage,
                "Could not reach the server.",
                "error"
            );

        } finally {

            setBusy(verificationForm, false);
        }
    });

    // RESEND CODE
    resendButton.addEventListener("click", async () => {

        clearMessage(codeMessage);

        const email = savedEmail();

        if (!email) {

            restartFlow(
                "Your session expired. Please enter your email again."
            );

            return;
        }

        resendButton.disabled = true;

        try {

            const result = await post(
                "forgot_password_request",
                { email }
            );

            if (!result.success) {

                showMessage(
                    codeMessage,
                    result.message || "Unable to resend code.",
                    "error"
                );

                resendButton.disabled = false;

                return;
            }

            verificationCode.value = "";

            showDevCode(result);

            showMessage(
                codeMessage,
                "A new verification code has been sent.",
                "success"
            );

            startCooldown();

        } catch (error) {

            showMessage(
                codeMessage,
                "Could not reach the server.",
                "error"
            );

            resendButton.disabled = false;
        }
    });

    // BACK TO EMAIL
    backToEmailButton.addEventListener("click", () => {

        clearInterval(cooldownTimer);

        verificationCode.value = "";

        clearMessage(codeMessage);
        clearMessage(emailMessage);

        showDevCode(null);

        sessionStorage.removeItem(TOKEN_KEY);
        sessionStorage.removeItem("userResetRole");

        showStep(emailStep);
        resetEmail.focus();
    });

    // STEP 3: NEW PASSWORD
    // SAME REQUIREMENTS FOR ALL USERS

    const SPECIAL = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>/?]/;

    function updateRequirement(element, valid, label) {

        if (!element) return;

        element.classList.toggle("valid", valid);

        element.textContent =
            (valid ? "✓ " : "○ ") + label;
    }

    // LIVE PASSWORD CHECKS
    newPassword.addEventListener("input", () => {

        const password = newPassword.value;

        updateRequirement(
            lengthRequirement,
            password.length >= 8,
            "At least 8 characters"
        );

        updateRequirement(
            capitalRequirement,
            /[A-Z]/.test(password),
            "At least one uppercase letter"
        );

        updateRequirement(
            specialRequirement,
            SPECIAL.test(password),
            "At least one special character (e.g. @ ! #)"
        );
    });

    // RESET PASSWORD
    newPasswordForm.addEventListener("submit", async event => {

        event.preventDefault();

        clearMessage(passwordMessage);

        const password = newPassword.value;
        const confirm = confirmPassword.value;

        if (password.length < 8) {

            showMessage(
                passwordMessage,
                "Password must contain at least 8 characters.",
                "error"
            );

            return;
        }

        if (!/[A-Z]/.test(password)) {

            showMessage(
                passwordMessage,
                "Password must contain an uppercase letter.",
                "error"
            );

            return;
        }

        if (!SPECIAL.test(password)) {

            showMessage(
                passwordMessage,
                "Password must contain at least one special character.",
                "error"
            );

            return;
        }

        if (password !== confirm) {

            showMessage(
                passwordMessage,
                "The passwords do not match.",
                "error"
            );

            return;
        }

        const email = savedEmail();

        const resetToken =
            sessionStorage.getItem(TOKEN_KEY);

        if (!email || !resetToken) {

            restartFlow(
                "Your session expired. Please start again."
            );

            return;
        }

        setBusy(newPasswordForm, true);

        try {

            const result = await post(
                "forgot_password_reset",
                {
                    email,
                    reset_token: resetToken,
                    new_password: password
                }
            );

            if (!result.success) {

                showMessage(
                    passwordMessage,
                    result.message || "Password reset failed.",
                    "error"
                );

                return;
            }

            // CLEAR RESET INFORMATION
            sessionStorage.removeItem(EMAIL_KEY);
            sessionStorage.removeItem(TOKEN_KEY);
            sessionStorage.removeItem("userResetRole");

            newPassword.value = "";
            confirmPassword.value = "";

            // SUCCESS PAGE
            showStep(successStep);

        } catch (error) {

            showMessage(
                passwordMessage,
                "Could not reach the server.",
                "error"
            );

        } finally {

            setBusy(newPasswordForm, false);
        }
    });

});
