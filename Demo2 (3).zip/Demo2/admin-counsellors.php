<?php
require_once __DIR__ . '/admin-auth.php';
require_once __DIR__ . '/demoDB.php';

// ADMIN DETAILS
$adminName = trim((string)($_SESSION['full_name'] ?? 'Admin'));

$adminInitial = strtoupper(
    substr($adminName !== '' ? $adminName : 'Admin', 0, 1)
);

// GET SAVED ADMIN PROFILE PICTURE
$adminPicture = (string)($_SESSION['profile_picture'] ?? '');

try {
    $stmt = $pdo->prepare("
        SELECT profile_picture
        FROM users
        WHERE user_id = ?
        AND role = 'admin'
        LIMIT 1
    ");

    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        $adminPicture = (string)($user['profile_picture'] ?? '');
        $_SESSION['profile_picture'] = $adminPicture;
    }

} catch (PDOException $e) {
    error_log('Admin picture error: ' . $e->getMessage());
}

// VALIDATE IMAGE
$hasAdminPicture = preg_match(
    '#^data:image/(?:png|jpeg|gif|webp);base64,[A-Za-z0-9+/=]+$#D',
    $adminPicture
) === 1;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Counsellors — WellnessHub</title>

    <link rel="stylesheet" href="css/style.css">

    <style>
        /* EXISTING MODAL STYLES */
        .modal-overlay {
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,.45);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 50;
        }

        .modal-box {
            width: min(420px, 90vw);
            max-height: 85vh;
            overflow-y: auto;
        }

        .forgot-message.error {
            color: #c44848;
        }

        .forgot-message.success {
            color: #2f744d;
        }

        /* PERFECTLY ROUND ADMIN PROFILE PICTURE */
        .topbar-actions .avatar.admin-avatar {
            width: 44px !important;
            height: 44px !important;
            min-width: 44px !important;
            min-height: 44px !important;
            flex: 0 0 44px !important;
            aspect-ratio: 1 / 1;
            border-radius: 50% !important;
            overflow: hidden;
            padding: 0;
            display: grid;
            place-items: center;
            box-sizing: border-box;
        }

        .topbar-actions .avatar.admin-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-radius: 50%;
            display: block;
        }
    </style>
</head>

<body class="app-body admin-body">

<div class="app-shell admin-shell">

    <!-- ADMIN SIDEBAR -->
    <aside class="sidebar admin-sidebar">

        <a class="brand-mini sidebar-brand" href="index.php">
            <span class="mini-leaf" aria-hidden="true">☘</span>
            <span>WellnessHub</span>
        </a>

        <nav class="side-nav" aria-label="Admin navigation">

            <a href="admin-dashboard.php">
                <span>▣</span> Dashboard
            </a>

            <a href="admin-users.php">
                <span>👥</span> Users
            </a>

            <a class="active" href="admin-counsellors.php">
                <span>♡</span> Counsellors
            </a>

            <a href="admin-reports.php">
                <span>📊</span> Reports
            </a>

            <a href="system-logs.php">
                <span>☷</span> System Logs
            </a>

            <a href="admin-settings.php">
                <span>⚙</span> Settings
            </a>

            <a href="admin-profile.php">
                <span>👤</span> My Profile
            </a>

            <a href="logout.php">
                <span>↪</span> Logout
            </a>

        </nav>
    </aside>

    <!-- MAIN CONTENT -->
    <main class="dashboard-main admin-main">

        <header class="topbar admin-topbar">

            <div>
                <p class="eyebrow">Admin Side</p>

                <h1>Counsellors</h1>

                <p class="page-subtitle">
                    Manage counsellor workload and availability.
                </p>
            </div>

            <div class="topbar-actions">

                <!-- NOTIFICATION ICON -->
                <a class="icon-btn admin-icon"
                   href="system-logs.php"
                   aria-label="System logs">
                    🔔
                </a>

                <!-- ROUND PROFILE PICTURE -->
                <a href="admin-profile.php"
                   class="avatar admin-avatar"
                   title="Click to view My Profile"
                   aria-label="Open My Profile">

                    <?php if ($hasAdminPicture): ?>

                        <img
                            src="<?= htmlspecialchars(
                                $adminPicture,
                                ENT_QUOTES,
                                'UTF-8'
                            ) ?>"
                            alt="Admin profile picture"
                        >

                    <?php else: ?>

                        <?= htmlspecialchars(
                            $adminInitial,
                            ENT_QUOTES,
                            'UTF-8'
                        ) ?>

                    <?php endif; ?>

                </a>

            </div>
        </header>

        <!-- ADD COUNSELLOR BUTTON -->
        <div class="inline"
             style="margin-bottom:14px; justify-content:flex-end;">

            <button
                class="btn btn-purple btn-small"
                type="button"
                id="addCounsellorBtn">
                Add Counsellor
            </button>

        </div>

        <!-- COUNSELLORS GRID -->
        <section class="three-col" id="counsellorGrid">
            <p class="muted">Loading counsellors…</p>
        </section>

        <!-- ADD COUNSELLOR MODAL -->
        <div id="addCounsellorModal"
             class="modal-overlay"
             style="display:none;">

            <div class="modal-box panel">

                <h2>Add Counsellor</h2>

                <p class="muted">
                    Creates both a real login account
                    and a booking-page profile.
                </p>

                <label class="field">
                    <span>Full Name</span>
                    <input type="text" id="ccName">
                </label>

                <label class="field">
                    <span>Email</span>
                    <input type="email"
                           id="ccEmail"
                           placeholder="Enter email address">
                </label>

                <label class="field">
                    <span>Password</span>
                    <input type="text"
                           id="ccPassword"
                           placeholder='Must start with "123"'>
                </label>

                <label class="field">
                    <span>Gender</span>

                    <select id="ccGender">
                        <option value="Prefer not to say">
                            Prefer not to say
                        </option>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                        <option value="Non-binary">Non-binary</option>
                    </select>
                </label>

                <label class="field">
                    <span>Specialties</span>
                    <input type="text"
                           id="ccSpecialties"
                           placeholder="e.g. Anxiety, Academic Stress">
                </label>

                <label class="field">
                    <span>Avatar Emoji</span>
                    <input type="text"
                           id="ccAvatar"
                           placeholder="🧑🏽">
                </label>

                <p id="ccMessage" class="forgot-message"></p>

                <div class="inline" style="margin-top:10px;">

                    <button class="btn btn-ghost"
                            type="button"
                            id="ccCancel">
                        Cancel
                    </button>

                    <button class="btn btn-primary"
                            type="button"
                            id="ccSubmit">
                        Create Counsellor
                    </button>

                </div>
            </div>
        </div>

    </main>
</div>

<!-- EXISTING JAVASCRIPT -->
<script src="js/admin-counsellors.js"></script>

</body>
</html>