
<?php

$sections = [

[
"Introduction and Scope",
"WellnessHub is a student mental wellness platform designed to support emotional wellbeing through mood tracking, stress assessments, private journaling, wellness progress monitoring and counselling support. This Privacy and Personal Information Protection Policy explains how WellnessHub collects, processes, stores, protects, shares and deletes personal information in accordance with South Africa's Protection of Personal Information Act 4 of 2013 (POPIA). The policy applies to students, registered users, counsellors, administrators and other authorized persons who interact with the platform. WellnessHub recognizes that mental health information is particularly sensitive and requires enhanced confidentiality, responsible handling and appropriate security safeguards."
],

[
"Responsible Party and Information Officer",
"Under POPIA, the responsible party is the organization that determines why and how personal information is processed. The organization operating WellnessHub is responsible for establishing appropriate privacy policies, security procedures, lawful processing grounds and accountability mechanisms. An Information Officer must oversee compliance responsibilities and respond to requests relating to personal information. Before this policy is published, WellnessHub must identify its actual legal operating entity, physical address, Information Officer and privacy contact details. Responsible Party: [ORGANIZATION NAME]. Address: [PHYSICAL ADDRESS]. Information Officer: [NAME]. Privacy Email: [EMAIL ADDRESS]."
],

[
"Definitions Under POPIA",
"Personal information means information relating to an identifiable living individual or, where applicable, an identifiable existing juristic person. A data subject is the individual whose personal information is being processed. Processing includes collecting, recording, organizing, storing, updating, retrieving, using, distributing and deleting personal information. Special personal information includes sensitive categories such as information concerning a person's health. A responsible party determines the purposes and means of processing personal information, while an operator processes information on behalf of a responsible party under a contract or mandate. Consent means a voluntary, specific and informed expression of agreement."
],

[
"Categories of Personal Information Collected",
"WellnessHub may collect personal information necessary for its services, including full names, email addresses, student identification details, login credentials, account preferences, mood assessments, stress ratings, journal entries, counselling requests, appointment information, consent records and account activity. Technical information such as session identifiers, security logs and device information may also be processed where necessary for platform security and functionality. WellnessHub must ensure that the information collected is relevant, adequate and not excessive for the purpose for which it is required."
],

[
"Special Personal Information and Mental Health Data",
"Information concerning a student's emotional wellbeing, stress levels, psychological experiences, counselling interactions and personal journal entries may constitute special personal information under POPIA. Such information requires additional protection because unauthorized disclosure could affect an individual's privacy, dignity, wellbeing or personal relationships. WellnessHub must establish an applicable legal authorization or statutory exception before processing special personal information. Access must be restricted to appropriately authorized persons, and sensitive information must not be disclosed merely because an individual has registered an account."
],

[
"Purpose of Collecting Personal Information",
"WellnessHub processes information for specific purposes connected to the delivery of mental wellness services. These purposes may include creating user accounts, authenticating registered users, recording daily mood check-ins, displaying stress trends, maintaining personal journals, facilitating counselling requests, providing wellness resources, responding to support enquiries and protecting the security of the platform. Information must not be used for unrelated purposes without an appropriate lawful basis. Private journal entries must not automatically be used for advertising, unrelated research, artificial intelligence training or institutional monitoring."
],

[
"Lawful Processing and Consent",
"Section 11 of POPIA establishes circumstances under which personal information may lawfully be processed. These include consent, contractual necessity, compliance with legal obligations and other grounds recognized by the Act. Where WellnessHub relies on consent, it must be voluntary, specific and informed. Users should understand what information is collected, why it is required and how it will be used. Where applicable, users must be able to withdraw consent. Additional legal requirements apply to the processing of special personal information, and ordinary acceptance of website terms must not be treated as unrestricted permission to process sensitive mental health information."
],

[
"Condition 1: Accountability",
"Accountability requires the responsible party to ensure that all eight conditions for lawful processing are satisfied. WellnessHub must establish appropriate procedures for protecting personal information throughout its lifecycle. This includes assigning privacy responsibilities, maintaining records of processing activities, reviewing security arrangements, providing appropriate staff training and evaluating potential privacy risks. The responsible party remains accountable for ensuring that personal information is processed lawfully, including where authorized service providers assist with processing."
],

[
"Condition 2: Processing Limitation",
"Processing limitation requires personal information to be processed lawfully and reasonably in a manner that does not unnecessarily infringe privacy. WellnessHub should collect only the information necessary to deliver its intended services. Students should not be required to disclose unnecessary personal experiences or sensitive details to access basic platform functionality. Information should generally be collected directly from the individual concerned, subject to exceptions recognized under POPIA. Appropriate safeguards must prevent excessive collection, unauthorized access and processing beyond legitimate purposes."
],

[
"Condition 3: Purpose Specification",
"Purpose specification requires WellnessHub to collect information for a specific, explicitly defined and lawful purpose. Users must be informed why their information is needed before it is collected, subject to applicable statutory exceptions. Information should not be retained for longer than necessary unless a lawful retention ground applies. WellnessHub should establish documented retention periods for user accounts, mood records, journal entries, counselling requests, technical logs and backup records. Information that is no longer required should be securely deleted, destroyed or de-identified where appropriate."
],

[
"Condition 4: Further Processing Limitation",
"Personal information collected for one purpose must not automatically be used for unrelated purposes. Any further processing must be compatible with the original collection purpose or otherwise authorized by law. For example, a journal entry submitted for private personal reflection should not automatically become available to university management, advertisers or external researchers. WellnessHub must assess additional processing activities, including institutional reporting, predictive analytics, artificial intelligence features and research projects, before introducing them."
],

[
"Condition 5: Information Quality",
"WellnessHub must take reasonably practicable steps to ensure that personal information is complete, accurate, not misleading and updated where necessary, taking account of the purpose for which it is used. Students should have appropriate methods to update incorrect account details. Mood and stress assessments represent information reported by users at particular times and should not automatically be interpreted as confirmed medical diagnoses. Where counselling or clinical information is involved, correction procedures must also respect applicable professional and legal requirements."
],

[
"Condition 6: Openness",
"Openness requires transparency about the collection and processing of personal information. WellnessHub must provide appropriate information about the identity of the responsible party, the categories of information collected, the purposes of processing, relevant recipients, applicable rights and possible international transfers. Users should be informed whether providing particular information is mandatory or voluntary and what consequences may result from not providing it. Material changes to privacy practices should be communicated appropriately."
],

[
"Condition 7: Security Safeguards",
"WellnessHub must implement appropriate and reasonable technical and organizational security measures to protect personal information against loss, damage, unauthorized destruction, unlawful access and unlawful processing. Measures should include secure password hashing, encrypted connections, appropriate database permissions, access controls, secure session handling, input validation, software updates, security monitoring and protected backups. Access to sensitive mental health information should be limited according to authorized roles. Security procedures must be regularly assessed and improved as necessary."
],

[
"Condition 8: Data Subject Participation",
"POPIA provides data subjects with rights relating to their personal information, subject to applicable legal requirements and exceptions. Users may request confirmation of whether their information is held, request access to qualifying records, seek correction or deletion of certain information and exercise applicable objection rights. WellnessHub must provide an appropriate procedure for receiving and responding to such requests. Identity verification may be required to protect information from unauthorized disclosure."
],

[
"Privacy and Confidentiality of Personal Journals",
"WellnessHub provides a personal journaling feature intended to allow students to record their thoughts, feelings and emotional experiences. Journal entries should be private by default and protected against unauthorized access. The platform must clearly explain whether entries are stored in a database, locally on a device or through another service. Counsellors, administrators and other users should not receive access unless an appropriate lawful basis and authorization exist. Journal content should not be exposed in system logs, public reports or notifications."
],

[
"Mood Tracking and Stress Assessments",
"WellnessHub may allow users to record daily moods, emotional experiences and stress levels. This information may be used to display personal wellness patterns and historical trends. Mood assessments should be treated as personal wellbeing indicators rather than professional medical diagnoses. Users should receive clear explanations of how their responses are stored, analyzed and displayed. Access to identifiable assessment records must be appropriately restricted, and any additional use for institutional analytics must comply with applicable privacy requirements."
],

[
"Counselling Services and Support Referrals",
"Where WellnessHub offers counselling appointments, referrals or support services, it must clearly explain what personal information is shared with counsellors or other service providers. Information sharing must be limited to what is necessary and lawfully permitted. Counselling notes and sensitive communications should be protected from unnecessary administrative access. If emergency intervention or risk escalation procedures are introduced, WellnessHub must establish lawful grounds, appropriate criteria, safeguards and clear disclosures to users."
],

[
"Automated Processing and Artificial Intelligence",
"If WellnessHub introduces artificial intelligence, automated emotional assessments or predictive wellness features, users should receive appropriate information about the processing involved. Automated results should not be represented as confirmed medical diagnoses. Where decisions are based solely on automated processing and produce legal or similarly substantial effects, the requirements of section 71 of POPIA must be assessed. Appropriate safeguards may include human involvement, opportunities to challenge outcomes and procedures for correcting inaccurate information."
],

[
"Sharing Information With Third Parties",
"WellnessHub may need to work with authorized service providers such as hosting companies, technical support providers, email services or counselling organizations. Personal information must only be shared where there is an appropriate lawful basis. Operators processing information on behalf of the responsible party must be subject to suitable contractual and security arrangements. Identifiable mental health information should not be sold to advertisers or disclosed to unauthorized parties. Any disclosure required by law must comply with applicable legal requirements."
],

[
"International Transfers of Personal Information",
"If WellnessHub uses hosting, cloud storage, backup services or external providers located outside South Africa, personal information may be transferred internationally. Such transfers must comply with section 72 of POPIA. The responsible party must identify an applicable lawful transfer ground and establish appropriate protections where required. Users should receive relevant information about international processing arrangements and associated safeguards."
],

[
"Protection of Children's Personal Information",
"POPIA establishes additional restrictions on processing the personal information of children, generally individuals under the age of 18. If WellnessHub permits minors to register, the platform must assess applicable legal authorizations, exceptions and consent requirements. Appropriate age-related safeguards and privacy notices must be established. Enrollment at a university or educational institution does not automatically establish that every student is legally an adult."
],

[
"Cookies, Sessions and Technical Information",
"WellnessHub may use essential cookies and session technologies to support login functionality, account security and normal website operation. Technical records may be used to identify errors, prevent unauthorized access and maintain service reliability. Any optional analytics or third-party tracking technologies should be accurately disclosed. Passwords, private journal entries and sensitive session credentials should not be included in ordinary technical logs. Cookie practices must reflect the technologies actually implemented on the website."
],

[
"Data Retention, Backups and Secure Deletion",
"WellnessHub must establish appropriate retention periods for personal information according to the purpose of processing and applicable legal obligations. Information should not be retained indefinitely without justification. When records are no longer required, they should be securely deleted, destroyed or de-identified where legally appropriate. Backup systems must be protected against unauthorized access. Users should be informed that deleted information may temporarily remain in protected backups where lawful retention arrangements apply."
],

[
"Security Breaches and Incident Notification",
"Section 22 of POPIA establishes notification requirements where there are reasonable grounds to believe that personal information has been accessed or acquired by an unauthorized person. Subject to statutory qualifications, the responsible party must notify the Information Regulator and affected data subjects as soon as reasonably possible after discovering the compromise. WellnessHub should maintain procedures for identifying, investigating, containing and responding to security incidents. Appropriate records of incidents and corrective measures should be maintained."
],

[
"Direct Marketing and Communications",
"WellnessHub may communicate with users regarding account security, requested appointments, support services and relevant platform activities. Service-related notifications should be distinguished from optional marketing messages. Electronic direct marketing must comply with section 69 of POPIA and other applicable laws. Sensitive mental health information should not be used to target advertisements or promotional campaigns. Where required, users must receive appropriate consent options and mechanisms to opt out."
],

[
"User Rights, Complaints and Information Requests",
"Users may contact the responsible party to request access to personal information, seek corrections, request qualifying deletions, object to certain processing activities or withdraw consent where applicable. Requests should be submitted to the designated WellnessHub privacy contact. The responsible party must assess and respond to requests in accordance with applicable legal requirements. Users may also lodge complaints with the Information Regulator of South Africa through its official website at https://inforegulator.org.za/."
],

[
"Policy Amendments and Applicable Legislation",
"WellnessHub should periodically review this policy to reflect changes in its services, information processing activities, security practices and applicable legal requirements. Material changes should be communicated to users where required. This policy is intended to reflect the framework of the Protection of Personal Information Act 4 of 2013 and relevant provisions of the Promotion of Access to Information Act 2 of 2000. The official legislation remains the authoritative legal source. This document is a draft policy and must be reviewed against the actual operation of WellnessHub before publication."
]

];

function safe($value) {
    return htmlspecialchars(
        $value,
        ENT_QUOTES | ENT_SUBSTITUTE,
        "UTF-8"
    );
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>POPIA Compliance | WellnessHub</title>

<style>

* {
    box-sizing: border-box;
}

html {
    scroll-behavior: smooth;
}

body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: linear-gradient(
        135deg,
        #d6ebd9,
        #f6faf6
    );
    color: #24372b;
    line-height: 1.8;
}

header {
    background: white;
    padding: 22px 6%;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid #dce9df;
}

.logo {
    color: #216c43;
    font-size: 22px;
    font-weight: bold;
}

header a {
    color: #216c43;
    text-decoration: none;
    font-weight: bold;
}

.container {
    max-width: 1100px;
    margin: 45px auto;
    padding: 20px;
}

.hero {
    background: linear-gradient(
        120deg,
        #216c43,
        #56a770
    );
    color: white;
    padding: 45px;
    border-radius: 20px;
}

.hero h1 {
    font-size: 35px;
    margin: 0;
}

.hero p {
    margin-bottom: 0;
}

.layout {
    display: grid;
    grid-template-columns: 270px 1fr;
    gap: 25px;
    margin-top: 25px;
}

.contents {
    background: white;
    padding: 25px;
    border-radius: 18px;
    height: fit-content;
    position: sticky;
    top: 20px;
    max-height: 90vh;
    overflow-y: auto;
}

.contents h2 {
    color: #216c43;
    font-size: 20px;
}

.contents a {
    display: block;
    color: #348754;
    text-decoration: none;
    font-size: 13px;
    padding: 7px 0;
}

.contents a:hover {
    text-decoration: underline;
}

.policy {
    background: white;
    padding: 40px;
    border-radius: 18px;
    box-shadow: 0 10px 35px rgba(0,0,0,0.06);
}

.policy section {
    padding: 20px 0;
    border-bottom: 1px solid #e1ebe3;
    scroll-margin-top: 20px;
}

.policy h2 {
    color: #216c43;
    font-size: 22px;
}

.policy p {
    color: #405348;
}

.notice {
    background: #e9f5ed;
    padding: 20px;
    border-left: 5px solid #348754;
    border-radius: 10px;
}

.btn {
    display: inline-block;
    margin-top: 20px;
    padding: 13px 22px;
    background: #216c43;
    color: white;
    text-decoration: none;
    border-radius: 10px;
    border: none;
    font-weight: bold;
    cursor: pointer;
}

.btn:hover {
    background: #164c2f;
}

.footer {
    text-align: center;
    color: #607466;
    padding: 30px;
}

@media (max-width: 800px) {
    .layout {
        grid-template-columns: 1fr;
    }

    .contents {
        position: static;
        max-height: none;
    }

    .policy {
        padding: 25px;
    }

    .hero h1 {
        font-size: 27px;
    }
}

@media print {
    body {
        background: white;
    }

    header,
    .contents,
    .btn {
        display: none;
    }

    .layout {
        display: block;
    }

    .policy {
        box-shadow: none;
    }
}

</style>
</head>

<body>

<header>
    <div class="logo">✚ WellnessHub</div>
    <a href="login.php">← Back to Login</a>
</header>

<div class="container">

<div class="hero">
    <h1>POPIA & Privacy Protection Policy</h1>

    <p>
        WellnessHub Student Mental Wellness Platform
        <br>
        Protection of Personal Information Act 4 of 2013
        <br>
        Republic of South Africa
    </p>

    <button class="btn"
        onclick="window.print()">
        Print / Save as PDF
    </button>
</div>

<div class="layout">

<nav class="contents">
    <h2>Table of Contents</h2>

    <?php foreach ($sections as $index => $section): ?>

    <a href="#section-<?php echo $index + 1; ?>">
        <?php echo $index + 1; ?>.
        <?php echo safe($section[0]); ?>
    </a>

    <?php endforeach; ?>
</nav>

<main class="policy">

<div class="notice">
    <strong>Important Privacy Notice</strong>

    <p>
        WellnessHub is committed to responsible
        handling of personal information.
        This document is a draft privacy policy.
        Actual compliance depends on the
        platform's implemented safeguards,
        processing activities and legal review.
    </p>
</div>

<?php foreach ($sections as $index => $section): ?>

<section id="section-<?php echo $index + 1; ?>">

    <h2>
        <?php echo $index + 1; ?>.
        <?php echo safe($section[0]); ?>
    </h2>

    <p>
        <?php echo safe($section[1]); ?>
    </p>

</section>

<?php endforeach; ?>

<section>
    <h2>Official POPIA Legislation</h2>

    <p>
        For the full wording of the South African
        Protection of Personal Information Act,
        consult the official government source.
    </p>

    <a href="https://www.gov.za/documents/protection-personal-information-act"
       target="_blank"
       rel="noopener noreferrer">
       Read the Official POPIA Act
    </a>

    <p>
        Information Regulator:
        <a href="https://inforegulator.org.za/"
           target="_blank"
           rel="noopener noreferrer">
           www.inforegulator.org.za
        </a>
    </p>
</section>

<a href="login.php" class="btn">
    ← Return to WellnessHub Login
</a>

</main>
</div>

<div class="footer">
    WellnessHub © 2026
    <br>
    Privacy and Personal Information Protection
</div>

</div>

</body>
</html>
