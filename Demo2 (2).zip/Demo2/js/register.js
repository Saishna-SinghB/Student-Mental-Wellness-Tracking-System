
/* ==========================================
   WELLNESSHUB - REGISTRATION JAVASCRIPT
   ========================================== */

// Display an error below a field
function showError(fieldId, message) {
    const el = document.getElementById(fieldId + '-error');

    if (el) {
        el.textContent = message || '';
    }
}

// Display a message at the top of the form
function showBanner(message, type) {
    const banner = document.getElementById('formBanner');

    if (!banner) return;

    banner.className = 'banner ' + type;
    banner.textContent = message;
}

// Clear previous errors
function clearErrors() {
    [
        'fullName',
        'qualification',
        'studentNumber',
        'email',
        'password',
        'confirmPassword',
        'popiaAgree'
    ].forEach(function(id) {
        showError(id, '');
    });

    const banner = document.getElementById('formBanner');

    if (banner) {
        banner.className = 'banner';
        banner.textContent = '';
    }
}

// Validate registration information
function validateRegisterForm() {

    const fullName =
        document.getElementById('fullName').value.trim();

    const qualification =
        document.getElementById('qualification').value;

    const studentNumber =
        document.getElementById('studentNumber').value.trim();

    const email =
        document.getElementById('email').value.trim();

    const password =
        document.getElementById('password').value;

    const confirmPassword =
        document.getElementById('confirmPassword').value;

    const popiaChecked =
        document.getElementById('popiaAgree').checked;

    let valid = true;

    // FULL NAME VALIDATION
    if (!/^[A-Za-z]{3,}(\s[A-Za-z]{3,})+$/.test(fullName)) {

        showError(
            'fullName',
            'Please enter your name and surname.'
        );

        valid = false;
    }

    // QUALIFICATION VALIDATION
    if (!qualification || qualification.trim() === '') {

        showError(
            'qualification',
            'Please select your qualification.'
        );

        valid = false;
    }

    // STUDENT NUMBER VALIDATION
    if (!/^402\d{6}$/.test(studentNumber)) {

        showError(
            'studentNumber',
            'Student number must contain 9 digits starting with 402.'
        );

        valid = false;
    }

    // UNIVERSITY EMAIL VALIDATION
    const expectedEmail =
        studentNumber + '@my.richfield.ac.za';

    const emailPattern =
        /^402\d{6}@my\.richfield\.ac\.za$/i;

    if (!emailPattern.test(email)) {

        showError(
            'email',
            'Enter a valid Richfield student email address.'
        );

        valid = false;

    } else if (
        email.toLowerCase() !== expectedEmail.toLowerCase()
    ) {

        showError(
            'email',
            'Email must match your student number: ' +
            expectedEmail
        );

        valid = false;
    }

    // PASSWORD VALIDATION
    const specialCharacters =
        /[^A-Za-z0-9\s]/;

    if (password.length < 8) {

        showError(
            'password',
            'Password must be at least 8 characters long.'
        );

        valid = false;

    } else if (!/[A-Z]/.test(password)) {

        showError(
            'password',
            'Password must contain at least one uppercase letter.'
        );

        valid = false;

    } else if (!specialCharacters.test(password)) {

        showError(
            'password',
            'Password must contain at least one special character.'
        );

        valid = false;
    }

    // CONFIRM PASSWORD
    if (confirmPassword !== password) {

        showError(
            'confirmPassword',
            'Passwords do not match.'
        );

        valid = false;
    }

    // POPIA AGREEMENT
    if (!popiaChecked) {

        showError(
            'popiaAgree',
            'You must agree to the WellnessHub POPIA Privacy Policy.'
        );

        valid = false;
    }

    return valid;
}

// REGISTRATION FORM SUBMISSION
document.getElementById('registerForm')
    .addEventListener('submit', async function(event) {

        event.preventDefault();

        clearErrors();

        // Validate all fields
        if (!validateRegisterForm()) {
            return;
        }

        const form = document.getElementById('registerForm');
        const submitBtn = document.getElementById('submitBtn');

        submitBtn.disabled = true;
        submitBtn.textContent = 'Creating account...';

        const formData = new FormData(form);

        try {

            const response = await fetch(
                'api/demoAPI.php?action=register',
                {
                    method: 'POST',
                    body: formData
                }
            );

            const data = await response.json();

            if (!response.ok || !data.success) {

                showBanner(
                    data.message || 'Registration failed. Please try again.',
                    'error'
                );

                submitBtn.disabled = false;
                submitBtn.textContent = 'Create Account';

                return;
            }

            // SUCCESS
            showBanner(
                data.message || 'Account created successfully!',
                'success'
            );

            submitBtn.textContent = 'Account Created';

            // Redirect to login
            setTimeout(function() {
                window.location.href = 'login.php';
            }, 1200);

        } catch (error) {

            console.error('Registration error:', error);

            showBanner(
                'Unable to complete registration. Check your connection or PHP server.',
                'error'
            );

            submitBtn.disabled = false;
            submitBtn.textContent = 'Create Account';
        }

    });
