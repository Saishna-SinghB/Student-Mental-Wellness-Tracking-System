<?php require_once __DIR__ . '/auth-check.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <script>
    if (localStorage.getItem('wellnesshub_dark_mode') === '1') {
      document.documentElement.classList.add('theme-pending-dark');
    }
  </script>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Counselling Booking — WellnessHub</title>
  <link rel="stylesheet" href="css/style.css" />
  <style>
    /* Month/year navigation: readable in both light and dark themes. */
    .booking-calendar-header { margin-bottom:12px; }
    .booking-calendar-header h2 { margin-bottom:0; }
    .booking-month-controls {
      display:flex;
      flex-wrap:wrap;
      align-items:center;
      gap:8px;
      margin:12px 0 18px;
    }
    .booking-month-controls button,
    .booking-month-controls select {
      min-height:42px;
      border:1px solid #7c98bc;
      border-radius:10px;
      background:#e8f2ff;
      color:#102a45;
      font-size:14px;
      font-weight:700;
    }
    .booking-month-controls button {
      min-width:42px;
      padding:6px 10px;
      cursor:pointer;
    }
    .booking-month-controls select { padding:8px 10px; cursor:pointer; }
    #calendarMonthSelect { flex:1 1 135px; min-width:125px; }
    #calendarYearSelect { flex:0 1 95px; }
    .booking-month-controls button:hover { background:#cce3ff; }
    .booking-month-controls button:focus-visible,
    .booking-month-controls select:focus-visible {
      outline:3px solid #62a6ff;
      outline-offset:2px;
    }
    .calendar-day { font:inherit; cursor:pointer; }
    .calendar-day[disabled] { cursor:not-allowed; opacity:.38; }
    .calendar-day.selected { outline:3px solid #58d6a0; outline-offset:-2px; }
    .calendar-day.calendar-empty { visibility:hidden; pointer-events:none; }
    .calendar-help { font-size:12px; margin:12px 0 0; }
    .slot[disabled] { opacity:.4; cursor:not-allowed; text-decoration:line-through; }
    .appointments-section { margin-top:20px; border-top:1px solid var(--line, #40536c); padding-top:18px; }
    .appointments-section h3 { margin:0 0 12px; font-size:18px; }
    #appointmentsList { display:grid; gap:12px; }
    .multi-appointment-card { border:1px solid var(--line, #40536c); border-radius:13px; padding:14px; }
    .multi-appointment-card .appt-details { display:flex; gap:10px; align-items:center; margin-bottom:10px; }
    .multi-appointment-card .appt-details strong { display:block; line-height:1.5; }
    .multi-appointment-card .appt-details p { margin:4px 0 0; }
    .multi-appointment-card .appt-actions { display:flex; flex-wrap:wrap; gap:8px; }
    @media (max-width:640px) {
      .booking-month-controls { gap:6px; }
      .booking-month-controls button { min-width:38px; }
    }
  </style>
</head>
<body class="app-body">
  <script src="js/theme.js"></script>
  <script src="js/notif-badge.js"></script>

  <div class="app-shell">
    <aside class="sidebar student-sidebar">
      <a class="brand-mini sidebar-brand" href="index.php">
        <span class="mini-leaf" aria-hidden="true">☘</span>
        <span>WellnessHub</span>
      </a>

      <nav class="side-nav" aria-label="Student navigation">
        <a href="dashboard.php"><span>▣</span> Dashboard</a>
        <a href="mood-tracking.php"><span>☺</span> Mood Tracking</a>
        <a href="journal.php"><span>✎</span> Journal</a>
        <a href="self-help-library.php"><span>▤</span> Self-Help Library</a>
        <a class="active" href="counselling-booking.php"><span>♡</span> Book Counselling</a>
        <a href="peer-support.php"><span>☷</span> Peer Support</a>
        <a href="achievements.php"><span>★</span> Achievements</a>
        <a href="notifications.php"><span>🔔</span> Notifications</a>
        <a href="settings.php"><span>⚙</span> Settings</a>
        <a href="logout.php"><span>↪</span> Logout</a>
      </nav>
    </aside>

    <main class="dashboard-main">
      <header class="topbar">
        <div>
          <p class="eyebrow">Student Side</p>
          <h1>Counselling Booking</h1>
          <p class="page-subtitle">Book different counsellors on different dates or times, and manage your appointments.</p>
        </div>
        <div class="topbar-actions">
          <a class="icon-btn notif-bell" href="notifications.php" aria-label="Notifications">🔔<span class="notif-dot" id="notifDot" style="display:none;"></span></a>
          <?php $firstName = explode(' ', $_SESSION['full_name'])[0]; ?>
          <?php $avatarStyle = !empty($_SESSION['profile_picture']) ? ' style="background-image:url(\'' . htmlspecialchars($_SESSION['profile_picture'], ENT_QUOTES) . '\'); background-size:cover; background-position:center;"' : ''; ?>
          <a href="profile.php" class="avatar" aria-label="My Profile"<?= $avatarStyle ?>><?= empty($_SESSION['profile_picture']) ? htmlspecialchars(strtoupper(substr($firstName, 0, 1))) : '' ?></a>
        </div>
      </header>

      <section class="booking-layout">
        <article class="panel">
          <div class="panel-heading"><h2>Book a Counselling Session</h2></div>
          <label class="field">
            <span>Select Counsellor</span>
            <select id="counsellorSelect"><option value="">Loading counsellors…</option></select>
          </label>
          <div class="counsellor-card" id="counsellorCard" style="display:none;">
            <div class="face" id="counsellorFace"></div>
            <div>
              <h3 id="counsellorName"></h3>
              <p class="muted" id="counsellorGender"></p>
              <p class="muted" id="counsellorSpecialties"></p>
            </div>
          </div>
        </article>

        <article class="panel">
          <div class="calendar-header booking-calendar-header">
            <h2 id="calendarMonthLabel">Loading…</h2>
            <span class="pill pill-blue">Select Date</span>
          </div>

          <div class="booking-month-controls" aria-label="Calendar navigation">
            <button id="previousMonthBtn" type="button" aria-label="Previous month" title="Previous month">&#10094;</button>
            <select id="calendarMonthSelect" aria-label="Select month"></select>
            <select id="calendarYearSelect" aria-label="Select year"></select>
            <button id="nextMonthBtn" type="button" aria-label="Next month" title="Next month">&#10095;</button>
          </div>

          <div class="calendar-grid" id="calendarGrid" aria-label="Choose an appointment date"></div>
          <p class="muted calendar-help">You can browse January–December. Past dates and weekends cannot be booked.</p>
        </article>

        <article class="panel">
          <h2>Available Slots</h2>
          <p class="muted" id="selectedDateLabel">Pick a counsellor and a date to see available times.</p>
          <div class="slot-list" id="slotList"></div>
          <button class="btn btn-primary btn-full" style="margin-top:14px" id="bookBtn" type="button" disabled>Book Session</button>

          <div class="appointments-section">
            <h3>My Upcoming Appointments</h3>
            <div id="appointmentsList" aria-live="polite"></div>
            <p class="muted" id="noAppointmentMsg">No upcoming appointments. You can book more than one session.</p>
          </div>
        </article>
      </section>
    </main>
  </div>

  <script src="js/counselling-booking.js?v=multiple-20261030"></script>
</body>
</html>
