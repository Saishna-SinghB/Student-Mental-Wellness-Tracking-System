<?php
require_once __DIR__ . '/admin-auth.php';
require_once __DIR__ . '/demoDB.php';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

if (
    ($_SESSION['role'] ?? '') !== 'admin' ||
    empty($_SESSION['user_id'])
) {
    http_response_code(403);
    exit('Admin access only.');
}

if (!isset($pdo) || !($pdo instanceof PDO)) {
    http_response_code(500);
    exit('Database connection unavailable.');
}

$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

if (empty($_SESSION['admin_settings_csrf'])) {
    $_SESSION['admin_settings_csrf'] = bin2hex(random_bytes(32));
}

function asH($value): string {
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES | ENT_SUBSTITUTE,
        'UTF-8'
    );
}

function asJson(bool $success, string $message, array $data = []): void {
    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode([
        'success' => $success,
        'message' => $message,
        'data' => $data
    ]);
    exit;
}

function asSqlName(string $name): string {
    return '`' . str_replace('`', '``', $name) . '`';
}

/* =====================================
   ADMIN SETTINGS ACTIONS
===================================== */

if (
    $_SERVER['REQUEST_METHOD'] === 'POST' &&
    isset($_POST['settings_action'])
) {
    if (!hash_equals(
        $_SESSION['admin_settings_csrf'],
        (string)($_POST['csrf'] ?? '')
    )) {
        http_response_code(403);
        asJson(false, 'Session verification failed. Refresh this page.');
    }

    $action = (string)$_POST['settings_action'];

    try {

        // WEEKLY MOOD REPORT

        if ($action === 'weekly_report') {
            $rows = $pdo->query("
                SELECT mood, COUNT(*) AS total
                FROM mood_checkins
                WHERE checkin_date >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
                GROUP BY mood
                ORDER BY mood
            ")->fetchAll(PDO::FETCH_ASSOC);

            header('Content-Type: text/csv; charset=UTF-8');
            header(
                'Content-Disposition: attachment; filename="wellnesshub-weekly-mood-' .
                date('Y-m-d') . '.csv"'
            );
            header('Cache-Control: no-store');

            $out = fopen('php://output', 'w');

            fputcsv($out, [
                'Mood',
                'Number of check-ins',
                'Reporting period'
            ]);

            foreach ($rows as $row) {
                $mood = (string)$row['mood'];

                if (preg_match('/^[=+@\-]/', $mood)) {
                    $mood = "'" . $mood;
                }

                fputcsv($out, [
                    $mood,
                    (int)$row['total'],
                    'Last 7 days'
                ]);
            }

            if (!$rows) {
                fputcsv($out, [
                    'No check-ins',
                    0,
                    'Last 7 days'
                ]);
            }

            fclose($out);
            exit;
        }

        // DATABASE BACKUP

        if ($action === 'download_backup') {
            header('Content-Type: application/sql; charset=UTF-8');
            header(
                'Content-Disposition: attachment; filename="wellnesshub-backup-' .
                date('Y-m-d-His') . '.sql"'
            );
            header('Cache-Control: no-store, private');

            echo "-- WellnessHub database backup\n";
            echo "-- Created " . date('c') . "\n";
            echo "SET FOREIGN_KEY_CHECKS=0;\n";
            echo "SET NAMES utf8mb4;\n\n";

            $tables = $pdo->query('SHOW FULL TABLES')
                          ->fetchAll(PDO::FETCH_NUM);

            foreach ($tables as $item) {
                $table = (string)$item[0];
                $type = (string)($item[1] ?? 'BASE TABLE');

                if (strtoupper($type) !== 'BASE TABLE') {
                    continue;
                }

                $identifier = asSqlName($table);

                $createRow = $pdo->query(
                    'SHOW CREATE TABLE ' . $identifier
                )->fetch(PDO::FETCH_NUM);

                if (!$createRow || !isset($createRow[1])) {
                    continue;
                }

                echo "-- Table {$identifier}\n";
                echo "DROP TABLE IF EXISTS {$identifier};\n";
                echo $createRow[1] . ";\n";

                $records = $pdo->query(
                    'SELECT * FROM ' . $identifier
                );

                while ($record = $records->fetch(PDO::FETCH_NUM)) {
                    $values = [];

                    foreach ($record as $value) {
                        if ($value === null) {
                            $values[] = 'NULL';
                        } elseif (
                            is_string($value) &&
                            !preg_match('//u', $value)
                        ) {
                            $values[] = '0x' . bin2hex($value);
                        } else {
                            $values[] = $pdo->quote((string)$value);
                        }
                    }

                    echo 'INSERT INTO ' . $identifier .
                         ' VALUES (' . implode(',', $values) . ");\n";
                }

                echo "\n";
            }

            echo "SET FOREIGN_KEY_CHECKS=1;\n";
            exit;
        }

        // SEND HIGH-RISK NOTIFICATIONS

        if ($action === 'notify_alerts') {
            $pdo->exec("
                CREATE TABLE IF NOT EXISTS admin_alert_deliveries (
                    alert_id INT NOT NULL,
                    counsellor_id INT NOT NULL,
                    delivered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (alert_id, counsellor_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            ");

            $alerts = $pdo->query("
                SELECT alert_id
                FROM risk_alerts
                WHERE severity = 'high'
                AND status <> 'resolved'
            ")->fetchAll(PDO::FETCH_COLUMN);

            $counsellors = $pdo->query("
                SELECT user_id
                FROM users
                WHERE role = 'counsellor'
            ")->fetchAll(PDO::FETCH_COLUMN);

            $mark = $pdo->prepare("
                INSERT IGNORE INTO admin_alert_deliveries
                    (alert_id, counsellor_id)
                VALUES (:alert, :counsellor)
            ");

            $notify = $pdo->prepare("
                INSERT INTO notifications
                    (user_id, type, title, message)
                VALUES (:user_id, :type, :title, :message)
            ");

            $count = 0;
            $pdo->beginTransaction();

            try {
                foreach ($alerts as $alertId) {
                    foreach ($counsellors as $counsellorId) {
                        $mark->execute([
                            ':alert' => (int)$alertId,
                            ':counsellor' => (int)$counsellorId
                        ]);

                        if ($mark->rowCount() === 1) {
                            $notify->execute([
                                ':user_id' => (int)$counsellorId,
                                ':type' => 'risk_alert',
                                ':title' => 'High-priority risk alert',
                                ':message' =>
                                    'A high-priority student wellbeing alert needs review. Open Risk Alerts for details.'
                            ]);

                            $count++;
                        }
                    }
                }

                $pdo->commit();
            } catch (Throwable $e) {
                $pdo->rollBack();
                throw $e;
            }

            if ($count > 0) {
                asJson(
                    true,
                    "Sent {$count} new in-app notifications.",
                    ['sent' => $count]
                );
            }

            asJson(
                true,
                'No new high-priority alerts to notify.',
                ['sent' => 0]
            );
        }

        http_response_code(400);
        asJson(false, 'Unknown settings action.');

    } catch (Throwable $e) {
        error_log('Admin settings action error: ' . $e->getMessage());
        http_response_code(500);
        asJson(
            false,
            'Action failed. Check your database schema and PHP error log.'
        );
    }
}

/* =====================================
   ADMIN PROFILE PICTURE
===================================== */

$adminName = trim((string)($_SESSION['full_name'] ?? 'Admin'));
$firstName = explode(' ', $adminName ?: 'Admin')[0];
$initial = strtoupper(substr($firstName, 0, 1));

$adminPicture = (string)($_SESSION['profile_picture'] ?? '');

try {
    $avatarStmt = $pdo->prepare("
        SELECT profile_picture
        FROM users
        WHERE user_id = ?
          AND role = 'admin'
        LIMIT 1
    ");

    $avatarStmt->execute([$_SESSION['user_id']]);
    $avatarAccount = $avatarStmt->fetch(PDO::FETCH_ASSOC);

    if ($avatarAccount) {
        $adminPicture = (string)(
            $avatarAccount['profile_picture'] ?? ''
        );

        $_SESSION['profile_picture'] = $adminPicture;
    }

} catch (PDOException $ex) {
    error_log(
        'Admin profile picture lookup failed: ' .
        $ex->getMessage()
    );
}

$hasAdminPicture = preg_match(
    '#^data:image/(?:png|jpe?g|gif|webp);base64,[A-Za-z0-9+/=]+$#D',
    $adminPicture
) === 1;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Settings — WellnessHub</title>
    <link rel="stylesheet" href="css/style.css">

    <style>
        /* SETTINGS */
        .admin-settings-page .setting-row {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 20px;
        }

        .admin-settings-page .setting-row > div {
            flex: 1;
            min-width: 0;
        }

        .admin-settings-page .setting-row strong {
            display: block;
            margin-bottom: 8px;
        }

        .admin-settings-page .setting-row .muted {
            line-height: 1.55;
        }

        .as-state {
            display: inline-block;
            font-size: 12px;
            font-weight: 750;
            padding: 6px 11px;
            border-radius: 30px;
            background: #51356b;
            color: #e1d0f5;
            margin: 10px 0 0;
        }

        .as-state.good {
            background: #246448;
            color: #e0ffe8;
        }

        .as-action {
            appearance: none;
            border: 1px solid #9362da;
            background: #713dcc;
            color: #fff;
            border-radius: 11px;
            padding: 10px 14px;
            font: inherit;
            font-weight: 750;
            cursor: pointer;
            white-space: nowrap;
        }

        .as-action:hover {
            background: #8551df;
        }

        .as-action:disabled {
            opacity: .6;
            cursor: wait;
        }

        .as-message {
            padding: 15px 18px;
            background: #35204b;
            border: 1px solid #654280;
            border-radius: 14px;
            color: #e3d4f3;
            margin: 0 0 22px;
        }

        .as-message.success {
            background: #214b36;
            border-color: #3f845f;
            color: #e3ffec;
        }

        .as-message.error {
            background: #53293f;
            border-color: #a45b70;
            color: #ffdeeb;
        }

        .as-message[hidden] {
            display: none !important;
        }

        .as-info {
            font-size: 13px;
            line-height: 1.55;
            color: #ceb6e6;
            margin-top: 12px;
        }

        .as-info a {
            color: #edceff;
            text-decoration: underline;
        }

        .as-audit {
            appearance: none;
            display: inline-block;
            border: 0;
            flex: none;
            cursor: pointer;
            width: 60px;
            height: 35px;
            border-radius: 20px;
            background: #9992ad;
            position: relative;
            transition: background .2s;
        }

        .as-audit:before {
            content: "";
            position: absolute;
            left: 4px;
            top: 4px;
            width: 27px;
            height: 27px;
            background: #fff;
            border-radius: 50%;
            transition: transform .2s;
        }

        .as-audit.on {
            background: #358b59;
        }

        .as-audit.on:before {
            transform: translateX(25px);
        }

        .as-audit:disabled {
            opacity: .6;
            cursor: not-allowed;
        }

        .as-audit:focus-visible,
        .as-action:focus-visible {
            outline: 3px solid #d6a4ff;
            outline-offset: 3px;
        }

        .as-locked {
            color: #c4f3d3;
            background: #285b44;
            border: 1px solid #3d8761;
            border-radius: 30px;
            padding: 9px 11px;
            font-weight: 800;
            font-size: 12px;
            white-space: nowrap;
        }

        /* PERFECT ROUND PROFILE PICTURE */
        .admin-settings-page .topbar-actions .avatar.admin-avatar {
            width: 44px !important;
            height: 44px !important;
            min-width: 44px !important;
            min-height: 44px !important;
            flex: 0 0 44px !important;
            aspect-ratio: 1 / 1;
            border-radius: 50% !important;
            overflow: hidden;
            padding: 0;
            display: grid;
            place-items: center;
            box-sizing: border-box;
            text-decoration: none;
        }

        .admin-settings-page .topbar-actions .avatar.admin-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-radius: 50%;
            display: block;
        }

        @media (max-width: 690px) {
            .admin-settings-page .setting-row {
                flex-wrap: wrap;
            }

            .as-action {
                white-space: normal;
            }
        }
    </style>
</head>

<body class="app-body admin-body admin-settings-page">

<div class="app-shell admin-shell">

    <!-- ADMIN SIDEBAR -->
    <aside class="sidebar admin-sidebar">

        <a class="brand-mini sidebar-brand" href="index.php">
            <span class="mini-leaf" aria-hidden="true">☘</span>
            <span>WellnessHub</span>
        </a>

        <nav class="side-nav" aria-label="Admin navigation">

            <a href="admin-dashboard.php">
                <span>▣</span> Dashboard
            </a>

            <a href="admin-users.php">
                <span>👥</span> Users
            </a>

            <a href="admin-counsellors.php">
                <span>♡</span> Counsellors
            </a>

            <a href="admin-reports.php">
                <span>📊</span> Reports
            </a>

            <a href="system-logs.php">
                <span>☷</span> System Logs
            </a>

            <a class="active" href="admin-settings.php">
                <span>⚙</span> Settings
            </a>

            <a href="admin-profile.php">
                <span>👤</span> My Profile
            </a>

            <a href="logout.php">
                <span>↪</span> Logout
            </a>

        </nav>
    </aside>

    <!-- MAIN CONTENT -->
    <main class="dashboard-main admin-main">

        <header class="topbar admin-topbar">

            <div>
                <p class="eyebrow">Admin Side</p>
                <h1>Admin Settings</h1>
                <p class="page-subtitle">
                    Manage security, backups, reports and counsellor notifications.
                </p>
            </div>

            <div class="topbar-actions">

                <a
                    class="icon-btn admin-icon"
                    href="system-logs.php"
                    aria-label="System logs"
                >
                    🔔
                </a>

                <!-- SAVED ADMIN PROFILE PICTURE -->
                <a
                    href="admin-profile.php"
                    class="avatar admin-avatar"
                    title="Click to view My Profile"
                    aria-label="Open My Profile"
                >
                    <?php if ($hasAdminPicture): ?>
                        <img
                            src="<?= asH($adminPicture) ?>"
                            alt="Admin profile picture"
                        >
                    <?php else: ?>
                        <?= asH($initial) ?>
                    <?php endif; ?>
                </a>

            </div>
        </header>

        <!-- STATUS MESSAGE -->
        <div
            id="asMessage"
            class="as-message"
            role="status"
            aria-live="polite"
        >
            Loading audit logging from MySQL...
        </div>

        <!-- SETTINGS -->
        <section class="two-col">

            <!-- SECURITY SETTINGS -->
            <article class="panel">

                <h2>Security Settings</h2>

                <!-- ROLE-BASED ACCESS -->
                <div class="setting-row">

                    <div>
                        <strong>Role-based access control</strong>

                        <p class="muted">
                            Student, counsellor and admin permissions
                            are enforced on protected pages.
                        </p>

                        <span class="as-state good">
                            Always enabled
                        </span>
                    </div>

                    <span class="as-locked">
                        ✓ Protected
                    </span>

                </div>

                <!-- DATABASE BACKUP -->
                <div class="setting-row">

                    <div>
                        <strong>Database backup</strong>

                        <p class="muted">
                            Download a SQL backup of the
                            WellnessHub database now.
                        </p>

                        <span class="as-state good">
                            Manual backup available
                        </span>

                        <p class="as-info">
                            Keep the downloaded SQL file secure
                            because it contains private student data.
                            Automated nightly backups require a
                            scheduled service.
                        </p>
                    </div>

                    <form method="post" action="admin-settings.php">

                        <input
                            type="hidden"
                            name="csrf"
                            value="<?= asH($_SESSION['admin_settings_csrf']) ?>"
                        >

                        <input
                            type="hidden"
                            name="settings_action"
                            value="download_backup"
                        >

                        <button class="as-action" type="submit">
                            Download backup
                        </button>

                    </form>

                </div>

                <!-- AUDIT LOGGING -->
                <div class="setting-row">

                    <div>
                        <strong>Audit logging</strong>

                        <p class="muted">
                            Track account changes and exports.
                            Disabling logging affects security records.
                        </p>

                        <span class="as-state" id="asAuditState">
                            Loading...
                        </span>
                    </div>

                    <button
                        class="as-audit"
                        type="button"
                        id="asAudit"
                        role="switch"
                        aria-label="Audit logging"
                        aria-checked="false"
                        disabled
                    ></button>

                </div>

            </article>

            <!-- PLATFORM SETTINGS -->
            <article class="panel">

                <h2>Platform Settings</h2>

                <!-- WEEKLY MOOD REPORTS -->
                <div class="setting-row">

                    <div>
                        <strong>Weekly mood reports</strong>

                        <p class="muted">
                            Download an aggregate seven-day
                            mood summary now.
                        </p>

                        <span class="as-state good">
                            CSV report available
                        </span>

                        <p class="as-info">
                            Automatic weekly email delivery
                            needs an email service and scheduler.
                        </p>
                    </div>

                    <form method="post" action="admin-settings.php">

                        <input
                            type="hidden"
                            name="csrf"
                            value="<?= asH($_SESSION['admin_settings_csrf']) ?>"
                        >

                        <input
                            type="hidden"
                            name="settings_action"
                            value="weekly_report"
                        >

                        <button class="as-action" type="submit">
                            Download report
                        </button>

                    </form>

                </div>

                <!-- RISK ALERT DELIVERY -->
                <div class="setting-row">

                    <div>
                        <strong>Risk alert delivery</strong>

                        <p class="muted">
                            Notify counsellors about existing
                            unresolved, high-priority alerts
                            using in-app notifications.
                        </p>

                        <span class="as-state good">
                            Manual delivery available
                        </span>

                        <p class="as-info">
                            Use
                            <a href="risk-alerts.php">Risk Alerts</a>
                            to review details.
                            Automatic delivery requires
                            scheduled processing.
                        </p>
                    </div>

                    <button
                        class="as-action"
                        type="button"
                        id="asNotify"
                    >
                        Send alerts now
                    </button>

                </div>

                <!-- ANONYMOUS PEER SUPPORT -->
                <div class="setting-row">

                    <div>
                        <strong>Anonymous board moderation</strong>

                        <p class="muted">
                            Reported peer-support posts are reviewed
                            by counsellors using the moderation queue.
                        </p>

                        <span class="as-state good">
                            Counsellor-managed workflow
                        </span>

                        <p class="as-info">
                            Moderation endpoints currently require
                            the counsellor role. This is not a
                            platform-wide on/off switch.
                        </p>
                    </div>

                    <span class="as-locked">
                        ✓ Enforced
                    </span>

                </div>

            </article>

        </section>

    </main>
</div>

<!-- ADMIN SETTINGS JAVASCRIPT -->
<script>
(() => {

    const api = "api/demoAPI.php";

    const toggle = document.getElementById("asAudit");
    const badge = document.getElementById("asAuditState");
    const message = document.getElementById("asMessage");
    const sendButton = document.getElementById("asNotify");

    const csrf = <?= json_encode($_SESSION['admin_settings_csrf']) ?>;

    let enabled = false;
    let ready = false;

    // SHOW STATUS MESSAGE
    function notify(text, kind = "") {
        message.textContent = text;
        message.className = "as-message " + kind;
    }

    // UPDATE AUDIT SWITCH
    function render() {
        toggle.classList.toggle("on", enabled);
        toggle.setAttribute("aria-checked", String(enabled));
        toggle.disabled = !ready;

        badge.textContent = ready
            ? (enabled ? "Enabled" : "Disabled")
            : "Unavailable";

        badge.classList.toggle("good", ready && enabled);
    }

    // SEND REQUEST TO API
    async function apiCall(action, data) {
        const options = {
            credentials: "same-origin",
            cache: "no-store"
        };

        if (data) {
            options.method = "POST";

            options.headers = {
                "Content-Type": "application/x-www-form-urlencoded"
            };

            options.body = new URLSearchParams(data);
        }

        const response = await fetch(
            api + "?action=" + action,
            options
        );

        const result = await response.json();

        if (!response.ok || !result.success) {
            throw new Error(
                result.message || "Server error"
            );
        }

        return result;
    }

    // LOAD AUDIT SETTING
    async function load() {
        try {
            const result = await apiCall(
                "admin_platform_settings_get"
            );

            enabled = Boolean(
                result.data.audit_logging_enabled
            );

            ready = true;
            render();

            notify(
                "Settings loaded. Action buttons are ready.",
                "success"
            );

        } catch (err) {
            ready = false;
            render();

            notify(
                "Could not load audit setting: " + err.message,
                "error"
            );
        }
    }

    // SAVE AUDIT SETTING
    toggle.addEventListener("click", async () => {

        if (!ready) {
            return;
        }

        const next = !enabled;

        if (!next) {
            const confirmed = confirm(
                "Disable audit logging? " +
                "This stops logging of security-relevant actions."
            );

            if (!confirmed) {
                return;
            }
        }

        ready = false;
        render();

        try {
            await apiCall(
                "admin_platform_settings_update",
                {
                    audit_logging_enabled: next ? "1" : "0"
                }
            );

            enabled = next;

            notify(
                "Audit logging " +
                (enabled ? "enabled" : "disabled") +
                " and saved.",
                "success"
            );

        } catch (err) {
            notify(
                "Could not save audit setting: " + err.message,
                "error"
            );
        }

        ready = true;
        render();
    });

    // SEND HIGH-PRIORITY ALERT NOTIFICATIONS
    sendButton.addEventListener("click", async () => {

        sendButton.disabled = true;

        notify("Sending available high-priority alerts...");

        try {
            const response = await fetch(
                "admin-settings.php",
                {
                    method: "POST",
                    credentials: "same-origin",

                    headers: {
                        "Content-Type":
                            "application/x-www-form-urlencoded"
                    },

                    body: new URLSearchParams({
                        settings_action: "notify_alerts",
                        csrf: csrf
                    })
                }
            );

            const result = await response.json();

            if (!response.ok || !result.success) {
                throw new Error(
                    result.message || "Action failed"
                );
            }

            notify(result.message, "success");

        } catch (err) {
            notify(
                "Could not send notifications: " + err.message,
                "error"
            );

        } finally {
            sendButton.disabled = false;
        }
    });

    render();
    load();

})();
</script>

</body>
</html>