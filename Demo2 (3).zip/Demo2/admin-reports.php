<?php
require_once __DIR__ . '/admin-auth.php';
require_once __DIR__ . '/demoDB.php';

// ADMIN DETAILS
$adminName = trim(
    (string)($_SESSION['full_name'] ?? 'Admin')
);

$adminInitial = strtoupper(
    substr($adminName !== '' ? $adminName : 'Admin', 0, 1)
);

// LOAD SAVED ADMIN PROFILE PICTURE
$adminPicture = (string)($_SESSION['profile_picture'] ?? '');

try {

    $stmt = $pdo->prepare("
        SELECT profile_picture
        FROM users
        WHERE user_id = ?
        AND role = 'admin'
        LIMIT 1
    ");

    $stmt->execute([$_SESSION['user_id']]);

    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {

        $adminPicture = (string)(
            $user['profile_picture'] ?? ''
        );

        $_SESSION['profile_picture'] = $adminPicture;

    }

} catch (PDOException $e) {

    error_log(
        'Admin profile picture error: ' . $e->getMessage()
    );

}

// VALIDATE PICTURE
$hasAdminPicture = preg_match(
    '#^data:image/(?:png|jpeg|gif|webp);base64,[A-Za-z0-9+/=]+$#D',
    $adminPicture
) === 1;
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Reports & Export — WellnessHub</title>

    <link rel="stylesheet" href="css/style.css">

    <style>

        /* PERFECTLY ROUND ADMIN PROFILE PICTURE */

        .topbar-actions .avatar.admin-avatar {
            width: 44px !important;
            height: 44px !important;
            min-width: 44px !important;
            min-height: 44px !important;
            flex: 0 0 44px !important;
            aspect-ratio: 1 / 1;
            border-radius: 50% !important;
            overflow: hidden;
            padding: 0;
            display: grid;
            place-items: center;
            box-sizing: border-box;
        }

        .topbar-actions .avatar.admin-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-radius: 50%;
            display: block;
        }

    </style>

</head>

<body class="app-body admin-body">

<div class="app-shell admin-shell">

    <!-- ADMIN SIDEBAR -->

    <aside class="sidebar admin-sidebar">

        <a
            class="brand-mini sidebar-brand"
            href="index.php"
        >

            <span class="mini-leaf" aria-hidden="true">
                ☘
            </span>

            <span>WellnessHub</span>

        </a>

        <nav
            class="side-nav"
            aria-label="Admin navigation"
        >

            <a href="admin-dashboard.php">
                <span>▣</span> Dashboard
            </a>

            <a href="admin-users.php">
                <span>👥</span> Users
            </a>

            <a href="admin-counsellors.php">
                <span>♡</span> Counsellors
            </a>

            <a
                class="active"
                href="admin-reports.php"
            >
                <span>📊</span> Reports
            </a>

            <a href="system-logs.php">
                <span>☷</span> System Logs
            </a>

            <a href="admin-settings.php">
                <span>⚙</span> Settings
            </a>

            <!-- MY PROFILE -->

            <a href="admin-profile.php">
                <span>👤</span> My Profile
            </a>

            <a href="logout.php">
                <span>↪</span> Logout
            </a>

        </nav>

    </aside>


    <!-- MAIN CONTENT -->

    <main class="dashboard-main admin-main">

        <!-- HEADER -->

        <header class="topbar admin-topbar">

            <div>

                <p class="eyebrow">
                    Admin Side
                </p>

                <h1>Reports & Export</h1>

                <p class="page-subtitle">
                    Generate and export institutional wellness reports.
                </p>

            </div>

            <!-- TOP RIGHT BUTTONS -->

            <div class="topbar-actions">

                <!-- SYSTEM LOGS -->

                <a
                    class="icon-btn admin-icon"
                    href="system-logs.php"
                    aria-label="System logs"
                >
                    🔔
                </a>


                <!-- ROUND ADMIN PROFILE PICTURE -->

                <a
                    href="admin-profile.php"
                    class="avatar admin-avatar"
                    title="Click to view My Profile"
                    aria-label="Open My Profile"
                >

                    <?php if ($hasAdminPicture): ?>

                        <img
                            src="<?= htmlspecialchars(
                                $adminPicture,
                                ENT_QUOTES,
                                'UTF-8'
                            ) ?>"
                            alt="Admin profile picture"
                        >

                    <?php else: ?>

                        <?= htmlspecialchars(
                            $adminInitial,
                            ENT_QUOTES,
                            'UTF-8'
                        ) ?>

                    <?php endif; ?>

                </a>

            </div>

        </header>


        <!-- REPORTS CONTENT -->

        <section class="page-grid">

            <!-- REPORT SELECTION -->

            <article class="panel">

                <div class="panel-heading">

                    <h2>Institution Wellness Report</h2>

                </div>

                <div class="three-col">

                    <!-- REPORT TYPE -->

                    <label class="field">

                        <span>Report Type</span>

                        <select id="reportType">

                            <option value="monthly">
                                Monthly Report
                            </option>

                            <option value="risk">
                                Risk Report
                            </option>

                            <option value="engagement">
                                Engagement Report
                            </option>

                        </select>

                    </label>


                    <!-- MONTH -->

                    <label class="field">

                        <span>Month</span>

                        <select id="reportMonth"></select>

                    </label>


                    <!-- QUALIFICATION -->

                    <label class="field">

                        <span>Qualification</span>

                        <select id="reportQualification">

                            <option value="all">
                                All Qualifications
                            </option>

                            <?php
                            require_once __DIR__ . '/qualifications.php';

                            renderQualificationOptions();
                            ?>

                        </select>

                    </label>

                </div>

            </article>


            <!-- REPORT SUMMARY -->

            <article class="panel">

                <h2>Report Summary</h2>

                <div class="report-summary">

                    <!-- AVERAGE MOOD -->

                    <div class="report-card">

                        <span>
                            Average Mood
                        </span>

                        <strong id="rAvgMood">
                            –
                        </strong>

                        <small id="rAvgMoodChange"></small>

                    </div>


                    <!-- ELEVATED CONCERN -->

                    <div class="report-card">

                        <span
                            title="Based on self-reported mood check-in averages — not a clinical risk assessment."
                        >
                            Elevated Concern ⓘ
                        </span>

                        <strong id="rConcern">
                            –
                        </strong>

                        <small id="rConcernChange"></small>

                    </div>


                    <!-- COUNSELLING SESSIONS -->

                    <div class="report-card">

                        <span>
                            Counselling Sessions
                        </span>

                        <strong id="rSessions">
                            –
                        </strong>

                        <small id="rSessionsChange"></small>

                    </div>

                </div>


                <!-- EXPORT BUTTONS -->

                <div
                    class="inline"
                    style="margin-top:18px"
                >

                    <button
                        class="btn btn-purple"
                        type="button"
                        id="exportPdfBtn"
                    >
                        Export as PDF
                    </button>

                    <button
                        class="btn btn-light"
                        type="button"
                        id="exportCsvBtn"
                    >
                        Export as CSV
                    </button>

                </div>

            </article>

        </section>

    </main>

</div>


<!-- EXISTING JAVASCRIPT -->

<script src="js/admin-reports.js"></script>

</body>
</html>