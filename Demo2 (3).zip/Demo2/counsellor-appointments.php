<?php
require_once __DIR__ . '/counsellor-auth.php';
require_once __DIR__ . '/demoDB.php';

// COUNSELLOR DETAILS
$counsellorName = trim(
    (string)($_SESSION['full_name'] ?? 'Counsellor')
);

$counsellorInitial = strtoupper(
    substr($counsellorName, 0, 1)
);

// LOAD PROFILE PICTURE FROM DATABASE
$profilePicture = '';

try {
    $stmt = $pdo->prepare("
        SELECT profile_picture
        FROM users
        WHERE user_id = ?
        AND role = 'counsellor'
        LIMIT 1
    ");

    $stmt->execute([$_SESSION['user_id']]);

    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        $profilePicture = $user['profile_picture'] ?? '';
        $_SESSION['profile_picture'] = $profilePicture;
    }

} catch (PDOException $e) {
    error_log('Profile picture error: ' . $e->getMessage());
    $profilePicture = $_SESSION['profile_picture'] ?? '';
}

// VALIDATE SAVED PICTURE
$hasProfilePicture = is_string($profilePicture)
    && preg_match(
        '#^data:image/(?:jpeg|png|gif|webp);base64,[A-Za-z0-9+/=]+$#D',
        $profilePicture
    ) === 1;

$avatarStyle = '';

if ($hasProfilePicture) {
    $safePicture = htmlspecialchars(
        $profilePicture,
        ENT_QUOTES,
        'UTF-8'
    );

    $avatarStyle = 'style="background-image:url(\'' .
        $safePicture .
        '\');background-size:cover;background-position:center;"';
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Counsellor Appointment Calendar — WellnessHub</title>

    <link rel="stylesheet" href="css/style.css">
</head>

<body class="app-body dark-body counsellor-body">

<div class="app-shell dark-shell">

    <!-- SIDEBAR -->
    <aside class="sidebar counsellor-sidebar">

        <a class="brand-mini sidebar-brand" href="index.php">
            <span class="mini-leaf" aria-hidden="true">☘</span>
            <span>WellnessHub</span>
        </a>

        <nav class="side-nav" aria-label="Counsellor navigation">

            <a href="counsellor-dashboard.php">
                <span>▣</span> Dashboard
            </a>

            <a href="counsellor-students.php">
                <span>👥</span> Students
            </a>

            <a href="risk-alerts.php">
                <span>⚠</span> Risk Alerts
            </a>

            <a class="active" href="counsellor-appointments.php">
                <span>📅</span> Appointments
            </a>

            <a href="counsellor-resources.php">
                <span>▤</span> Resources
            </a>

            <a href="counsellor-profile.php">
                <span>👤</span> My Profile
            </a>

            <a href="logout.php">
                <span>↪</span> Logout
            </a>

        </nav>

    </aside>

    <!-- MAIN CONTENT -->
    <main class="dashboard-main dark-main">

        <header class="topbar dark-topbar">

            <div>
                <p class="eyebrow">Counsellor Side</p>

                <h1>Counsellor Appointment Calendar</h1>

                <p class="page-subtitle">
                    Manage daily appointments and availability.
                </p>
            </div>

            <div class="topbar-actions">

                <!-- ALERTS -->
                <a
                    class="icon-btn dark-icon"
                    href="risk-alerts.php"
                    aria-label="Alerts"
                >
                    🔔
                </a>

                <!-- PROFILE PICTURE -->
                <a
                    href="counsellor-profile.php"
                    class="avatar dark-avatar"
                    title="Click to view My Profile"
                    aria-label="Open My Profile"
                    <?= $avatarStyle ?>
                >
                    <?php if (!$hasProfilePicture): ?>
                        <?= htmlspecialchars(
                            $counsellorInitial,
                            ENT_QUOTES,
                            'UTF-8'
                        ) ?>
                    <?php endif; ?>
                </a>

            </div>

        </header>

        <!-- APPOINTMENT CALENDAR -->
        <section class="page-grid">

            <article class="panel">

                <div class="panel-heading">

                    <h2 id="weekLabel">This Week</h2>

                    <div class="inline">

                        <button
                            type="button"
                            class="btn btn-ghost btn-small"
                            id="prevWeekBtn"
                        >
                            ‹ Prev
                        </button>

                        <button
                            type="button"
                            class="btn btn-ghost btn-small"
                            id="todayBtn"
                        >
                            Today
                        </button>

                        <button
                            type="button"
                            class="btn btn-ghost btn-small"
                            id="nextWeekBtn"
                        >
                            Next ›
                        </button>

                    </div>

                </div>

                <div
                    class="timeline-grid"
                    id="timelineGrid"
                ></div>

            </article>

        </section>

    </main>

</div>

<script src="js/counsellor-appointments.js"></script>

</body>
</html>