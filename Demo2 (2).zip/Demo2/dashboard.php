<?php require_once __DIR__ . '/auth-check.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <script>if (localStorage.getItem("wellnesshub_dark_mode") === "1") { document.documentElement.classList.add("theme-pending-dark"); }</script>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>WellnessHub Dashboard</title>
  <link rel="stylesheet" href="css/style.css" />
  <style>
    /* Supplementary style for the real stress slider — same convention as register.php's banner styles */
    .stress-slider{ width:100%; margin:10px 0; accent-color:#4b73d9; }

    /* Mood emoji "wiggle" — plays whenever the cursor passes over a mood
       button, whether that's a plain hover or the mouse being dragged
       across the row with the button held down (CSS :hover reacts purely
       to cursor position, not click state, so a drag-across naturally
       re-triggers this on each emoji as the pointer crosses it). */
    @keyframes moodWiggle {
      0%   { transform: scale(1) rotate(0deg); }
      30%  { transform: scale(1.3) rotate(-10deg); }
      60%  { transform: scale(1.3) rotate(8deg); }
      100% { transform: scale(1.18) rotate(0deg); }
    }
    .mood-row .mood span{ display:inline-block; transition:transform .15s ease; }
    .mood-row .mood:hover span{ animation: moodWiggle .4s ease; }
    .mood-row .mood.active span{ transform: scale(1.18); }
    .mood-row .mood span img{ width:40px; height:40px; display:block; }
  </style>
</head>
<body class="app-body">
  <script src="js/theme.js"></script>
  <script src="js/notif-badge.js"></script>
  <div class="app-shell">
    <aside class="sidebar student-sidebar">
      <a class="brand-mini sidebar-brand" href="index.php">
        <span class="mini-leaf" aria-hidden="true">☘</span>
        <span>WellnessHub</span>
      </a>

      <nav class="side-nav" aria-label="Student navigation">
        <a class="active" href="dashboard.php"><span>▣</span> Dashboard</a>
        <a href="mood-tracking.php"><span>☺</span> Mood Tracking</a>
        <a href="journal.php"><span>✎</span> Journal</a>
        <a href="self-help-library.php"><span>▤</span> Self-Help Library</a>
        <a href="counselling-booking.php"><span>♡</span> Book Counselling</a>
        <a href="peer-support.php"><span>☷</span> Peer Support</a>
        <a href="achievements.php"><span>★</span> Achievements</a>
        <a href="notifications.php"><span>🔔</span> Notifications</a>
        <a href="settings.php"><span>⚙</span> Settings</a>
        <a href="logout.php"><span>↪</span> Logout</a>
      </nav>
    </aside>

    <main class="dashboard-main ">
      <header class="topbar">
        <div>
          <p class="eyebrow">Student Side</p>
          <?php
            $hour = (int) date('G');
            $greeting = $hour < 12 ? 'Good morning' : ($hour < 18 ? 'Good afternoon' : 'Good evening');
            $firstName = explode(' ', $_SESSION['full_name'])[0];
          ?>
          <h1><?= $greeting ?>, <?= htmlspecialchars($firstName) ?> 🌱</h1>
          <p class="page-subtitle">Your student dashboard overview.</p>
        </div>
        <div class="topbar-actions">
          <a class="icon-btn notif-bell" href="notifications.php" aria-label="Notifications">🔔<span class="notif-dot" id="notifDot" style="display:none;"></span></a>
          <?php $avatarStyle = !empty($_SESSION['profile_picture']) ? ' style="background-image:url(\'' . htmlspecialchars($_SESSION['profile_picture'], ENT_QUOTES) . '\'); background-size:cover; background-position:center;"' : ''; ?>
          <a href="profile.php" class="avatar" aria-label="My Profile"<?= $avatarStyle ?>><?= empty($_SESSION['profile_picture']) ? htmlspecialchars(strtoupper(substr($firstName, 0, 1))) : '' ?></a>
        </div>
      </header>
      <section class="dashboard-grid">
        <article class="panel checkin-panel">
          <div class="panel-heading"><div><p class="eyebrow">Daily Check-In</p><h2>How are you feeling today?</h2></div></div>
          <div class="mood-row" aria-label="Mood options">
            <button class="mood active" type="button" data-mood="great"><span><img src="img/mood/happy.gif" alt="Happy" /></span><small>Happy</small></button>
            <button class="mood" type="button" data-mood="good"><span><img src="img/mood/good.gif" alt="Good" /></span><small>Good</small></button>
            <button class="mood" type="button" data-mood="okay"><span><img src="img/mood/fine.gif" alt="Fine" /></span><small>Fine</small></button>
            <button class="mood" type="button" data-mood="low"><span><img src="img/mood/sad.gif" alt="Sad" /></span><small>Sad</small></button>
            <button class="mood" type="button" data-mood="struggling"><span><img src="img/mood/struggling.gif" alt="Struggling" /></span><small>Struggling</small></button>
          </div>
          <div class="slider-wrap">
            <div class="slider-label"><span>Stress level</span><strong id="stressValue">3</strong></div>
            <input type="range" id="stressSlider" class="stress-slider" min="0" max="10" step="1" value="3" aria-label="Stress level" />
            <div class="scale"><span>0</span><span>10</span></div>
          </div>
          <button class="btn btn-primary checkin-btn" type="button" id="checkinBtn">Submit Check-In</button>
        </article>
        <article class="panel summary-panel">
          <p class="eyebrow">This Week Summary</p>
          <div class="donut" id="moodDonut" role="img" aria-label="Mood summary chart"></div>
          <ul class="legend">
            <li><span class="legend-dot calm"></span> <span id="pct-calm">0</span>% Fine</li>
            <li><span class="legend-dot neutral"></span> <span id="pct-neutral">0</span>% Positive</li>
            <li><span class="legend-dot low"></span> <span id="pct-low">0</span>% Neutral</li>
            <li><span class="legend-dot risk"></span> <span id="pct-risk">0</span>% Low</li>
          </ul>
          <p class="muted" id="summaryEmptyState" style="display:none; font-size:13px; margin-top:8px;">No check-ins yet this week.</p>
        </article>
        <a class="panel action-panel action-journal" href="journal.php"><div class="action-icon">📓</div><h3>Journal</h3><p>Write your thoughts</p></a>
        <a class="panel action-panel action-library" href="self-help-library.php"><div class="action-icon">☯</div><h3>Self-Help</h3><p>Resources & exercises</p></a>
        <a class="panel action-panel action-counselling" href="counselling-booking.php"><div class="action-icon">💬</div><h3>Book Counselling</h3><p>Schedule a session</p></a>
        <a class="panel action-panel action-peer" href="peer-support.php"><div class="action-icon">🤝</div><h3>Peer Support</h3><p>Connect anonymously</p></a>
      </section>
      <section class="feature-strip">
        <div class="strip-item"><span class="strip-icon">🛡</span><div><h4>Secure & Private</h4><p>POPIA Compliant</p></div></div>
        <div class="strip-item"><span class="strip-icon">📊</span><div><h4>Real-time Analytics</h4><p>Early detection & support</p></div></div>
        <div class="strip-item"><span class="strip-icon">🌐</span><div><h4>Accessible Anytime</h4><p>Web-based platform</p></div></div>
        <div class="strip-item"><span class="strip-icon">🤝</span><div><h4>Anonymous Support</h4><p>Safe peer community</p></div></div>
        <div class="strip-item"><span class="strip-icon">💚</span><div><h4>Built for Students</h4><p>Because your mind matters</p></div></div>
      </section>
    </main>
  </div>
  <script src="js/checkin.js"></script>
</body>
</html>
