
// ===============================================
// WELLNESSHUB - COUNSELLOR STUDENT OVERVIEW
// ===============================================

// MOOD EMOJIS
const MOOD_EMOJI = {
    great: '😊',
    good: '🙂',
    okay: '😐',
    low: '😟',
    struggling: '😣'
};

// STORE ALL STUDENTS FROM THE DATABASE
let allStudents = [];

// ===============================================
// PAGE INITIALIZATION
// ===============================================

document.addEventListener('DOMContentLoaded', () => {

    const searchInput = document.getElementById('studentSearch');

    const saveNoteBtn = document.getElementById('saveNoteBtn');

    // LOAD ALL STUDENTS
    loadStudents();

    // SEARCH STUDENTS WHILE TYPING
    searchInput.addEventListener('input', function () {

        const searchValue = this.value;

        filterStudents(searchValue);

    });

    // SAVE COUNSELLOR NOTE
    saveNoteBtn.addEventListener('click', saveNote);

});

// ===============================================
// LOAD STUDENTS FROM DATABASE
// ===============================================

async function loadStudents() {

    const tableBody = document.getElementById('studentsTableBody');

    tableBody.innerHTML = `
        <tr>
            <td colspan="5" style="text-align:center; padding:25px;">
                Loading students...
            </td>
        </tr>
    `;

    try {

        const response = await fetch(
            'api/demoAPI.php?action=counsellor_students_list',
            {
                method: 'GET',
                credentials: 'same-origin',
                cache: 'no-store'
            }
        );

        if (!response.ok) {
            throw new Error(
                'Server returned status ' + response.status
            );
        }

        const result = await response.json();

        if (!result.success) {
            throw new Error(
                result.message || 'Unable to load students.'
            );
        }

        // SAVE ALL STUDENTS INTO ARRAY
        allStudents = Array.isArray(result.data?.students)
            ? result.data.students
            : [];

        // DISPLAY STUDENTS BASED ON CURRENT SEARCH
        const currentSearch = document.getElementById(
            'studentSearch'
        ).value;

        filterStudents(currentSearch);

    } catch (error) {

        console.error(
            'Failed to load students:',
            error
        );

        tableBody.innerHTML = `
            <tr>
                <td colspan="5"
                    style="text-align:center; padding:25px; color:#ff9999;">
                    Could not load student records.
                    Please check the server connection.
                </td>
            </tr>
        `;

    }
}

// ===============================================
// SEARCH ALL STUDENTS
// ===============================================

function filterStudents(searchText) {

    // CONVERT SEARCH TO LOWERCASE
    const search = String(searchText || '')
        .trim()
        .replace(/\s+/g, ' ')
        .toLowerCase();

    // IF SEARCH IS EMPTY, SHOW ALL STUDENTS
    if (search === '') {

        renderTable(allStudents);

        return;
    }

    // FILTER ALL STUDENTS
    const filteredStudents = allStudents.filter(student => {

        const fullName = String(
            student.full_name || ''
        ).toLowerCase();

        const studentNumber = String(
            student.student_number || ''
        ).toLowerCase();

        // SEARCH FULL NAME OR STUDENT NUMBER
        return (
            fullName.includes(search) ||
            studentNumber.includes(search)
        );

    });

    // DISPLAY MATCHING STUDENTS ONLY
    renderTable(filteredStudents);

}

// ===============================================
// DISPLAY STUDENT TABLE
// ===============================================

function renderTable(students) {

    const tableBody = document.getElementById(
        'studentsTableBody'
    );

    tableBody.innerHTML = '';

    // NO MATCHING STUDENTS
    if (students.length === 0) {

        const row = document.createElement('tr');

        const cell = document.createElement('td');

        cell.colSpan = 5;

        cell.textContent = 'No students found.';

        cell.style.textAlign = 'center';

        cell.style.padding = '30px';

        cell.style.color = '#b8c7dc';

        row.appendChild(cell);

        tableBody.appendChild(row);

        return;
    }

    // CREATE ROW FOR EVERY MATCHING STUDENT
    students.forEach(student => {

        const row = document.createElement('tr');

        // ===================================
        // STUDENT NAME
        // ===================================

        const nameCell = document.createElement('td');

        nameCell.textContent = student.full_name || 'Unknown Student';

        row.appendChild(nameCell);

        // ===================================
        // STUDENT MOOD
        // ===================================

        const moodCell = document.createElement('td');

        const mood = String(
            student.last_mood || ''
        ).toLowerCase();

        if (mood !== '') {

            const emoji = MOOD_EMOJI[mood] || '😐';

            moodCell.textContent = emoji + ' ' + mood;

        } else {

            moodCell.textContent = '—';

        }

        row.appendChild(moodCell);

        // ===================================
        // STUDENT RISK
        // ===================================

        const riskCell = document.createElement('td');

        const riskPill = document.createElement('span');

        riskPill.className = 'pill pill-green';

        riskPill.textContent = 'Low';

        if (Number(student.has_high_risk) === 1) {

            riskPill.className = 'pill pill-red';

            riskPill.textContent = 'High';

        } else if (Number(student.open_alerts) > 0) {

            riskPill.className = 'pill pill-orange';

            riskPill.textContent = 'Medium';

        }

        riskCell.appendChild(riskPill);

        row.appendChild(riskCell);

        // ===================================
        // LAST CHECK-IN
        // ===================================

        const checkinCell = document.createElement('td');

        checkinCell.textContent =
            student.last_checkin || '—';

        row.appendChild(checkinCell);

        // ===================================
        // ADD NOTE BUTTON
        // ===================================

        const actionCell = document.createElement('td');

        const noteButton = document.createElement('button');

        noteButton.type = 'button';

        noteButton.className =
            'btn btn-ghost btn-small note-btn';

        noteButton.textContent = 'Add Note';

        noteButton.addEventListener('click', () => {

            openNoteEditor(student);

        });

        actionCell.appendChild(noteButton);

        row.appendChild(actionCell);

        // ADD ROW TO TABLE
        tableBody.appendChild(row);

    });

}

// ===============================================
// OPEN FOLLOW-UP NOTE EDITOR
// ===============================================

function openNoteEditor(student) {

    const editor = document.getElementById(
        'noteEditor'
    );

    const title = document.getElementById(
        'noteEditorTitle'
    );

    const studentId = document.getElementById(
        'noteStudentId'
    );

    const noteText = document.getElementById(
        'noteText'
    );

    // DISPLAY NOTE EDITOR
    editor.style.display = 'block';

    // DISPLAY STUDENT NAME
    title.textContent =
        'Add follow-up note — ' + student.full_name;

    // STORE STUDENT ID
    studentId.value = student.user_id;

    // CLEAR PREVIOUS NOTE
    noteText.value = '';

    // SCROLL TO EDITOR
    editor.scrollIntoView({
        behavior: 'smooth',
        block: 'nearest'
    });

    noteText.focus();

}

// ===============================================
// SAVE FOLLOW-UP NOTE
// ===============================================

async function saveNote() {

    const userId = document.getElementById(
        'noteStudentId'
    ).value;

    const noteText = document.getElementById(
        'noteText'
    );

    const note = noteText.value.trim();

    const saveButton = document.getElementById(
        'saveNoteBtn'
    );

    // VALIDATE STUDENT
    if (!userId) {

        alert('Please select a student.');

        return;
    }

    // VALIDATE NOTE
    if (note === '') {

        alert('Please write a note before saving.');

        noteText.focus();

        return;
    }

    const formData = new FormData();

    formData.append('user_id', userId);

    formData.append('note', note);

    saveButton.disabled = true;

    saveButton.textContent = 'Saving...';

    try {

        const response = await fetch(
            'api/demoAPI.php?action=counsellor_note_save',
            {
                method: 'POST',
                credentials: 'same-origin',
                body: formData
            }
        );

        if (!response.ok) {
            throw new Error(
                'Server returned status ' + response.status
            );
        }

        const result = await response.json();

        if (!result.success) {

            alert(
                result.message || 'Could not save note.'
            );

            return;
        }

        // HIDE NOTE EDITOR
        document.getElementById(
            'noteEditor'
        ).style.display = 'none';

        alert('Follow-up note saved successfully.');

    } catch (error) {

        console.error(
            'Failed to save note:',
            error
        );

        alert(
            'Unable to save the note. Please try again.'
        );

    } finally {

        saveButton.disabled = false;

        saveButton.textContent = 'Save Note';

    }
}
