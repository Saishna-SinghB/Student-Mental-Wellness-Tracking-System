
// ===============================================
// WELLNESSHUB - COUNSELLOR RISK ALERTS
// ===============================================

let selectedAlert = null;
let updateInProgress = false;

// ===============================================
// INITIALIZE
// ===============================================

document.addEventListener('DOMContentLoaded', () => {

    document.getElementById('refreshBtn')
        .addEventListener('click', () => {
            loadAlerts();
        });

    document.getElementById('markInProgressBtn')
        .addEventListener('click', () => {
            updateSelectedAlert('in_progress');
        });

    document.getElementById('resolveBtn')
        .addEventListener('click', () => {
            updateSelectedAlert('resolved');
        });

    loadAlerts();
});

// ===============================================
// SHOW FEEDBACK
// ===============================================

function setFeedback(elementId, message, type = 'info') {

    const element = document.getElementById(elementId);

    element.textContent = message;

    element.className = 'risk-feedback ' + type;
}

// ===============================================
// LOAD / REFRESH ALERTS
// ===============================================

async function loadAlerts() {

    const refreshButton = document.getElementById('refreshBtn');

    refreshButton.disabled = true;
    refreshButton.textContent = 'Refreshing...';

    setFeedback(
        'riskFeedback',
        'Checking for the latest alerts...',
        'info'
    );

    try {

        const response = await fetch(
            'api/demoAPI.php?action=risk_alerts_list&t=' + Date.now(),
            {
                method: 'GET',
                credentials: 'same-origin',
                cache: 'no-store'
            }
        );

        if (!response.ok) {
            throw new Error(
                'Server returned HTTP ' + response.status
            );
        }

        const result = await response.json();

        if (!result.success) {
            throw new Error(
                result.message || 'Unable to retrieve alerts.'
            );
        }

        const alerts = Array.isArray(result.data?.alerts)
            ? result.data.alerts
            : [];

        renderAlerts(alerts);

        const time = new Date().toLocaleTimeString([], {
            hour: '2-digit',
            minute: '2-digit'
        });

        setFeedback(
            'riskFeedback',
            `Updated at ${time}. ${alerts.length} active alert(s).`,
            'success'
        );

    } catch (error) {

        console.error('Failed to refresh risk alerts:', error);

        setFeedback(
            'riskFeedback',
            'Could not refresh alerts. Check your server connection.',
            'error'
        );

    } finally {

        refreshButton.disabled = false;
        refreshButton.textContent = '🔄 Refresh';

    }
}

// ===============================================
// RENDER ALERTS
// ===============================================

function renderAlerts(alerts) {

    const list = document.getElementById('riskList');

    const empty = document.getElementById('riskEmpty');

    const previousSelectedId = selectedAlert
        ? String(selectedAlert.alert_id)
        : '';

    document.getElementById('alertCount').textContent =
        alerts.length;

    // REMOVE OLD ALERT CARDS
    list.querySelectorAll('.risk-item').forEach(item => {
        item.remove();
    });

    if (alerts.length === 0) {

        empty.style.display = 'block';

        clearSelection();

        return;
    }

    empty.style.display = 'none';

    alerts.forEach(alert => {

        const item = document.createElement('div');

        item.className = 'risk-item';

        item.dataset.alertId = alert.alert_id;

        // SEVERITY
        const severityPill = alert.severity === 'high'
            ? '<span class="pill pill-red">High</span>'
            : '<span class="pill pill-orange">Medium</span>';

        // STATUS
        const statusPill = alert.status === 'in_progress'
            ? '<span class="pill pill-blue">In Progress</span>'
            : '<span class="pill pill-purple">Open</span>';

        item.innerHTML = `
            <div>
                <h3>
                    Student: ${escapeHtml(alert.student_name)}
                </h3>

                <p class="risk-score">
                    ${severityPill}
                    ${statusPill}
                </p>

                <p>${escapeHtml(alert.reason)}</p>
            </div>

            <div class="risk-actions">
                <button
                    class="risk-review-btn"
                    type="button"
                    aria-label="Review alert for ${escapeHtml(alert.student_name)}"
                >
                    Review
                </button>
            </div>
        `;

        const reviewButton = item.querySelector(
            '.risk-review-btn'
        );

        reviewButton.addEventListener('click', event => {

            event.stopPropagation();

            selectAlert(alert);

        });

        // ALSO ALLOW CLICKING THE WHOLE CARD
        item.addEventListener('click', () => {
            selectAlert(alert);
        });

        list.appendChild(item);
    });

    // KEEP PREVIOUS SELECTION IF IT STILL EXISTS
    if (previousSelectedId !== '') {

        const updatedSelection = alerts.find(
            alert => String(alert.alert_id) === previousSelectedId
        );

        if (updatedSelection) {
            selectAlert(updatedSelection, false);
        } else {
            clearSelection();
        }
    }
}

// ===============================================
// SELECT ALERT
// ===============================================

function selectAlert(alert, scrollToNote = true) {

    selectedAlert = alert;

    document.getElementById('selectedAlertId').value =
        alert.alert_id;

    document.getElementById('selectedStudentLabel').textContent =
        `Selected: ${alert.student_name} — ${alert.reason}`;

    document.getElementById('actionNote').value =
        alert.note || '';

    const progressButton = document.getElementById(
        'markInProgressBtn'
    );

    const resolveButton = document.getElementById(
        'resolveBtn'
    );

    // ALREADY IN PROGRESS?
    progressButton.disabled =
        updateInProgress ||
        alert.status === 'in_progress';

    resolveButton.disabled = updateInProgress;

    // HIGHLIGHT SELECTED ALERT
    document.querySelectorAll('.risk-item').forEach(item => {

        const isSelected =
            String(item.dataset.alertId) ===
            String(alert.alert_id);

        item.classList.toggle(
            'selected-risk',
            isSelected
        );

    });

    setFeedback(
        'actionFeedback',
        `Reviewing alert for ${alert.student_name}.`,
        'info'
    );

    if (scrollToNote) {

        document.getElementById('actionNote').focus();

    }
}

// ===============================================
// CLEAR SELECTION
// ===============================================

function clearSelection() {

    selectedAlert = null;

    document.getElementById('selectedAlertId').value = '';

    document.getElementById('selectedStudentLabel').textContent =
        'Select an alert on the left to act on it.';

    document.getElementById('actionNote').value = '';

    document.getElementById('markInProgressBtn').disabled = true;

    document.getElementById('resolveBtn').disabled = true;

    document.querySelectorAll('.risk-item').forEach(item => {

        item.classList.remove('selected-risk');

    });
}

// ===============================================
// UPDATE ALERT STATUS
// ===============================================

async function updateSelectedAlert(status) {

    if (updateInProgress) {
        return;
    }

    if (!selectedAlert) {

        setFeedback(
            'actionFeedback',
            'Please select an alert using Review.',
            'error'
        );

        return;
    }

    const alertId = selectedAlert.alert_id;

    const note = document.getElementById('actionNote')
        .value.trim();

    // REQUIRE NOTE BEFORE RESOLVING
    if (status === 'resolved' && note === '') {

        setFeedback(
            'actionFeedback',
            'Please write a follow-up note before resolving the alert.',
            'error'
        );

        document.getElementById('actionNote').focus();

        return;
    }

    // CONFIRM RESOLUTION
    if (status === 'resolved') {

        const confirmed = confirm(
            'Resolve this alert and save the follow-up note?'
        );

        if (!confirmed) {
            return;
        }
    }

    const formData = new FormData();

    formData.append('alert_id', alertId);

    formData.append('status', status);

    formData.append('note', note);

    const progressButton = document.getElementById(
        'markInProgressBtn'
    );

    const resolveButton = document.getElementById(
        'resolveBtn'
    );

    updateInProgress = true;

    progressButton.disabled = true;
    resolveButton.disabled = true;

    setFeedback(
        'actionFeedback',
        'Saving the alert update...',
        'info'
    );

    try {

        const response = await fetch(
            'api/demoAPI.php?action=risk_alert_update',
            {
                method: 'POST',
                credentials: 'same-origin',
                body: formData
            }
        );

        if (!response.ok) {
            throw new Error(
                'Server returned HTTP ' + response.status
            );
        }

        const result = await response.json();

        if (!result.success) {

            setFeedback(
                'actionFeedback',
                result.message || 'Could not update the alert.',
                'error'
            );

            return;
        }

        clearSelection();

        await loadAlerts();

        setFeedback(
            'actionFeedback',
            status === 'resolved'
                ? 'Alert resolved and follow-up note saved successfully.'
                : 'Alert marked In Progress successfully.',
            'success'
        );

    } catch (error) {

        console.error('Failed to update risk alert:', error);

        setFeedback(
            'actionFeedback',
            'Unable to update the alert. Please try again.',
            'error'
        );

    } finally {

        updateInProgress = false;

        if (selectedAlert) {

            progressButton.disabled =
                selectedAlert.status === 'in_progress';

            resolveButton.disabled = false;

        } else {

            progressButton.disabled = true;
            resolveButton.disabled = true;

        }
    }
}

// ===============================================
// ESCAPE USER TEXT
// ===============================================

function escapeHtml(value) {

    const div = document.createElement('div');

    div.textContent =
        value == null ? '' : String(value);

    return div.innerHTML;
}
