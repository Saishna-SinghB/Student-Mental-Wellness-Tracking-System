// settings.js — loaded by settings.php
// Password recovery lives on forgot-password.php, not on Settings.

const switches = {
  dark_mode: document.getElementById('switchDarkMode'),
  booking_reminders: document.getElementById('switchBookingReminders'),
  weekly_mood_email: document.getElementById('switchWeeklyEmail')
};

let current = {
  dark_mode: false,
  booking_reminders: true,
  weekly_mood_email: true
};

function renderSwitches() {
  Object.entries(switches).forEach(([key, element]) => {
    if (!element) return;
    const enabled = Boolean(current[key]);
    element.classList.toggle('on', enabled);
    element.setAttribute('aria-checked', String(enabled));
  });
}

async function loadSettings() {
  try {
    const response = await fetch('api/demoAPI.php?action=settings_get', { cache: 'no-store' });
    const data = await response.json();

    if (!response.ok || !data.success) {
      throw new Error(data.message || 'Could not load your settings.');
    }

    current = { ...current, ...data.data };
    renderSwitches();
  } catch (error) {
    console.error('Failed to load settings:', error);
  }
}

async function saveSettings() {
  try {
    const response = await fetch('api/demoAPI.php?action=settings_update', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        dark_mode: current.dark_mode ? '1' : '0',
        booking_reminders: current.booking_reminders ? '1' : '0',
        weekly_mood_email: current.weekly_mood_email ? '1' : '0'
      })
    });
    const data = await response.json();
    if (!response.ok || !data.success) {
      alert(data.message || 'Could not save settings.');
    }
  } catch (error) {
    console.error('Failed to save settings:', error);
    alert('Could not reach the server.');
  }
}

document.addEventListener('DOMContentLoaded', () => {
  Object.entries(switches).forEach(([key, element]) => {
    if (!element) return;
    element.setAttribute('role', 'switch');
    element.setAttribute('tabindex', '0');

    const toggle = () => {
      current[key] = !current[key];
      renderSwitches();
      saveSettings();

      if (key === 'dark_mode' && window.WellnessHubTheme) {
        window.WellnessHubTheme.applyTheme(current.dark_mode);
        localStorage.setItem('wellnesshub_dark_mode', current.dark_mode ? '1' : '0');
      }
    };

    element.addEventListener('click', toggle);
    element.addEventListener('keydown', (event) => {
      if (event.key === 'Enter' || event.key === ' ') {
        event.preventDefault();
        toggle();
      }
    });
  });

  renderSwitches();
  loadSettings();
});
