
<?php
require_once __DIR__ . '/counsellor-auth.php';

$counsellorName = $_SESSION['full_name'] ?? 'Counsellor';

$counsellorInitial = strtoupper(
    substr(trim($counsellorName), 0, 1)
);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>
        Welcome, <?= htmlspecialchars($counsellorName) ?> — WellnessHub
    </title>

    <link rel="stylesheet" href="css/style.css">

    <style>
        /* CLICKABLE COUNSELLOR PROFILE */

        .counsellor-body .counsellor-profile-link {
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;

            text-decoration: none !important;
            cursor: pointer !important;

            position: relative;
            z-index: 20;

            pointer-events: auto !important;
            flex-shrink: 0;

            transition: transform 0.2s ease;
        }

        .counsellor-body .counsellor-profile-link:hover {
            transform: scale(1.08);
            box-shadow: 0 0 0 4px rgba(70, 140, 235, 0.25);
        }

        .counsellor-body .counsellor-profile-link:focus-visible {
            outline: 3px solid #75b5ff;
            outline-offset: 3px;
        }
    </style>

</head>

<body class="app-body dark-body counsellor-body">

<div class="app-shell dark-shell">

    <!-- COUNSELLOR SIDEBAR -->

    <aside class="sidebar counsellor-sidebar">

        <a class="brand-mini sidebar-brand"
           href="index.php">

            <span class="mini-leaf" aria-hidden="true">
                ☘
            </span>

            <span>WellnessHub</span>

        </a>

        <nav class="side-nav"
             aria-label="Counsellor navigation">

            <a class="active"
               href="counsellor-dashboard.php">
                <span>▣</span> Dashboard
            </a>

            <a href="counsellor-students.php">
                <span>👥</span> Students
            </a>

            <a href="risk-alerts.php">
                <span>⚠</span> Risk Alerts
            </a>

            <a href="counsellor-appointments.php">
                <span>📅</span> Appointments
            </a>

            <a href="counsellor-resources.php">
                <span>▤</span> Resources
            </a>

            <!-- MY PROFILE -->

            <a href="counsellor-profile.php">
                <span>👤</span> My Profile
            </a>

            <a href="logout.php">
                <span>↪</span> Logout
            </a>

        </nav>

    </aside>

    <!-- MAIN DASHBOARD -->

    <main class="dashboard-main dark-main">

        <!-- HEADER -->

        <header class="topbar dark-topbar">

            <div>

                <p class="eyebrow">
                    Counsellor Side
                </p>

                <h1>
                    Welcome,
                    <?= htmlspecialchars($counsellorName) ?>
                </h1>

                <p class="page-subtitle">
                    Here is today's counselling overview.
                </p>

            </div>

            <!-- TOP RIGHT BUTTONS -->

            <div class="topbar-actions">

                <!-- NOTIFICATION BELL -->

                <a class="icon-btn dark-icon"
                   href="risk-alerts.php"
                   aria-label="Alerts">
                    🔔
                </a>

                <!-- CLICKABLE D PROFILE -->

                <a
                    href="counsellor-profile.php"
                    class="avatar dark-avatar counsellor-profile-link"
                    title="Click to view My Profile"
                    aria-label="Open My Profile"
                >
                    <?= htmlspecialchars(
                        $counsellorInitial,
                        ENT_QUOTES,
                        'UTF-8'
                    ) ?>
                </a>

            </div>

        </header>

        <!-- DASHBOARD CONTENT -->

        <section class="page-grid">

            <!-- STATISTICS -->

            <div class="kpi-grid">

                <div class="kpi-card">

                    <span>
                        Students Checked In Today
                    </span>

                    <strong id="kpiCheckins">
                        —
                    </strong>

                    <small class="green">
                        Today
                    </small>

                </div>

                <div class="kpi-card">

                    <span>
                        High Risk Students
                    </span>

                    <strong class="red"
                            id="kpiHighRisk">
                        —
                    </strong>

                    <small class="red">
                        Needs attention
                    </small>

                </div>

                <div class="kpi-card">

                    <span>
                        Appointments Today
                    </span>

                    <strong id="kpiAppointments">
                        —
                    </strong>

                    <small class="green">
                        Scheduled
                    </small>

                </div>

                <div class="kpi-card">

                    <span>
                        Resolved Alerts
                    </span>

                    <strong id="kpiResolved">
                        —
                    </strong>

                    <small class="green">
                        Last 7 days
                    </small>

                </div>

            </div>

            <!-- GRAPHS -->

            <section class="two-col">

                <!-- EMOTIONAL INDEX -->

                <article class="panel">

                    <h2>
                        Emotional Index Trend
                    </h2>

                    <div style="position:relative;height:260px;">

                        <canvas id="emotionalIndexChart"></canvas>

                    </div>

                </article>

                <!-- MOOD DISTRIBUTION -->

                <article class="panel">

                    <h2>
                        Mood Distribution
                    </h2>

                    <div style="position:relative;height:260px;">

                        <canvas id="moodDistributionChart"></canvas>

                    </div>

                </article>

            </section>

        </section>

    </main>

</div>

<!-- EXISTING JAVASCRIPT FILES -->

<script src="js/vendor/chart.umd.min.js"></script>
<script src="js/counsellor-dashboard.js"></script>
<script src="js/counsellor-charts.js"></script>

</body>
</html>
